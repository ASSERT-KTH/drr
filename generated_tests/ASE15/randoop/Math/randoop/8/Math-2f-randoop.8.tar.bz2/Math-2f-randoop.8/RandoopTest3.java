
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(1.6894283186300372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9929714740858919d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     double var7 = var0.nextWeibull(0.5028092245014826d, 1.1858699313494176d);
//     double var9 = var0.nextChiSquare(1.0d);
//     int var12 = var0.nextInt(0, 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.03085260365036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1444339553161331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.3717188590854432d, (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.15595806f, (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.15595806f));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-83857780));

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.290429738684689d, 5.514627478466221d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.2241977397815322d));

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
//     int var10 = var4.nextInt((-6), 10);
//     var4.reSeed();
//     var4.reSeed(0L);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var4.nextInversionDeviate(var14);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.891704828860318d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8917048288603182d);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     long var17 = var7.nextLong((-414028722650554365L), 0L);
//     double var19 = var7.nextT(22411.793069624626d);
//     int var22 = var7.nextInt(0, 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-325020737002522830L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.1749082701326359d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 6);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.6566695863938614E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6566695863938614E-16d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1000678.2817635591d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1000678.0d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.638820928472139E-17d, (java.lang.Number)0.43511877764350804d, (java.lang.Number)1L);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }
// 
// 
//     org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var4 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var4);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Object[] var7 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, var7);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.23094703161653143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     double var11 = var0.nextChiSquare(0.761957659063951d);
//     double var13 = var0.nextExponential(1.378315632917706d);
//     double var16 = var0.nextBeta(130113.66062120028d, 10.0d);
//     double var18 = var0.nextExponential(0.9672751717291171d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.3786541106953036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.9808863958242393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9999132066391596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.37921947697992137d);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.23094703161653143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.4655668951150267d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    double var19 = var11.getNumericalMean();
    double var21 = var11.cumulativeProbability(8);
    var11.reseedRandomGenerator(2L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var25 = var11.sample((-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var7.nextPascal(208069560, 40.95048516891738d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
//     int var10 = var4.nextInt((-6), 10);
//     var4.reSeed();
//     long var14 = var4.nextLong((-9109855603261136600L), 32L);
//     var4.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var4.nextGaussian(0.44805272741785984d, (-0.4195903379527587d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 22.511131074500152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-8570877187541387169L));
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(6901081964622120046L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6901081964622120046L);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.07477341765096279d, 2.1263056137976035E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1263056137976035E30d);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     var7.reSeed(0L);
//     double var17 = var7.nextExponential(5.199206964447618d);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var21 = new org.apache.commons.math3.distribution.HypergeometricDistribution(3, 3, 1);
//     int var22 = var21.getPopulationSize();
//     int var23 = var21.getSampleSize();
//     int var24 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var21);
//     boolean var25 = var21.isSupportConnected();
//     double var27 = var21.probability(63);
//     double var28 = var21.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 46L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.529327541714445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(81L);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    var7.reSeedSecure();
    long var17 = var7.nextPoisson(0.15015415474359342d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var7.nextUniform(0.782013887229037d, 0.001767255981647298d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.58221626f, (-7.031049078224121d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5822162f);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.31834230895305893d, (java.lang.Number)16.51038740791099d, true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(3.093721944405666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0479073096496276d));

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     int var17 = var7.nextBinomial(8, 0.0d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var7.nextSample(var18, 428451470);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var3 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.7693376445680227d, (java.lang.Number)0.2712856473959901d, var3);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var20 = var7.nextUniform(0.9999993243506345d, 534.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 174.12613420688191d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(8.333159876951516d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     var7.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var21 = null;
//     double var22 = var7.nextInversionDeviate(var21);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var32 = new int[] { 10};
    var30.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var44 = new int[] { 10};
    var42.setSeed(var44);
    var35.setSeed(var44);
    var30.setSeed(var44);
    var1.setSeed(var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var50 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     var0.reSeedSecure((-6116618998156505929L));
//     double var12 = var0.nextUniform(0.3010299956639812d, 0.8450950061731151d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.7874758448128512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999985650344648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.4920289234641759d);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextWeibull(8.127037209198646d, 5.514627478466221d);
//     var7.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.012352116850586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12.805119350894921d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 5.0202168525138315d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(69340.50103785434d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 263.3258457460155d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.probability(10);
    double var19 = var11.cumulativeProbability(29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-4.925715506645026d), 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-119.51102587202425d));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.41163626780150286d, var1, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var18 = var7.nextUniform(0.3443874796808435d, 2.537297501373361d, true);
//     double var21 = var7.nextUniform((-1.4597135858742798E-16d), 20.66124363087071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.9307938203344215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 6.52484721237944d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-52624155), 93018071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 93018071);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c();
    var2.setSeed(72L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { 1, 0, 1};
    var6.setSeed(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var18 = new int[] { 1, 0, 1};
    var14.setSeed(var18);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var14);
    byte[] var22 = new byte[] { (byte)10};
    var14.nextBytes(var22);
    var6.nextBytes(var22);
    var2.nextBytes(var22);
    var1.nextBytes(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.15595806f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4901161E-8f);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.016113149763313152d), 2.209155774176144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     int var9 = var0.nextHypergeometric(428451470, 7, 2);
//     double var11 = var0.nextT(0.761957659063951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(85L, 60L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.19847748309768d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1183975475332371E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.1920624227533994d));
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(8.362584059135381d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.891813282204676d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(5, 6.283185307179586d);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var14 = new int[] { 1, 0, 1};
//     var10.setSeed(var14);
//     int var16 = var10.nextInt();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var10, 10, 4, 9);
//     int[] var22 = var20.sample(100);
//     int[] var24 = var20.sample(65);
//     double var26 = var20.cumulativeProbability((-1));
//     double var27 = var20.getNumericalMean();
//     int var28 = var20.getPopulationSize();
//     int var29 = var20.getPopulationSize();
//     int var30 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var20);
//     double var34 = var0.nextUniform(3.2104769607016383E-6d, 9.151022396274623d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.704587977123551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1607.347497256443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-810646614));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 3.6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0.8757239987314651d);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform(5.3360106650016d, 1079.5810741532396d, false);
//     double var9 = var0.nextCauchy(4.284201251169182d, 0.9415740839056164d);
//     double var13 = var0.nextUniform(0.3010299956639812d, 0.7634244805601391d, false);
//     int var17 = var0.nextHypergeometric(669834927, 42, 428451470);
//     double var19 = var0.nextExponential(3.461816101240877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 893.7473719523181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.891778974036182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.34396223844860535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.4323122374775432d);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.5557396120680712E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5557397E7d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)4.055908274771898d, (java.lang.Number)0.26460785404894344d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.26460785404894344d+ "'", var5.equals(0.26460785404894344d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 4.055908274771898d+ "'", var6.equals(4.055908274771898d));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.3443874796808435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3515862758644833d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var4);
    java.lang.String var6 = var2.toString();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = new java.lang.Object[] { 53L};
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var7, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var6.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    long var21 = var7.nextPoisson(1.2012365955976083d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var25 = var7.nextLong(0L, (-7529656944096573677L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0L);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextCauchy(26.468397517010732d, 0.7816736683885532d);
//     int var28 = var7.nextPascal(61, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var31 = var7.nextPascal((-93018071), 77.6875011190186d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.926203032350111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.163800848428086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 26.922194432534138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2147483647);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    double var16 = var7.nextChiSquare(93649.84672246638d);
    double var19 = var7.nextBeta(1.1815477295339092d, 2121.6118402321868d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 93452.71554851689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.3318443645018615E-4d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.5792308106225605d, (java.lang.Number)6.010917772984692E-4d, (java.lang.Number)2.634177959523138d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.6553631666580286d, 25088.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25088.000140524422d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)32.09529257088266d, (java.lang.Number)16.51038740791099d, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 32.09529257088266d+ "'", var4.equals(32.09529257088266d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(245.46665027666086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 245L);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1024.0001f, 2.167739475973386d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.2327048838369965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     double var11 = var0.nextChiSquare(0.761957659063951d);
//     double var13 = var0.nextExponential(1.378315632917706d);
//     double var16 = var0.nextBeta(130113.66062120028d, 10.0d);
//     int var19 = var0.nextInt((-83857780), (-6));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.3786541106953036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.9808863958242393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9999132066391596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-14738492));
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     int[] var3 = new int[] { 10};
//     var1.setSeed(var3);
//     float var5 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var9 = var6.nextWeibull(0.7610726839071428d, 0.9999993243506345d);
//     double var11 = var6.nextExponential(6.07662907668239d);
//     int var14 = var6.nextSecureInt(10, 208069560);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.76195765f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.290429738684689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.6664111005102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 102741415);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    int var42 = var36.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var46 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var36, 10, 4, 9);
    int[] var48 = var46.sample(100);
    int[] var50 = var46.sample(65);
    var34.setSeed(var50);
    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(var50);
    var52.setSeed(4768992702775877903L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     var0.reSeed(10L);
//     double var6 = var0.nextGamma(0.1096622711232151d, 25.21435585163038d);
//     long var9 = var0.nextSecureLong(27L, 39L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.010362048038259351d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 29L);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(65677.36502449299d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    double var20 = var11.cumulativeProbability(60481539);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.009470344f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0094703445f);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    double var20 = var11.upperCumulativeProbability(9);
    int[] var22 = var11.sample(42);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(6.3135427094879235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.030352739768491715d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    float var29 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.7463033f);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.4995328008980024d), var2, true);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     long var17 = var7.nextLong((-414028722650554365L), 0L);
//     double var19 = var7.nextT(22411.793069624626d);
//     double var22 = var7.nextGaussian(3.6d, 17050.433923472523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-266296365141499526L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.9381290171938528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1316.7672816417653d));
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(9.151280024146605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9L);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.0d, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)3.368048800002836d, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.58221626f, (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    double var19 = var11.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    double var6 = var0.nextGaussian(0.9035979175136787d, 0.7553717358309021d);
    double var8 = var0.nextExponential(6.061046620561879E28d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextGamma(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7106055568407954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.3133793396658025E28d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     double var14 = var7.nextUniform(0.27045149498596743d, 4.352694383675031d);
//     double var17 = var7.nextUniform(0.0d, 0.088080102426826d);
//     var7.reSeed((-7316180772744173669L));
//     long var22 = var7.nextSecureLong(60L, 82L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.4447996764224045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.05361446892311553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 79L);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(32768.0f, 65.58336876857805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32767.998f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.192093E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.192093E-7f);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-93018071));

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }
// 
// 
//     org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.2891073680063085d);
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var11 = new int[] { 1, 0, 1};
//     var7.setSeed(var11);
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
//     java.lang.Object[] var14 = new java.lang.Object[] { var7};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
//     org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var2, var14);
//     org.apache.commons.math3.exception.util.ExceptionContext var18 = var17.getContext();
//     var1.addSuppressed((java.lang.Throwable)var17);
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.exception.NotPositiveException var24 = new org.apache.commons.math3.exception.NotPositiveException(var22, (java.lang.Number)100.0d);
//     java.lang.Number var25 = var24.getMin();
//     java.lang.Throwable[] var26 = var24.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var27 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, (java.lang.Object[])var26);
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var17, var20, (java.lang.Object[])var26);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)25.68447716417873d, var6, false);
    var3.addSuppressed((java.lang.Throwable)var8);
    boolean var10 = var8.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextCauchy(26.468397517010732d, 0.7816736683885532d);
//     int var28 = var7.nextPascal(61, 0.0d);
//     double var31 = var7.nextF(0.3931421251672571d, 0.3253809740926889d);
//     double var33 = var7.nextT(1.097475105290114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.5138809545669742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7.02553275648749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 27.379779884916058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.3580208917888138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-5.846851061032542d));
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(8.088948341483892d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(31698.143427126535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     double var11 = var0.nextT(0.09942769605832733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.655423525961468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.51173029393967d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 20.9320646443596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.09580136809584583d));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    var7.reSeedSecure((-414028722650554365L));
    double var15 = var7.nextT(2.4039881628133278E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.7641100778210086d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(669834927, 669834927);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 669834927);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.31834230895305893d, (java.lang.Number)0.049816982749194494d);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var0.nextInt(10);
//     long var3 = var0.nextLong();
//     int var5 = var0.nextInt(7);
//     boolean var6 = var0.nextBoolean();
//     float var7 = var0.nextFloat();
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
//     double var10 = var9.nextDouble();
//     double var11 = var9.nextDouble();
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var17 = new int[] { 1, 0, 1};
//     var13.setSeed(var17);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var13);
//     var19.reSeedSecure((-1L));
//     int[] var24 = var19.nextPermutation(100, 8);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
//     var9.setSeed(var24);
//     int[] var28 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var28);
//     var29.clear();
//     int var31 = var29.nextInt();
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(0L);
//     boolean var34 = var33.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var40 = new int[] { 1, 0, 1};
//     var36.setSeed(var40);
//     org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var36);
//     org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var48 = new int[] { 1, 0, 1};
//     var44.setSeed(var48);
//     org.apache.commons.math3.random.RandomDataImpl var50 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var44);
//     byte[] var52 = new byte[] { (byte)10};
//     var44.nextBytes(var52);
//     var36.nextBytes(var52);
//     var33.nextBytes(var52);
//     var29.nextBytes(var52);
//     var9.nextBytes(var52);
//     var0.nextBytes(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3674297067110431083L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.19685662f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.954816313157598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(248.3433089416754d, 2.474110514047286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 248.3433089416754d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var31 = var28.getNumericalVariance();
    int var32 = var28.sample();
    double var33 = var28.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3.6d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(534.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5689236698079085d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var9 = var0.nextGamma(0.8899536081879631d, 0.8825395169829675d);
//     double var11 = var0.nextExponential(3.6d);
//     var0.reSeedSecure(11L);
//     var0.reSeedSecure(72L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.10870984647283992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7423099072146648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9038634767233538d);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9038634767233538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7857226331577654d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(86179.77788266764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86179.0d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(893.7473719523181d, 238925.01314861703d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0037406849601764993d);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     double var11 = var0.nextT(2.8894739470706012d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.035274697474353d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 208603.43987506148d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2.096590862145546d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0642526152601026d);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.7169636292746049d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(55L, 33L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 33L);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var18 = var7.nextInt((-6), 15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var7.nextGaussian(0.5792308106225605d, (-0.4910114401587537d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 11);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2058461.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.537469659977987d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    double var19 = var11.upperCumulativeProbability(16);
    int var21 = var11.inverseCumulativeProbability(0.7744227068102951d);
    int var22 = var11.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.1751388992973673d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-9109855603261136600L));
    double var2 = var1.nextDouble();
    long var3 = var1.nextLong();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 0, (-3), 39);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4473593886404428d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 7808248002097901876L);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial((-8406519), 0.7157990521557022d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.2568045532874783d);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     int[] var8 = var0.nextPermutation(61, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(82L, 23L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.923014591223555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14681.539064382763d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure(2876919108950029338L);
//     var0.reSeed();
//     long var10 = var0.nextPoisson(2.4339933340222135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.639609110913022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.11666087366993E32d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7L);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var11 = var0.nextGamma(4.850588148931125d, 0.47355289240887427d);
//     double var14 = var0.nextCauchy(2312.7809931100232d, 1.034362739798913E-15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.182164768243127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.5615880094462601E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.475416273899667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.5009913639196486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2312.7809931100232d);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.3474657337831263d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)3327.545661366997d, (java.lang.Number)2.2560527698684258E29d, (java.lang.Number)22026L);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 22026L+ "'", var4.equals(22026L));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    boolean var20 = var11.isSupportConnected();
    int var21 = var11.getSampleSize();
    double var23 = var11.probability(93018071);
    int var24 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 9);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    var4.reSeedSecure(46734L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    double var19 = var7.nextExponential(1.87731868091954d);
    java.lang.String var21 = var7.nextHexString(16);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var27 = new int[] { 1, 0, 1};
    var23.setSeed(var27);
    int var29 = var23.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var33 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var23, 10, 4, 9);
    int var34 = var33.getNumberOfSuccesses();
    double var36 = var33.probability(10);
    boolean var37 = var33.isSupportConnected();
    int var38 = var33.getNumberOfSuccesses();
    int var39 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.9964021940844213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "cf083761fba1d6ec"+ "'", var21.equals("cf083761fba1d6ec"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 3);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    var7.reSeed((-2757668752704241422L));
    double var21 = var7.nextF(5.726911865353372d, 0.19767649048318184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.1081817052208804d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1), (java.lang.Number)6.3135427094879235d, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(3, 3, 1);
    double var4 = var3.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-2.4426979143732317d), (java.lang.Number)1.0835445809218502d, (java.lang.Number)0.5363421394550557d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.5363421394550557d+ "'", var5.equals(0.5363421394550557d));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.335737920591789d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6950245289838621d));

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    int var42 = var36.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var46 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var36, 10, 4, 9);
    int[] var48 = var46.sample(100);
    int[] var50 = var46.sample(65);
    var34.setSeed(var50);
    long var52 = var34.nextLong();
    int var53 = var34.nextInt();
    float var54 = var34.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == (-2757668752704241422L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1620663137);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.51703656f);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     double var7 = var0.nextGamma(16822.424193698815d, 1.4549341288792002d);
//     double var10 = var0.nextF(0.6119740461869303d, 0.6151775063123803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 16.578663121778575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "4aaeb18085"+ "'", var4.equals("4aaeb18085"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24113.205682364227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9.474165888826526d);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.999999074752766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.293175786513731d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.673337917539172d, (-5.846851061032542d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1735131434933699d));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)50L);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    var0.reSeedSecure(68L);
    int var9 = var0.nextInt(16, 1620663137);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1596099342);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    double var9 = var0.nextChiSquare(2.3283064365386963E-10d);
    double var12 = var0.nextF(2.2327048838369965d, 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.8771624283741013E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.955436945151348d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.2130532941206642d));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    double var16 = var11.cumulativeProbability((-194062463));
    int var17 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     var0.reSeedSecure((-6116618998156505929L));
//     int var12 = var0.nextBinomial(3, 0.9964021940844213d);
//     int var15 = var0.nextBinomial(15, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5347434860560938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999996255809941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextZipf((-1), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.58646678812106d);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.setSeed(0);
//     int var6 = var2.nextInt(7);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var8 = var7.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var9 = var7.getRandomGenerator();
//     double var13 = var7.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var16 = var7.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var19 = var7.nextBinomial(13, 0.3010299956639812d);
//     int var22 = var7.nextZipf(10, 4.940878138553293d);
//     int[] var25 = var7.nextPermutation(14, 11);
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
//     var2.setSeed(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 29822.513914074792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 15.532636535265445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    double var16 = var7.nextChiSquare(22.73661948371242d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 26.109463425863378d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.3088437356800402E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(3.4447996764224045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9979654283545768d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var19 = new int[] { 10};
    var17.setSeed(var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var26 = new int[] { 1, 0, 1};
    var22.setSeed(var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var31 = new int[] { 10};
    var29.setSeed(var31);
    var22.setSeed(var31);
    var17.setSeed(var31);
    var13.setSeed(var31);
    var13.setSeed((-96398574));
    var13.setSeed(8);
    float var40 = var13.nextFloat();
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var46 = new int[] { 1, 0, 1};
    var42.setSeed(var46);
    org.apache.commons.math3.random.RandomDataImpl var48 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var42);
    byte[] var51 = new byte[] { (byte)(-1), (byte)10};
    var42.nextBytes(var51);
    var13.nextBytes(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.30913758f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)105.89977766676469d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2876919108950029338L);
    int var3 = var1.nextInt(93018071);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 81217892);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextF(25.21435585163038d, 2058461.3166939607d);
    var7.reSeed(72L);
    double var19 = var7.nextBeta(4.284201251169182d, 3.2804921616048866E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.2012365955976083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.1015427018731914E-9d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.7693376445680227d, (java.lang.Number)0.2712856473959901d, var3);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.2712856473959901d+ "'", var5.equals(0.2712856473959901d));

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
//     var7.reSeed();
//     int var17 = var7.nextSecureInt(7, 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.4597135858742798E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 13);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.33115294219320335d, (java.lang.Number)12.332151351658016d, false);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.15595806f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextWeibull(8.127037209198646d, 5.514627478466221d);
//     double var27 = var7.nextT(1.0054434642069592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.0234166339678925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 106.65799450181888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 6.564834221647105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2.7713772066652633d);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(5.518046566573254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3490522698682663d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var7.nextPascal(81217892, 3.846776373613042E8d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    var7.reSeed((-2757668752704241422L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextPascal(31, 2.1751388992973673d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)6.463308536397313d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(54L, 53L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 54L);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(54L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 54L);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    int var11 = var1.nextInt();
    double var12 = var1.nextGaussian();
    long var14 = var1.nextLong(254L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.1719246526310684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 221L);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.06360859642650762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-6));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.05651210978738594d, 6.929625337259191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05651210978738594d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(40.95048516891738d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0446666099261446E17d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    java.lang.String var17 = var7.nextHexString(65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextHypergeometric((-52624155), 24, (-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "d5572a37f358531b88626f43818ba7d3cf083761fba1d6ec0cd2f7ed3220ebd6c"+ "'", var17.equals("d5572a37f358531b88626f43818ba7d3cf083761fba1d6ec0cd2f7ed3220ebd6c"));

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextBeta(7.552633489589084d, 0.9995149440000322d);
    double var17 = var7.nextGaussian(0.03490658503988659d, 0.9415740839056164d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var7.nextT((-2.2241977397815322d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.9672751717291171d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.060403506527442d));

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     var7.reSeedSecure();
//     double var19 = var7.nextT(1.378315632917706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.0594978456299025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.10748060684316456d);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.07718251686616505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0013470890442906357d));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.0104501637590833d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7468372633269955d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5.786435608620413d, (java.lang.Number)1.6894283186300372d, false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)1.908642352606886d, true);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    var4.addSuppressed((java.lang.Throwable)var5);
    java.lang.Throwable[] var9 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.8233259972087809d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.027158344429828d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.30688767342229006d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.8825395169829676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.015403220350313197d);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     double var13 = var0.nextUniform(0.46647993410200317d, 26.0d, false);
//     double var15 = var0.nextT(14.922606072771678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24.846301425358277d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.057395037460252346d));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var14 = new int[] { 1, 0, 1};
    var10.setSeed(var14);
    org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var10);
    java.lang.Object[] var17 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)10, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)1041.37115449346d, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2.1789698445394334d, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1316.7672816417653d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var1 = var0.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 754117498);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-194062463));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 194062463);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportUpperBound();
    int var17 = var11.getPopulationSize();
    double var19 = var11.upperCumulativeProbability((-93018071));
    double var21 = var11.probability(25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(4.056126661996904d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.056126661996904d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024.0001f);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.055742016949076274d, (java.lang.Number)406.4705924790716d, (java.lang.Number)0.9969705520480721d);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     double var11 = var7.nextExponential(0.15015415474359342d);
//     var7.reSeed();
//     double var14 = var7.nextExponential(1.5318819596985707d);
//     double var16 = var7.nextExponential(1.2048984641481295E15d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.09347294900676971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.3120683577879568d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0063889788803556E15d);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(32767.998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.001953125f);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    var11.reSeedSecure((-1L));
    int[] var16 = var11.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    var1.setSeed(var16);
    int[] var20 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
    var21.clear();
    int var23 = var21.nextInt();
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var26 = var25.nextBoolean();
    org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var32 = new int[] { 1, 0, 1};
    var28.setSeed(var32);
    org.apache.commons.math3.random.RandomDataImpl var34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var28);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var36);
    byte[] var44 = new byte[] { (byte)10};
    var36.nextBytes(var44);
    var28.nextBytes(var44);
    var25.nextBytes(var44);
    var21.nextBytes(var44);
    var1.nextBytes(var44);
    double var50 = var1.nextDouble();
    int var51 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.33354954032831396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1110367640);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    double var19 = var11.upperCumulativeProbability(16);
    int var20 = var11.getSampleSize();
    int var21 = var11.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform(7.347148652666165d, 6.283185307179586d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.641131857214605d);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-118603794), (-52624155));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-52624155));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    var11.reseedRandomGenerator(55L);
    int var23 = var11.sample();
    int var24 = var11.getSupportUpperBound();
    double var26 = var11.upperCumulativeProbability(100);
    int var27 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 9);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextF(2.409530291336139d, (-0.658113963207486d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3370962126946149d);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var4 = var0.nextChiSquare(5.726911865353372d);
//     double var6 = var0.nextExponential(6.283185307179586d);
//     var0.reSeedSecure((-432485425446058487L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma((-7.031049078224121d), 12.75082779586157d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.753597377695851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.577699900525733d);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    var2.clear();
    float var5 = var2.nextFloat();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9775554f);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    int var10 = var4.nextInt((-6), 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.nextSecureInt(81217892, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)7.570160841992396d, (java.lang.Number)3.012352116850586d, (java.lang.Number)1.684009276724495d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1), (java.lang.Number)6.3135427094879235d, false);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)0.9415740839056164d, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     var0.reSeed();
//     double var11 = var0.nextCauchy(4.955436945151348d, 2.0453921118134297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 26L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.0816766204009296d);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-2757668752704241422L));
    double var7 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.3839448921259779d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.02069733480244646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0002141974802856d);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     java.lang.String var13 = var7.nextSecureHexString(15);
//     double var16 = var7.nextGamma(0.9999999979227431d, 6.449365385301751E29d);
//     double var19 = var7.nextGaussian(9.0d, 1.1067567812930754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "3ef6c835c04e6b8"+ "'", var13.equals("3ef6c835c04e6b8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.369934664123801E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 8.272421903492118d);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     int[] var6 = var0.nextPermutation(42, 3);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(2.0785650438157504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.85496493411544d));
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextPascal(10, 0.9572134964551632d);
    double var17 = var7.nextGaussian(2.537297501373361d, 0.9672751717291171d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("", "b23");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.4120899632444508d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     long var7 = var0.nextSecureLong(10L, 93L);
//     java.lang.String var9 = var0.nextSecureHexString(4);
//     org.apache.commons.math3.random.RandomGenerator var10 = var0.getRandomGenerator();
//     int var13 = var0.nextZipf(69, 1.041888119963332d);
//     var0.reSeed(67L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0371400493024525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 67L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "13d3"+ "'", var9.equals("13d3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
//     boolean var13 = var10.getBoundIsAllowed();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var18 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var14, (java.lang.Number)(-1L), (java.lang.Number)6.283185307179586d, false);
//     var10.addSuppressed((java.lang.Throwable)var18);
//     org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var18);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.474110514047286d, (java.lang.Number)1.794E-43f, true);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(11866.960945221417d, 0.6988646946736641d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 703.7396810014848d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.6217577265485514d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5562643946486053d));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(30.337005276849467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47227949375488115d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.15595806f), 19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-81766.94f));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)(-1));
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(20.34275247523163d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.729836093118467d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    double var19 = var11.getNumericalMean();
    double var21 = var11.cumulativeProbability(8);
    int var22 = var11.getSupportUpperBound();
    int var23 = var11.getSampleSize();
    int var24 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 9);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.1318738927017994d), 0.5792308106225605d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.1318738927017994d));

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var8 = new int[] { 1, 0, 1};
    var4.setSeed(var8);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    byte[] var20 = new byte[] { (byte)10};
    var12.nextBytes(var20);
    var4.nextBytes(var20);
    var1.nextBytes(var20);
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var29 = new int[] { 1, 0, 1};
    var25.setSeed(var29);
    org.apache.commons.math3.random.RandomDataImpl var31 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var25);
    byte[] var33 = new byte[] { (byte)10};
    var25.nextBytes(var33);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var36);
    int var45 = var42.nextZipf(10, 3.141592653589793d);
    double var48 = var42.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var51 = var42.nextPermutation(100, 100);
    var25.setSeed(var51);
    org.apache.commons.math3.random.Well19937c var54 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var56 = new int[] { 10};
    var54.setSeed(var56);
    org.apache.commons.math3.random.Well19937c var59 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var63 = new int[] { 1, 0, 1};
    var59.setSeed(var63);
    org.apache.commons.math3.random.Well19937c var66 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var68 = new int[] { 10};
    var66.setSeed(var68);
    var59.setSeed(var68);
    var54.setSeed(var68);
    var25.setSeed(var68);
    var1.setSeed(var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var77 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-23), 754117498, 60481539);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextExponential(8.97308641465062d);
    double var9 = var0.nextCauchy((-0.4195903379527587d), 96.06190599231006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.16607997176057543d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 154.09188493897506d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.9228868551870015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.973605054999637d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    var11.reseedRandomGenerator(55L);
    int var23 = var11.sample();
    int var24 = var11.getSupportUpperBound();
    double var26 = var11.upperCumulativeProbability(100);
    double var28 = var11.upperCumulativeProbability(24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     long var12 = var0.nextLong(7L, 34915L);
//     double var15 = var0.nextF(1103.1901787829615d, 32.09529257088266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6763059781217748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.547243241282439d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.9605913629917932d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20865L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.7481315247620552d);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     double var8 = var0.nextUniform((-0.016245086893048467d), 4.641588833612778d);
//     var0.reSeed();
//     double var11 = var0.nextT(65677.36502449299d);
//     double var14 = var0.nextGaussian(2.0453921118134297d, 1.041888119963332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.47737025416549606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.324274688207468d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8573586899453746d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.394261854664726d);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.0563366458702615E9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963258482287d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextPascal(11, 245.46665027666086d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.4154758067826922d, (java.lang.Number)9.151022396274623d, (java.lang.Number)0.7853981623588199d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(32767.998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32768);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.4774960009367326d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(6.598197098603711d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 378.04884614545773d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.1559581f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1559581f);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     long var17 = var7.nextLong((-414028722650554365L), 0L);
//     double var19 = var7.nextT(22411.793069624626d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var7.nextInt(83, (-8406519));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-355602506400149343L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.634411161133085d);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)6.770734296545935d, (java.lang.Number)0.10829202723336492d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 6.770734296545935d+ "'", var5.equals(6.770734296545935d));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.7257969399088773d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0027608403710084d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    double var14 = var11.upperCumulativeProbability((-118603794));
    double var15 = var11.getNumericalVariance();
    int var16 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 9);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 3);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     int var17 = var7.nextBinomial(8, 0.0d);
//     double var20 = var7.nextGamma(22.140692632779267d, 9.754247826527576d);
//     long var23 = var7.nextSecureLong(74L, 46637L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 214.92722629758254d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 6996L);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)40.95048516891738d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.020085817952422695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.020087168550343037d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var6 = var0.nextPoisson(0.4323122374775432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03901918346093155d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var5 = var4.getArgument();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    var4.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    java.lang.Number var13 = var10.getMax();
    java.lang.Number var14 = var10.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 3.141592653589793d+ "'", var13.equals(3.141592653589793d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 3.141592653589793d+ "'", var14.equals(3.141592653589793d));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    int var11 = var1.nextInt();
    double var12 = var1.nextGaussian();
    long var14 = var1.nextLong(46734L);
    var1.setSeed((-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.1719246526310684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 34915L);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     org.apache.commons.math3.random.RandomGenerator var16 = var0.getRandomGenerator();
//     double var19 = var0.nextWeibull(0.7630515037413252d, 1353831.6439071347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18837.95215007209d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.9852953267583202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4.114423181425841E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 6531939.008693985d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.9371038524921493d, 12.805119350894921d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9371038524921493d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    var11.reseedRandomGenerator(55L);
    int var23 = var11.sample();
    int var24 = var11.sample();
    int var25 = var11.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var27 = var11.inverseCumulativeProbability(6.41679394022645d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
//     var7.reSeed();
//     double var17 = var7.nextBeta(2.726066212978514E-4d, 1.378315632917706d);
//     long var19 = var7.nextPoisson(1.2012365955976083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.9995149440000322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    double var20 = var7.nextCauchy(43.19990300454566d, 2.7756045370371223E10d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var24 = var7.nextHypergeometric((-14738492), (-52624155), 62);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3.0576568553121532E10d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)74L, (java.lang.Number)(-4.925715506645026d), false);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var0.nextInt(10);
//     long var3 = var0.nextLong();
//     int var5 = var0.nextInt(7);
//     boolean var6 = var0.nextBoolean();
//     double var7 = var0.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4186507875570185101L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.8729151995897483d);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9999999f, (java.lang.Number)1.1376946885222738d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var11 = var0.nextGamma(4.850588148931125d, 0.47355289240887427d);
//     var0.reSeedSecure();
//     long var14 = var0.nextPoisson(4.641588833612778d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 11.92471477920658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3105436617034528E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.256656943706002d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.48439927478303296d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3L);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-1.4597135858742798E-16d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    int var3 = var1.nextInt();
    long var4 = var1.nextLong();
    double var5 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-194062463));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1930906741579263412L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.18740706185553035d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)10.0f, (java.lang.Number)3.141592653589793d);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var8 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var4, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var9 = var8.getArgument();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var10, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    var8.addSuppressed((java.lang.Throwable)var14);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var14.getContext();
    var3.addSuppressed((java.lang.Throwable)var14);
    java.lang.Number var18 = var3.getLo();
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var21 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var19, (java.lang.Number)5.770988097403407d);
    var3.addSuppressed((java.lang.Throwable)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)(-1)+ "'", var9.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 10.0f+ "'", var18.equals(10.0f));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     int var14 = var7.nextZipf(9, 93649.84672246638d);
//     double var16 = var7.nextChiSquare(93649.84672246638d);
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var7.nextInversionDeviate(var17);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    boolean var35 = var34.nextBoolean();
    double var36 = var34.nextDouble();
    long var38 = var34.nextLong(7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.6287849591819767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 5L);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.016113847097290086d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0001298308433815d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(26.94414842759192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.94414842759192d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     double var11 = var0.nextExponential(1.2905389698182939d);
//     var0.reSeed(25L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextZipf(0, 0.11301524106650007d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.10012549355428124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999998783129218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7655795326474033d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.826218382711509d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0094703445f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError();
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var14 = new int[] { 1, 0, 1};
//     var10.setSeed(var14);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var10);
//     java.lang.Object[] var17 = new java.lang.Object[] { var10};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var17);
//     org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)10, var17);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var4, var17);
//     org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)5.93502618160048d, var17);
//     org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var22);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     double var22 = var7.nextCauchy(2.93710385249215d, 0.33115294219320335d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.setSecureAlgorithm("774e5780dc", "org.apache.commons.math3.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (6.314)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.936894927751442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 81.16738986058718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.1596445552536645d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     int var5 = var0.nextInt(4, 65);
//     var0.reSeed(74L);
//     long var9 = var0.nextPoisson(0.7104343504355127d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextPoisson((-0.7891391771877577d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8252415710904637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2L);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(30);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.31834230895305893d, (java.lang.Number)0.049816982749194494d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.049816982749194494d+ "'", var5.equals(0.049816982749194494d));

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(4.970591925624977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6035389327400638d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(4.60890860857409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.608908608574091d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(5.761705377322171d, 0.9265429545997971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.04356636163181944d));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.4901161E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-1.247925452902965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    double var12 = var7.nextWeibull(0.001129876315267469d, 0.9964021940844213d);
    var7.reSeedSecure((-6878022790933652708L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.2190167037857677E196d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.6293945E-6f, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25f);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var9 = var0.nextGamma(0.8899536081879631d, 0.8825395169829675d);
//     double var11 = var0.nextExponential(3.6d);
//     var0.reSeedSecure(11L);
//     var0.reSeed(52L);
//     long var17 = var0.nextPoisson(0.47355289240887427d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02739700457530148d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3404636771486922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2015780163258867d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0L);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     long var6 = var0.nextPoisson(0.9999993243506345d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextSecureLong(22026L, 49L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9046672613448736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7163dfec47"+ "'", var4.equals("7163dfec47"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure(2876919108950029338L);
//     var0.reSeed();
//     var0.reSeed(6996L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.47840486141952876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1020140872303544E32d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var31 = var28.getNumericalVariance();
    int var32 = var28.getSupportUpperBound();
    boolean var33 = var28.isSupportConnected();
    int var34 = var28.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 4);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(4, 1, 1);
//     int var8 = var0.nextZipf(4, 8.97308641465062d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial((-118603794), 15.261044137712046d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var16 = var7.nextPermutation(100, 100);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    var17.setSeed(5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.1920929E-7f), (-14738492));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.1070184668034227d), 3.882579444988825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1070184668034227d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    org.apache.commons.math3.random.RandomGenerator var4 = var0.getRandomGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "f7ed2672e7e57dd93e3456e01a24138c3146005645");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    double var11 = var7.nextExponential(0.15015415474359342d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var7.nextSecureHexString((-358148614));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.09347294900676971d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.9999992310258898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403029529373817d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    long var21 = var7.nextLong(0L, 91L);
    double var23 = var7.nextExponential(1.181547729533909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 72L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.172574142517163d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var11 = var0.nextGamma(4.850588148931125d, 0.47355289240887427d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.734498463070194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9670826.136169078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.42465750972951205d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0217116607389125d);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    double var14 = var11.probability((-118603794));
    double var15 = var11.getNumericalVariance();
    double var17 = var11.probability((-6));
    int var18 = var11.getSupportLowerBound();
    double var20 = var11.cumulativeProbability(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.016245086893048467d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var5.nextT((-0.12660232803252297d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    boolean var4 = var2.nextBoolean();
    boolean var5 = var2.nextBoolean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextInt((-14738492));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var16 = var7.nextPermutation(100, 100);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int[] var30 = var28.sample(100);
    int[] var32 = var28.sample(65);
    boolean var33 = var28.isSupportConnected();
    double var35 = var28.upperCumulativeProbability(10);
    double var36 = var28.getNumericalVariance();
    double var38 = var28.upperCumulativeProbability(61);
    int var39 = var28.getPopulationSize();
    double var40 = var28.getNumericalVariance();
    double var43 = var28.cumulativeProbability(0, 69);
    int var44 = var28.sample();
    int var45 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    var7.reSeedSecure(56L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 4);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(208069560, 0, 0);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy((-0.6321205588285576d), 1.2895855093964026d);
//     int var6 = var0.nextZipf(61, 6.60674839016517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.7421198667844211d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     double var11 = var7.nextExponential(0.15015415474359342d);
//     var7.reSeed();
//     double var14 = var7.nextExponential(1.5318819596985707d);
//     var7.reSeedSecure(33L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.09347294900676971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.1619301933384962d);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.4339933340222135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.404332579379748d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.7693376445680227d);
    java.lang.Number var2 = var1.getMin();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var5 = var0.nextExponential(8.365175298942184d);
//     var0.reSeedSecure(16L);
//     var0.reSeedSecure(7808248002097901876L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4.432714979377472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.762501953246898d);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(0, 0.5918164732033864d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.454996948963613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0362377132229443E32d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    double var19 = var11.getNumericalVariance();
    double var21 = var11.upperCumulativeProbability(61);
    int var22 = var11.getPopulationSize();
    double var24 = var11.cumulativeProbability(69);
    double var27 = var11.cumulativeProbability(2, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.4d);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     double var11 = var0.nextChiSquare(40.95048516891738d);
//     int var14 = var0.nextPascal(83, 0.5826716629917943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 69160.39356535062d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.41267485606645343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 34.4090594746943d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 42);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    int var19 = var7.nextZipf(8, 0.5826716629917943d);
    var7.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    float var5 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.76195765f);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var9 = var0.nextGamma(0.8899536081879631d, 0.8825395169829675d);
//     double var11 = var0.nextExponential(3.6d);
//     var0.reSeedSecure(11L);
//     var0.reSeed(52L);
//     double var18 = var0.nextGaussian(0.999999998129049d, 48.108264995729755d);
//     double var21 = var0.nextGamma(1.115901134774571d, 3.5619036968121845E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.07824775613857425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3484422066393789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.47422864360125344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 40.16466172583783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.393462852256127E9d);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(194062463, (-358148614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 194062463);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var10 = new byte[] { (byte)(-1), (byte)10};
    var1.nextBytes(var10);
    var1.clear();
    double var13 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.09975663986204619d);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var9 = var0.nextGamma(0.8899536081879631d, 0.8825395169829675d);
//     double var11 = var0.nextExponential(3.6d);
//     var0.reSeedSecure(11L);
//     double var15 = var0.nextExponential(2.220446049250313E-16d);
//     int var18 = var0.nextInt(100, 1620663137);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0015695980716027916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.11592447105026873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.102832513297189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.0779670322014278E-17d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 888146883);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(85L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     double var12 = var0.nextF(0.39371623903891373d, 3.2541630921465963d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGamma((-0.8573586899453746d), 5.761705377322171d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 81693.9048312358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.229702242822698d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.2461438582828743d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f"+ "'", var14.equals("1d0525e8aae8febb0157ee74f"));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0997566f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.4505806E-9f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.upperCumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-6116618998156505929L));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var19 = var7.nextGaussian(14.94806722174175d, 38.42983716254903d);
    double var21 = var7.nextT(0.9415740839056164d);
    double var23 = var7.nextT(0.5363421394550557d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var7.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-7.879966881943199d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.5693573844758614d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.22360516167138558d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     double var21 = var7.nextExponential(174.12613420688191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.901490397266907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 17.965104133067634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 155.09509239201503d);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var7.nextInt(57, (-810646614));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(25088.000140524422d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    double var16 = var7.nextChiSquare(93649.84672246638d);
    double var18 = var7.nextT(27.913274388776458d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 93452.71554851689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.1955506016835279d));

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.001767255981647298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    double var19 = var11.getNumericalVariance();
    double var21 = var11.upperCumulativeProbability(61);
    int var22 = var11.getPopulationSize();
    double var23 = var11.getNumericalVariance();
    int var24 = var11.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.846776373613042E8d, (java.lang.Number)7808248002097901876L, false);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(short)1, (java.lang.Number)10.0f, (java.lang.Number)(-0.6321205588285576d));
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0f+ "'", var5.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0f+ "'", var7.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-0.6321205588285576d)+ "'", var8.equals((-0.6321205588285576d)));

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.03085260365036d, 0.9999996064388104d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.030853784333928713d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    java.lang.Object[] var19 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)10, var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)5.93502618160048d, var19);
    org.apache.commons.math3.exception.MathInternalError var25 = new org.apache.commons.math3.exception.MathInternalError(var1, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var26 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.1318738927017994d), var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)61, (java.lang.Number)2, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 61 is larger than, or equal to, the maximum (2)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 61 is larger than, or equal to, the maximum (2)"));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-1.0f), 1024.0001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var19 = var7.nextGaussian(14.94806722174175d, 38.42983716254903d);
    int var23 = var7.nextHypergeometric(42, 6, 6);
    var7.reSeed(5L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var27 = var7.nextHexString((-1120319269));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-7.879966881943199d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getNumberOfSuccesses();
    int var14 = var11.getPopulationSize();
    double var16 = var11.probability((-1549560137));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.09975663986204619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.001741081816318928d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     int[] var6 = var0.nextPermutation(42, 3);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGamma((-0.20264446420595678d), 1.0501125473562256d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextCauchy(26.468397517010732d, 0.7816736683885532d);
//     int var28 = var7.nextPascal(61, 0.0d);
//     org.apache.commons.math3.distribution.RealDistribution var29 = null;
//     double var30 = var7.nextInversionDeviate(var29);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian((-0.20264446420595678d), 2.497498709678805d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var7.nextGamma(10.201158186626492d, (-0.7088530508724903d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.8444915149156582d));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.19685662f, 32768.004f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19685662f);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    double var17 = var11.probability(8);
    int var18 = var11.getSupportUpperBound();
    int var19 = var11.getNumberOfSuccesses();
    int var20 = var11.getSupportLowerBound();
    int var21 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(18837.95215007209d, 1090.7151534294098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18837.95215007209d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.15595807f, (-0.15595806f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.15595806f));

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(42.91946710884891d, 3.093721944405666d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.30041955087089284d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1.9630576730222766d, (java.lang.Number)3.6876927921820193d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.9630576730222766d+ "'", var5.equals(1.9630576730222766d));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var8 = new int[] { 1, 0, 1};
    var4.setSeed(var8);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    java.lang.Object[] var11 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.3443874796808435d, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     var0.reSeedSecure((-6116618998156505929L));
//     int var12 = var0.nextBinomial(3, 0.9964021940844213d);
//     int var15 = var0.nextBinomial(15, 0.0d);
//     double var18 = var0.nextWeibull(3.1619301933384962d, 2.1680043056814067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.154875329285909d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999993021989222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.8055997598417877d);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     int var25 = var7.nextZipf(2, 0.3961916630178961d);
//     var7.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var29 = var7.nextPermutation((-6), 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.554837769710508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 39.678804848095744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.5693573844758614d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5315170012933516d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8100386108167767d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(4, 1, 1);
//     var0.reSeed();
//     int var9 = var0.nextInt((-6), 60481539);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 47291613);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(8.127037209198646d, 7.658254451575135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.658254451575135d);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
//     org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var13 = new int[] { 1, 0, 1};
//     var9.setSeed(var13);
//     org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
//     java.lang.Object[] var16 = new java.lang.Object[] { var9};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, var16);
//     org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var0, var16);
//     java.lang.Throwable var22 = null;
//     var21.addSuppressed(var22);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(7.347148652666165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7L);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    long var21 = var7.nextLong(0L, 91L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var7.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 72L);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     java.lang.String var13 = var7.nextSecureHexString(15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var7.nextPascal((-83857780), 0.0371400493024525d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b1a3cfdf5ce22ad"+ "'", var13.equals("b1a3cfdf5ce22ad"));
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var22 = var7.nextLong(39L, (-432485425446058487L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var5 = var0.nextExponential(8.365175298942184d);
//     var0.reSeedSecure(16L);
//     double var10 = var0.nextBeta(0.6466904717391735d, 9.6981839791934d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("774e5780dc", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.29804431858587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 27.190784089769803d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.022410211031257267d);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var31 = var28.getNumericalVariance();
    int var32 = var28.getSampleSize();
    int var33 = var28.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 4);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextGamma(1.1815477295339092d, 0.46647993410200317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.07679212007749366d);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException(var5, (java.lang.Number)100.0d);
    java.lang.Number var8 = var7.getMin();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(-52624155), (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    var0.reSeed(4480904336415030557L);
    double var9 = var0.nextBeta(44.83548874338596d, 8.768916560445668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8280662994811954d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    long var21 = var7.nextPoisson(1.2012365955976083d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var24 = var7.nextPermutation((-7), 32768);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0L);

  }

}
