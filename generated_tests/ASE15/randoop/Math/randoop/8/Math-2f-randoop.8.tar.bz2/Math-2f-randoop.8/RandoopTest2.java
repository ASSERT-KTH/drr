
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.15595806f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.15595806f);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(3, 3, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var3.inverseCumulativeProbability(12.099262142751375d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    var4.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextPascal(7, (-7.879966881943199d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.07800136192161476d);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.07827191997339972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27977119217925156d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.7281779665864416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(12.236902640271552d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.0d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.1752005863472421d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(49.0d, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25088.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(254L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(65.18510402677708d, 3.9209536856213183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 65.18510402677707d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.upperCumulativeProbability((-10));
    int var18 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    double var10 = var4.nextGamma(2.7693376445680227d, 38.42983716254903d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var13 = var4.nextSecureLong(2876919108950029338L, 32L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 103.86450481904308d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    double var22 = var11.upperCumulativeProbability((-93018071));
    int var23 = var11.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(69, (-8406519), 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7088983115648917d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.1867080271667598E12d);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     double var17 = var0.nextChiSquare(12.140465251696156d);
//     var0.reSeedSecure();
//     double var20 = var0.nextChiSquare(22025.465794806718d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextBinomial((-2), 6.60674839016517d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.145049729787575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46502L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7443715074170005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.922070446561813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 22025.530556379832d);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(61, 61, (-96398574));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.5890264028647865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1875.7963509951387d);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextExponential(8.97308641465062d);
    double var8 = var0.nextT(16822.424193698815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.16607997176057543d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9266747739199285d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.9999997600389442d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.967968127418054d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextPascal((-127), 0.17453292519943295d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9999999f), 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.2281699380152802d, (java.lang.Number)3.407736098774514d, false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    double var9 = var0.nextChiSquare(2.3283064365386963E-10d);
    var0.reSeedSecure(74L);
    double var13 = var0.nextExponential(0.05651210978738594d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var0.nextT((-7.879966881943199d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.8771624283741013E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.06354856064671875d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.1923162405546828d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7991105662085616d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(6.929625337259191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var7.nextInversionDeviate(var14);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     double var12 = var0.nextGaussian(0.0d, 6.7727635120911645d);
//     var0.reSeedSecure(1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8456361335633256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.344080097374083E11d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.5393018773037259d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5.1994693663327345d);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure(2876919108950029338L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.184936171549692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.6160068928088E31d);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var16 = var7.nextPermutation(100, 100);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    var17.setSeed((-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var10 = var0.nextT(99.99999999999999d);
//     var0.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextWeibull(0.341345202615279d, (-0.7891391771877577d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1663927930262965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7.470745182252033E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.47624635138434557d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.34381094110475147d);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(7.379921727179645d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.696469177659388d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(37004.49588976037d, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2312.7809931100232d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    boolean var2 = var1.nextBoolean();
    long var3 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-3396324968578305623L));

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.30913758f, (-1.1920929E-7f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1920929E-7f));

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.3931421251672571d, 238925.01314861703d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-13.26490580831474d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.635938953296214d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.08426832637046788d, (java.lang.Number)6.913801585216292d, true);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.731175276583916E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.731175276583916E30d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    int var17 = var11.getSupportLowerBound();
    int var18 = var11.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.9956059622125122d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9956059622125122d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var5 = var4.getArgument();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    var4.addSuppressed((java.lang.Throwable)var10);
    java.lang.Number var12 = var10.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 3.141592653589793d+ "'", var12.equals(3.141592653589793d));

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     java.lang.String var15 = var7.nextHexString(30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "dfffd22d60187e9c8747461eda93f6"+ "'", var15.equals("dfffd22d60187e9c8747461eda93f6"));
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.1336149855922958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0023320214285903473d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)26.468397517010732d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00390625f);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(5, 6.283185307179586d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(44.83548874338596d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8477383107815817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1543.0314471285765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)4.055908274771898d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.4574326092991893d, 0.7504405634174012d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5560267600126776d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-2));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)4.460135315166678d, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     java.lang.String var13 = var7.nextSecureHexString(15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var7.nextInt(0, (-10));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "112532aa5430b80"+ "'", var13.equals("112532aa5430b80"));
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(4.60890860857409d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.209155774176144d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextF(25.21435585163038d, 2058461.3166939607d);
    double var17 = var7.nextUniform(0.0d, 0.9987594964776787d);
    double var20 = var7.nextF(0.40877566087838346d, 0.09347294900676971d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var7.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.2012365955976083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.60794615935029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 16.51038740791099d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian((-0.20264446420595678d), 2.497498709678805d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var16 = var7.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.8444915149156582d));

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    int var16 = var13.nextInt();
    long var17 = var13.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1120319269));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4768992702775877903L);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var4 = var0.nextExponential(2.2891073680063085d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(6, (-0.7050223271581353d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6385874694931898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.8492661203164715d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(74L, 46872L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 74L);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var11.cumulativeProbability(428451470, (-6));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-2));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(42.8879512411425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     org.apache.commons.math3.random.RandomGenerator var16 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextZipf((-194062463), 6.770734296545935d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 19108.873370168858d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.536632385427596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 5.873226882508094E27d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextHexString((-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 28.590031131015504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1024196908022227E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.8222445648410996d);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.06354856064671875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0011091316181885394d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.30913758f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.587658155301d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.876661972910309E30d);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var8 = var5.nextF(0.33354954032831396d, 68.34266005659136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.04630902351677092d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)46734L);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(8.97308641465062d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0d);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull(0.0d, 4.641588833612778d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 86723.63215794657d);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(1.2246467991473532E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2246467991473532E-16d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 61);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.9999979652231713d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1120319269));
    var1.setSeed(254L);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(8.84574216192367d, 2.209155774176144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8.84574216192367d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)5);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.07827191997339972d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.547566361334657d));

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     int var25 = var7.nextZipf(2, 0.3961916630178961d);
//     double var27 = var7.nextT(1.891704828860318d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.661304365149806d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3.2560395758933995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.7869665539332111d);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    boolean var4 = var2.nextBoolean();
    int var5 = var2.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 60481539);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    var1.setSeed(91L);
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 6901081964622120046L);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    var7.reSeed();
    var7.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.10429317151917769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0054434642069592d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var3.nextSecureInt(100, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextSecureLong(65L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14357.883087841588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.6934553640513363d);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(5.555563365755192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7467581488642825d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var12 = new int[] { 1, 0, 1};
    var8.setSeed(var12);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
    java.lang.Object[] var15 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10, var15);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.0d, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    long var5 = var1.nextLong(3L);
    long var7 = var1.nextLong(46872L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2113L);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(14, 81217892, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    long var22 = var7.nextPoisson(0.3717188590854432d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var24 = var7.nextHexString((-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0L);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.335737920591789d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.32391311953262847d));

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(32L, 93L);
//     double var5 = var0.nextT(0.7426404527543018d);
//     double var8 = var0.nextUniform(0.7281779665864416d, 0.8490064729285955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 89L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.884733845961214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8267428338221843d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2113L, (java.lang.Number)(-1.0f), false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    java.lang.Throwable[] var4 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(214.92722629758254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.751187751071757d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var7.nextUniform(0.4066076797520086d, 2.220446049250313E-16d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1079.5810741532396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.15595807f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1549560137), (-1549560137));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1549560137));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, (-4), 0, (-93613120));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     java.lang.String var6 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull(17.32951918688061d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8191525850070516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "77498f2198"+ "'", var4.equals("77498f2198"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a9685d1916"+ "'", var6.equals("a9685d1916"));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(16, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.115901134774571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.241121429462325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.042034579264082d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException(var2, (java.lang.Number)100.0d);
    java.lang.Number var5 = var4.getMin();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    double var19 = var11.getNumericalMean();
    double var21 = var11.cumulativeProbability(8);
    var11.reseedRandomGenerator(2L);
    var11.reseedRandomGenerator((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    int var20 = var11.getPopulationSize();
    double var21 = var11.getNumericalVariance();
    double var23 = var11.cumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(4.583016737336699d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    double var14 = var11.upperCumulativeProbability((-118603794));
    int var15 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var4 = var0.nextChiSquare(0.9292273298132443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var6 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.37402661224265255d);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.001129876315267469d, 65.18510402677708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.001129876315267469d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.15595806f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var8 = var0.nextGaussian(22.140692632779267d, 1.0335493168349069E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.068794984665114d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3911845494799388E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7119153.579263781d);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.2845301529959981E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     java.lang.String var15 = var7.nextHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var7.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 90L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "b23"+ "'", var15.equals("b23"));
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.00390625f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.00390625f);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(8.768916560445668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15304646581243325d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, (-810646614), 350937176, 15);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), (-93613120));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-93613120));

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.1680043056814067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    int var42 = var36.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var46 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var36, 10, 4, 9);
    int[] var48 = var46.sample(100);
    int[] var50 = var46.sample(65);
    var34.setSeed(var50);
    org.apache.commons.math3.random.RandomDataGenerator var52 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0301066080631203d, (java.lang.Number)48.108264995729755d, false);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var8 = var0.nextExponential(1.2895855093964026d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull((-0.7278654655222002d), 1.660633273090299d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 57034.40007446242d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8362677605260765d);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
//     int var10 = var4.nextInt((-6), 10);
//     var4.reSeed();
//     long var14 = var4.nextLong((-9109855603261136600L), 32L);
//     var4.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var4.nextUniform(7.621133953612494d, 0.7744227068102951d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 22.511131074500152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2553476067322455569L));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    var2.addSuppressed((java.lang.Throwable)var9);
    boolean var11 = var9.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-1.932065588732449d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2L));

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
//     org.apache.commons.math3.distribution.RealDistribution var8 = null;
//     double var9 = var4.nextInversionDeviate(var8);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(0, (-1120319269));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 26.93801876120206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.39109298606696E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 35.2665501065108d);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     double var8 = var0.nextGaussian(0.782013887229037d, 0.782013887229037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 20.09455636997508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.027979121577570654d));
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)12.236902640271552d, (java.lang.Number)(byte)1, false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(43308.07807140918d, (-1.8444915149156582d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 43308.07807140918d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1, 0, 1};
    var3.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
    byte[] var11 = new byte[] { (byte)10};
    var3.nextBytes(var11);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var18 = new int[] { 1, 0, 1};
    var14.setSeed(var18);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var14);
    int var23 = var20.nextZipf(10, 3.141592653589793d);
    double var26 = var20.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var29 = var20.nextPermutation(100, 100);
    var3.setSeed(var29);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var34 = new int[] { 10};
    var32.setSeed(var34);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var41 = new int[] { 1, 0, 1};
    var37.setSeed(var41);
    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var46 = new int[] { 10};
    var44.setSeed(var46);
    var37.setSeed(var46);
    var32.setSeed(var46);
    var3.setSeed(var46);
    var1.setSeed(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-23), (-1023), 61);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-2.2667103256235044d), 0.8825395169829676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)8.362584059135381d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)6901081964622120046L, true);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    double var16 = var11.cumulativeProbability(428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(7.819050563341387E20d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.36492531586638527d);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(6.7727635120911645d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5328464714508349d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-2.8122751623675955E-4d), 1.4517803089065216E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4517803089065216E30d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.9999979652231713d, 4.940878138553293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.940878138553293d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.243965329766882d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     int[] var8 = var0.nextPermutation(61, 7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.0434963510468283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.512716820557492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.13829574457526012d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.002413716084335376d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextBeta(1.4597135858742798E-16d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.3296790815549895d);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     java.lang.String var7 = var0.nextHexString(6);
//     double var11 = var0.nextUniform(0.04630902351677092d, 5.514627478466221d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.16828299989603027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "7aa900"+ "'", var7.equals("7aa900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.355882029466596d);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.6861855915722702E176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 585);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var7.nextHypergeometric((-93613120), 30, 3);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(5, 6.283185307179586d);
//     double var11 = var0.nextGaussian(0.33354954032831396d, 0.7610726839071428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1294565219381592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5514.539537206738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.29068377125614d));
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    var0.reSeedSecure(11L);
    double var8 = var0.nextExponential(1.2012365955976083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.022233301971648117d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1), 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.3717188590854432d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.189936461065306d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    int var35 = var1.nextInt(30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var37 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 16);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.04630902351677092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04630902351677092d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.cumulativeProbability((-1));
    boolean var19 = var11.isSupportConnected();
    double var22 = var11.cumulativeProbability((-52624155), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var8 = var0.nextF(0.7806640867181274d, 0.3717188590854432d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(6901081964622120046L, 60L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 183.1256735971287d);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(1, (-8406519), 9);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.15595806f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15595807f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.7891391771877577d), (java.lang.Number)(-4), false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-4)+ "'", var4.equals((-4)));

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.016114544521814232d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     double var8 = var0.nextWeibull(0.2712856473959901d, 10.201158186626492d);
//     double var11 = var0.nextF(3.661304365149806d, 6.929625337259191d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.009815534862554279d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 308.73091256785426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.172250155042838d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    long var5 = var2.nextLong();
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    double var8 = var7.nextDouble();
    double var9 = var7.nextDouble();
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var15 = new int[] { 1, 0, 1};
    var11.setSeed(var15);
    org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
    var17.reSeedSecure((-1L));
    int[] var22 = var17.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
    var7.setSeed(var22);
    int[] var26 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var26);
    var27.clear();
    int var29 = var27.nextInt();
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var32 = var31.nextBoolean();
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var38 = new int[] { 1, 0, 1};
    var34.setSeed(var38);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var34);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var46 = new int[] { 1, 0, 1};
    var42.setSeed(var46);
    org.apache.commons.math3.random.RandomDataImpl var48 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var42);
    byte[] var50 = new byte[] { (byte)10};
    var42.nextBytes(var50);
    var34.nextBytes(var50);
    var31.nextBytes(var50);
    var27.nextBytes(var50);
    var7.nextBytes(var50);
    var2.nextBytes(var50);
    org.apache.commons.math3.random.RandomDataGenerator var57 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2876919108950029338L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    var7.reSeed();
    var7.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextLong(32L, 93L);
//     double var6 = var0.nextCauchy(6.283185307179586d, 0.3931421251672571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 77L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.926113166649637d);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-194062463), 0, 669834927);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.0d, var16);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var2, var16);
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError(var1, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)16822.424193698815d, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.30913758f, 0.00390625f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.30913758f);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1023);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     double var7 = var0.nextBeta(0.999999998129049d, 1.1752005863472421d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.06360859642650762d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "eb5928f294"+ "'", var4.equals("eb5928f294"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9265429545997971d);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.0641972560883777d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.8595496779067604d));

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform(5.3360106650016d, 1079.5810741532396d, false);
//     double var9 = var0.nextCauchy(4.284201251169182d, 0.9415740839056164d);
//     double var13 = var0.nextUniform(0.3010299956639812d, 0.7634244805601391d, false);
//     long var16 = var0.nextSecureLong((-9109855603261136600L), 93L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 558.5048765336236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.537576630574783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.6988646946736641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7316180772744173669L));
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9999997600389442d, 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2693737.5293707973d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.0012314856832879519d, false);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var31 = var28.getNumericalVariance();
    int var32 = var28.getSupportUpperBound();
    int var33 = var28.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 4);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.284201251169182d, (java.lang.Number)31029.150975170018d, (java.lang.Number)0.0d);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 31029.150975170018d+ "'", var5.equals(31029.150975170018d));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(3.172250155042838d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.172250155042838d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.9371038524921493d, (java.lang.Number)6.7727635120911645d, (java.lang.Number)(-6878022790933652708L));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var19 = new int[] { 10};
    var17.setSeed(var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var26 = new int[] { 1, 0, 1};
    var22.setSeed(var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var31 = new int[] { 10};
    var29.setSeed(var31);
    var22.setSeed(var31);
    var17.setSeed(var31);
    var13.setSeed(var31);
    var13.setSeed((-96398574));
    org.apache.commons.math3.random.RandomDataImpl var38 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.192093E-7f, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.4683048930644915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.468304893064492d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(3.661304365149806d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 38.91206532575796d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(534.4916555247646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 534.0d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     double var11 = var0.nextExponential(1.2905389698182939d);
//     var0.reSeed(25L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3686ee3acf", "eb5928f294");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.21748326375064497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999991795230873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.877336973548094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.257732107789746d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.13301388022607083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13262199811610234d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.23094703161653143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13.232290202701638d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(306.0196847852814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 306L);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)25.68447716417873d, var6, false);
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var10 = var8.getMin();
    boolean var11 = var8.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextGamma(43.19990300454566d, 2.4683048930644915d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var22 = var7.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 101.46617535658866d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.2065299964591305d, 31029.150975170018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31029.15099862723d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     double var11 = var7.nextExponential(0.15015415474359342d);
//     long var14 = var7.nextSecureLong(61L, 46637L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.09347294900676971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 15927L);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextUniform(0.27045149498596743d, 4.352694383675031d);
    double var17 = var7.nextUniform(0.0d, 0.088080102426826d);
    double var19 = var7.nextT(3.9209536856213183d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var7.nextBeta((-0.7891391771877577d), 0.6988646946736641d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.4447996764224045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05361446892311553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.4910114401587537d));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { 1, 0, 1};
    var6.setSeed(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    java.lang.Object[] var13 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var13);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     java.lang.String var4 = var0.nextSecureHexString(42);
//     var0.reSeedSecure(71L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "15107bd874ff18f6ed799cdaedf60dd8cc956efa29"+ "'", var4.equals("15107bd874ff18f6ed799cdaedf60dd8cc956efa29"));
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-2757668752704241422L));
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var12 = new int[] { 1, 0, 1};
    var8.setSeed(var12);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
    var14.reSeedSecure((-1L));
    int[] var19 = var14.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    long var22 = var20.nextLong(55L);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var28 = new int[] { 1, 0, 1};
    var24.setSeed(var28);
    org.apache.commons.math3.random.RandomDataImpl var30 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var24);
    byte[] var32 = new byte[] { (byte)10};
    var24.nextBytes(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.RandomDataImpl var41 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var35);
    int var44 = var41.nextZipf(10, 3.141592653589793d);
    double var47 = var41.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var50 = var41.nextPermutation(100, 100);
    var24.setSeed(var50);
    var20.setSeed(var50);
    var1.setSeed(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     var0.reSeed();
//     var0.reSeed();
//     java.lang.String var16 = var0.nextSecureHexString(64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 93033.58819902467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.21833000297672053d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "0b0806612c491920b2686612a7ffb6f50b3d8f9c0c66f8e57e670d116e66fd01"+ "'", var16.equals("0b0806612c491920b2686612a7ffb6f50b3d8f9c0c66f8e57e670d116e66fd01"));
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    double var19 = var11.getNumericalVariance();
    double var21 = var11.upperCumulativeProbability(61);
    int var22 = var11.getPopulationSize();
    double var23 = var11.getNumericalVariance();
    double var26 = var11.cumulativeProbability(0, 69);
    int var27 = var11.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    int var31 = var28.sample();
    int var32 = var28.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 9);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(1.0335493168349069E7d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 22.172403105976933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.775752452431026E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 25.1534358179811d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException(var5, (java.lang.Number)100.0d);
    java.lang.Number var8 = var7.getMin();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(-52624155), (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2L, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)30.05169001350385d, var1, false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.6321205588285576d), (java.lang.Number)4.284201251169182d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var7.nextSecureInt(669834927, 6);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9266747739199285d, 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.02814153923766949d));

  }

//  public void test212() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }
//
//
//    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//    var0.reSeed();
//    int var5 = var0.nextHypergeometric(4, 1, 1);
//    var0.reSeed(46925L);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == 0);
//
//  }
//
  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(63);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int var14 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 9);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.08426832637046788d, (java.lang.Number)0.13262199811610234d, false);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    int[] var3 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    var4.clear();
    int var6 = var4.nextInt();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var9 = var8.nextBoolean();
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var15 = new int[] { 1, 0, 1};
    var11.setSeed(var15);
    org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var23 = new int[] { 1, 0, 1};
    var19.setSeed(var23);
    org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var19);
    byte[] var27 = new byte[] { (byte)10};
    var19.nextBytes(var27);
    var11.nextBytes(var27);
    var8.nextBytes(var27);
    var4.nextBytes(var27);
    var1.nextBytes(var27);
    int var33 = var1.nextInt();
    double var34 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.5918164732033864d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    int var20 = var11.getPopulationSize();
    boolean var21 = var11.isSupportConnected();
    boolean var22 = var11.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextT(0.09347294900676971d);
    int var9 = var0.nextBinomial(65, 0.9672751717291171d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var0.nextSecureLong(3L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)93033.58819902467d);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeed(0L);
//     org.apache.commons.math3.random.RandomGenerator var10 = var0.getRandomGenerator();
//     var0.reSeedSecure(60L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.151022396274623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.350099221133929E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10.183973508648856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    int var10 = var0.nextZipf(6, 1.0335493168349069E7d);
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var14 = var0.nextPermutation(63, 350937176);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.533809723277221d, (java.lang.Number)0.05361446892311553d, var3);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var10 = var0.nextT(99.99999999999999d);
//     var0.reSeedSecure(10L);
//     double var15 = var0.nextWeibull(2.731175276583916E30d, 0.41163626780150286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.559579178656478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 20299.104450394138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.0132790915040224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2033038447758037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.41163626780150286d);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.9999999979227431d, 1.2905389698182939d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6592288770851267d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)534.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    double var17 = var11.probability(8);
    int var18 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    long var21 = var7.nextPoisson(1.2012365955976083d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var23 = var7.nextSecureHexString((-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0L);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(5.804641090815146d, 16.853135916639044d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.447493824406243E12d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getSupportUpperBound();
    double var14 = var11.cumulativeProbability((-194062463));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var16 = var11.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 2113L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    double var4 = var2.nextGaussian();
    double var5 = var2.nextGaussian();
    float var6 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9570892f);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var10 = var0.nextExponential(1.0d);
//     org.apache.commons.math3.random.RandomGenerator var11 = var0.getRandomGenerator();
//     int var14 = var0.nextPascal(5, 0.43511877764350804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 27.563181194750733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5557396120680712E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8498552948338339d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9412849019579741d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(3, 3, 1);
    double var5 = var3.upperCumulativeProbability((-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     long var17 = var7.nextLong((-414028722650554365L), 0L);
//     double var19 = var7.nextT(22411.793069624626d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var22 = var7.nextLong(46872L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-18357630988042166L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.8539832713370468d);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     double var22 = var7.nextCauchy(2.93710385249215d, 0.33115294219320335d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var7.nextHypergeometric(62, 7, (-52624155));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.043673948530945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.03802576011342973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.236441924325579d);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.016114544521814232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.01611454452181423d));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(93452.71554851689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.970591925624977d);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(15, 30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.870399700245757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.2633630179028634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 72.38536891874473d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    double var6 = var0.nextGamma(0.1096622711232151d, 25.21435585163038d);
    double var9 = var0.nextBeta(0.9999997600389442d, 1079.5810741532396d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var0.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.010362048038259351d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 6.010917772984692E-4d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(4.051023823665012d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0765225659012843d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.474110514047286d, 81217892);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextUniform(0.27045149498596743d, 4.352694383675031d);
    double var17 = var7.nextUniform(0.0d, 0.088080102426826d);
    double var19 = var7.nextT(3.9209536856213183d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var7.nextPascal(60481539, (-0.016113149763313152d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.4447996764224045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05361446892311553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.4910114401587537d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4774959f);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.18712958355001746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18822363177558585d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100);
//     int[] var6 = new int[] { 10};
//     var4.setSeed(var6);
//     var1.setSeed(var6);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var12 = var9.nextSecureInt((-96398574), 6);
//     double var14 = var9.nextChiSquare(26.90872600746492d);
//     var9.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-83857780));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 31.740272484770454d);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     double var8 = var0.nextWeibull(0.2712856473959901d, 10.201158186626492d);
//     double var10 = var0.nextChiSquare(1079.5810741532396d);
//     org.apache.commons.math3.random.RandomGenerator var11 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.6981839791934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 186.4934544319377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1090.7151534294098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.8E-45f, 0.4774959f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4774959f);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024.0001f);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.18712958355001746d, (-3.5816635108956087d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.18712958355001746d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.0785650438157504d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var12 = new int[] { 1, 0, 1};
    var8.setSeed(var12);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
    java.lang.Object[] var15 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10, var15);
    org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var3, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1), var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)2.9371038524921493d, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 1.7869665539332111d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.7050223271581353d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.65677616269017d));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    long var17 = var7.nextPoisson(1.2012365955976083d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var20 = var7.nextLong(46925L, (-6116618998156505929L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3L);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5231009852891018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8057404733545233d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0L, (java.lang.Number)1.3514488136855796d, true);
    java.lang.Number var5 = var4.getMin();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1.4995328008980024d), (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3514488136855796d+ "'", var5.equals(1.3514488136855796d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextGamma(12.099262142751375d, (-0.5063656411097588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 93L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.749664150715203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 47105L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5218376598019842d);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     var7.reSeed((-166140055330010418L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var7.nextUniform(6.07662907668239d, 0.2033038447758037d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.428328164430871d);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.209155774176144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1660079038526812d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.2453532855874733E32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.09529257088266d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(350937176, (-4), 15);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var5 = var0.nextExponential(8.365175298942184d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextZipf(0, 43.19990300454566d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.158520438985425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9.711949768575522d);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     double var19 = var7.nextGaussian(16.51038740791099d, 2.4039881628133278E10d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var7.nextPascal((-93613120), (-65.68792148528178d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.8628738851325504d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-6.96279436498996E9d));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(60.28026284097294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5114212345986345E26d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    long var21 = var7.nextPoisson(1.2012365955976083d);
    double var24 = var7.nextBeta(0.1719246526310684d, 1.891704828860318d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var26 = var7.nextSecureHexString((-1549560137));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.31796994915118965d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-2757668752704241422L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2757668752704241422L);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-9109855603261136600L), 46637L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 46637L);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.07277703f, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.58221626f);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.3931421251672571d, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.310681736021897E-39d);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     var7.reSeed(0L);
//     double var17 = var7.nextChiSquare(2.7257969399088773d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 50L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.6876927921820193d);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(2, 669834927);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-358148614));

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     java.lang.String var6 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextF(0.9265429545997971d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 28.572675601858464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f925e79c07"+ "'", var4.equals("f925e79c07"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2cd06c7d59"+ "'", var6.equals("2cd06c7d59"));
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.536743E-7f, 0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(0, (-0.01611454452181423d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.3117346428249892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999996615484807d);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var32 = new int[] { 10};
    var30.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var44 = new int[] { 10};
    var42.setSeed(var44);
    var35.setSeed(var44);
    var30.setSeed(var44);
    var1.setSeed(var44);
    float var49 = var1.nextFloat();
    var1.setSeed((-1120319269));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.76195765f);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(3.407736098774514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     var7.reSeedSecure();
//     long var23 = var7.nextSecureLong((-2757668752704241422L), 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.761705377322171d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 51.380128051879694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-725041627791147652L));
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var11 = new int[] { 1, 0, 1};
    var7.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
    java.lang.Object[] var14 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.7317389317780593d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7317389317780593d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.982441812995697E30d, (java.lang.Number)85L, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    var7.reSeedSecure((-414028722650554365L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var7.nextPascal(57, (-1.1051749493157323d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)4.055908274771898d, (java.lang.Number)0.26460785404894344d);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var6 = var5.toString();
    var4.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var6.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(32610.097719459052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(24.846301425358277d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var9 = new byte[] { (byte)10};
//     var1.nextBytes(var9);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var16 = new int[] { 1, 0, 1};
//     var12.setSeed(var16);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
//     int var21 = var18.nextZipf(10, 3.141592653589793d);
//     double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
//     int[] var27 = var18.nextPermutation(100, 100);
//     var1.setSeed(var27);
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var34 = new int[] { 1, 0, 1};
//     var30.setSeed(var34);
//     org.apache.commons.math3.random.RandomDataImpl var36 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var30);
//     double var39 = var36.nextGaussian(3.141592653589793d, 10.0d);
//     var36.reSeed(10L);
//     var36.reSeed();
//     double var45 = var36.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var48 = var36.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var51 = var36.nextPermutation(8, 7);
//     var1.setSeed(var51);
//     boolean var53 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.9995149440000322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 5.737386060081889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 6.8093473578120465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     int var5 = var0.nextInt(4, 65);
//     double var8 = var0.nextF(9.151280024146605d, 3.286292495855155d);
//     double var10 = var0.nextExponential(3.6574758508329603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.3799661860217153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5315170012933516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2962801607415591d);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(14, 0.782013887229037d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.7951208062406558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 406.49582694663934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     var7.reSeed((-166140055330010418L));
//     var7.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var7.nextWeibull(0.0d, 1.2404374004543741d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.156437224936596d);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var10 = new int[] { 10};
    var8.setSeed(var10);
    var1.setSeed(var10);
    var1.clear();
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var19 = new int[] { 1, 0, 1};
    var15.setSeed(var19);
    int var21 = var15.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var25 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var15, 10, 4, 9);
    int[] var27 = var25.sample(100);
    int[] var29 = var25.sample(65);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
    var1.setSeed(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.15595806f, var2, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var8 = var0.nextF(0.7806640867181274d, 0.3717188590854432d);
//     java.lang.String var10 = var0.nextHexString(5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0835445809218502d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "8ccc2"+ "'", var10.equals("8ccc2"));
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     double var8 = var0.nextChiSquare(10.0d);
//     int var11 = var0.nextZipf(10, 1.1858699313494176d);
//     double var14 = var0.nextF(1.181547729533909d, 0.24175283435836448d);
//     long var16 = var0.nextPoisson(51.380128051879694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 39.83798261066189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 40.95048516891738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.201357751958055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.6125468276096667E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 58L);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var2 = var0.nextPoisson(3.6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var4 = var0.nextExponential((-0.5063656411097588d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4L);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.11301524106650007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var7.nextSample(var17, (-8406519));
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextPoisson((-0.1070184668034227d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.924182792759084d);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)43.19990300454566d, var1, true);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-1.8595496779067604d), 2.0785650438157504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.8595496779067604d));

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var18 = var7.nextInt((-6), 15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var7.nextPascal(6, 2312.7809931100232d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     java.lang.String var14 = var7.nextHexString(100);
//     int var17 = var7.nextInt(8, 13);
//     double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
//     long var22 = var7.nextPoisson(0.3717188590854432d);
//     double var24 = var7.nextExponential(1.2065299964591305d);
//     long var27 = var7.nextSecureLong(0L, 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1592294.6908971414d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.1787508883725546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0L);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.9964021940844213d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5388624668757487d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.7262566507187045d), 0.2183959234640678d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.07106888032650108d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var13);
    double var18 = var16.nextT(3.51625245907178d);
    double var21 = var16.nextGaussian(3.712792388468654d, 3.6125468276096667E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.7104343504355127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3.7124510110735724d);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     var0.reSeed(0L);
//     int var7 = var0.nextZipf(10, 2147.432395050844d);
//     double var9 = var0.nextExponential(0.2712856473959901d);
//     int var12 = var0.nextSecureInt(0, 61);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var0.nextSecureHexString((-96398574));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.049816982749194494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 51);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    double var17 = var7.nextCauchy(10.201158186626492d, 2.2891073680063085d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextHypergeometric((-4), 93018071, (-118603794));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 17.748282306882505d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)3.751187751071757d, (java.lang.Number)0.9964021940844213d, false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0563366458702615E9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.058808539379528374d);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     org.apache.commons.math3.random.RandomGenerator var16 = var0.getRandomGenerator();
//     java.lang.String var18 = var0.nextSecureHexString(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31698.143427126535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.882972387958593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.8199250592611863E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "fac58d5a9b"+ "'", var18.equals("fac58d5a9b"));
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var8 = new int[] { 1, 0, 1};
    var4.setSeed(var8);
    org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    byte[] var20 = new byte[] { (byte)10};
    var12.nextBytes(var20);
    var4.nextBytes(var20);
    var1.nextBytes(var20);
    long var24 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-7529656944096573677L));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     double var6 = var0.nextExponential(1.0197670739888333E28d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.025050668700661E27d);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     org.apache.commons.math3.random.RandomGenerator var10 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6964482765773647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.098475204876267E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 27.913274388776458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.07277703f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07277703f);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     double var7 = var0.nextChiSquare(0.9266747739199285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08134802711336403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1103.1901787829615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.4339933340222135d);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.87731868091954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.33115294219320335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.34412264933935055d);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     int var5 = var0.nextSecureInt(1, 10);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0L, (java.lang.Number)1.3514488136855796d, true);
    java.lang.Number var5 = var4.getMin();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1.801839672038146d), (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3514488136855796d+ "'", var5.equals(1.3514488136855796d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian((-0.20264446420595678d), 2.497498709678805d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var7.nextPascal(3, 20.34275247523163d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.8444915149156582d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var34 = var7.nextHypergeometric((-1549560137), 0, (-358148614));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     long var7 = var0.nextSecureLong(10L, 93L);
//     java.lang.String var9 = var0.nextHexString(42);
//     long var11 = var0.nextPoisson(0.8304341776476892d);
//     var0.reSeedSecure(7808248002097901876L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.3084754425163718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 53L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "3e654225c4b000bfa055c5ba64a0344f42bac633d1"+ "'", var9.equals("3e654225c4b000bfa055c5ba64a0344f42bac633d1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.43511877764350804d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    int var21 = var11.getSupportLowerBound();
    double var23 = var11.upperCumulativeProbability(57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.07477341765096279d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07477341765096279d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(4.970591925624977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3722632545629136d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    boolean var20 = var11.isSupportConnected();
    var11.reseedRandomGenerator(72L);
    int var23 = var11.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.7693376445680227d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.7693376445680227d+ "'", var4.equals(2.7693376445680227d));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9999999979227431d, var1, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var4);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     double var17 = var0.nextChiSquare(12.140465251696156d);
//     var0.reSeedSecure();
//     double var20 = var0.nextChiSquare(22025.465794806718d);
//     int var23 = var0.nextInt((-1549560137), (-3));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0424931001290507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46709L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.96143680020994d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 14.995184196448212d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 21903.83917938213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-663776062));
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)2.93710385249215d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)31029.150975170018d, (java.lang.Number)4.850588148931125d, false);
    var1.addSuppressed((java.lang.Throwable)var6);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    var0.reSeed((-166140055330010418L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var0.nextBeta(6.073056959154308d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextBeta(10.201158186626492d, 0.001129876315267469d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(52L, (-1369798007726508792L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 20.68779162725587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.0d);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var11.cumulativeProbability(63, 4);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     var0.reSeedSecure((-6116618998156505929L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18472.098631970002d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.076631132412643d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(306.0196847852814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.41679394022645d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.619271173180935d, 13.910315127978533d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.619271173180935d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.4092822771139013d, (-93613120));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     int var4 = var2.nextInt();
//     int var6 = var2.nextInt(42);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var10 = var7.nextUniform(0.3961916630178961d, 15.22621231266953d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var7.nextSample(var11, 25);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    long var2 = var1.nextLong();
    var1.setSeed(91L);
    int var6 = var1.nextInt(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.30693223235013783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.30693223235013783d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    boolean var5 = var2.nextBoolean();
    double var6 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.7157990521557022d);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-2L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-810646614));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    double var10 = var4.nextGamma(2.7693376445680227d, 38.42983716254903d);
    var4.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 103.86450481904308d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.8773824271569775d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3642817058273673d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.055684390990072566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05418926844439042d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var14 = new int[] { 1, 0, 1};
    var10.setSeed(var14);
    org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var10);
    java.lang.Object[] var17 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)10, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     java.lang.String var6 = var0.nextHexString(10);
//     double var9 = var0.nextGaussian(0.8456361335633256d, 0.17453292519943295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.598197098603711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "740ab860c4"+ "'", var4.equals("740ab860c4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f11209d233"+ "'", var6.equals("f11209d233"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0501125473562256d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9999999979227431d, 0.44974510690998637d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.846776373613042E8d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1), (java.lang.Number)6.3135427094879235d, false);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (6.314)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (6.314)"));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03490658503988659d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(186.4934544319377d, 3.6125468276096667E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0018905674628824d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.794E-43f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.7553717358309021d, (java.lang.Number)1.87731868091954d, (java.lang.Number)26.90872600746492d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 26.90872600746492d+ "'", var5.equals(26.90872600746492d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.87731868091954d+ "'", var6.equals(1.87731868091954d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    double var20 = var11.upperCumulativeProbability(9);
    int[] var22 = var11.sample(42);
    double var24 = var11.probability(63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.9843875149634705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17693659866317846d);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     double var9 = var0.nextGamma(8.768916560445668d, 1.1264588458117917d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1484430271783892d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.977664381087071E10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.553013427837032d);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 22026L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22026L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)0, (java.lang.Number)1.908642352606886d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.908642352606886d+ "'", var5.equals(1.908642352606886d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    var7.reSeed(6901081964622120046L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)49.0d, (java.lang.Number)31698.143427126535d, (java.lang.Number)4.051023823665012d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)0, (java.lang.Number)2.0d, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)6.07662907668239d);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     int[] var11 = var0.nextPermutation(11, 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.27880174694234583d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.974743860672566E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 27.945036721996285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var5 = var0.nextExponential(8.365175298942184d);
//     int var8 = var0.nextPascal(10, 0.29353980793136686d);
//     double var10 = var0.nextT(101.46617535658866d);
//     var0.reSeed(58L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.26054365238188865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.936293072423965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8307279306526907d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9999999979227431d, var1, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (null)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (null)"));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.15595807f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15595809f);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.1376946885222738d, 0.5826716629917943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.097475105290114d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.8426969626615404d, (java.lang.Number)1.034362739798913E-15d, (java.lang.Number)4.055908274771898d);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(32768.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32768.004f);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.6466904717391735d, 1.0501125473562256d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6466904717391735d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.8813735870195429d));

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
//     java.lang.Number var4 = var3.getMax();
//     java.lang.Throwable var5 = null;
//     var3.addSuppressed(var5);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(3.6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var4 = var0.nextChiSquare(5.726911865353372d);
//     var0.reSeedSecure((-166140055330010418L));
//     double var9 = var0.nextBeta(16.853135916639044d, 12.236902640271552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7.172031286085538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6062296201032537d);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextLong((-6116618998156505929L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.335737920591789d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var10 = var0.nextT(99.99999999999999d);
//     int var13 = var0.nextInt(0, 100);
//     var0.reSeedSecure(54L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.15151602562696098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 184725.83346702476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.205267026606057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.02886808489775315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 84);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.461518408584977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9686966716607449d));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    var7.reSeedSecure(23L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6566695863938614E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6566695863938616E-16d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(186.4934544319377d, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1480317588595153E34d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var13);
    double var18 = var16.nextT(3.51625245907178d);
    double var22 = var16.nextUniform(0.0d, 1.4154758067826922d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.7104343504355127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8038699885742367d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(4.167894952977355d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 63.579366321366805d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)32L);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-96398574));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 350937176, 428451470, (-1549560137));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     long var10 = var0.nextLong(55L, 82L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 58L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 67L);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.15595807f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15595807f);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    var0.reSeedSecure(11L);
    double var9 = var0.nextUniform((-36.04365338911715d), 3.882579444988825d);
    double var12 = var0.nextBeta(0.1336149855922958d, 0.4078398151591566d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("0008", "0d47c2e9a4cadefcffd34fea37b8db5ba207e39e12");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0785650438157504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.020085817952422695d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    boolean var4 = var2.nextBoolean();
    float var5 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.014081955f);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(24, (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 24);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var7 = var0.nextBeta(1.189936461065306d, 3.2104769607016383E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    var1.setSeed(91L);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7.570160841992396d, (java.lang.Number)(-3.826806846853243E-5d), var2);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var4 = var0.nextChiSquare(0.9292273298132443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextZipf((-93018071), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.2965067394825416d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    double var19 = var11.getNumericalMean();
    double var21 = var11.cumulativeProbability(8);
    double var22 = var11.getNumericalMean();
    double var23 = var11.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 3.6d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1269.3739277026489d, 16822.424193698815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16870.24795078823d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.7141855694587375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8450950061731151d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 32768.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(26.90872600746492d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.90872600746492d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    var11.reSeedSecure((-1L));
    int[] var16 = var11.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    var1.setSeed(var16);
    int[] var20 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
    var21.clear();
    int var23 = var21.nextInt();
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var26 = var25.nextBoolean();
    org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var32 = new int[] { 1, 0, 1};
    var28.setSeed(var32);
    org.apache.commons.math3.random.RandomDataImpl var34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var28);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    org.apache.commons.math3.random.RandomDataImpl var42 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var36);
    byte[] var44 = new byte[] { (byte)10};
    var36.nextBytes(var44);
    var28.nextBytes(var44);
    var25.nextBytes(var44);
    var21.nextBytes(var44);
    var1.nextBytes(var44);
    double var50 = var1.nextDouble();
    float var51 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.33354954032831396d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.25852752f);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     int var15 = var0.nextZipf(10, 4.940878138553293d);
//     int var18 = var0.nextZipf(8, 51.380128051879694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 50215.506900244975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 15.261044137712044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1, 0, 1};
    var3.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var3);
    byte[] var11 = new byte[] { (byte)10};
    var3.nextBytes(var11);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var18 = new int[] { 1, 0, 1};
    var14.setSeed(var18);
    org.apache.commons.math3.random.RandomDataImpl var20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var14);
    byte[] var22 = new byte[] { (byte)10};
    var14.nextBytes(var22);
    var3.nextBytes(var22);
    var1.nextBytes(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var38 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var34, 2147483647, 1, (-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3L);
    java.lang.Number var2 = var1.getArgument();
    java.lang.Number var3 = var1.getMin();
    java.lang.Number var4 = var1.getMin();
    java.lang.String var5 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 3L+ "'", var2.equals(3L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 3 is smaller than the minimum (0)"+ "'", var5.equals("org.apache.commons.math3.exception.NotPositiveException: 3 is smaller than the minimum (0)"));

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     double var11 = var0.nextChiSquare(0.761957659063951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextSecureLong(9223372036854775807L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.3786541106953036d);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    int var4 = var2.nextInt();
    int var6 = var2.nextInt(42);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 13);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
    double var16 = var7.nextF(1.1264588458117917d, 51090.46487338002d);
    double var20 = var7.nextUniform(0.3961916630178961d, 1.070379039193733d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.4597135858742798E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.7800584599696019d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.6151775063123803d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    double var14 = var11.getNumericalVariance();
    int var15 = var11.getSupportLowerBound();
    double var17 = var11.upperCumulativeProbability(11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.1070184668034227d), (java.lang.Number)1.8482997974150024d, true);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var19 = var7.nextPermutation(0, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 15.060344247632125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.2355579282143314E32d);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextT(0.19767649048318184d);
    int var17 = var7.nextZipf(100, 1.1858699313494176d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var7.nextPascal((-10), 0.7806640867181274d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.5792260817990332d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 69);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    double var11 = var7.nextExponential(0.15015415474359342d);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var7.nextUniform(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.09347294900676971d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     double var12 = var0.nextF(0.39371623903891373d, 3.2541630921465963d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(428451470, 2.5557396120680712E7d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 78166.46779895123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8122993773816004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6065023621703509d);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    int var13 = var11.getSupportUpperBound();
    double var15 = var11.probability(42);
    double var18 = var11.cumulativeProbability(19, 585);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    var0.reSeedSecure(11L);
    double var9 = var0.nextUniform((-36.04365338911715d), 3.882579444988825d);
    double var12 = var0.nextBeta(0.1336149855922958d, 0.4078398151591566d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var15 = var0.nextPermutation(8, 93018071);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0785650438157504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.020085817952422695d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.5115296784115013d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.986322523755449d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var18 = var7.nextPascal(0, 7.172031286085538d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    boolean var35 = var34.nextBoolean();
    double var36 = var34.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var37 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var34);
    double var40 = var37.nextGamma(80965.49562032598d, 0.15015415474359342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.6287849591819767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12227.859048027736d);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-0.7449400628223749d), 1.1858699313494176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var12 = new int[] { 1, 0, 1};
    var8.setSeed(var12);
    org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var8);
    java.lang.Object[] var15 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)10, var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var15);
    org.apache.commons.math3.exception.util.ExceptionContext var21 = var20.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.908642352606886d, 19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1000678.2817635591d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.743864861367417d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)Double.NaN, (java.lang.Number)1.4222084788221239d, (java.lang.Number)4.970591925624977d);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(186.4934544319377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(26.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull(1.2012365955976083d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2));
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.0f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.9999999f, (-6));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.015624998f);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    double var15 = var11.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 3.6d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     double var6 = var0.nextT(0.09347294900676971d);
//     int var9 = var0.nextBinomial(65, 0.9672751717291171d);
//     double var12 = var0.nextGamma(3.315556210533579d, 0.5028092245014826d);
//     long var15 = var0.nextSecureLong(0L, 83L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.337903735516005E10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.0999609429624697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 35L);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var32 = var7.nextChiSquare(0.3961916630178961d);
    double var35 = var7.nextUniform(0.054973020182809376d, 6.3135427094879235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.01709579639546183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.167739475973386d);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var4 = var0.nextExponential(3.027851898363248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.839851007861118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.0959528105207554d);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1024.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2207031E-4f);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    int var18 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeed();
//     double var8 = var0.nextChiSquare(10.0d);
//     int var11 = var0.nextZipf(10, 1.1858699313494176d);
//     double var14 = var0.nextCauchy(0.07477341765096279d, 0.43511877764350804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.786435608620413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.3738395289977994E11d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.770988097403407d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1.5158363148828102d));
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    boolean var35 = var34.nextBoolean();
    double var36 = var34.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var37 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var41 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var34, 3, 9, (-52624155));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.6287849591819767d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(15);
    var1.setSeed((-1549560137));
    long var5 = var1.nextLong(9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4480904336415030557L);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     var0.reSeedSecure(11L);
//     int var9 = var0.nextSecureInt((-4), 0);
//     double var11 = var0.nextChiSquare(0.761957659063951d);
//     double var14 = var0.nextGaussian(0.5028092245014826d, 13.232290202701638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.3786541106953036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-34.76092980000487d));
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    var11.reseedRandomGenerator(55L);
    int var23 = var11.sample();
    int var24 = var11.sample();
    int var25 = var11.getSupportUpperBound();
    double var27 = var11.probability((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.9999999f), 2.4683048930644915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9999998f));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7.552633489589084d);
    java.lang.String var2 = var1.toString();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    int var19 = var11.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var21 = var11.sample((-6));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     double var17 = var0.nextChiSquare(12.140465251696156d);
//     var0.reSeedSecure();
//     int var21 = var0.nextInt(61, 428451470);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 39L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0104501637590833d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46542L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8072083389398849d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 14.922606072771678d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 208069560);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    int var13 = var11.getSupportUpperBound();
    int var14 = var11.getSupportLowerBound();
    int var15 = var11.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.999835544105946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0L, (java.lang.Number)1.3514488136855796d, true);
    java.lang.Number var5 = var4.getMin();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.3514488136855796d+ "'", var5.equals(1.3514488136855796d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    double var18 = var11.upperCumulativeProbability(10);
    double var19 = var11.getNumericalVariance();
    double var21 = var11.upperCumulativeProbability(61);
    int var22 = var11.getPopulationSize();
    double var23 = var11.getNumericalVariance();
    double var26 = var11.cumulativeProbability(0, 69);
    int var27 = var11.sample();
    var11.reseedRandomGenerator((-1369798007726508792L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(15.261044137712044d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15.261044137712046d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.07718251686616505d), (java.lang.Number)0.24175283435836448d, (java.lang.Number)13.969011016549919d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    double var15 = var11.cumulativeProbability(62, 350937176);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(86180.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1504.1247493687133d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     long var7 = var0.nextSecureLong(10L, 93L);
//     java.lang.String var9 = var0.nextHexString(42);
//     long var11 = var0.nextPoisson(0.8304341776476892d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0049399168834388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 27L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "567819302217ed2b57c910b144c956c3857043c90a"+ "'", var9.equals("567819302217ed2b57c910b144c956c3857043c90a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     int var14 = var7.nextZipf(9, 93649.84672246638d);
//     java.lang.String var16 = var7.nextHexString(8);
//     org.apache.commons.math3.distribution.RealDistribution var17 = null;
//     double var18 = var7.nextInversionDeviate(var17);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(18.80792450347103d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6593793426088554d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    double var19 = var11.upperCumulativeProbability(16);
    int var20 = var11.getSampleSize();
    double var21 = var11.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.24d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var14 = var7.nextLong(53L, (-166140055330010418L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0997566f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0997566f);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 6.559579178656478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)5.726911865353372d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     double var18 = var0.nextF(0.46647993410200317d, 2.709053496411273d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 69340.50103785434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2359554745414252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8.869148315743345E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.07166635496017965d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    var7.reSeedSecure((-414028722650554365L));
    var7.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.7281779665864416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7281779665864416d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    var11.reseedRandomGenerator((-432485425446058487L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var11.cumulativeProbability((-83857780), (-93018071));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     var0.reSeedSecure();
//     double var5 = var0.nextT(70.08228481062106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.6444741545391341d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.7088530508724903d));
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.15595809f, 3.368048800002836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1559581f);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var14 = var0.nextExponential(26.468397517010732d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(20299.104450394138d, 1.0018905674628824d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 63664.65047271222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.9657602728170693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 34.25860347596137d);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    double var19 = var11.getNumericalMean();
    double var21 = var11.cumulativeProbability(8);
    int var22 = var11.getNumberOfSuccesses();
    double var23 = var11.getNumericalMean();
    int var24 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 9);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.4092822771139013d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.518046566573254d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.794E-43f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     long var13 = var7.nextSecureLong(0L, 93L);
//     var7.reSeed(0L);
//     double var17 = var7.nextExponential(5.199206964447618d);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var21 = new org.apache.commons.math3.distribution.HypergeometricDistribution(3, 3, 1);
//     int var22 = var21.getPopulationSize();
//     int var23 = var21.getSampleSize();
//     int var24 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var21);
//     boolean var25 = var21.isSupportConnected();
//     double var27 = var21.probability(63);
//     int var28 = var21.sample();
//     boolean var29 = var21.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 49L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.529327541714445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == true);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(46872L, 39L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.7349391596820163d);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(42.8879512411425d, (-1.6444741545391341d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42.91946710884891d);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(9.423306724374884E31d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    double var7 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.8112566187941526d);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
//     boolean var3 = var2.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var16 = var7.nextPermutation(100, 100);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var15 = new int[] { 1, 0, 1};
    var11.setSeed(var15);
    org.apache.commons.math3.random.RandomDataImpl var17 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
    java.lang.Object[] var18 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var9, var18);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)10, var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var18);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.2905389698182939d, var18);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9775554f, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    int var21 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 9);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     double var3 = var0.nextChiSquare(0.6466904717391735d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.13792898670441528d);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     int var12 = var0.nextZipf(53, 17.748282306882505d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.6539607231520765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.999999762685731d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4664226460185819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.5115296784115013d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.18712958355001746d, 0.9956059622125122d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1857879119551602d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(24.846301425358277d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.212708905463782d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(22026L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22026L);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     boolean var2 = var1.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var8 = new int[] { 1, 0, 1};
//     var4.setSeed(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
//     byte[] var12 = new byte[] { (byte)10};
//     var4.nextBytes(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var19 = new int[] { 1, 0, 1};
//     var15.setSeed(var19);
//     org.apache.commons.math3.random.RandomDataImpl var21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var15);
//     int var24 = var21.nextZipf(10, 3.141592653589793d);
//     double var27 = var21.nextBeta(5.804641090815146d, 0.27045149498596743d);
//     int[] var30 = var21.nextPermutation(100, 100);
//     var4.setSeed(var30);
//     org.apache.commons.math3.random.Well19937c var33 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var37 = new int[] { 1, 0, 1};
//     var33.setSeed(var37);
//     org.apache.commons.math3.random.RandomDataImpl var39 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var33);
//     double var42 = var39.nextGaussian(3.141592653589793d, 10.0d);
//     var39.reSeed(10L);
//     var39.reSeed();
//     double var48 = var39.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var51 = var39.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var54 = var39.nextPermutation(8, 7);
//     var4.setSeed(var54);
//     var1.setSeed(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.9995149440000322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 6.1468111669192265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9.770925404536754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    float var5 = var1.nextFloat();
    double var6 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9158810627712619d);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(5.761705377322171d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9112751329907487d);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextT(0.09347294900676971d);
    int var9 = var0.nextBinomial(65, 0.9672751717291171d);
    var0.reSeedSecure(16L);
    double var14 = var0.nextGamma(6.777131443293426d, 0.9412849019579741d);
    double var17 = var0.nextUniform((-1.8444915149156582d), 17050.433923472523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 7.658254451575135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 11866.960945221417d);

  }

}
