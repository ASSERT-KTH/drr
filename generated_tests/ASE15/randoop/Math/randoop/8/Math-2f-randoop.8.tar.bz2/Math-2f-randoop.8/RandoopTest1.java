
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation(0, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.298586875683879d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.752805989261019E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6.208679990644235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     var7.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var7.nextInversionDeviate(var11);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     double var7 = var0.nextGamma(16822.424193698815d, 1.4549341288792002d);
//     int var10 = var0.nextSecureInt((-194062463), (-10));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong(2876919108950029338L, 85L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 16.157273558480945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "42c6a8caca"+ "'", var4.equals("42c6a8caca"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24549.500335972105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-175491730));
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(9.754247826527576d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-2.085860893902951d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.085860893902951d));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0763035517091262E30d, (java.lang.Number)9L, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0763035517091262E30d+ "'", var5.equals(1.0763035517091262E30d));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4, 63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(65.18510402677708d, 2.20165534752854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 65.18510402677707d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.726066212978514E-4d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 45L);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)70.08228481062106d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(46763L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1549560137));

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation((-6), (-93018071));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3976186429428674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0021400356949552272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5160433821421911d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(22026.465794806718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22026L);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-0.016113149763313152d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.8122751623675955E-4d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin((-0.5792260817990332d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6177789716675184d));

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial(42, 89880.15295851197d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 89L);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("b23", "0d47c2e9a4cadefcffd34fea37b8db5ba207e39e12");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var6, 10, 7, 63);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9791175537771886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32768.0f);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     double var11 = var0.nextExponential(1.2905389698182939d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0813279298653886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999996600529159d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3913577383871325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.10186146820582281d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(65.18510402677707d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7050223271581353d));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.007758104443520159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19796353819225385d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000001f);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     java.lang.String var8 = var0.nextHexString(8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 47751.791335180824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "40c4e449"+ "'", var8.equals("40c4e449"));
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var7.nextSample(var17, 13);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     int var9 = var0.nextHypergeometric(428451470, 7, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3686ee3acf", "3f002a4923");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 28.609665147504867d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.9796027457223E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     long var9 = var0.nextPoisson(0.007758104443520159d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGamma(0.0d, 2.968212069455292d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 26.069025533793365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.1167004914510745E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13.328404037793302d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10);
    int var3 = var1.nextInt(428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 350937176);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial((-810646614), 1.7169636292746049d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 78L);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var40 = new int[] { 1, 0, 1};
    var36.setSeed(var40);
    int var42 = var36.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var46 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var36, 10, 4, 9);
    int[] var48 = var46.sample(100);
    int[] var50 = var46.sample(65);
    var34.setSeed(var50);
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var57 = new int[] { 1, 0, 1};
    var53.setSeed(var57);
    int var59 = var53.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var63 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var53, 10, 4, 9);
    int[] var65 = var63.sample(100);
    int[] var67 = var63.sample(65);
    double var69 = var63.cumulativeProbability((-1));
    double var70 = var63.getNumericalMean();
    double var72 = var63.upperCumulativeProbability(9);
    int[] var74 = var63.sample(42);
    var34.setSeed(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0011913680197832047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0011913677379536511d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.93710385249215d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9371038524921493d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, true);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var12 = var11.getNumericalVariance();
    var11.reseedRandomGenerator((-432485425446058487L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     var7.reSeed((-166140055330010418L));
//     double var21 = var7.nextCauchy(0.09975663986204619d, 0.46647993410200317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.770734296545935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.3752346927195682d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.00390625f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.341345202615279d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(55L, (-6116618998156505929L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 55L);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var7.nextWeibull(13.969011016549919d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(3.6574758508329603d, 13.546076278624843d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.546076278624843d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.9969705520480721d, (java.lang.Number)406.4705924790716d, false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.1649950720257549d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.801839672038146d));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(4.170565826393714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.36831833028699d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.4869035278007987d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3247245115809454d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3327.5461746900623d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(10.342682394931924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31029.150952915195d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(65.18510402677707d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1376946885222738d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    java.lang.Number var2 = var1.getMin();
    java.lang.Number var3 = var1.getArgument();
    java.lang.Number var4 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)1+ "'", var3.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)1+ "'", var4.equals((short)1));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.8E-45f, (-23));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(1.8771624283741013E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8771624283741013E-9d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("0008", "6a9a6861b0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.49775480507015946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1264588458117917d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.nextGamma(100.0d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    float var5 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var6.nextHypergeometric(0, 61, 6);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.76195765f);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)20.583749267742867d, (java.lang.Number)0.9999993243506345d, (java.lang.Number)(-96398574));

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.7891391771877577d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.4066076797520086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 23.29690396739707d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     int var9 = var0.nextHypergeometric(428451470, 7, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("54aca0", "a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.579777385457103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.973016950056886E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    int var4 = var2.nextInt();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var7 = var6.nextBoolean();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var21 = new int[] { 1, 0, 1};
    var17.setSeed(var21);
    org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var17);
    byte[] var25 = new byte[] { (byte)10};
    var17.nextBytes(var25);
    var9.nextBytes(var25);
    var6.nextBytes(var25);
    var2.nextBytes(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var33 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, (-810646614), 0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0000001f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    int var10 = var4.nextInt((-6), 10);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var4.nextInt(3, (-4));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.18712617245889246d, 0.001129876315267469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.18712958355001746d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var3 = new int[] { 10};
    var1.setSeed(var3);
    var1.setSeed(1L);
    float var7 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.07277703f);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     double var17 = var0.nextChiSquare(12.140465251696156d);
//     java.lang.String var19 = var0.nextHexString(15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 82L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.293530492821362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46734L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9228868551870015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 17.32951918688061d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "dcc72af70429508"+ "'", var19.equals("dcc72af70429508"));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)6.283185307179586d, false);
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    var4.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(6.3135427094879235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8426969626615404d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    boolean var16 = var11.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var18 = var11.sample((-23));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    int var4 = var2.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(32768.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00390625f);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    byte[] var20 = new byte[] { (byte)10};
    var12.nextBytes(var20);
    var1.nextBytes(var20);
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var25 = var1.nextInt((-52624155));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     int var4 = var0.nextZipf(63, 2.2327048838369965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.016245086893048467d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.016246516085482415d));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(86179.77788266764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86180.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0f), 350937176);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9415740839056164d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7553152061365451d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     int var5 = var0.nextSecureInt(4, 100);
//     org.apache.commons.math3.random.RandomGenerator var6 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextSecureLong(0L, (-414028722650554365L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.7308454365005908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(9.536743E-7f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var18 = var7.nextSecureLong(61L, 11L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.1336149855922958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1429526816705859d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.536743E-7f);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     long var6 = var0.nextPoisson(0.9999993243506345d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(1, (-1549560137));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.7436507393139604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ead8a28a1f"+ "'", var4.equals("ead8a28a1f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7.552633489589084d);
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"+ "'", var3.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 7.553 is smaller than, or equal to, the minimum (0)"));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("", "3686ee3acf");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.18712617245889246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7278654655222002d));

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     double var3 = var0.nextChiSquare(0.6466904717391735d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextSecureInt(0, (-52624155));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.07673520962625457d);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var16 = var7.nextChiSquare(5.804641090815146d);
//     var7.reSeed((-166140055330010418L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var7.nextHypergeometric((-810646614), 24, 13);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 13.047542877083535d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var7.nextBinomial((-2), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(70.08228481062106d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8233259972087809d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)32.36831833028699d, (java.lang.Number)24455.75887001267d, true);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 862.7997795017259d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextExponential(8.97308641465062d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var0.nextLong(91L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.16607997176057543d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.2404374004543741d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-6));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    long var21 = var7.nextLong(0L, 91L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var24 = var7.nextLong(0L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 72L);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.3003053587917186d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3003053587917186d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.328704913108978d, 14.94806722174175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.4121880166367814E7d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.247925452902965d), 32610.097719459052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.826806846853243E-5d));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(65.18510402677707d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 65L);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     java.util.Collection var17 = null;
//     java.lang.Object[] var19 = var7.nextSample(var17, (-4));
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     double var17 = var0.nextChiSquare(12.140465251696156d);
//     var0.reSeedSecure();
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 65);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.968212069455292d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.378315632917706d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 0.07277703f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9964021940844213d, 0.3443874796808435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9987594964776787d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.6287849591819767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8567104181085349d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var7.nextExponential((-1.189520633886725d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    int[] var16 = var11.sample(6);
    double var18 = var11.upperCumulativeProbability(0);
    var11.reseedRandomGenerator(74L);
    var11.reseedRandomGenerator(55L);
    int var23 = var11.sample();
    int var24 = var11.sample();
    int var25 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.7262566507187045d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextGamma((-0.7891391771877577d), 0.8233259972087809d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11475.269060429904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.994773292690594d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9.111402161395537E28d);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.07277703f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.801839672038146d), 63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.6619037645972216E19d));

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     int[] var8 = var0.nextPermutation(61, 7);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, (-96398574));
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var7.nextPascal(14, 584.4833102390261d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.859430599490439d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.3543011903101407d);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.2891073680063085d, 1.4549341288792002d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2891073680063085d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.000001f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9999993243506345d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.6119740461869303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8490064729285955d);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100);
//     int[] var6 = new int[] { 10};
//     var4.setSeed(var6);
//     var1.setSeed(var6);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var9.nextInversionDeviate(var10);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var22 = var7.nextSecureLong(100L, 52L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)61L);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    double var17 = var11.probability(8);
    int var18 = var11.getSupportUpperBound();
    int var19 = var11.sample();
    int[] var21 = var11.sample(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-7.031049078224121d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    long var17 = var7.nextPoisson(1.2012365955976083d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var7.nextUniform(4.352694383675031d, 1.1376946885222738d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3L);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     double var14 = var7.nextUniform(0.27045149498596743d, 4.352694383675031d);
//     long var17 = var7.nextSecureLong(72L, 100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.4447996764224045d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 97L);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    double var19 = var7.nextExponential(1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var7.nextUniform(1.8482997974150024d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.9964021940844213d);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial(8, 26.90872600746492d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.3846777327839117d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.2482223897480536E11d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(4.170565826393714d, (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, (-4), (-93018071), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(31143.40177049524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { 1, 0, 1};
    var6.setSeed(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    java.lang.Object[] var13 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10, var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-3.5816635108956087d), var13);
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var17.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.17453292519943295d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.29353980793136686d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    long var4 = var2.nextLong();
    float var5 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.15595806f);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var4.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.5707963267948966d, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 23.596040842006182d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.054973020182809376d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05651210978738594d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000002f);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    double var20 = var11.probability(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     boolean var2 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-23), (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-96398574));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(45L, 46763L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 45L);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextT(0.09347294900676971d);
    int var9 = var0.nextBinomial(65, 0.9672751717291171d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb((-1.0f), (-23));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.1920929E-7f));

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.7693376445680227d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 2.769 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 2.769 is smaller than, or equal to, the minimum (0)"));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)16822.424193698815d, (java.lang.Number)0.1649950720257549d, false);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.5028092245014826d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-9109855603261136600L));
    var1.setSeed(55L);
    byte[] var7 = new byte[] { (byte)1, (byte)10, (byte)10};
    var1.nextBytes(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var14 = var0.nextExponential(26.468397517010732d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextCauchy(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11795.453201538605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.4326124631243764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 30.334722635735172d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.5701035626714024d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    int var19 = var11.getPopulationSize();
    int var20 = var11.getPopulationSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var11.cumulativeProbability((-1), (-52624155));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.1943367631001946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5792308106225605d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeedSecure();
//     long var14 = var7.nextSecureLong(32L, 100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 56L);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-93018071));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 93018071);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextExponential(306.0196847852814d);
    double var17 = var7.nextCauchy(3.141592653589793d, 1.4869035278007987d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var7.nextUniform(5.403760950865342d, (-0.7262566507187045d), false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 406.4705924790716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 13.546076278624843d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     int var5 = var0.nextInt(4, 65);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 63);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     double var8 = var0.nextUniform((-0.016245086893048467d), 4.641588833612778d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextWeibull((-0.6321205588285577d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8747143898685905d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.9081962454041133d);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(4, 1, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("08a8be8f", "0d47c2e9a4cadefcffd34fea37b8db5ba207e39e12");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     org.apache.commons.math3.random.RandomGenerator var16 = var0.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var0.nextPermutation((-93613120), 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 63261.44429608825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0848651874445825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.5329755491092497E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.1096622711232151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.115901134774571d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.2891073680063085d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.658113963207486d));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)61, (java.lang.Number)2, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.7278654655222002d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6217577265485514d));

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var7.nextGamma(5.514627478466221d, (-0.5693573844758614d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)10.0d);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    var7.reSeed();
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(31029.150952915195d, 1.1752005863472421d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31029.150975170018d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-93613120), 65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 65);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(6.770734296545935d, 81217892);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1, 0, 1};
    var5.setSeed(var9);
    org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
    byte[] var13 = new byte[] { (byte)10};
    var5.nextBytes(var13);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var20 = new int[] { 1, 0, 1};
    var16.setSeed(var20);
    org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var16);
    int var25 = var22.nextZipf(10, 3.141592653589793d);
    double var28 = var22.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var31 = var22.nextPermutation(100, 100);
    var5.setSeed(var31);
    var1.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(var31);
    boolean var35 = var34.nextBoolean();
    double var36 = var34.nextDouble();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var34, (-1), 63, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.6287849591819767d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    int var20 = var11.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.342682394931924d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999979227431d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(3, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.4549341288792002d, 5.555563365755192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.555563365755192d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.2712856473959901d, (java.lang.Number)0.0f, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     org.apache.commons.math3.distribution.RealDistribution var17 = null;
//     double var18 = var7.nextInversionDeviate(var17);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(5.452971374636091E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.4517803089065216E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     java.lang.String var6 = var0.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextT((-119.51102587202428d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.202842060776327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2810ef759c"+ "'", var4.equals("2810ef759c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "36e5c9c488"+ "'", var6.equals("36e5c9c488"));
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var19 = var7.nextHypergeometric(65, 13, 3);
//     var7.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var7.nextUniform(12.140465251696156d, 1.4869035278007987d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var11.cumulativeProbability(63, (-194062463));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    var0.reSeed((-166140055330010418L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextZipf(2, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9999999979227431d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7853981623588199d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.016113149763313152d), (java.lang.Number)6.283185307179586d, (java.lang.Number)22.414949260270113d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    int var18 = var11.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 7.621133953612494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.538842383511958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9317082226199355d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.000001f, 2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextGaussian(0.31834230895305893d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     int var17 = var7.nextBinomial(8, 0.0d);
//     var7.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var19 = null;
//     double var20 = var7.nextInversionDeviate(var19);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(5.452971374636091E7d, 20.34275247523163d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.570795953736777d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     double var15 = var0.nextUniform(16.853135916639044d, 2.2560527698684258E29d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextGamma(3.328704913108978d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 77671.94042269867d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.47107792278817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.8928983190456228E29d);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.08426832637046788d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.43841774391598476d);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     var0.reSeedSecure(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal((-96398574), 0.9969705520480721d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 11.562323216722463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 431.2744189549313d);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(6.606748390165169d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.60674839016517d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextT(0.19767649048318184d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var7.nextSecureInt(350937176, 65);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.5792260817990332d));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.9987594964776787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7610726839071428d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(6.283185307179586d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 534.4916555247646d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.8773824271569775d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.070379039193733d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var2 = var0.nextPoisson(3.6d);
//     double var5 = var0.nextF(0.7553717358309021d, 0.7037513723270065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.1675310595357129d);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     var7.reSeed();
//     double var13 = var7.nextGaussian(0.7426404527543018d, 19.591610988479747d);
//     double var16 = var7.nextUniform(5.555563365755192d, 8.97308641465062d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.1789698445394334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 6.913801585216292d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.4517803089065216E30d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2048984641481295E15d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.539292122333146E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5392921223331462E-5d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var7.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999f));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportUpperBound();
    double var18 = var11.upperCumulativeProbability(7);
    double var19 = var11.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.24d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9228868551870015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.516544814112052d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    int var13 = var11.getPopulationSize();
    double var14 = var11.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var11.cumulativeProbability(15, 8);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.6d);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextF(12.140465251696156d, 1.1935683377421018d);
//     int[] var22 = var7.nextPermutation(8, 7);
//     double var25 = var7.nextCauchy(26.468397517010732d, 0.7816736683885532d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var7.nextBinomial((-2), 1.7281579281775712d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.866658532629791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 34.92722120781139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 14.149604402178575d);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(2.8E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    var7.reSeedSecure();
    double var18 = var7.nextF(89880.15295851197d, 6840.77334039907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextSecureInt(69, (-93018071));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0103627457703912d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0f, 0.02069733480244646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.7278654655222002d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9241727673330036d));

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform(5.3360106650016d, 1079.5810741532396d, false);
//     double var9 = var0.nextCauchy(4.284201251169182d, 0.9415740839056164d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(104.72186504908284d, (-0.016114544521814232d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 170.90823580276012d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 28.919001251638342d);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)1);
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Object[] var4 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var4);
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     var2.clear();
//     int var4 = var2.nextInt();
//     int var6 = var2.nextInt(42);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var11 = var8.nextSecureInt(0, 10);
//     int[] var14 = var8.nextPermutation(42, 3);
//     var2.setSeed(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var9 = new int[] { 1, 0, 1};
//     var5.setSeed(var9);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var5);
//     java.lang.Object[] var12 = new java.lang.Object[] { var5};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)10, var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var12);
//     org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var15);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.49775480507015946d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4039671901691459d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.0f), (-0.99999994f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextExponential(306.0196847852814d);
    double var17 = var7.nextCauchy(3.141592653589793d, 1.4869035278007987d);
    var7.reSeed(60L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 406.4705924790716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 13.546076278624843d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (-1.1920929E-7f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(22026.465794806718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    int var18 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.770734296545935d, (-3.826806846853243E-5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.2104769607016383E-6d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(7.379921727179645d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var1 = var0.toString();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var1.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextExponential(306.0196847852814d);
    double var17 = var7.nextCauchy(3.141592653589793d, 1.4869035278007987d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var19 = var7.nextHexString((-10));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 406.4705924790716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 13.546076278624843d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7037513723270065d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7806640867181274d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-3.826806846853243E-5d), (java.lang.Number)(-0.4195903379527587d), (java.lang.Number)0.07020221590414388d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.3088437356800402E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.077258393765406E9d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     double var6 = var0.nextBeta(0.24d, 3.328704913108978d);
//     double var8 = var0.nextExponential(6.4121880166367814E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0012314856832879519d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.895955297262974E7d);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextT(0.09347294900676971d);
    int var9 = var0.nextBinomial(65, 0.9672751717291171d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextZipf(0, 0.1719246526310684d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    var11.reseedRandomGenerator(1L);
    double var20 = var11.cumulativeProbability(42, 69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.2905389698182939d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)7.552633489589084d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000002f);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.05361446892311553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     double var7 = var0.nextCauchy(0.3003053587917186d, 4.850588148931125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.318476422252055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0cb8e60b79"+ "'", var4.equals("0cb8e60b79"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.12660232803252297d));
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-1.801839672038146d), 9.492547179491174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var7.nextUniform(1.986281309696751d, 0.41251696324654447d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var30 = var1.nextLong((-432485425446058487L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var11 = new int[] { 1, 0, 1};
    var7.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
    java.lang.Object[] var14 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.0d, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var14);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var10 = new byte[] { (byte)(-1), (byte)10};
    var1.nextBytes(var10);
    float var12 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0997566f);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var19 = var7.nextHypergeometric(65, 13, 3);
//     double var22 = var7.nextGamma(101.46617535658866d, 2.497498709678805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 248.3433089416754d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.619271173180935d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     double var2 = var1.nextDouble();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(100);
//     int[] var6 = new int[] { 10};
//     var4.setSeed(var6);
//     var1.setSeed(var6);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var12 = var9.nextSecureInt((-96398574), 6);
//     double var14 = var9.nextChiSquare(26.90872600746492d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var9.nextZipf(0, 4.318476422252055d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.40877566087838346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-14544403));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 31.740272484770454d);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     double var9 = var0.nextExponential(1.2905389698182939d);
//     double var11 = var0.nextExponential(1.2905389698182939d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta(0.17453292519943295d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.30563311397776d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999995689821259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6165432798201775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6035549610992802d);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.9209536856213183d, (java.lang.Number)9, false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, (-1549560137));
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var18 = var11.getNumericalMean();
    double var20 = var11.upperCumulativeProbability(9);
    double var23 = var11.cumulativeProbability(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3L);
    java.lang.Number var2 = var1.getArgument();
    java.lang.Number var3 = var1.getMin();
    java.lang.Number var4 = var1.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 3L+ "'", var2.equals(3L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(86179.77788266764d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7.552633489589084d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var2.nextLong(82L, 25L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(26.468397517010732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.09347294900676971d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var13 = new int[] { 1, 0, 1};
    var9.setSeed(var13);
    org.apache.commons.math3.random.RandomDataImpl var15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var9);
    java.lang.Object[] var16 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)10, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9995149440000322d, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2.726066212978514E-4d, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(6.929625337259191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6341189315679165d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(61L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61L);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(6.061046620561879E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int var2 = var0.nextInt(10);
//     long var3 = var0.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var6 = var4.nextExponential(10.0d);
//     double var9 = var4.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     int[] var12 = var4.nextPermutation(61, 7);
//     var0.setSeed(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1369798007726508792L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.732128407749153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 238925.01314861703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.46647993410200317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.44974510690998637d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportUpperBound();
    int var17 = var11.getSupportUpperBound();
    double var19 = var11.cumulativeProbability((-6));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.016113149763313152d), 5.452971374636091E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.452971374636091E7d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.4066076797520086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.38558850872182215d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(5.726911865353372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0d);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     java.lang.Number var12 = var4.getMax();
//     java.lang.String var13 = var4.toString();
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5148.282084813554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(0, 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 20);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.8825395169829676d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000002f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(38.42983716254903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     double var11 = var0.nextGamma(4.850588148931125d, 0.47355289240887427d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf(0, 1.1376946885222738d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 13.523530630999616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 782654.812479884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2.8079432819709034d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7865952912591581d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(862.7997795017259d, 46836.09140422274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 862.7997795017259d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4.055908274771898d, 0.6119740461869303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.055908274771898d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.8773824271569775d, (java.lang.Number)86179.77788266764d, true);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.33115294219320335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1051749493157323d));

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var7 = var0.nextChiSquare(0.1429526816705859d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var0.nextLong(2876919108950029338L, 11L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextBeta(13.969011016549919d, 99.99999999999999d);
//     var7.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.804641090815146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.461518408584977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.12033121762809897d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    double var13 = var11.upperCumulativeProbability(0);
    int var14 = var11.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 10);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var10 = new int[] { 1, 0, 1};
    var6.setSeed(var10);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var6);
    java.lang.Object[] var13 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)10, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2, (java.lang.Number)72L, false);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(15);
    var1.setSeed((-1549560137));
    var1.setSeed((-194062463));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextGamma(43.19990300454566d, 2.4683048930644915d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var7.nextWeibull(1.5701035626714024d, (-7.0362356667574275d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 101.46617535658866d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-2757668752704241422L), (-6116618998156505929L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6116618998156505929L));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    double var16 = var7.nextChiSquare(93649.84672246638d);
    var7.reSeed(91L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var7.nextInt(63, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 93452.71554851689d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.1675310595357129d, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 42.8879512411425d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9987594964776787d, false);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextChiSquare((-0.7278654655222002d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 42258.73220570962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.3603663443740888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    double var22 = var7.nextExponential(41.41942533978215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.611121515496936d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var11 = new int[] { 1, 0, 1};
    var7.setSeed(var11);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var7);
    java.lang.Object[] var14 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)10, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.0d, var14);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, var14);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var25 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var21, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var26 = var25.getArgument();
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var31 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var27, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    var25.addSuppressed((java.lang.Throwable)var31);
    org.apache.commons.math3.exception.util.ExceptionContext var33 = var31.getContext();
    boolean var34 = var31.getBoundIsAllowed();
    var19.addSuppressed((java.lang.Throwable)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (byte)(-1)+ "'", var26.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    double var9 = var0.nextExponential(0.2712856473959901d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextInt(7, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.049816982749194494d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-10), 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.801839672038146d), 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 130113.66062120028d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    double var17 = var7.nextWeibull(24329.65241188829d, 22026.465794806718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 22027.245958282594d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    boolean var20 = var11.isSupportConnected();
    int var22 = var11.inverseCumulativeProbability(0.5028092245014826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-0.9999999f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var18 = var7.nextInt((-6), 15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var7.nextPascal(9, 1.2048984641481295E15d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-5));
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var7.nextUniform(406.4705924790716d, 3.141592653589793d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.055684390990072566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.055742016949076274d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(22026L, 74L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 74L);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.1719246526310684d, 7.552633489589084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1719246526310684d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(14);
    double var16 = var11.cumulativeProbability(69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.02239904561084646d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.533809723277221d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2950257526489923d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(130113.66062120028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextInt(25, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var19 = var7.nextGaussian(14.94806722174175d, 38.42983716254903d);
    double var21 = var7.nextT(0.9415740839056164d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var7.nextUniform(31143.40177049524d, 0.9964021940844213d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-7.879966881943199d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.5693573844758614d));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    boolean var2 = var1.nextBoolean();
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(5, 6.283185307179586d);
//     var0.reSeedSecure(9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.932065588732449d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4590.184143762931d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     double var8 = var0.nextCauchy(0.0d, 1.7169636292746049d);
//     org.apache.commons.math3.random.RandomGenerator var9 = var0.getRandomGenerator();
//     int var12 = var0.nextBinomial(10, 0.29353980793136686d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 11.697805220740092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.10611555608461332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.4995328008980024d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.probability(10);
    int var18 = var11.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeed(0L);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8.956000617180518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.728413450840646E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13.8991622542805d);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023));

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(31143.40177049524d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2147483647, 63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     java.lang.String var4 = var0.nextHexString(10);
//     double var7 = var0.nextGamma(16822.424193698815d, 1.4549341288792002d);
//     var0.reSeedSecure(5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.491512737473852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "772941b87d"+ "'", var4.equals("772941b87d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24040.441826167375d);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.46647993410200317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     int var5 = var0.nextSecureInt(1, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextGamma(3327.545661366997d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(4.284201251169182d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07477341765096279d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.6119740461869303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8185155547291311d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-10));

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(144.26931954487853d, 4.352694383675031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.5016380332821193E9d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    int var11 = var1.nextInt();
    double var12 = var1.nextGaussian();
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var15 = var14.nextBoolean();
    int var16 = var14.nextInt();
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    org.apache.commons.math3.random.RandomDataImpl var24 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var18);
    byte[] var26 = new byte[] { (byte)10};
    var18.nextBytes(var26);
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var33 = new int[] { 1, 0, 1};
    var29.setSeed(var33);
    org.apache.commons.math3.random.RandomDataImpl var35 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var29);
    int var38 = var35.nextZipf(10, 3.141592653589793d);
    double var41 = var35.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var44 = var35.nextPermutation(100, 100);
    var18.setSeed(var44);
    var14.setSeed(var44);
    org.apache.commons.math3.random.Well19937c var47 = new org.apache.commons.math3.random.Well19937c(var44);
    var1.setSeed(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.1719246526310684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-118603794));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    double var17 = var7.nextCauchy(13.546076278624843d, 22026.465794806718d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 72634.19882825635d);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF((-0.9241727673330036d), 60.28026284097294d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.839166805432682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.6398854429223877E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13.486724185068281d);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.13829574457526012d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    long var5 = var1.nextLong(3L);
    long var7 = var1.nextLong(60L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 25L);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.182880077234183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.182880077234183d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeedSecure();
    int var14 = var7.nextZipf(9, 93649.84672246638d);
    double var16 = var7.nextChiSquare(93649.84672246638d);
    var7.reSeed(91L);
    double var21 = var7.nextWeibull(99.99999999999999d, 16.51038740791099d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 93452.71554851689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 16.385703183210563d);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(406.4705924790716d, 0.8307659113974537d);
//     double var6 = var0.nextBeta(31143.40177049524d, 12.236902640271552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.891704828860318d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9996261151355865d);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var13 = var10.getContext();
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError();
//     org.apache.commons.math3.exception.util.ExceptionContext var19 = var18.getContext();
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var30 = new int[] { 1, 0, 1};
//     var26.setSeed(var30);
//     org.apache.commons.math3.random.RandomDataImpl var32 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var26);
//     java.lang.Object[] var33 = new java.lang.Object[] { var26};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var34 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var24, var33);
//     org.apache.commons.math3.exception.NotFiniteNumberException var35 = new org.apache.commons.math3.exception.NotFiniteNumberException(var22, (java.lang.Number)10, var33);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var36 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var21, var33);
//     org.apache.commons.math3.exception.MathIllegalStateException var37 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var20, var33);
//     org.apache.commons.math3.exception.NotFiniteNumberException var38 = new org.apache.commons.math3.exception.NotFiniteNumberException(var16, (java.lang.Number)1.2905389698182939d, var33);
//     org.apache.commons.math3.exception.MathIllegalStateException var39 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, var33);
//     org.apache.commons.math3.exception.MathIllegalStateException var40 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var14, var33);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    double var19 = var7.nextGaussian(14.94806722174175d, 38.42983716254903d);
    double var21 = var7.nextT(0.9415740839056164d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var24 = var7.nextSecureLong(85L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-7.879966881943199d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.5693573844758614d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var3 = var1.nextLong();
    var1.setSeed(91L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-414028722650554365L));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(6.60674839016517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.0d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.3253809740926889d, 1.0713856867035541E32d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-65.68792148528178d));

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.02601447842813017d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.4039671901691459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39371623903891373d);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     double var14 = var7.nextF(25.21435585163038d, 2058461.3166939607d);
//     double var17 = var7.nextUniform(0.0d, 0.9987594964776787d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var7.nextSample(var18, 10);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    int var4 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    int var6 = var2.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 60481539);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.999999998129049d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.794E-43f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.794E-43f);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform(6840.77334039907d, 8.768916560445668d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 58773.5114830959d);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    int var4 = var2.nextInt();
    int var6 = var2.nextInt(42);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    int var8 = var2.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 669834927);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    boolean var15 = var11.isSupportConnected();
    int var16 = var11.getSupportUpperBound();
    int var17 = var11.getPopulationSize();
    double var19 = var11.upperCumulativeProbability((-93018071));
    int var20 = var11.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 9);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(26.94414842759192d, (-4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.684009276724495d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-23));
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextSecureInt(100, 61);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)3.141592653589793d, true);
    java.lang.Number var5 = var4.getArgument();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)(-1)+ "'", var5.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(5.804641090815146d);
//     double var5 = var0.nextUniform(0.27045149498596743d, 6840.77334039907d);
//     int var8 = var0.nextZipf(5, 6.283185307179586d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(1L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6082067064864886d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5167.435862281198d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2246467991473532E-16d);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     long var5 = var0.nextPoisson(248.3433089416754d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 254L);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(7.552633489589084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.881784197001252E-16d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.4869035278007987d, 0.07477341765096279d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0301066080631203d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(70.08228481062106d, 65.58336876857805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9843875149634705d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var4 = var0.nextCauchy(1.32662446455161d, 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 44.83548874338596d);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.93710385249215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9371038524921502d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2.6649762425333257d));

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)130113.66062120028d, (java.lang.Number)0.4574326092991893d, true);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int var12 = var11.getNumberOfSuccesses();
    double var14 = var11.probability(10);
    int var15 = var11.getPopulationSize();
    double var16 = var11.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 3.6d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0f);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.9292273298132443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1923162405546828d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    double var4 = var0.nextExponential(0.3443874796808435d);
    double var6 = var0.nextT(0.09347294900676971d);
    int var9 = var0.nextBinomial(65, 0.9672751717291171d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var0.nextLong(2876919108950029338L, 1930906741579263412L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4574326092991893d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.337903735516005E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 63);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.3474657337831263d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4154758067826922d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(86180.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86180.0d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var16.nextHypergeometric(0, 0, 16);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)2.93710385249215d, (java.lang.Number)0.8307659113974537d, true);
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.982441812995697E30d, (java.lang.Number)85L, false);
    var3.addSuppressed((java.lang.Throwable)var7);
    boolean var9 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric((-2), (-93613120), 24);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.1397247292885222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999999219068538d);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1930906741579263412L);
    boolean var2 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(24455.75887001267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("774e5780dc", "3f002a4923");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.055742016949076274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var1.nextLong((-432485425446058487L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.461816101240877d);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(26.90872600746492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(2.220446049250313E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4092822771139013d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-0.016114544521814232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    double var13 = var7.nextGaussian(0.0d, 2.220446049250313E-16d);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSecureAlgorithm("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b", "774e5780dc");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.4597135858742798E-16d));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.4597135858742798E-16d), Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4597135858742798E-16d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var7 = var4.nextCauchy(0.41251696324654447d, 1.5607966601082315d);
    int var10 = var4.nextInt((-6), 10);
    var4.reSeedSecure();
    long var13 = var4.nextPoisson(26.94414842759192d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 22.511131074500152d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 23L);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.4574326092991893d, 0.4039671901691459d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4574326092991892d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-93018071), 61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.4326677757426955d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.79003748136923d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    int var7 = var0.nextZipf(10, 2147.432395050844d);
    double var9 = var0.nextExponential(0.2712856473959901d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextSecureInt(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.049816982749194494d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    double var9 = var0.nextChiSquare(2.3283064365386963E-10d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.nextInt((-23), (-1549560137));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.8771624283741013E-9d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    double var14 = var7.nextT(0.19767649048318184d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextUniform(1.1574479291749462E10d, Double.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.5792260817990332d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    double var11 = var7.nextExponential(0.15015415474359342d);
    var7.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var7.nextHypergeometric((-93018071), (-118603794), 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.09347294900676971d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.6341189315679165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.634118931567917d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(4.096342788157551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.05169001350385d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextWeibull(0.1096622711232151d, 2058461.314264962d);
//     int[] var8 = var0.nextPermutation(61, 7);
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     var9.setSeed((-4));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.570160841992396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.2845301529959981E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.33115294219320335d, (java.lang.Number)1024.0f, false);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9241727673330036d), (-0.12660232803252297d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9241727673330036d));

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int var3 = var1.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 60481539, 3, (-1120319269));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-118603794));

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)43.19990300454566d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     double var16 = var7.nextUniform(2.537297501373361d, 6.3135427094879235d);
//     double var19 = var7.nextBeta(13.969011016549919d, 99.99999999999999d);
//     org.apache.commons.math3.distribution.IntegerDistribution var20 = null;
//     int var21 = var7.nextInversionDeviate(var20);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     var0.reSeed();
//     var0.reSeed(0L);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var0.nextSample(var16, 3);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var7.nextWeibull((-1.4597135858742798E-16d), 130113.66062120028d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.2012365955976083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var1 = null;
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    double var12 = var7.nextWeibull(0.001129876315267469d, 0.9964021940844213d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var7.nextHypergeometric((-1023), 63, 428451470);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.2190167037857677E196d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed(10L);
    double var5 = var0.nextExponential(0.3961916630178961d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5262415067028997d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
    var7.reSeed(10L);
    java.lang.String var14 = var7.nextHexString(100);
    int var17 = var7.nextInt(8, 13);
    double var20 = var7.nextCauchy(10.201158186626492d, 2058461.3166939607d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var22 = var7.nextSecureHexString((-1120319269));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 5.804641090815146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"+ "'", var14.equals("1d0525e8aae8febb0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c521ef005c568febacfc31fc87faf2b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1592294.6908971414d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.0d, (java.lang.Number)4.611121515496936d, var3);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.1858699313494176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.782013887229037d);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var4 = var0.nextChiSquare(5.726911865353372d);
//     double var6 = var0.nextExponential(6.283185307179586d);
//     org.apache.commons.math3.random.RandomGenerator var7 = var0.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.9960027976498926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3341399772629092d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    double var13 = var7.nextBeta(5.804641090815146d, 0.27045149498596743d);
    double var16 = var7.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var22 = new int[] { 1, 0, 1};
    var18.setSeed(var22);
    int var24 = var18.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var28 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 10, 4, 9);
    int var29 = var28.getSupportUpperBound();
    int var30 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var28);
    double var31 = var28.getNumericalVariance();
    int var32 = var28.getSupportUpperBound();
    boolean var33 = var28.isSupportConnected();
    int var34 = var28.getSampleSize();
    double var36 = var28.upperCumulativeProbability(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.2895855093964026d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-432485425446058487L));

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.7281779665864416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8916416084699902d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-2), 93018071);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(86180.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    java.lang.Object[] var19 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)10, var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var19);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var3, var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(20.66124363087071d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4.070639049858762d));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    double var7 = var0.nextCauchy(93648.04747608298d, 1.87731868091954d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 93649.84672246638d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.30913758f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.30913758f);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.999999753342362d, 1041.37115449346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1041.37115449346d);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(8.116217376679442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(69, (-52624155), (-93018071));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.09942769605832733d, 14.94806722174175d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.034362739798913E-15d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(7.621133953612494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.13301388022607083d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.2633630179028634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5372975013733616d);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var4 = var0.nextExponential(1.0d);
//     double var7 = var0.nextBeta(2058461.314264962d, 1.5318819596985707d);
//     var0.reSeedSecure((-6116618998156505929L));
//     double var11 = var0.nextExponential(0.999999753342362d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.41163626780150286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9999979652231713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2645086695827112d);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure((-1L));
//     var7.reSeed();
//     double var13 = var7.nextGaussian(0.7426404527543018d, 19.591610988479747d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var7.nextSecureHexString((-93613120));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-33.559965522338274d));
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    int var7 = var1.nextInt();
    org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 10, 4, 9);
    int[] var13 = var11.sample(100);
    int[] var15 = var11.sample(65);
    double var17 = var11.cumulativeProbability((-1));
    double var19 = var11.probability((-6));
    int var20 = var11.getPopulationSize();
    int var21 = var11.getNumberOfSuccesses();
    double var23 = var11.cumulativeProbability(350937176);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-810646614));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-2757668752704241422L));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(4.940878138553293d, 0.9843875149634705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.940878138553293d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(3.093721944405666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(96.06190599231006d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.564992837725344d);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     double var8 = var0.nextUniform((-0.016245086893048467d), 4.641588833612778d);
//     var0.reSeedSecure(52L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextF(0.0d, (-3.826806846853243E-5d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.5663535815471356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5948591513122125d);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.638820928472139E-17d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.6388209284721384E-17d);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed(10L);
//     double var4 = var0.nextExponential(0.3443874796808435d);
//     double var6 = var0.nextT(0.09347294900676971d);
//     int var9 = var0.nextSecureInt(9, 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4574326092991893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.337903735516005E10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 13);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)0.9995149440000322d, (java.lang.Number)12.236902640271552d);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    java.lang.Object[] var19 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var10, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)10, var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1.2905389698182939d, var19);
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.93710385249215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(0, 10);
//     var0.reSeedSecure();
//     long var7 = var0.nextSecureLong(3L, 100L);
//     double var10 = var0.nextUniform(0.0d, 2.0d);
//     long var12 = var0.nextPoisson(46836.09140422274d);
//     double var15 = var0.nextBeta(3.2150924088272843d, 0.9999996064388104d);
//     int var18 = var0.nextInt((-96398574), 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 83L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5231009852891018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 47314L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.3949989350821404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-8406519));
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.192093E-7f);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-52624155), 9, (-52624155));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.7281579281775712d, 15.22621231266953d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.11301524106650007d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    int var11 = var1.nextInt();
    double var12 = var1.nextGaussian();
    var1.setSeed((-194062463));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.1719246526310684d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0L, (java.lang.Number)1.3514488136855796d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.3514488136855796d+ "'", var4.equals(1.3514488136855796d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2058461.3166939607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure(10L);
    var0.reSeed(0L);
    long var6 = var0.nextPoisson(0.31834230895305893d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var0.nextPascal(16, 3.4447996764224045d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(46925L, 91L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 91L);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.8176795340571648d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.335737920591789d));

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(4, 1, 1);
//     int var8 = var0.nextZipf(4, 8.97308641465062d);
//     double var11 = var0.nextGaussian(0.9292273298132443d, 26.90872600746492d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(8, (-52624155), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.6905864152733461d);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(41.41942533978215d, 0.6119740461869303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.1318738927017994d));

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.07277703f);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)12.236902640271552d, (java.lang.Number)(byte)1, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    int var14 = var7.nextInt(1, 4);
    int var17 = var7.nextBinomial(8, 0.0d);
    var7.reSeed((-414028722650554365L));
    long var21 = var7.nextPoisson(1.2012365955976083d);
    var7.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var7.nextWeibull((-0.016246516085482415d), 1.2404374004543741d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0L);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     org.apache.commons.math3.random.RandomGenerator var1 = var0.getRandomGenerator();
//     org.apache.commons.math3.random.RandomGenerator var2 = var0.getRandomGenerator();
//     double var6 = var0.nextUniform((-36.04365338911715d), 93649.84672246638d, false);
//     double var9 = var0.nextWeibull(0.9995149440000322d, 3.882579444988825d);
//     int var12 = var0.nextBinomial(13, 0.3010299956639812d);
//     var0.reSeed();
//     int var16 = var0.nextPascal(9, 0.8307659113974537d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var0.nextSecureLong(9223372036854775807L, (-6116618998156505929L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 91569.05576498932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.211346422336481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(6, (-1), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 16.216404361292874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.4814130964324707E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7250909482896571d);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(15);
    var1.clear();

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var10 = var7.nextZipf(10, 3.141592653589793d);
    var7.reSeedSecure();
    double var14 = var7.nextF(25.21435585163038d, 2058461.3166939607d);
    double var17 = var7.nextUniform(0.0d, 0.9987594964776787d);
    double var20 = var7.nextF(0.40877566087838346d, 0.09347294900676971d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var23 = var7.nextBinomial(24, 10.732128407749153d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.2012365955976083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.60794615935029d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 16.51038740791099d);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeedSecure(10L);
//     double var5 = var0.nextWeibull(2.2891073680063085d, 0.9292273298132443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextZipf((-127), 2.092704808311689d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4535922286928695d);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(13.8991622542805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.0d);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.115901134774571d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9999992310258898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(3.141592653589793d, 10.0d);
//     var7.reSeed(10L);
//     var7.reSeed();
//     var7.reSeedSecure();
//     double var18 = var7.nextUniform(0.3443874796808435d, 2.537297501373361d, true);
//     org.apache.commons.math3.distribution.RealDistribution var19 = null;
//     double var20 = var7.nextInversionDeviate(var19);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var7.reSeedSecure((-1L));
    int[] var12 = var7.nextPermutation(100, 8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    long var15 = var13.nextLong(55L);
    int var16 = var13.nextInt();
    boolean var17 = var13.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 14L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1120319269));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.1920929E-7f, 0.30913758f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.30913758f);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextUniform(1.87731868091954d, 3.982441812995697E30d);
//     double var7 = var0.nextExponential(25.68447716417873d);
//     var0.reSeedSecure();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.384683190607213d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.2135895306869311E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.27639597893080103d);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.15595806f, 60.28026284097294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.15595807f);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.9528550936606419d, 428451470);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.352694383675031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 77.6875011190186d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.0f);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var2.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var5 = new int[] { 1, 0, 1};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    byte[] var9 = new byte[] { (byte)10};
    var1.nextBytes(var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var16 = new int[] { 1, 0, 1};
    var12.setSeed(var16);
    org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var12);
    int var21 = var18.nextZipf(10, 3.141592653589793d);
    double var24 = var18.nextBeta(5.804641090815146d, 0.27045149498596743d);
    int[] var27 = var18.nextPermutation(100, 100);
    var1.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var32 = new int[] { 10};
    var30.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var39 = new int[] { 1, 0, 1};
    var35.setSeed(var39);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var44 = new int[] { 10};
    var42.setSeed(var44);
    var35.setSeed(var44);
    var30.setSeed(var44);
    var1.setSeed(var44);
    float var49 = var1.nextFloat();
    double var50 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.9995149440000322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.76195765f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.041888119963332d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(25.68447716417873d, 534.4916555247646d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 534.4916555247646d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(9.151280024146605d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.151280024146605d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    boolean var2 = var1.nextBoolean();
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    var1.setSeed(var4);
    var1.setSeed(1930906741579263412L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextExponential(10.0d);
//     double var5 = var0.nextGamma(100.0d, 1.0763035517091262E30d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation((-194062463), 30);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 13.817717374798768d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.1464943045623411E32d);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed(10L);
    java.lang.String var4 = var0.nextHexString(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d0525e8aae8feb"+ "'", var4.equals("1d0525e8aae8feb"));

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1113.1943527767144d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.181547729533909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1815477295339092d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var5 = new int[] { 1, 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var10 = var7.nextZipf(10, 3.141592653589793d);
//     var7.reSeedSecure();
//     int var14 = var7.nextInt(1, 4);
//     var7.reSeed();
//     int var18 = var7.nextInt((-6), 15);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var24 = new int[] { 1, 0, 1};
//     var20.setSeed(var24);
//     org.apache.commons.math3.random.RandomDataImpl var26 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var20);
//     int var29 = var26.nextZipf(10, 3.141592653589793d);
//     double var32 = var26.nextBeta(5.804641090815146d, 0.27045149498596743d);
//     double var35 = var26.nextUniform((-0.5440211108893698d), 2.4683048930644915d);
//     org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var41 = new int[] { 1, 0, 1};
//     var37.setSeed(var41);
//     int var43 = var37.nextInt();
//     org.apache.commons.math3.distribution.HypergeometricDistribution var47 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var37, 10, 4, 9);
//     int var48 = var47.getSupportUpperBound();
//     int var49 = var26.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var47);
//     double var50 = var47.getNumericalVariance();
//     int var51 = var47.getSupportUpperBound();
//     boolean var52 = var47.isSupportConnected();
//     int var53 = var47.getSampleSize();
//     int var54 = var7.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var47);
//     int[] var56 = var47.sample(14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.9995149440000322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1.2895855093964026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-810646614));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.24d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)4.461518408584977d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(61, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.0000001f, 2.20165534752854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000002f);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)3.6388209284721384E-17d, (java.lang.Number)(-0.6217577265485514d));

  }

}
