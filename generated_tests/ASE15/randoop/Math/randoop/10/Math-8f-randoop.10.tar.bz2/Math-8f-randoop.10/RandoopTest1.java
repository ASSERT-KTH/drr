
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1010.0d, (java.lang.Object[])var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var11, false);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)13L, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var14 = var1.nextBeta(0.002349480672631077d, 210.92556641937855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4467128375208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 78.29985619497148d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 18.93738076039688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure((-414028722650554365L));
//     double var15 = var0.nextT(97.96410453789858d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextPascal(2, (-37.441946953176824d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 214.93416814096457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "68da2d1d15"+ "'", var9.equals("68da2d1d15"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7169891422427604d);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    var0.setSeed((-1));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    double[] var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 0.0d);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.21819979512271087d), (java.lang.Number)79.25588231908337d, 2);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 79.25588231908337d+ "'", var4.equals(79.25588231908337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 79.25588231908337d+ "'", var5.equals(79.25588231908337d));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var18, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var27, var35);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var17, var35);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var39, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    boolean var50 = org.apache.commons.math3.util.MathArrays.checkOrder(var46, var47, false, false);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var51);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var61 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeDivide(var58, var61);
    org.apache.commons.math3.util.MathArrays.checkOrder(var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var51, var63);
    double[] var67 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var70 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var67, var70);
    double[] var73 = new double[] { };
    double[] var75 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var73, var75);
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeAdd(var67, var75);
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var75, var81, true);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var51, var75);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var46, var75);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var75);
    double var87 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 1.0d);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1667864798);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, 2147483647);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
//     long var11 = var5.nextSecureLong(100L, 152600911433040288L);
//     var5.reSeed((-190865323983646368L));
//     double var15 = var5.nextChiSquare(23.41031146092985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-414028722650554365L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 606.9017688960619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6066523849031269L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 34.42327651958706d);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     double var12 = var1.nextGamma(0.1928598019429595d, 0.2861352605845807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3280556153295825L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.03128256092855926d);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     var0.reSeed(152600911433040288L);
//     double var16 = var0.nextUniform(1.5957881318373452d, 211.607835419992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-159.76552048924424d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2385054915770946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.17149026238833906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 110.89451131356839d);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    int[] var8 = new int[] { 100};
    int[] var10 = new int[] { 100};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var10);
    int[] var16 = new int[] { 100};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var16);
    var2.setSeed(var16);
    int[] var21 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
    org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var21);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    byte[] var5 = new byte[] { };
    var2.nextBytes(var5);
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     double var15 = var0.nextGaussian(0.01360821383479298d, 98.78946634923011d);
//     double var17 = var0.nextExponential(263.1966961055d);
//     double var19 = var0.nextExponential(10.022332172410472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 88.15402739841298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.266224756383808d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.8108077325299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-75.73464216245455d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 79.16073610760711d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 21.75923163002327d);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.2683148062047325d, 2.1202883854072287d, 315951.04828560806d, 9862.916937121827d, 183.75983595296293d, 271.97770974580874d, 204.0345260030692d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.1162489245857506E9d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    boolean var30 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var28, true);
    double[] var31 = new double[] { };
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var31, var33);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var31, var37);
    double[] var40 = new double[] { };
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var40, var42);
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var40, var46);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var46, var49, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var46, var53, false);
    double[] var56 = new double[] { };
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var56, var62);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeDivide(var46, var62);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var46);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var67);
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var6, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 100.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    double var3 = var0.nextDouble();
    float var4 = var0.nextFloat();
    float var5 = var0.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.6709920656782435d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.81482935f);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    long[] var2 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double[] var5 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var8 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var8);
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeDivide(var5, var8);
//     double[] var11 = new double[] { };
//     double[] var13 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var13);
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var11, var13);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var13);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var20 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var10, var13);
//     double var22 = var20.density(99.02988657003175d);
//     boolean var23 = var20.isSupportUpperBoundInclusive();
//     double var25 = var20.probability(263.1966961055d);
//     boolean var26 = var20.isSupportUpperBoundInclusive();
//     var20.reseedRandomGenerator((-4848980640512349401L));
//     double var29 = var20.getSupportUpperBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.0d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.2000918311981499d, (java.lang.Number)(-0.3825598013031125d), false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(247.92369202626887d, 284.941661635924d, 5289.984619604681d, 0.0d, 0.8148294445871034d, 99.33168725200979d, (-1.6717906599940322d), 203.21393087615945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 70384.99599681215d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     var1.reSeedSecure();
//     long var17 = var1.nextSecureLong(0L, 259766232686583471L);
//     double var20 = var1.nextF(117.67233364565794d, 34.42327651958706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.41314575899459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 97.20990205617449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 82.29253582157449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 623.7618277857923d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 95718881548815280L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.4222226581896908d);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     int[] var10 = var0.nextPermutation(9, 4);
//     double var12 = var0.nextT(284.941661635924d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt((-1), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 197.78950906740658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.8510850692253282d));
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
//     var6.setSeed(259766232686583471L);
//     double var9 = var6.nextDouble();
//     var6.setSeed(106L);
//     double[] var12 = new double[] { };
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14, var17, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var21 = new double[] { };
//     double[] var23 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var21, var23);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var26 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var23, var26, false);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var23);
//     double[] var30 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var31 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var6, var23, var30);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    var3.setSeed(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0737206121073526d, (java.lang.Number)9.95645506445408d, (java.lang.Number)10L);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 9.95645506445408d+ "'", var5.equals(9.95645506445408d));

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(98.42888798257793d, 0.0469031636391882d, 98.46324585220091d, 98.88500098380753d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9741.15478920364d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.0d, 92.58889101274673d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(133869137708899648L, 99185013732155984L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2982694597243116d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 54.06394866293846d);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    int var6 = var2.nextInt(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportLowerBoundInclusive();
    var16.reseedRandomGenerator(2876919108950029338L);
    double var23 = var16.density(0.7157990521557022d);
    boolean var24 = var16.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     var1.reSeedSecure(100L);
//     double var20 = var1.nextGaussian(98.46324585220091d, 102.05756005359903d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("34f4a8a232072f569851e7e4c75425", "1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 123059029886613328L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.7792214873882597E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7891794675637991d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 18.04297777390029d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0991832135313893d, (java.lang.Number)211.607835419992d, (java.lang.Number)37.394228706165585d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.cumulativeProbability(1.0646160893106429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.inverseCumulativeProbability(79.16073610760711d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.probability(0.3055322893119356d);
    double var22 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var20 = var16.getSupportUpperBound();
    boolean var21 = var16.isSupportUpperBoundInclusive();
    double var22 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int var6 = var5.nextInt();
    long var7 = var5.nextLong();
    byte[] var8 = new byte[] { };
    var5.nextBytes(var8);
    var0.nextBytes(var8);
    int[] var11 = new int[] { };
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 6);
    var0.setSeed(var11);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    int[] var11 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    var12.setSeed(0);
    int[] var16 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = var17.nextInt();
    long var19 = var17.nextLong();
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c();
    var20.setSeed(6);
    int[] var24 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var24);
    int var26 = var25.nextInt();
    long var27 = var25.nextLong();
    byte[] var28 = new byte[] { };
    var25.nextBytes(var28);
    var20.nextBytes(var28);
    var17.nextBytes(var28);
    var12.nextBytes(var28);
    var2.nextBytes(var28);
    double var34 = var2.nextDouble();
    var2.setSeed(1667864798);
    float var37 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.21316570576788885d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.4317212f);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeDivide(var4, var7);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var21);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeAdd(var18, var26);
    double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var12, var31);
    double[] var36 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var36);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeDivide(var36, var39);
    double[] var42 = new double[] { };
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var42, var44);
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeAdd(var36, var44);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var44, var50, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = null;
    boolean var56 = org.apache.commons.math3.util.MathArrays.checkOrder(var44, var53, true, false);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var44);
    double[] var59 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var59);
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeDivide(var59, var62);
    double[] var65 = new double[] { };
    double[] var67 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var65, var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var70 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var67, var70, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var67);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var74 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var64, var67);
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = null;
    double[] var76 = new double[] { };
    double[] var78 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var78);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var76, var78);
    double[] var82 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var82);
    double var84 = org.apache.commons.math3.util.MathArrays.distance1(var76, var82);
    org.apache.commons.math3.util.MathArrays.OrderDirection var85 = null;
    double[] var87 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var87);
    double[] var90 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var90);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeDivide(var87, var90);
    double[][] var93 = new double[][] { var90};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var82, var85, var93);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var64, var75, var93);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var44, var93);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var93);
    org.apache.commons.math3.exception.NotFiniteNumberException var98 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-115747454037461536L), (java.lang.Object[])var93);
    org.apache.commons.math3.exception.NotFiniteNumberException var99 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.7473807753292526d, (java.lang.Object[])var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     int var9 = var0.nextSecureInt(7, 30);
//     var0.reSeedSecure((-1680313010742393856L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 142.58414165061558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 28);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var30, var33);
    double[] var36 = new double[] { };
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var36, var38);
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var38);
    double[] var45 = org.apache.commons.math3.util.MathArrays.normalizeArray(var43, 0.0d);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var24, var43);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var51 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.normalizeArray(var48, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    boolean var59 = org.apache.commons.math3.util.MathArrays.checkOrder(var55, var56, false, false);
    double[] var60 = new double[] { };
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var60);
    double[] var67 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var67);
    double[] var70 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var67, var70);
    org.apache.commons.math3.util.MathArrays.checkOrder(var72);
    double var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var60, var72);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var79 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var79);
    double[] var81 = org.apache.commons.math3.util.MathArrays.ebeDivide(var76, var79);
    double[] var82 = new double[] { };
    double[] var84 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var84);
    double var86 = org.apache.commons.math3.util.MathArrays.distance1(var82, var84);
    org.apache.commons.math3.util.MathArrays.checkPositive(var84);
    double var88 = org.apache.commons.math3.util.MathArrays.safeNorm(var84);
    double[] var89 = org.apache.commons.math3.util.MathArrays.ebeAdd(var76, var84);
    org.apache.commons.math3.util.MathArrays.OrderDirection var90 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var84, var90, true);
    double var93 = org.apache.commons.math3.util.MathArrays.distance1(var60, var84);
    boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var55, var84);
    double var95 = org.apache.commons.math3.util.MathArrays.distance(var24, var55);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var96 = org.apache.commons.math3.util.MathArrays.distance(var18, var55);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    boolean var20 = var16.isSupportUpperBoundInclusive();
    double var22 = var16.probability(0.0d);
    boolean var23 = var16.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var13 = var1.nextT(98.46619727159656d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextSecureInt(28, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 101.01538287925496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1339204650525916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7137374429984744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.8729626527211417d);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    long[] var2 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.0737206121073526d, 4, var3, true);
    java.lang.Number var6 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0737206121073526d+ "'", var6.equals(1.0737206121073526d));

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(2, 52501.352056858435d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6703621889992398d);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextLong(1571403733602285824L, (-1680313010742393856L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.36274095234681d);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.ebeDivide(var9, var12);
//     double[] var15 = new double[] { };
//     double[] var17 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var17);
//     double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var17);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, 0.0d);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var3, var22);
//     double[] var27 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var27);
//     double[] var30 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var30);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var27, var30);
//     double[] var33 = new double[] { };
//     double[] var35 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var35);
//     double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var35);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35, var41, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
//     boolean var47 = org.apache.commons.math3.util.MathArrays.checkOrder(var35, var44, true, false);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var35);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var35);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextGaussian(210.05292023350523d, 0.00801543912443346d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextBinomial((-163349561), 9.929477942980203d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.47616438262094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 210.0464655876662d);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)88.2514775318289d);
    org.apache.commons.math3.exception.DimensionMismatchException var5 = new org.apache.commons.math3.exception.DimensionMismatchException(4, 30);
    var2.addSuppressed((java.lang.Throwable)var5);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)606.9017688960619d);
//     java.lang.Object var13 = var12.getSecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 226.71502882511598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + 606.9017688960619d+ "'", var13.equals(606.9017688960619d));
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextGamma(9.92668559023387d, 211.5172666085467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46337545978561d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2105.5194125238986d);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var3 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var0, var1, true);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1205512795, 5);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)(-1.0f), var6, true);
    java.lang.Number var9 = var8.getMin();
    boolean var10 = var8.getBoundIsAllowed();
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var12 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)0+ "'", var12.equals((short)0));

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    int[] var0 = new int[] { };
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var4);
    int[] var8 = new int[] { 100};
    int[] var10 = new int[] { 100};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var10);
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = org.apache.commons.math3.util.MathArrays.distance(var2, var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     var1.reSeedSecure(28078456255874636L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.53197467943274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 96.69144063320101d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.008043248190119192d);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var4);
    java.lang.Object var8 = var4.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1L)+ "'", var5.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(106L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform((-0.3941648194355074d), (-97.02018957950251d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    var16.reseedRandomGenerator(11555020432364844L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var40.setSecureAlgorithm("2b12bb0", "f6acecb9ba89e67fbd08cb695527db");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var60, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var64 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var54, var57);
    double[] var66 = var64.sample(9);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var66);
    double[] var69 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var69);
    double[] var72 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var69, var72);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var34, var72);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = null;
    boolean var79 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var76, true, false);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 100.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
    double[] var45 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var45);
    double[] var48 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
    double[] var51 = new double[] { };
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var62 = new double[] { };
    double[] var64 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var64);
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
    org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
    double[] var73 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var73);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
    double[][] var79 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
    double[] var84 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var83, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
//     double[] var6 = new double[] { };
//     double[] var8 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
//     boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
//     double[] var22 = new double[] { };
//     double[] var24 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var24);
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
//     double[] var28 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var28);
//     double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
//     double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
//     double[] var34 = null;
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var5, var34);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var18, var24);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var28 = new double[] { };
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var28, var30);
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var30);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0847091605564438d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var3 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[] var55 = new double[] { };
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var55, var57);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var57, var60, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var57);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var64 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var54, var57);
    double[] var66 = var64.sample(9);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var66);
    double[] var69 = new double[] { };
    double[] var71 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var69, var71);
    double[] var75 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var69, var75);
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = null;
    boolean var81 = org.apache.commons.math3.util.MathArrays.checkOrder(var75, var78, false, true);
    double[] var83 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var83);
    double[] var86 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var86);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var83, var86);
    double[] var90 = org.apache.commons.math3.util.MathArrays.normalizeArray(var83, 0.0d);
    double var91 = org.apache.commons.math3.util.MathArrays.distance(var75, var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var92 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var66, var75);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     double var9 = var0.nextExponential(183.75983595296293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 220.27967013927585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 665.9207982102981d);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var3, var6, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    double[] var12 = new double[] { };
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var12, var18);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var26);
    double[][] var29 = new double[][] { var26};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var21, var29);
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var29);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var10, var29);
    org.apache.commons.math3.exception.MathIllegalArgumentException var33 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, (-63560251), (-63560251));

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     var13.reSeedSecure();
//     int var23 = var13.nextInt(0, 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-549596712));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 3);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var10 = var0.nextGamma(0.9638486378008077d, 444.0293055330172d);
//     double var13 = var0.nextCauchy(98.40187854858537d, 290.60054602954324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.02337093150714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 325.59250627415844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2771.7435600413346d);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    boolean var5 = var2.nextBoolean();
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var6.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Comparable[] var4 = new java.lang.Comparable[] { 10};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
//     boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, true);
//     org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var15, true);
//     int var18 = var17.getIndex();
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.util.Localizable var20 = null;
//     long[] var24 = new long[] { 0L, 10L};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var24);
//     long[][] var26 = new long[][] { var24};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var26);
//     org.apache.commons.math3.exception.NotFiniteNumberException var28 = new org.apache.commons.math3.exception.NotFiniteNumberException(var20, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var26);
//     org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var17, var19, (java.lang.Object[])var26);
//     org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var11, (java.lang.Object[])var26);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(92, 827167750, 92);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.64343910565811d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-332537868696652544L));
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var10 = var0.nextGamma(0.9638486378008077d, 444.0293055330172d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(827167750, 88.20256579008964d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.7301975946991539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 101.02142832135698d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var14, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var8, var11);
    double var20 = var18.density(99.02988657003175d);
    boolean var21 = var18.isSupportLowerBoundInclusive();
    var18.reseedRandomGenerator(2876919108950029338L);
    double var25 = var18.density(0.7157990521557022d);
    var18.reseedRandomGenerator(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var18);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var50 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var40, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    double[] var52 = new double[] { };
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var52, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var52, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var61, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51, var69);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var72 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var32, var40);
    double[] var74 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var77 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var77);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var74, var77);
    org.apache.commons.math3.util.MathArrays.checkOrder(var79);
    org.apache.commons.math3.util.MathArrays.checkOrder(var79);
    double[] var83 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var83);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var79, var83);
    double[] var87 = org.apache.commons.math3.util.MathArrays.normalizeArray(var79, 3.0896657965554652d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var88 = org.apache.commons.math3.util.MathArrays.linearCombination(var40, var79);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(0.7446287025499129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     int var14 = var0.nextZipf(9, 210.26801214771172d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var0.nextInversionDeviate(var15);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(33.87099243611685d, 1088.635562624777d, 10.010675150539647d, 9.927198205545196d, 65.2560351111629d, 9.823059185582977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 37613.558758855805d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var13 = new double[] { };
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var13, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    double[] var19 = new double[] { };
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var19, var21);
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var19, var25);
    org.apache.commons.math3.util.MathArrays.OrderDirection var28 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.checkOrder(var25, var28, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.isMonotonic(var25, var32, false);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var35, var41);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var41);
    double var46 = org.apache.commons.math3.util.MathArrays.distance(var18, var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var45);
    double[] var48 = new double[] { };
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var48, var50);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var48, var54);
    org.apache.commons.math3.util.MathArrays.OrderDirection var57 = null;
    boolean var60 = org.apache.commons.math3.util.MathArrays.checkOrder(var54, var57, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    boolean var63 = org.apache.commons.math3.util.MathArrays.isMonotonic(var54, var61, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var64 = org.apache.commons.math3.util.MathArrays.linearCombination(var45, var54);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var5.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     var1.reSeedSecure(100L);
//     double var20 = var1.nextGaussian(98.46324585220091d, 102.05756005359903d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextGaussian(243.39148903006193d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 37569492833752176L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.4775079831152724d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 48.02549705059001d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var43 = var40.nextPermutation(7, 92);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var13 = var1.nextT(98.46619727159656d);
//     long var15 = var1.nextPoisson(106.0271272985156d);
//     double var17 = var1.nextExponential(10.010675150539647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 97.61679135540601d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f"+ "'", var6.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.5130596728606336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9113220391122172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.39832943860245823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 99L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.056389821547084d);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     double[] var1 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var1);
//     double[] var4 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var4);
//     double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
//     double[] var7 = new double[] { };
//     double[] var9 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var9);
//     double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
//     double[] var17 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var14, var17);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int var6 = var5.nextInt();
    long var7 = var5.nextLong();
    byte[] var8 = new byte[] { };
    var5.nextBytes(var8);
    var0.nextBytes(var8);
    int[] var12 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var12);
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
    var0.setSeed(var15);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(203.21393087615945d, 3.670312001858478d, 9.927198205545196d, 290.60054602954324d, 1.0847091605564438d, 312871.1913118577d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 343004.95503869426d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { false};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    java.lang.Throwable[] var10 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     int[] var10 = var0.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c();
//     var11.setSeed(6);
//     int[] var15 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int var17 = var16.nextInt();
//     long var18 = var16.nextLong();
//     byte[] var19 = new byte[] { };
//     var16.nextBytes(var19);
//     var11.nextBytes(var19);
//     int[] var22 = new int[] { };
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 6);
//     var11.setSeed(var22);
//     int[] var27 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(var27);
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var27);
//     int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
//     int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
//     double var32 = org.apache.commons.math3.util.MathArrays.distance(var22, var30);
//     int[] var33 = null;
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var33);
//     int var35 = org.apache.commons.math3.util.MathArrays.distance1(var10, var33);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     double var11 = var0.nextT(211.79400708576884d);
//     long var13 = var0.nextPoisson(0.7090371711746789d);
//     double var17 = var0.nextUniform((-0.32325280016288294d), 9862.916937121827d, true);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 5829916);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     double var6 = var2.nextGaussian();
//     var2.setSeed(43059505226525080L);
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl();
//     var9.reSeedSecure();
//     double var13 = var9.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var16 = var9.nextZipf(8, 98.28206305872513d);
//     int[] var19 = var9.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     int[] var22 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(var22);
//     int var24 = var23.nextInt();
//     long var25 = var23.nextLong();
//     double var26 = var23.nextGaussian();
//     int[] var28 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var28);
//     int var30 = var29.nextInt();
//     long var31 = var29.nextLong();
//     byte[] var32 = new byte[] { };
//     var29.nextBytes(var32);
//     var23.nextBytes(var32);
//     var20.nextBytes(var32);
//     var2.nextBytes(var32);
//     double[] var38 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var38);
//     double[] var41 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var41);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var38, var41);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.normalizeArray(var38, 100.0d);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
//     boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var45, var46, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var45);
//     double[] var51 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var51);
//     double[] var54 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var54);
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var54);
//     double[] var57 = new double[] { };
//     double[] var59 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var59);
//     double var61 = org.apache.commons.math3.util.MathArrays.distance1(var57, var59);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var59);
//     double var63 = org.apache.commons.math3.util.MathArrays.safeNorm(var59);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeAdd(var51, var59);
//     double[] var66 = org.apache.commons.math3.util.MathArrays.normalizeArray(var64, 0.0d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var45, var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6984489763881883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 208.6189578014164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     long var13 = var0.nextPoisson(121.6356374977755d);
//     var0.reSeed(112L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextHypergeometric(0, 0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 197.99440346708894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c792c045dd"+ "'", var9.equals("c792c045dd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 104L);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var3 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     int[] var14 = var0.nextPermutation(1, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 126.7343346873629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.093594075635607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.385180791776747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.cumulativeProbability(1.0646160893106429d);
    double var23 = var16.cumulativeProbability(104.91028148840213d);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair((java.lang.Object)104.91028148840213d, (java.lang.Object)97.92480086319091d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    float[] var0 = null;
    float[] var1 = null;
    float[] var2 = new float[] { };
    boolean var3 = org.apache.commons.math3.util.MathArrays.equals(var1, var2);
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var4);
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2074243331, var1, true);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     var1.reSeedSecure(100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextUniform(116.28669882378713d, 98.44078667812042d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 64162787959459840L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.05944777244203833d);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(43059505226525080L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-63560251));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 29, 8);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var21 = var16.probability(263.1966961055d);
    boolean var22 = var16.isSupportUpperBoundInclusive();
    var16.reseedRandomGenerator(133869137708899648L);
    double var26 = var16.probability(191.0943244061241d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    float var3 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9775554f);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1422716669, 2147483647);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var22 = var16.cumulativeProbability(0.02678742855378105d, 8871.347843840067d);
    double var23 = var16.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var26 = var16.probability(116.28669882378713d, 99.94971311903645d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)(-1), (java.lang.Number)28078456255874636L, 92);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    double var19 = var16.cumulativeProbability(7167.615997776342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    long var5 = var3.nextLong();
    var3.clear();
    int var8 = var3.nextInt(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2876919108950029338L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0, var1, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.cumulativeProbability(98.6636142140316d, 45.06487043076392d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var22 = var16.cumulativeProbability(0.02678742855378105d, 8871.347843840067d);
    double var23 = var16.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var25 = var16.inverseCumulativeProbability(88.20256579008964d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)11L, (java.lang.Number)1.0f, true);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    double var20 = var16.cumulativeProbability(1.208726759939196d);
    double var23 = var16.cumulativeProbability(9.927959811989089d, 201.10872070139894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)194.78635754815068d, (java.lang.Number)1.819217204815299d, true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.819217204815299d+ "'", var6.equals(1.819217204815299d));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var20 = var16.sample();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var16.inverseCumulativeProbability(1.505308581282821d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(byte)(-1), (java.lang.Number)2, false);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     java.lang.String var8 = var1.nextHexString(8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextSecureInt(0, (-694891488));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9c7850c6f3"+ "'", var6.equals("9c7850c6f3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "72f60b76"+ "'", var8.equals("72f60b76"));
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)37.394228706165585d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    double[] var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var16, var19, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var23 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var13, var16);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
    double[] var36 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var36);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeDivide(var36, var39);
    double[][] var42 = new double[][] { var39};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var34, var42);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var13, var24, var42);
    org.apache.commons.math3.exception.MathIllegalStateException var45 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var1, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    int[] var4 = new int[] { 100};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    boolean var6 = var2.equals((java.lang.Object)var4);
    java.lang.Object var7 = var2.getValue();
    java.lang.Object var8 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    int var13 = var2.nextInt(827167750);
    boolean var14 = var2.nextBoolean();
    boolean var15 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 809123836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var4 = new int[] { 100};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance(var0, var7);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    float var5 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.014081955f);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var6, (java.lang.Number)100.26932579100311d, var8, false);
    var3.addSuppressed((java.lang.Throwable)var10);
    java.lang.Number var12 = var3.getLo();
    java.lang.Number var13 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation(30, (-1128991284));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.12854378039014658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-13.366726437154856d));
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextZipf(100, 0.9638486378008077d);
//     long var5 = var0.nextPoisson(98.88500098380753d);
//     double var8 = var0.nextF(192.2191052341085d, 63.87757706359718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 95L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.9459911029453463d);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextPascal(0, 99.2782319289774d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45405214019941d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 95.19925491177779d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.4031856899901309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "45a71b0830458a108ca9e82c3495f65d901b8c0356761cd8bf5656941f906a6ebf452e2ea90c37c29e117786872c1d8fab79"+ "'", var12.equals("45a71b0830458a108ca9e82c3495f65d901b8c0356761cd8bf5656941f906a6ebf452e2ea90c37c29e117786872c1d8fab79"));
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 6);
//     java.lang.String var4 = var3.toString();
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var4 = var0.nextT(742.6248114744293d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextPoisson((-0.1892589982345936d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.5656685332712276d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.0811101516127348d);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)58.468608413067535d, (java.lang.Number)2.056788858578444d, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.056788858578444d+ "'", var4.equals(2.056788858578444d));

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     double var6 = var2.nextGaussian();
//     var2.setSeed(43059505226525080L);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     var10.reSeedSecure();
//     double var14 = var10.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var17 = var10.nextZipf(8, 98.28206305872513d);
//     int[] var20 = var10.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
//     int[] var23 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int var25 = var24.nextInt();
//     long var26 = var24.nextLong();
//     double var27 = var24.nextGaussian();
//     int[] var29 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var31 = var30.nextInt();
//     long var32 = var30.nextLong();
//     byte[] var33 = new byte[] { };
//     var30.nextBytes(var33);
//     var24.nextBytes(var33);
//     var21.nextBytes(var33);
//     var2.nextBytes(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6984489763881883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 201.75738308956042d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     long var8 = var0.nextSecureLong((-4736355256857903122L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.21316570576788885d, (-1.5254128255056287d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "1a2e4159c"+ "'", var2.equals("1a2e4159c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "c36682b41f48736d8c65f301de6c39"+ "'", var5.equals("c36682b41f48736d8c65f301de6c39"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2181418625405702912L));
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(short)1, (java.lang.Number)(-1.0f), false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0f)+ "'", var5.equals((-1.0f)));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.probability(0.3055322893119356d);
    double var22 = var16.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 5829916);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     long var22 = var13.nextLong(0L, 13L);
//     int var25 = var13.nextSecureInt((-1), 809123836);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-125716405));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 11387117);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    double var21 = var16.probability(263.1966961055d);
    boolean var22 = var16.isSupportUpperBoundInclusive();
    var16.reseedRandomGenerator((-4848980640512349401L));
    double var25 = var16.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var16.inverseCumulativeProbability(181.247410273537d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextBinomial(28, 189.61815153637863d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 101.26742369521271d);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     var0.reSeed(152600911433040288L);
//     java.lang.String var15 = var0.nextHexString(7);
//     org.apache.commons.math3.distribution.IntegerDistribution var16 = null;
//     int var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.inverseCumulativeProbability(1104.179131411614d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    long[] var12 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var12);
    long[][] var14 = new long[][] { var12};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var14);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.21819979512271087d), (java.lang.Number)79.25588231908337d, 2);
    java.lang.Number var4 = var3.getPrevious();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 79.25588231908337d+ "'", var4.equals(79.25588231908337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1128991284), 1667864798);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 809123836, 9);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = new double[] { };
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var5, var7);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var15);
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var21, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var29, var35, true);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var5, var29);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     var1.reSeed(3513799009476651814L);
//     double var8 = var1.nextExponential(65.2560351111629d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.980646904443526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 67.10398150052652d);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    double var12 = var2.nextDouble();
    int var14 = var2.nextInt(6);
    int var15 = var2.nextInt();
    double var16 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2074243331);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.7231465203852943d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextBeta(3.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-135.36165032509055d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.3573618757384485d);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var10 = var0.nextGamma(0.9638486378008077d, 444.0293055330172d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(7, 210.26801214771172d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-2.4300228967926003d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 79.32858401716992d);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var13, false);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var22);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var26, var27, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     double var6 = var2.nextGaussian();
//     var2.setSeed(43059505226525080L);
//     long var9 = var2.nextLong();
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var10);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    java.lang.String var42 = var40.nextHexString(7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var44 = var40.nextHexString((-96398574));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "150543b"+ "'", var42.equals("150543b"));

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2b12bb0", "1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 74.92777394987019d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 13.844639395343137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.77719495658795d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var20 = var16.getSupportUpperBound();
    var16.reseedRandomGenerator((-115747454037461536L));
    boolean var23 = var16.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var1.nextPermutation((-1128991284), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     long var11 = var0.nextPoisson(9.927959811989089d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(28, 27.18273250644198d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 117.03297628388734d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7368610735722845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 14L);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)211.5409799176563d, (java.lang.Number)(byte)0, false);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var7 = var1.nextGamma(91.73734938536145d, 98.96880118978186d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextSecureLong(6066523849031269L, (-3372461070849671680L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9313.598465142082d);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    var2.clear();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var13.nextBinomial(10, 623.7618277857923d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 12168.048178086838d);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     double var7 = var0.nextUniform((-37.441946953176824d), 37.394228706165585d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextPoisson((-0.11765698642290988d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.1610718637409457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-18.931270365305835d));
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     int var15 = var1.nextSecureInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var17 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45694956079997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 95.87146518707202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3043451563789692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "b680"+ "'", var12.equals("b680"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 83);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     java.lang.String var9 = var0.nextSecureHexString(5829916);
//     int var12 = var0.nextPascal(73, 0.23344772945559902d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.04333876110416757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 244);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(4286978429002110849L);
    double var9 = var2.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.9636132194023059d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)247.45752224305923d);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     long var14 = var1.nextSecureLong((-3567176491980158464L), 43059505226525080L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.43652237373647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 81.44418157194426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 49.269561697352415d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2806187763758602752L));
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(165.22373033698972d, 8.035088550415418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("a8bb2312", "f6d99a5fb8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.076207939760602d);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     var1.reSeedSecure();
//     double var13 = var1.nextCauchy(606.9017688960619d, 0.3055322893119356d);
//     int var16 = var1.nextZipf(30, 1.2000918311981499d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.33743701342628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "5"+ "'", var6.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 607.1072574602813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGamma(98.88500098380753d, 1.0847091605564438d);
//     java.lang.String var9 = var0.nextSecureHexString(5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(28, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 104.69597099051225d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 113.9850223319271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "755c1"+ "'", var9.equals("755c1"));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    var2.setSeed(43059505226525080L);
    long var9 = var2.nextLong();
    float var10 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4848980640512349401L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.31171608f);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    java.lang.Object[] var8 = new java.lang.Object[] { var6};
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
    long var10 = var5.nextPoisson(0.26800388045607487d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 606.9017688960619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var37, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     double var11 = var1.nextChiSquare(1.2388070620041405d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextPascal(1667864798, 1.0159264522107176d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.1225291256178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.8338455529414733d);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    float[] var6 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var7);
    java.lang.Object[] var9 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var9);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var1, var9);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var0, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeed((-2269827290554446382L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.1873976334817486d));
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1543116286);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)9843.530265446541d, (java.lang.Number)189.61815153637863d, (java.lang.Number)0.3441412950324493d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.lang.String var13 = var1.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextWeibull((-1.0d), (-0.4184846162521546d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4683613639194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 100.32944781187653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 56.86966889804811d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "c"+ "'", var13.equals("c"));
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     int var15 = var1.nextSecureInt(10, 100);
//     double var18 = var1.nextF(842.087036110989d, 1.1974708505559213d);
//     double var20 = var1.nextExponential(6.7068743582446215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46512211468145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 97.25177190186518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5742251148047507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "edb0"+ "'", var12.equals("edb0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 54.23317161276515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12.716848922017999d);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextGaussian(0.23344772945559902d, 1.8229678545960526d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var1.nextBinomial(98, 117.67233364565794d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.7625918438223507d));
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    boolean var7 = var6.nextBoolean();
    double var8 = var6.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8255079335182625d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10, (java.lang.Number)98.47480055949d, var3);
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 98.47480055949d+ "'", var5.equals(98.47480055949d));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)211.11038733317636d, (java.lang.Number)200.55910227357631d, 30, var3, false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("b", "0dff92a0d7");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var9, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    boolean var14 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var12, false);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1205512795, 98);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportLowerBoundInclusive();
    var16.reseedRandomGenerator(2876919108950029338L);
    double var23 = var16.density(0.7157990521557022d);
    double var25 = var16.probability(0.003494754140413766d);
    boolean var26 = var16.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = var16.inverseCumulativeProbability(189.61815153637863d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    double var12 = var2.nextDouble();
    int var14 = var2.nextInt(6);
    int[] var16 = new int[] { 100};
    int[] var18 = new int[] { 100};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    var2.setSeed(var18);
    int[] var25 = new int[] { 100};
    int[] var27 = new int[] { 100};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var27);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(var27);
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 10);
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var18, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var9 = new int[] { 100};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var3, var9);
    int[] var13 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    int var15 = var14.nextInt();
    var14.clear();
    var14.setSeed(100L);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var28 = new int[] { 100};
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
    var14.setSeed(var28);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var3, var28);
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     long var8 = var0.nextSecureLong((-4736355256857903122L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(10.105148859000192d, 1.0410251609935102d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "082bd1941"+ "'", var2.equals("082bd1941"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "58113decea0f94d7bd0f5e6170ed33"+ "'", var5.equals("58113decea0f94d7bd0f5e6170ed33"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-3159072710913301504L));
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 827167750);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextDouble();
    var1.setSeed(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9775554539871507d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(244, (-125716405));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var1 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var4 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, false, true);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(819462356);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    double var19 = var16.cumulativeProbability(98.57943496629362d);
    var16.reseedRandomGenerator(101L);
    double[] var23 = var16.sample(30);
    double var24 = var16.getSupportLowerBound();
    double var25 = var16.getSupportLowerBound();
    double var27 = var16.density(226.71502882511598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.6368217509307181d, 1.6486550157904805d, 74.70596145044928d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0498993738364044d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    double var24 = var16.getSupportLowerBound();
    double[] var26 = var16.sample(2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     var0.reSeedSecure(0L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 216.56463742148304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9723.814054663138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.5226552290037116d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 176.7725905699395d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 2);
    int[] var11 = new int[] { 100};
    int[] var13 = new int[] { 100};
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 10);
    int[] var30 = new int[] { 100};
    int[] var32 = new int[] { 100};
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var32);
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var32);
    int[] var38 = new int[] { 100};
    int[] var40 = new int[] { 100};
    int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var38, var40);
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
    org.apache.commons.math3.random.Well19937c var44 = new org.apache.commons.math3.random.Well19937c(var40);
    int[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 10);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var32, var40);
    int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var32);
    var18.setSeed(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var5 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.9405132696386548d), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf(98, (-37.441946953176824d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 209.9343177538742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9831.149472153164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.4545922831619236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 173.38564016384683d);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextT(97.97864407980379d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial(9, 83.3326923348544d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.413919953858d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 103.16277764050601d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.39179589952714466d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.39832943860245823d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.cumulativeProbability(0.03359081770746613d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var22);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var27, var30, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var34 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var24, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = null;
    double[] var36 = new double[] { };
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var36, var38);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var36, var42);
    org.apache.commons.math3.util.MathArrays.OrderDirection var45 = null;
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var50);
    double[][] var53 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var42, var45, var53);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var35, var53);
    double[] var57 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var57);
    double[] var60 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var60);
    double[] var62 = org.apache.commons.math3.util.MathArrays.ebeDivide(var57, var60);
    double[] var63 = new double[] { };
    double[] var65 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var65);
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var63, var65);
    org.apache.commons.math3.util.MathArrays.checkPositive(var65);
    double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeAdd(var57, var65);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int[] var7 = new int[] { 100};
    int[] var9 = new int[] { 100};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var3.setSeed(var13);
    var3.setSeed((-115747454037461536L));
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.1460388204540751d, (java.lang.Number)8665.328506412081d, false);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4826365375887363d);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    var16.reseedRandomGenerator(10L);
    double var23 = var16.getNumericalVariance();
    double var25 = var16.cumulativeProbability(0.003494754140413766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSecureAlgorithm("e", "150543b");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 606.9017688960619d);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     java.lang.String var5 = var0.nextSecureHexString(30);
//     long var8 = var0.nextSecureLong((-4736355256857903122L), 0L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 1);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.clear();
//     java.util.List var11 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var12 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var11);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)163.87452391184175d, (java.lang.Number)6, (java.lang.Number)444.0293055330172d);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     int var12 = var0.nextZipf(6, 321.6792596437714d);
//     int var15 = var0.nextZipf(5, 1.9605318349984269d);
//     int var18 = var0.nextSecureInt((-838354274), 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 276.2030684411809d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.33112665569960686d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-264936759));
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     double[] var7 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var7);
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
//     boolean var13 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var10, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
//     boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var14, false);
//     double[] var17 = new double[] { };
//     double[] var19 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
//     double[] var23 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var17, var23);
//     double var26 = org.apache.commons.math3.util.MathArrays.safeNorm(var23);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var23);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var23);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    double[] var0 = null;
    double[][] var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var1 = new double[] { };
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var10, false, true);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, 0.0d);
    double var23 = org.apache.commons.math3.util.MathArrays.distance(var7, var15);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    double[] var30 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var24, var30);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[][] var41 = new double[][] { var38};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var30, var33, var41);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var7, var41);
    org.apache.commons.math3.exception.NullArgumentException var44 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     double var16 = var1.nextWeibull(0.9846580496679653d, 9.927198205545196d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform((-0.4184846162521546d), (-0.4184846162521546d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45959039068853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 103.65562244301455d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 98.2803452447918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 39.18827085247947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.318191037292559d);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     var1.reSeedSecure(10L);
//     double var17 = var1.nextBeta(63.20443649540218d, 9.90259223244539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.75093480377689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6"+ "'", var6.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8257165627073703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9.904240794022492d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.8900430103456601d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial(1543116286, 290.60054602954324d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.33920977825773d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8709426151172742d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1736698663, 0);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var34);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = null;
    boolean var44 = org.apache.commons.math3.util.MathArrays.checkOrder(var17, var41, true, true);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var17);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var49 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var50 = var49.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var51 = var49.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = var49.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var55 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var52, false, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     long var12 = var0.nextPoisson(1.018077367346247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 176.5568350171341d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10147.966843902852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2L);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    int[] var0 = new int[] { };
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 6);
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var4 = var3.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var8 = var5.nextUniform(0.7090371711746789d, 3887.603878597613d);
//     long var11 = var5.nextSecureLong(100L, 152600911433040288L);
//     var5.reSeed((-190865323983646368L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var5.nextSecureInt(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-414028722650554365L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 606.9017688960619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 127157237037712880L);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var15, true);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var11 = var1.nextCauchy(0.5104454862955553d, 97.97864407980379d);
//     int var14 = var1.nextZipf(3, 1.0646160893106429d);
//     var1.reSeedSecure();
//     var1.reSeed((-115747454037461536L));
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var1.nextSample(var18, 9);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var4 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    long[][] var6 = new long[][] { var4};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.3955019469796721d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    java.lang.Object var7 = var4.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1L)+ "'", var5.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1L)+ "'", var7.equals((-1L)));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var3 = null;
    float[] var4 = new float[] { };
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var3, var4);
    float[] var8 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var9);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var3, var8);
    float[] var12 = null;
    float[] var13 = new float[] { };
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var12, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var8, var13);
    float[] var16 = null;
    float[] var17 = new float[] { };
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var16, var17);
    float[] var21 = new float[] { 0.0f, (-1.0f)};
    float[] var22 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var21);
    float[] var25 = null;
    float[] var26 = new float[] { };
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var25, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var21, var26);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var8, var21);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var21);
    float[] var31 = null;
    float[] var32 = new float[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var31, var32);
    float[] var36 = new float[] { 0.0f, (-1.0f)};
    float[] var37 = null;
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var36);
    float[] var40 = null;
    float[] var41 = new float[] { };
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var40, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var36, var41);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(4);
//     double var5 = var0.nextCauchy(0.0d, 3.0896657965554652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "0175"+ "'", var2.equals("0175"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.380036973352875d);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     long var15 = var0.nextSecureLong(1L, 89368925716390480L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-51.266690217526275d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.5520859880271014d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.83149155850026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 73847804585312832L);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var10 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 1.0836579002185789d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     double var5 = var0.nextGaussian(0.0d, 92.58889101274673d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation((-1128991284), (-549596712));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0203864790125898d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 94.66732296258655d);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    var1.clear();

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[] var5 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
//     double[] var8 = new double[] { };
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10, var13, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var10);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var17 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var10);
//     double[] var19 = var17.sample(9);
//     double var20 = var17.getSupportLowerBound();
//     double var22 = var17.density(1.2316468095843844d);
//     double var24 = var17.inverseCumulativeProbability(1.0d);
//     double var25 = var17.getSupportLowerBound();
//     double[] var27 = var17.sample(2);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var0, var27);
//     double[] var29 = null;
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var27, var29);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     long var13 = var0.nextPoisson(121.6356374977755d);
//     double var15 = var0.nextChiSquare(290.63796974952476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 185.57795683562384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "3847982c56"+ "'", var9.equals("3847982c56"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 128L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 275.37293954352356d);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     var2.clear();
//     var2.setSeed(100L);
//     long var7 = var2.nextLong();
//     var2.setSeed(43059505226525080L);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl();
//     var10.reSeedSecure();
//     double var14 = var10.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var17 = var10.nextZipf(8, 98.28206305872513d);
//     int[] var20 = var10.nextPermutation(9, 4);
//     org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(var20);
//     int[] var23 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
//     int var25 = var24.nextInt();
//     long var26 = var24.nextLong();
//     double var27 = var24.nextGaussian();
//     int[] var29 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var29);
//     int var31 = var30.nextInt();
//     long var32 = var30.nextLong();
//     byte[] var33 = new byte[] { };
//     var30.nextBytes(var33);
//     var24.nextBytes(var33);
//     var21.nextBytes(var33);
//     var2.nextBytes(var33);
//     org.apache.commons.math3.random.RandomDataImpl var38 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     int[] var40 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var41 = new org.apache.commons.math3.random.Well19937c(var40);
//     int var42 = var41.nextInt();
//     double var43 = var41.nextDouble();
//     var41.setSeed((-1));
//     var41.setSeed(0L);
//     long var48 = var41.nextLong();
//     int[] var50 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var51 = new org.apache.commons.math3.random.Well19937c(var50);
//     var51.setSeed(0);
//     int[] var55 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var56 = new org.apache.commons.math3.random.Well19937c(var55);
//     int var57 = var56.nextInt();
//     long var58 = var56.nextLong();
//     org.apache.commons.math3.random.Well19937c var59 = new org.apache.commons.math3.random.Well19937c();
//     var59.setSeed(6);
//     int[] var63 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var64 = new org.apache.commons.math3.random.Well19937c(var63);
//     int var65 = var64.nextInt();
//     long var66 = var64.nextLong();
//     byte[] var67 = new byte[] { };
//     var64.nextBytes(var67);
//     var59.nextBytes(var67);
//     var56.nextBytes(var67);
//     var51.nextBytes(var67);
//     var41.nextBytes(var67);
//     var2.nextBytes(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3513799009476651814L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 182.7546727977175d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    double var19 = var16.cumulativeProbability(98.57943496629362d);
    var16.reseedRandomGenerator(101L);
    double[] var23 = var16.sample(30);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 5.477225575051661d);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var6 = var1.nextT(1.2388070620041405d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("fb25", "3c474fdeb4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.955270926748078d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.16764565966208952d));
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.2388070620041405d, 0.9179650267580631d, 1.9605318349984269d, 0.1460388204540751d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.423495314466542d);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
//     int var4 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var2);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var3 = new float[] { };
    boolean var4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var3);
    float[] var5 = null;
    float[] var6 = new float[] { };
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var5, var6);
    float[] var10 = new float[] { 0.0f, (-1.0f)};
    float[] var11 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var14 = null;
    float[] var15 = new float[] { };
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var14, var15);
    float[] var19 = new float[] { 0.0f, (-1.0f)};
    float[] var20 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    float[] var23 = null;
    float[] var24 = new float[] { };
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var23, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var19, var24);
    float[] var27 = null;
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var27, var28);
    float[] var32 = new float[] { 0.0f, (-1.0f)};
    float[] var33 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var27, var32);
    float[] var36 = null;
    float[] var37 = new float[] { };
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var36, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var32, var37);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var19, var32);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var10, var19);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var3, var19);
    float[] var43 = null;
    float[] var44 = new float[] { };
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var43, var44);
    float[] var48 = new float[] { 0.0f, (-1.0f)};
    float[] var49 = null;
    boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var48, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var43, var48);
    float[] var52 = null;
    float[] var53 = new float[] { };
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var52, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var48, var53);
    float[] var58 = new float[] { 0.0f, (-1.0f)};
    float[] var59 = null;
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var58);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var3, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var3 = new double[] { };
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double var7 = org.apache.commons.math3.util.MathArrays.distance1(var3, var5);
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var5);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var14);
    double[] var17 = new double[] { };
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeAdd(var11, var19);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var24, 0.0d);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var5, var24);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[] var35 = new double[] { };
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var35, var37);
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeAdd(var29, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var37, var43, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var49 = org.apache.commons.math3.util.MathArrays.checkOrder(var37, var46, true, false);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var24, var37);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var55 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var55);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeDivide(var52, var55);
    double[] var58 = new double[] { };
    double[] var60 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var60);
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var58, var60);
    org.apache.commons.math3.util.MathArrays.OrderDirection var63 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var60, var63, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var60);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var57, var60);
    double[] var69 = var67.sample(9);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var69);
    java.lang.Object[] var71 = new java.lang.Object[] { var69};
    org.apache.commons.math3.exception.NotFiniteNumberException var72 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)98.46619727159656d, var71);
    org.apache.commons.math3.exception.MathArithmeticException var73 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    boolean var21 = var16.isSupportLowerBoundInclusive();
    double var22 = var16.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int var6 = var5.nextInt();
    long var7 = var5.nextLong();
    byte[] var8 = new byte[] { };
    var5.nextBytes(var8);
    var0.nextBytes(var8);
    int[] var11 = new int[] { };
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 6);
    var0.setSeed(var11);
    int[] var16 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var11, var19);
    int[] var23 = new int[] { 100};
    int[] var25 = new int[] { 100};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int var27 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var25);
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    int[] var31 = new int[] { 100};
    int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var25, var31);
    int[] var35 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var35);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var35);
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    int var39 = org.apache.commons.math3.util.MathArrays.distance1(var25, var35);
    int[] var41 = new int[] { 100};
    int[] var43 = new int[] { 100};
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    int var45 = org.apache.commons.math3.util.MathArrays.distanceInf(var41, var43);
    int[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var43);
    int var47 = org.apache.commons.math3.util.MathArrays.distance1(var35, var46);
    int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(11387117);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var16 = new double[] { };
    double[] var18 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
    org.apache.commons.math3.util.MathArrays.checkPositive(var18);
    double var22 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeDivide(var24, var27);
    double[] var30 = new double[] { };
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var30, var32);
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var32);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var37, 0.0d);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var18, var37);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var1, var18);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var47);
    double[] var50 = new double[] { };
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var50, var52);
    double[] var56 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var56);
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var50, var56);
    double var59 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    double[] var60 = new double[] { };
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var62);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var56);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.0d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    java.lang.Number var15 = null;
    java.lang.Comparable[] var17 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var18, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var15, (java.lang.Object[])var17);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var22, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var29 = var28.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var30 = var28.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = var28.getDirection();
    boolean var33 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var17, var31, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var35 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var31, false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    long[] var2 = new long[] { (-1L), 1L};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)325.59250627415844d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var22 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var22);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var19, var22);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var27, var30, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var34 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var24, var27);
    double var36 = var34.density(99.02988657003175d);
    boolean var37 = var34.isSupportLowerBoundInclusive();
    var34.reseedRandomGenerator(2876919108950029338L);
    double var41 = var34.density(0.7157990521557022d);
    var34.reseedRandomGenerator(1L);
    double[] var45 = var34.sample(7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var45);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    long var7 = var2.nextLong();
    var2.setSeed(8);
    int[] var11 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    int var13 = var12.nextInt();
    long var14 = var12.nextLong();
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c();
    var15.setSeed(6);
    int[] var19 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = var20.nextInt();
    long var22 = var20.nextLong();
    byte[] var23 = new byte[] { };
    var20.nextBytes(var23);
    var15.nextBytes(var23);
    var12.nextBytes(var23);
    var2.nextBytes(var23);
    byte[] var28 = new byte[] { };
    var2.nextBytes(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 5220799318019361146L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1));
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.5996555078851037d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var3, true);
    int var6 = var5.getIndex();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var9);
    int var11 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    boolean var12 = var2.nextBoolean();
    boolean var13 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[] var5 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
//     double[] var8 = new double[] { };
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
//     double[] var14 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var14);
//     double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     double[] var18 = new double[] { };
//     double[] var20 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var20);
//     double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var14);
//     double[] var28 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var28);
//     double[] var31 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var31);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var33);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var33);
//     double[] var37 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var37);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var37);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, 3.0896657965554652d);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var42 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var14, var33);
//     double[] var43 = null;
//     double var44 = org.apache.commons.math3.util.MathArrays.linearCombination(var33, var43);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    boolean var19 = var16.isSupportUpperBoundInclusive();
    var16.reseedRandomGenerator(11L);
    double var22 = var16.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextSecureHexString(9);
//     var0.reSeedSecure();
//     var0.reSeed(120472809892799296L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(106L, 11L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "18a270467"+ "'", var2.equals("18a270467"));
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    java.lang.Object var4 = null;
    boolean var5 = var2.equals(var4);
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getKey();
    java.lang.Object var8 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1L)+ "'", var7.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.probability(0.3055322893119356d);
    double var22 = var16.getSupportLowerBound();
    boolean var23 = var16.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = org.apache.commons.math3.util.MathArrays.distance(var2, var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var5.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var4, true);
    int var7 = var6.getIndex();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException();
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    java.lang.Number var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var10, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var17 = var16.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var16.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var16.getDirection();
    boolean var21 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var19, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)200.0d, (java.lang.Number)195.7110153997647d, 171292551, var19, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     double var16 = var0.nextWeibull(98.46619727159656d, 1.819217204815299d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 234.61761940932126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c392b6c21f"+ "'", var9.equals("c392b6c21f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8361073492936983d);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     int var6 = var0.nextPascal(1, 0.0d);
//     double var8 = var0.nextT(195.7110153997647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.34218225734736135d);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGamma(158.66278299027854d, 0.0699854275336257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 60.99869228904644d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10.727877859107243d);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var9 = new int[] { 100};
//     int[] var11 = new int[] { 100};
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var11);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var11);
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var11);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var11);
//     java.util.List var21 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var22 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var20, var21);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.819217204815299d, (java.lang.Number)0.5104454862955553d, 3, var4, true);
    int var7 = var6.getIndex();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    long[] var13 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
    long[][] var15 = new long[][] { var13};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var15);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var15);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)4.380036973352875d, (java.lang.Object[])var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.34128277750061d, 0.0d, 98.45801321774103d, 0.0d, 43.11121494208779d, 0.0d, 0.0d, 1.0614018016610713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    boolean var40 = var39.isSupportConnected();
    double var41 = var39.getSupportUpperBound();
    boolean var42 = var39.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     var0.reSeedSecure(0L);
//     var0.reSeed();
//     double var8 = var0.nextChiSquare(195.7110153997647d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4377660856016459d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 194.79637114504527d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-264936759), 0);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var18, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[][] var35 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var27, var35);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var17, var35);
    double[] var39 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var39);
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeDivide(var39, var42);
    double[] var45 = new double[] { };
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var45, var47);
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeAdd(var39, var47);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var52);
    double[] var55 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var55);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var55, var58);
    double[] var61 = new double[] { };
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var61, var63);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var63, var66, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var63);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var70 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var60, var63);
    double var72 = var70.density(99.02988657003175d);
    boolean var73 = var70.isSupportLowerBoundInclusive();
    var70.reseedRandomGenerator(2876919108950029338L);
    double var77 = var70.density(0.7157990521557022d);
    var70.reseedRandomGenerator(1L);
    double[] var81 = var70.sample(7);
    double[] var82 = new double[] { };
    double[] var84 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var84);
    double var86 = org.apache.commons.math3.util.MathArrays.distance1(var82, var84);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var84, var87, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var84);
    boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var81, var84);
    org.apache.commons.math3.util.MathArrays.checkOrder(var84);
    double var93 = org.apache.commons.math3.util.MathArrays.distance1(var52, var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 100.0d);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 92);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    double var6 = var2.nextGaussian();
    long var7 = var2.nextLong();
    var2.setSeed(8);
    int[] var11 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
    int var13 = var12.nextInt();
    long var14 = var12.nextLong();
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c();
    var15.setSeed(6);
    int[] var19 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
    int var21 = var20.nextInt();
    long var22 = var20.nextLong();
    byte[] var23 = new byte[] { };
    var20.nextBytes(var23);
    var15.nextBytes(var23);
    var12.nextBytes(var23);
    var2.nextBytes(var23);
    var2.setSeed(99L);
    int[] var31 = new int[] { 100};
    int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 5);
    var2.setSeed(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.6984489763881883d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 5220799318019361146L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    boolean var21 = var16.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var16.probability(96.69144063320101d, 0.2809455189076284d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextWeibull(0.0d, 9.871651067214367d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.9883305629258499d));
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)209.84511029234756d, (java.lang.Number)1.078838815458333d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var11 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var9);
    double[] var12 = new double[] { };
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var14);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var2, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var12 = var1.nextUniform((-1.0d), 121.6356374977755d, true);
//     double var15 = var1.nextF(0.46079183707595545d, 263.1966961055d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextBinomial(6, 2.676352122068371d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.95145733931221d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0793749449371124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 104.64661705798218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.6546272174610901d);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5742251148047507d, (java.lang.Number)7.256842336162741d, 11387117);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-63560251));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c();
    var5.setSeed(6);
    int[] var9 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    int var11 = var10.nextInt();
    long var12 = var10.nextLong();
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var5.nextBytes(var13);
    var2.nextBytes(var13);
    float var17 = var2.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.9570892f);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     java.lang.String var13 = var1.nextHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var1.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45131825612856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 63.46595570543024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 48.15800075109739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "b"+ "'", var13.equals("b"));
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     int var10 = var0.nextInt((-1), 6);
//     double var12 = var0.nextT(204.0345260030692d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(2147483647, 2771.7435600413346d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 217.58060298498015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3283852865747546d);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[] var5 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var5);
//     double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
//     double[] var8 = new double[] { };
//     double[] var10 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var10);
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.ebeAdd(var2, var10);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double[] var17 = new double[] { };
//     double[] var19 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance1(var17, var19);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var19);
//     double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
//     double[] var25 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var25);
//     double[] var28 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var28);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeDivide(var25, var28);
//     double[] var31 = new double[] { };
//     double[] var33 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance1(var31, var33);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var33);
//     double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeAdd(var25, var33);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var38, 0.0d);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var19, var38);
//     double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var2, var19);
//     double var44 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     var1.reSeedSecure(10L);
//     long var17 = var1.nextLong((-178570625128491040L), 0L);
//     double var19 = var1.nextT(243.39148903006193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.12443669408873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6160964367128072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9.413221992523145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-27202004584556044L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.060226214201149195d));
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2104590830736605696L, (java.lang.Number)3887.603878597613d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3887.603878597613d+ "'", var6.equals(3887.603878597613d));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    boolean var20 = var16.isSupportUpperBoundInclusive();
    double var22 = var16.probability(0.0d);
    double var23 = var16.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var3 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var3);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var11);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var17, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.checkOrder(var11, var20, true, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var24, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var27 = null;
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    org.apache.commons.math3.exception.util.Localizable var33 = null;
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var50 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var40, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    double[] var52 = new double[] { };
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var52, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var52, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var61, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51, var69);
    org.apache.commons.math3.exception.MathIllegalStateException var72 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var32, var33, (java.lang.Object[])var69);
    org.apache.commons.math3.exception.MathIllegalStateException var73 = new org.apache.commons.math3.exception.MathIllegalStateException(var28, (java.lang.Object[])var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var11, var27, var69);
    org.apache.commons.math3.exception.NotFiniteNumberException var75 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)73, (java.lang.Object[])var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextBeta(0.6709920656782435d, 92.58889101274673d);
//     double var12 = var0.nextWeibull(299.89733044110505d, 1.5130596728606336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 116.50959254591758d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.34310832800162E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.5079335330352008d);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextF(209.84511029234756d, 1.2351727040922162d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextLong(4286978429002110849L, (-364738407763743936L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.9791130046093914d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var2.nextPermutation(1667864798, (-1128991284));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     double var12 = var0.nextT(10.056389821547084d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation(30, 11387117);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.202184607299236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-165988933659253472L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.037765007662883d);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var10 = var0.nextCauchy(3.0d, 0.2802818762189058d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3846288555899191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.171769354806784d);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     var0.reSeed(3281275508936619520L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-53.64296460224014d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 13.009457723740956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.7302955783791d);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(28, (-549596712));
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-549596712));

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var3 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var3);
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var3);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var6 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var1);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1422716669);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-96398574), 11387117);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 113.21514420198966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0012399809132848812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9700582047736338d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1, 9);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var22 = var16.cumulativeProbability(0.02678742855378105d, 8871.347843840067d);
    double var23 = var16.getSupportLowerBound();
    double var24 = var16.getSupportUpperBound();
    boolean var25 = var16.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     double var15 = var1.nextF(1.4815958130930773d, 299.89733044110505d);
//     int var18 = var1.nextZipf(30, 98.37316917261032d);
//     long var21 = var1.nextLong(10L, 60949576243059920L);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 109666311175995856L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.282853271652816E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.11381348834333911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 32414117392907468L);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var19 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var16, var19);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var24);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var24, var30, true);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var0, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    double var19 = var16.cumulativeProbability(98.57943496629362d);
    var16.reseedRandomGenerator(101L);
    double[] var23 = var16.sample(30);
    double[] var24 = new double[] { };
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    org.apache.commons.math3.util.MathArrays.checkOrder(var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    org.apache.commons.math3.util.MathArrays.OrderDirection var39 = null;
    double[] var40 = new double[] { };
    double[] var42 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var42);
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var40, var42);
    double[] var46 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var40, var46);
    org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
    double[] var51 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var51);
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var54);
    double[][] var57 = new double[][] { var54};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var46, var49, var57);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var39, var57);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double[] var65 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeDivide(var62, var65);
    double[] var69 = org.apache.commons.math3.util.MathArrays.normalizeArray(var62, 100.0d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var70 = null;
    boolean var73 = org.apache.commons.math3.util.MathArrays.checkOrder(var69, var70, false, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var60, var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var76 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var69);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(2.4755170523669765d, 0.0d, 247.92369202626887d, 0.23344772945559902d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 57.87722298178167d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    long var7 = var2.nextLong();
    int var9 = var2.nextInt(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3513799009476651814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var7 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var7);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeDivide(var7, var10);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var12);
    org.apache.commons.math3.exception.NumberIsTooLargeException var18 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.002349480672631077d, (java.lang.Number)5, true);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var27 = new double[] { };
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var27, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var29, var32, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var36 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var26, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    double[] var38 = new double[] { };
    double[] var40 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var40);
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var38, var40);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var38, var44);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var52);
    double[][] var55 = new double[][] { var52};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var44, var47, var55);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var26, var37, var55);
    org.apache.commons.math3.exception.MathIllegalStateException var58 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var18, var19, (java.lang.Object[])var55);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var55);
    double[] var60 = new double[] { };
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var60, var66);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.21819979512271087d), (java.lang.Number)79.25588231908337d, 2);
    int var4 = var3.getIndex();
    int var5 = var3.getIndex();
    int var6 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 10, 1);
//     int var4 = var3.getDimension();
//     java.lang.String var5 = var3.toString();
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(2876919108950029338L, (-89133013451536352L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double[] var5 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var5);
    double[] var7 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var5);
    double[] var8 = new double[] { };
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var8, var10);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var8, var14);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var18 = new double[] { };
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var18, var20);
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var20);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var14);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeDivide(var28, var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, 3.0896657965554652d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var42 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var14, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 809123836);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     double var11 = var0.nextUniform(98.47845151091803d, 99.02988657003175d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(85, 1205512795, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.18045050817264796d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 98.79629480244728d);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     var1.reSeed();
//     double var5 = var1.nextWeibull(165.22373033698972d, 8.035088550415418d);
//     var1.reSeed((-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.004957117437652d);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0847091605564438d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    long var4 = var2.nextLong();
    double var5 = var2.nextGaussian();
    boolean var6 = var2.nextBoolean();
    var2.setSeed(101L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     long var14 = var0.nextLong((-414028722650554365L), 60949576243059920L);
//     double var16 = var0.nextT(200.55910227357631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 218.0189338918402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "8121877ab6"+ "'", var9.equals("8121877ab6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-5948939577378167L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.13418341896698618d);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     long var7 = var1.nextSecureLong((-1L), 152600911433040288L);
//     double var9 = var1.nextChiSquare(0.01408195728001127d);
//     int var12 = var1.nextZipf(10, 1.636388788949819E-6d);
//     int var15 = var1.nextInt((-63560251), 827167750);
//     java.lang.String var17 = var1.nextSecureHexString(73);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextGamma(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 81887647269013840L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.1892921888107841E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 296037983);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "ad978ee80a3b8978641ae2167f8b3051f7a8015198aeee55e4bcac95b4a63b886d257972b"+ "'", var17.equals("ad978ee80a3b8978641ae2167f8b3051f7a8015198aeee55e4bcac95b4a63b886d257972b"));
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    double var12 = var2.nextDouble();
    int var14 = var2.nextInt(6);
    int var15 = var2.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    double var17 = var2.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.761957659063951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2074243331);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.08738583894899854d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int[] var9 = new int[] { 100};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance(var3, var9);
    int[] var13 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    int var15 = var14.nextInt();
    var14.clear();
    var14.setSeed(100L);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var22);
    int[] var28 = new int[] { 100};
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var28);
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
    var14.setSeed(var28);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var3, var28);
    int[] var34 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var35 = new org.apache.commons.math3.random.Well19937c(var34);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var34);
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    int[] var39 = new int[] { 100};
    int[] var41 = new int[] { 100};
    int[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var41);
    int var43 = org.apache.commons.math3.util.MathArrays.distanceInf(var39, var41);
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var41);
    org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(var41);
    int[] var47 = new int[] { 100};
    int[] var49 = new int[] { 100};
    int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var49);
    int[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var49);
    org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(var49);
    int[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 10);
    int var56 = org.apache.commons.math3.util.MathArrays.distance1(var41, var49);
    int var57 = org.apache.commons.math3.util.MathArrays.distanceInf(var34, var49);
    int[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 1);
    int var60 = org.apache.commons.math3.util.MathArrays.distance1(var3, var59);
    int[] var62 = new int[] { 100};
    int[] var64 = new int[] { 100};
    int[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    int var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var62, var64);
    int[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    int[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var64);
    org.apache.commons.math3.random.Well19937c var69 = new org.apache.commons.math3.random.Well19937c(var68);
    int var70 = org.apache.commons.math3.util.MathArrays.distance1(var3, var68);
    int[] var72 = new int[] { 100};
    int[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var72);
    int[] var75 = org.apache.commons.math3.util.MathArrays.copyOf(var72, 6);
    int var76 = org.apache.commons.math3.util.MathArrays.distance1(var3, var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var10 = var1.nextWeibull(0.9846580496679653d, 0.7157990521557022d);
//     java.lang.String var12 = var1.nextSecureHexString(4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextLong(10L, (-100272445965457136L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.31382856614817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 95.112681228572d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.47686594328591786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "de5e"+ "'", var12.equals("de5e"));
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    int[] var1 = new int[] { 100};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var4 = new int[] { 100};
    int[] var6 = new int[] { 100};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    int var8 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var6);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var6);
    int[] var12 = new int[] { 100};
    int[] var14 = new int[] { 100};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var14);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var14);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 10);
    int var21 = org.apache.commons.math3.util.MathArrays.distance1(var6, var14);
    int var22 = org.apache.commons.math3.util.MathArrays.distance1(var1, var6);
    int[] var24 = new int[] { 100};
    int[] var26 = new int[] { 100};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var26);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(var26);
    int var31 = org.apache.commons.math3.util.MathArrays.distance1(var1, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var26, (-264936759));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    int[] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 1422716669);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-63560251), 0);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-63560251)+ "'", var3.equals((-63560251)));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     double var4 = var2.nextDouble();
//     var2.setSeed((-1));
//     var2.setSeed(0L);
//     long var9 = var2.nextLong();
//     var2.setSeed(10);
//     var2.clear();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
//     double var16 = var13.nextUniform(98.42888798257793d, 15938.704455172932d);
//     int var19 = var13.nextSecureInt((-1128991284), 9);
//     var13.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var13.nextBinomial(100, 127.85684586340369d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.01408195728001127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4736355256857903122L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12168.048178086838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-563012966));
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5957881318373452d, (java.lang.Number)64.63644971152944d, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 64.63644971152944d+ "'", var4.equals(64.63644971152944d));

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextZipf(100, 0.9638486378008077d);
//     long var5 = var0.nextPoisson(98.88500098380753d);
//     long var7 = var0.nextPoisson(742.6248114744293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 94L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 750L);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)244);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    float[] var8 = new float[] { 0.0f, (-1.0f)};
    float[] var9 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var9);
    java.lang.Object[] var11 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var5, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)(byte)10, var11);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var11);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var20 = var16.getSupportUpperBound();
    var16.reseedRandomGenerator((-115747454037461536L));
    double var23 = var16.getSupportLowerBound();
    var16.reseedRandomGenerator(3513799009476651814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 819462356, 809123836);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-11.931127172391996d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 16.55908715748299d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.30872093323133004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.6860754221466062d));
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    java.lang.Object var8 = var2.getFirst();
    java.lang.Object var9 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1L+ "'", var9.equals(1L));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)8.85641908221212d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.cumulativeProbability(1.0646160893106429d);
    double var22 = var16.getSupportUpperBound();
    var16.reseedRandomGenerator((-4382318871018329088L));
    boolean var25 = var16.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    float var3 = var0.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.670992f);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.95514037483926d, 23.806807545596826d, 0.0d, 0.0d, 9.92668559023387d, 1.0001477678926383E8d, (-1.557125034392254d), 0.003494754140413766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.92817599364983E8d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.16187697798920236d, (java.lang.Number)0.4317212f, true);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var5, (java.lang.Number)253.07859717090338d);
    var3.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)98.2718673777206d, (java.lang.Number)(-0.9405132696386548d), true);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(3);
    var2.setSeed(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    java.lang.Number var6 = var5.getPrevious();
    boolean var7 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var10 = var0.nextGaussian(183.2263881473488d, 10.63187445392841d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextZipf(0, 98.42599099481274d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 132.64732116960357d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 179.87298034254235d);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 10};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)100, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    java.lang.String var8 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var8.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     java.lang.String var8 = var1.nextHexString(8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(1702.9401715137005d, 0.33468965266836004d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "407bd4930e"+ "'", var6.equals("407bd4930e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7f8d6a52"+ "'", var8.equals("7f8d6a52"));
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     int var11 = var1.nextInt(2, 9);
//     var1.reSeed((-115747454037461536L));
//     double var17 = var1.nextUniform(1.2000918311981499d, 1.0001477678926383E8d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 10.038853460454245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1311450620827197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.843372449527642E7d);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure((-414028722650554365L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(315951.04828560806d, 0.3055322893119356d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 209.22890927981544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "74948d4452"+ "'", var9.equals("74948d4452"));
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var6 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var6);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
//     double[] var9 = new double[] { };
//     double[] var11 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
//     boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
//     boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
//     double[] var25 = new double[] { };
//     double[] var27 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
//     double[] var31 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
//     boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var37, true);
//     double[] var41 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var41);
//     double[] var44 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var44);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var44);
//     double[] var47 = new double[] { };
//     double[] var49 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var49);
//     double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49, var52, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var46, var49);
//     double var58 = var56.density(99.02988657003175d);
//     boolean var59 = var56.isSupportLowerBoundInclusive();
//     var56.reseedRandomGenerator(2876919108950029338L);
//     double var63 = var56.density(0.7157990521557022d);
//     var56.reseedRandomGenerator(1L);
//     double[] var67 = var56.sample(7);
//     double[] var68 = new double[] { };
//     double[] var70 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var70);
//     double var72 = org.apache.commons.math3.util.MathArrays.distance1(var68, var70);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70, var73, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var67, var70);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var70);
//     double[] var80 = null;
//     double var81 = org.apache.commons.math3.util.MathArrays.linearCombination(var70, var80);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    var1.reSeedSecure();
    var1.reSeedSecure();

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.00801543912443346d, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.1707426224135316d);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     int var14 = var0.nextZipf(9, 210.26801214771172d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial(6, 1.057654215217053d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 191.77118595925222d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "3057a8b901"+ "'", var9.equals("3057a8b901"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    org.apache.commons.math3.exception.NotANumberException var4 = new org.apache.commons.math3.exception.NotANumberException();
    var3.addSuppressed((java.lang.Throwable)var4);
    java.lang.String var6 = var3.toString();
    boolean var7 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 7 and 8 are not strictly increasing (299.897 >= 1.322)"+ "'", var6.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 7 and 8 are not strictly increasing (299.897 >= 1.322)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     var1.reSeedSecure(16412887479476156L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.23893878687137d);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var5 = var4.getKey();
    java.lang.Object var6 = var4.getSecond();
    org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair(var4);
    java.lang.Object var8 = var4.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1L)+ "'", var5.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1L+ "'", var6.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1L+ "'", var8.equals(1L));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextPascal(92, 99.02988657003175d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextGaussian(210.05292023350523d, 0.00801543912443346d);
//     var1.reSeed(31715294113568244L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextSecureHexString((-163349561));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.45016536752121d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 210.0573946420688d);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var16 = var0.nextGaussian(0.0d, 70377.26652913699d);
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var0.nextInversionDeviate(var17);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(167.10424588351813d, 51.30880113197997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(88.15402739841298d, 85.18111844245895d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 223.71591836456298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10106.915183038462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7613713067452781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 239.6857631428271d);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)(-1.0f), var6, true);
    java.lang.Number var9 = var8.getMin();
    boolean var10 = var8.getBoundIsAllowed();
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Throwable[] var12 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     var0.setSeed(6);
//     int[] var4 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
//     int var6 = var5.nextInt();
//     long var7 = var5.nextLong();
//     byte[] var8 = new byte[] { };
//     var5.nextBytes(var8);
//     var0.nextBytes(var8);
//     int[] var11 = new int[] { };
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 6);
//     var0.setSeed(var11);
//     int[] var16 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
//     int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance(var11, var19);
//     int[] var22 = null;
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var22);
//     int[] var25 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(var25);
//     org.apache.commons.math3.random.Well19937c var27 = new org.apache.commons.math3.random.Well19937c(var25);
//     int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
//     int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    double var8 = var7.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.3674175180023106d));

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 3);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(1.2388070620041405d, 98.45317552126936d, true);
//     double var13 = var1.nextExponential(290.77256675474683d);
//     double var16 = var1.nextWeibull(0.9846580496679653d, 9.927198205545196d);
//     long var18 = var1.nextPoisson(99.02988657003175d);
//     double var21 = var1.nextGaussian(99.2782319289774d, 98.46652934914283d);
//     double var23 = var1.nextExponential(243.39148903006193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.4533634845985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 97.76363483209344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 72.11135414877975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 404.66549833768465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.548042389576006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 110L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 159.78378389742832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 126.81149513152093d);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextExponential(0.2683148062047325d);
//     long var5 = var0.nextPoisson(98.83522491911816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.12959630956947163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 79L);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    int[] var1 = new int[] { 100};
    int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var15, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var9, var18, true, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var22, false);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, (-96398574));
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.05949668097310608d, 0.28356588000571664d, 23405.381799800452d, 2.5520859880271014d, 18679.615042775484d, (-0.4378278462730581d), 252.87948712226319d, 1.2351727040922162d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 51866.458023454026d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100.0d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.String var3 = var1.toString();
    boolean var4 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"+ "'", var3.equals("org.apache.commons.math3.exception.NotPositiveException: 100 is smaller than the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     int var9 = var0.nextSecureInt(7, 30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextF(0.0d, 192.2191052341085d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-151.84811537410783d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 17);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1422716669, 1422716669);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1422716669);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("5", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8007288878700061d);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    java.lang.Throwable[] var9 = var5.getSuppressed();
    java.lang.Number var10 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0f+ "'", var10.equals(0.0f));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    long[] var5 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var5);
    long[][] var7 = new long[][] { var5};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var7);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextGaussian(210.05292023350523d, 0.00801543912443346d);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var1.nextSample(var8, 28);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)98.42176142483318d, (java.lang.Number)1.2000918311981499d, 7);
    java.lang.Number var4 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.2000918311981499d+ "'", var4.equals(1.2000918311981499d));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
    int[] var11 = new int[] { 100};
    int[] var13 = new int[] { 100};
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var13);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var13);
    int[] var19 = new int[] { 100};
    int[] var21 = new int[] { 100};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var21);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var21);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 10);
    int var28 = org.apache.commons.math3.util.MathArrays.distance1(var13, var21);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var13);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     int var9 = var1.nextZipf(10, 13.521216539811984d);
//     double var11 = var1.nextChiSquare(1.2388070620041405d);
//     var1.reSeed();
//     double var15 = var1.nextCauchy(0.3055322893119356d, 0.020579212303715753d);
//     long var17 = var1.nextPoisson(63.20443649540218d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextUniform(190.21516127970872d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.88585765674934d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8"+ "'", var6.equals("8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.9596882776062552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.31152474681352227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 69L);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var3);
    int[] var9 = new int[] { 100};
    int[] var11 = new int[] { 100};
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    int var13 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var11);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var11);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 10);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var11);
    int[] var20 = new int[] { 100};
    int[] var22 = new int[] { 100};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var22);
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var22);
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var3, var22);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     double var16 = var0.nextWeibull(98.46619727159656d, 1.819217204815299d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextGamma(605.1646017532264d, (-44205.17684959541d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 200.9696304720652d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "4ee40e45d1"+ "'", var9.equals("4ee40e45d1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.8361073492936983d);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     var0.reSeed(2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(0.9388262972919159d, 0.4826365375887363d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 185.5103767793697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "940b840a74"+ "'", var9.equals("940b840a74"));
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var12 = var1.nextUniform((-1.0d), 121.6356374977755d, true);
//     long var15 = var1.nextLong(259766232686583471L, 3513799009476651814L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextHypergeometric(5, 4, (-125716405));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.991643211130027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.1510104301427626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 121.5285871676682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1066588881589419520L);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    long var5 = var2.nextLong();
    var2.setSeed(45911908942817152L);
    double var8 = var2.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2269827290554446382L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-2.367121190248177d));

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     long var9 = var0.nextLong((-4736355256857903122L), (-414028722650554365L));
//     double var12 = var0.nextF(23.41031146092985d, 1.2000918311981499d);
//     int var16 = var0.nextHypergeometric(1422716669, 0, 0);
//     double var18 = var0.nextT(10.024409082583382d);
//     long var21 = var0.nextSecureLong((-32909180328375108L), 16412887479476156L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 29.597453627928687d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4368667302258025984L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5917234504871638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.4548538617229418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-7990904574080725L));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportLowerBound();
    double var21 = var16.density(1.2316468095843844d);
    double var23 = var16.inverseCumulativeProbability(1.0d);
    double var25 = var16.density(8871.347843840067d);
    double var26 = var16.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int[] var7 = new int[] { 100};
    int[] var9 = new int[] { 100};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var3.setSeed(var13);
    int[] var16 = new int[] { 100};
    int[] var18 = new int[] { 100};
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var18);
    int var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var18);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var13, var18);
    int[] var23 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var23);
    int var25 = var24.nextInt();
    var24.clear();
    var24.setSeed(100L);
    int[] var30 = new int[] { 100};
    int[] var32 = new int[] { 100};
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var32);
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(var32);
    int[] var38 = new int[] { 100};
    int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var38);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var38);
    var24.setSeed(var38);
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     int var12 = var0.nextZipf(6, 321.6792596437714d);
//     int var15 = var0.nextZipf(5, 1.9605318349984269d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(2147483647, 827167750);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 217.75139077502286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.007679394579718229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.cumulativeProbability(0.03359081770746613d);
    double[] var20 = var16.sample(4);
    double[] var21 = new double[] { };
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var21, var23);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = org.apache.commons.math3.util.MathArrays.distance(var20, var26);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var9, false, true);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeDivide(var14, var17);
    double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, 0.0d);
    double var22 = org.apache.commons.math3.util.MathArrays.distance(var6, var14);
    double[] var23 = new double[] { };
    double[] var25 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var25);
    double var27 = org.apache.commons.math3.util.MathArrays.distance1(var23, var25);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var23, var29);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var37);
    double[][] var40 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var29, var32, var40);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var40);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var47 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var47);
    double[] var50 = new double[] { };
    double[] var52 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var50, var52);
    org.apache.commons.math3.util.MathArrays.checkPositive(var52);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var52);
    double[] var59 = org.apache.commons.math3.util.MathArrays.normalizeArray(var57, 0.0d);
    double[] var60 = new double[] { };
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var60, var62);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var60, var66);
    org.apache.commons.math3.util.MathArrays.OrderDirection var69 = null;
    double[] var71 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var71);
    double[] var74 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var74);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeDivide(var71, var74);
    double[][] var77 = new double[][] { var74};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var66, var69, var77);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var57, var77);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var5.nextPermutation((-1128991284), 819462356);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
//     java.lang.Throwable var4 = null;
//     var3.addSuppressed(var4);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextInt((-1), 8);
//     var0.reSeedSecure(2L);
//     var0.reSeed(0L);
//     double var13 = var0.nextT(0.1490436810544255d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var16 = var0.nextPermutation(72, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 216.06599478302414d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17.84896418597868d);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var6 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var6);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
//     double[] var9 = new double[] { };
//     double[] var11 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
//     double[] var15 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
//     boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
//     boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
//     double[] var25 = new double[] { };
//     double[] var27 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var27);
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
//     double[] var31 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
//     boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var37, true);
//     double[] var41 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var41);
//     double[] var44 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var44);
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var44);
//     double[] var47 = new double[] { };
//     double[] var49 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var49);
//     double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49, var52, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var49);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var46, var49);
//     double var58 = var56.density(99.02988657003175d);
//     boolean var59 = var56.isSupportLowerBoundInclusive();
//     var56.reseedRandomGenerator(2876919108950029338L);
//     double var63 = var56.density(0.7157990521557022d);
//     var56.reseedRandomGenerator(1L);
//     double[] var67 = var56.sample(7);
//     double[] var68 = new double[] { };
//     double[] var70 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var70);
//     double var72 = org.apache.commons.math3.util.MathArrays.distance1(var68, var70);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70, var73, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var67, var70);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var70);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var70);
//     double[] var80 = null;
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeDivide(var70, var80);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    long[] var2 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    long[][] var4 = new long[][] { var2};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    long[] var7 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
    long[][] var9 = new long[][] { var7};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)98.42888798257793d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)9.973067336611587d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.9605318349984269d, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     var0.reSeedSecure((-1L));
//     int var14 = var0.nextZipf(9, 210.26801214771172d);
//     double var17 = var0.nextGaussian((-55.973096495762256d), 98.45377290426184d);
//     double var19 = var0.nextExponential(199.10497585318416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 220.0703428554842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c8ed75f3bf"+ "'", var9.equals("c8ed75f3bf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-135.57673003738026d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 225.74839664568833d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.7446287025499129d, (java.lang.Number)0.40877557f, false);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var10);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.3220963206821523d, (java.lang.Number)299.89733044110505d, 8);
    int var17 = var16.getIndex();
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var16.getContext();
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var16.getDirection();
    boolean var22 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var19, true, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var23, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)98.59613022131569d, (java.lang.Number)15938.704455172932d, true);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(100, 9);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 241.82706416543596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10046.750558229542d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.39606677309577476d);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     double var15 = var0.nextGaussian(0.01360821383479298d, 98.78946634923011d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 330.65656176681443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.42680566457563507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.8673784349219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-21.491089289801923d));
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextInt(819462356, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "75ecf45849"+ "'", var6.equals("75ecf45849"));
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var15 = var1.nextUniform(0.002349480672631077d, 42.56784123878263d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("e06d56c374", "cdcc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.51177320868027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "d"+ "'", var6.equals("d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.3651297962933229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.06278490221814612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 24.39388362114258d);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.cumulativeProbability(1.0646160893106429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var16.cumulativeProbability(91.3629924210577d, 0.9184495496004099d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(98.45317552126936d);
//     var0.reSeedSecure();
//     int var6 = var0.nextInt(2, 2074243331);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextUniform(605.1646017532264d, 209.60862244176295d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.356211940336911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 919307376);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)1.0737206121073526d, 4, var3, true);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    java.lang.Number var7 = var5.getPrevious();
    java.lang.Number var8 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0737206121073526d+ "'", var7.equals(1.0737206121073526d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    boolean var17 = var16.isSupportLowerBoundInclusive();
    double var19 = var16.cumulativeProbability(98.57943496629362d);
    var16.reseedRandomGenerator(101L);
    double[] var23 = var16.sample(30);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1042);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)284.941661635924d, (java.lang.Number)205.6654070615057d, (java.lang.Number)3.296907484618753d);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     double var11 = var0.nextT(211.79400708576884d);
//     long var13 = var0.nextPoisson(0.7090371711746789d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1", "6c8f794b2");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 168.04143452457703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "7bb981fd53"+ "'", var9.equals("7bb981fd53"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.0440626137081543d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double[] var18 = var16.sample(9);
    double var19 = var16.getSupportUpperBound();
    double var20 = var16.getSupportUpperBound();
    double var21 = var16.getNumericalVariance();
    var16.reseedRandomGenerator(95L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.String var1 = var0.toString();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var0.getContext();
    java.lang.Throwable[] var4 = var0.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"+ "'", var1.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var9 = null;
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var9, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var5, var10);
    float[] var13 = null;
    float[] var14 = new float[] { };
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var13, var14);
    float[] var18 = new float[] { 0.0f, (-1.0f)};
    float[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var13, var18);
    float[] var22 = null;
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var22, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var18, var23);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var5, var18);
    float[] var27 = null;
    float[] var28 = new float[] { };
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var27, var28);
    float[] var30 = new float[] { };
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    float[] var32 = null;
    float[] var33 = new float[] { };
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var32, var33);
    float[] var37 = new float[] { 0.0f, (-1.0f)};
    float[] var38 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var32, var37);
    float[] var41 = null;
    float[] var42 = new float[] { };
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var41, var42);
    float[] var46 = new float[] { 0.0f, (-1.0f)};
    float[] var47 = null;
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var41, var46);
    float[] var50 = null;
    float[] var51 = new float[] { };
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var50, var51);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var46, var51);
    float[] var54 = null;
    float[] var55 = new float[] { };
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var54, var55);
    float[] var59 = new float[] { 0.0f, (-1.0f)};
    float[] var60 = null;
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var54, var59);
    float[] var63 = null;
    float[] var64 = new float[] { };
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var63, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var59, var64);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var46, var59);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var37, var46);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var30, var46);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var18, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     int var4 = var0.nextInt(0, 10);
//     double var7 = var0.nextGaussian(1.176542981693557d, 1.8507918026021757d);
//     long var10 = var0.nextLong((-414028722650554365L), 132L);
//     long var13 = var0.nextSecureLong((-190865323983646368L), 1L);
//     double var16 = var0.nextGaussian(226.71502882511598d, 99.8591140316555d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.9108655595357689d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-65997532615886696L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-84397019443466256L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 156.12163537787714d);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     long var12 = var0.nextLong((-414028722650554365L), 100L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextSecureInt(4, (-1128991284));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 139.09086548579782d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.10051539435861026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-306032671886376640L));
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    var2.clear();
    var2.setSeed(100L);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    double[] var13 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var13);
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var7, var13);
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var16, false, true);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var13, var21);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeDivide(var31, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 100.0d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var2, var13, var31);
    org.apache.commons.math3.random.RandomDataImpl var40 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var2);
    java.lang.String var42 = var40.nextHexString(7);
    var40.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var46 = var40.nextPascal((-96398574), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "150543b"+ "'", var42.equals("150543b"));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     int[] var1 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     int var3 = var2.nextInt();
//     long var4 = var2.nextLong();
//     double var5 = var2.nextGaussian();
//     double var6 = var2.nextGaussian();
//     var2.setSeed(43059505226525080L);
//     long var9 = var2.nextLong();
//     int[] var10 = null;
//     var2.setSeed(var10);
//     float var12 = var2.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-96398574));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.7157990521557022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6984489763881883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4848980640512349401L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5335232f);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGaussian(99.2782319289774d, 0.05877392154888082d);
//     double var9 = var0.nextChiSquare(1.0836579002185789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 120.22721817250748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 99.35991845990331d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.18534362080316832d);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1422716669, 92);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)98.6636142140316d, (java.lang.Number)30, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-1L));
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-3372461070849671680L));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var1);
    long var4 = var3.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
    int[] var7 = new int[] { 100};
    int[] var9 = new int[] { 100};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    var3.setSeed(var13);
    var3.setSeed(11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-414028722650554365L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var9);
    double[] var15 = new double[] { };
    double[] var17 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var15, var17);
    double[] var21 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var15, var21);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    boolean var27 = org.apache.commons.math3.util.MathArrays.checkOrder(var21, var24, false, true);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var32 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var32);
    double[] var36 = org.apache.commons.math3.util.MathArrays.normalizeArray(var29, 0.0d);
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var21, var29);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var38 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var14, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    float[] var11 = new float[] { 0.0f, (-1.0f)};
    float[] var12 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var12);
    java.lang.Object[] var14 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)(byte)10, var14);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, var4, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)3887.603878597613d, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2147483647, 7);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
    double[] var6 = new double[] { };
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var6, var8);
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var6, var12);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var12, var15, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var19, false);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var28);
    double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var32);
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double[] var38 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var38);
    double[] var41 = new double[] { };
    double[] var43 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var41, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var43, var46, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var50 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var40, var43);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = null;
    double[] var52 = new double[] { };
    double[] var54 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var54);
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var52, var54);
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var52, var58);
    org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
    double[] var63 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var63);
    double[] var66 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var63, var66);
    double[][] var69 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var61, var69);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var40, var51, var69);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var72 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var32, var40);
    double[] var73 = new double[] { };
    double[] var75 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var73, var75);
    double[] var79 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var79);
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var73, var79);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = null;
    boolean var85 = org.apache.commons.math3.util.MathArrays.checkOrder(var79, var82, false, true);
    double[] var87 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var87);
    double[] var90 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var90);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeDivide(var87, var90);
    double[] var94 = org.apache.commons.math3.util.MathArrays.normalizeArray(var87, 0.0d);
    double var95 = org.apache.commons.math3.util.MathArrays.distance(var79, var87);
    double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var87);
    double var97 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 99.0d);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var1.nextPermutation(0, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.96815844600373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2"+ "'", var6.equals("2"));
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var18 = var16.density(99.02988657003175d);
    double var20 = var16.cumulativeProbability(1.208726759939196d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var22 = var16.sample((-264936759));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var12 = var1.nextGaussian(9.927198205545196d, 0.5104454862955553d);
//     var1.reSeedSecure(10L);
//     long var17 = var1.nextLong((-178570625128491040L), 0L);
//     double var20 = var1.nextGamma(1.0410251609935102d, 77.74838373665371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 99.31693111660628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "6"+ "'", var6.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.6818153752252089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9.155316616046466d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-156065838496041088L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 263.40732128021443d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 10, 1);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    int var5 = var3.getDimension();
    int var6 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)315951.04828560806d, (java.lang.Number)275.37293954352356d, false);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)18.70038216057098d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    int[] var4 = new int[] { 100};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    boolean var6 = var2.equals((java.lang.Object)var4);
    java.lang.Object var7 = var2.getValue();
    java.lang.Object var8 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1L+ "'", var7.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    int[] var1 = new int[] { 100};
    int[] var3 = new int[] { 100};
    int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-21.491089289801923d));

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var13 = var1.nextT(98.46619727159656d);
//     double var15 = var1.nextExponential(0.7694547768954918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100.49580968713244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "5"+ "'", var6.equals("5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.054158776464126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.05327950722912841d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.3968879300759241d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0516273656693287d);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     int var12 = var0.nextZipf(6, 321.6792596437714d);
//     double var15 = var0.nextUniform((-833.4352718740605d), 6.05792045843231d);
//     double var17 = var0.nextT(98.47480055949d);
//     var0.reSeedSecure(120472809892799296L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 94.01519101181238d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 11.511416173396643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-809.815483909131d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5526672969649961d);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(100.0d, 100.0d);
//     java.lang.String var6 = var1.nextSecureHexString(1);
//     double var9 = var1.nextF(98.34128277750061d, 98.42176142483318d);
//     double var11 = var1.nextChiSquare(1.0847091605564438d);
//     double var13 = var1.nextT(98.46619727159656d);
//     long var15 = var1.nextPoisson(106.0271272985156d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextUniform(106.0271272985156d, 9.921853769627177d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.8954116245823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "7"+ "'", var6.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2084360651871064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5374287432835984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.03317818915148789d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 118L);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(byte)1, var1, (java.lang.Number)(short)0);
    java.lang.Number var4 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 2074243331, (-96398574));
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-96398574));

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     java.lang.String var9 = var0.nextHexString(10);
//     double var11 = var0.nextT(211.79400708576884d);
//     long var13 = var0.nextPoisson(0.7090371711746789d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextGaussian(4.516769944047001d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 234.9697679594982d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "b3320cd41f"+ "'", var9.equals("b3320cd41f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.1984215875776048d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextWeibull(1.6486550157904805d, 100.0d);
//     double var7 = var0.nextGamma(98.88500098380753d, 1.0847091605564438d);
//     java.lang.String var9 = var0.nextSecureHexString(5);
//     int var12 = var0.nextBinomial(1, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 132.38030155725377d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 105.26207852446285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "533e1"+ "'", var9.equals("533e1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var12 = var0.nextGaussian(290.77256675474683d, 0.05877392154888082d);
//     double var15 = var0.nextGaussian(0.01360821383479298d, 98.78946634923011d);
//     double var17 = var0.nextExponential(263.1966961055d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-62.11357412541258d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.25102296631632914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 290.80903068434395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-6.702045322549117d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 121.32302744499553d);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.01408195728001127d, (java.lang.Number)13.009457723740956d, false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    long var5 = var2.nextLong();
    var2.setSeed(45911908942817152L);
    boolean var8 = var2.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2269827290554446382L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    var0.setSeed(6);
    int[] var4 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(var4);
    int var6 = var5.nextInt();
    long var7 = var5.nextLong();
    byte[] var8 = new byte[] { };
    var5.nextBytes(var8);
    var0.nextBytes(var8);
    int[] var11 = new int[] { };
    int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 6);
    var0.setSeed(var11);
    int[] var16 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
    int[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    double var21 = org.apache.commons.math3.util.MathArrays.distance(var11, var19);
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(827167750, 1736698663);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1642703950);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(224.24061129059865d, 0.0d, 1.3220963206821523d, 2.093594075635607d, 0.0d, 196.13997997609036d, 0.0d, 0.7157990521557022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.7679330243997877d);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[] var10 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 3.0896657965554652d);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.checkOrder(var6, var15, false, true);
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var23);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeAdd(var20, var28);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var36 = org.apache.commons.math3.util.MathArrays.linearCombination(var6, var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var3 = var0.nextT(98.28206305872513d);
//     java.lang.String var5 = var0.nextHexString(7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.12978592361376748d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "d8eb1b2"+ "'", var5.equals("d8eb1b2"));
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    float[] var0 = null;
    float[] var1 = new float[] { };
    boolean var2 = org.apache.commons.math3.util.MathArrays.equals(var0, var1);
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var6 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var6);
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var0, var5);
    float[] var9 = null;
    float[] var10 = new float[] { };
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var9, var10);
    float[] var14 = new float[] { 0.0f, (-1.0f)};
    float[] var15 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var14);
    float[] var18 = null;
    float[] var19 = new float[] { };
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var18, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    float[] var22 = null;
    float[] var23 = new float[] { };
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var22, var23);
    float[] var27 = new float[] { 0.0f, (-1.0f)};
    float[] var28 = null;
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var22, var27);
    float[] var31 = null;
    float[] var32 = new float[] { };
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var31, var32);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var27, var32);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var14, var27);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var5, var14);
    float[] var37 = null;
    float[] var38 = new float[] { };
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var37, var38);
    float[] var42 = new float[] { 0.0f, (-1.0f)};
    float[] var43 = null;
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var37, var42);
    float[] var46 = null;
    float[] var47 = new float[] { };
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var46, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var42, var47);
    float[] var52 = new float[] { 0.0f, (-1.0f)};
    float[] var53 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var47, var52);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var14, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     double var9 = var0.nextWeibull(0.5104454862955553d, 1.0991832135313893d);
//     double var11 = var0.nextChiSquare(1.2316468095843844d);
//     double var13 = var0.nextT(99.2782319289774d);
//     double var15 = var0.nextT(98.47845151091803d);
//     java.lang.String var17 = var0.nextHexString(100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-91.91274283150759d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.101872816223852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.04531378860481878d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.13397291649800916d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.02982135518297794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "a0a4d15ab202dbcd8e26ab10a562944b1eadbafbaccd5199fe2f95895a3f7050ba3bd3e81bd2feff1fe91f36eeceb91cd06f"+ "'", var17.equals("a0a4d15ab202dbcd8e26ab10a562944b1eadbafbaccd5199fe2f95895a3f7050ba3bd3e81bd2feff1fe91f36eeceb91cd06f"));
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var11 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var9);
    double[] var12 = new double[] { };
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var14, var17, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var21 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var11, var14);
    double var23 = var21.density(99.02988657003175d);
    boolean var24 = var21.isSupportLowerBoundInclusive();
    var21.reseedRandomGenerator(2876919108950029338L);
    double var28 = var21.density(0.7157990521557022d);
    var21.reseedRandomGenerator(1L);
    double[] var32 = var21.sample(7);
    double[] var33 = new double[] { };
    double[] var35 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var33, var35);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var35, var38, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double[] var9 = new double[] { };
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var9, var11);
    double[] var15 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var15);
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var9, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var18, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var22, false);
    double[] var25 = new double[] { };
    double[] var27 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var25, var27);
    double[] var31 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var31);
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var25, var31);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeDivide(var15, var31);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var15);
    org.apache.commons.math3.util.MathArrays.OrderDirection var37 = null;
    boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var36, var37, true);
    double[] var41 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var41);
    double[] var44 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var44);
    double[] var47 = new double[] { };
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var49, var52, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var56 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var46, var49);
    double var58 = var56.density(99.02988657003175d);
    boolean var59 = var56.isSupportLowerBoundInclusive();
    var56.reseedRandomGenerator(2876919108950029338L);
    double var63 = var56.density(0.7157990521557022d);
    var56.reseedRandomGenerator(1L);
    double[] var67 = var56.sample(7);
    double[] var68 = new double[] { };
    double[] var70 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var68, var70);
    org.apache.commons.math3.util.MathArrays.OrderDirection var73 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var70, var73, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var67, var70);
    org.apache.commons.math3.util.MathArrays.checkOrder(var70);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var79 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var36, var70);
    double var80 = var79.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d", "edb0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.46229508017086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 105.14225249559166d);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    double[] var8 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var8);
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var13 = org.apache.commons.math3.util.MathArrays.ebeDivide(var8, var11);
    double[] var14 = new double[] { };
    double[] var16 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var14, var16);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var16);
    double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, 0.0d);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var2, var21);
    double[] var26 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var29 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeDivide(var26, var29);
    double[] var32 = new double[] { };
    double[] var34 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
    org.apache.commons.math3.util.MathArrays.checkPositive(var34);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var34);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var34, var40, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.checkOrder(var34, var43, true, false);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeDivide(var21, var34);
    org.apache.commons.math3.random.RandomGenerator var48 = null;
    double[] var50 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var50);
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var53);
    double[] var56 = new double[] { };
    double[] var58 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var58);
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var56, var58);
    double[] var62 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var56, var62);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    double[] var66 = new double[] { };
    double[] var68 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var66, var68);
    org.apache.commons.math3.util.MathArrays.checkPositive(var68);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var68);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var62, var68);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeDivide(var50, var62);
    double[] var76 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var76);
    double[] var79 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var79);
    double[] var81 = org.apache.commons.math3.util.MathArrays.ebeDivide(var76, var79);
    org.apache.commons.math3.util.MathArrays.checkOrder(var81);
    org.apache.commons.math3.util.MathArrays.checkOrder(var81);
    double[] var85 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var81, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.normalizeArray(var81, 3.0896657965554652d);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var90 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var48, var62, var81);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    double[] var11 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var11);
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double[] var16 = org.apache.commons.math3.util.MathArrays.ebeDivide(var11, var14);
    double[][] var17 = new double[][] { var14};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var9, var17);
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(98.43652237373647d, 34.658825246755825d, 2452.034644566469d, 101.70480228133563d, 0.9922067047843496d, 0.0d, 23761.61681804298d, 208.18143482883644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5199522.875972667d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)187.4155101509404d, var1, false);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    int[] var1 = new int[] { 0};
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    int var3 = var2.nextInt();
    double var4 = var2.nextDouble();
    var2.setSeed((-1));
    var2.setSeed(0L);
    long var9 = var2.nextLong();
    var2.setSeed(10);
    int var13 = var2.nextInt(827167750);
    boolean var14 = var2.nextBoolean();
    org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var17 = var15.nextPoisson((-1.6720706382152082d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-96398574));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.01408195728001127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-4736355256857903122L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 809123836);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)98.43713016096305d, (java.lang.Number)9.834337537501083d, 5);
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.0847091605564438d);
    var3.addSuppressed((java.lang.Throwable)var5);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var2 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var2);
//     double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
//     double[] var6 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var6);
//     double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
//     double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
//     double[] var10 = new double[] { };
//     double[] var12 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     double[] var16 = new double[] { };
//     double[] var18 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var18);
//     double var20 = org.apache.commons.math3.util.MathArrays.distance1(var16, var18);
//     double[] var22 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var16, var22);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
//     boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var22, var25, false, true);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     boolean var31 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var29, false);
//     double[] var32 = new double[] { };
//     double[] var34 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var32, var34);
//     double[] var38 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var38);
//     double var40 = org.apache.commons.math3.util.MathArrays.distance1(var32, var38);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var38);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var15, var42);
//     double[] var45 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var45);
//     double[] var48 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var48);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeDivide(var45, var48);
//     double[] var51 = new double[] { };
//     double[] var53 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var53);
//     double var55 = org.apache.commons.math3.util.MathArrays.distance1(var51, var53);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var56 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var53, var56, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var53);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var50, var53);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var61 = null;
//     double[] var62 = new double[] { };
//     double[] var64 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var64);
//     double var66 = org.apache.commons.math3.util.MathArrays.distance1(var62, var64);
//     double[] var68 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var68);
//     double var70 = org.apache.commons.math3.util.MathArrays.distance1(var62, var68);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var71 = null;
//     double[] var73 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var73);
//     double[] var76 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var76);
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeDivide(var73, var76);
//     double[][] var79 = new double[][] { var76};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var68, var71, var79);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var50, var61, var79);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var82 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var42, var50);
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var42);
//     double[] var85 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var85);
//     double var87 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
//     boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var42, var85);
//     double[] var90 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 0.39583726512027007d);
//     double[] var91 = null;
//     double var92 = org.apache.commons.math3.util.MathArrays.distance1(var90, var91);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.2802818762189058d, (java.lang.Number)0.08748839710302334d, false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextWeibull(98.45317552126936d, 10.0d);
//     double var8 = var1.nextUniform(1.0d, 1.2388070620041405d, false);
//     double var12 = var1.nextUniform((-1.0d), 121.6356374977755d, true);
//     double var15 = var1.nextF(0.46079183707595545d, 263.1966961055d);
//     double var17 = var1.nextChiSquare(208.6189578014164d);
//     long var19 = var1.nextPoisson(1.4606943286412477d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.879954631323606d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0989486210752393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 106.86435898139051d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.4778000789108376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 209.7238641960261d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 3L);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)100, (java.lang.Number)0.0f, 0, var3, false);
    boolean var6 = var5.getStrict();
    int var7 = var5.getIndex();
    java.lang.Number var8 = var5.getPrevious();
    java.lang.Number var9 = var5.getPrevious();
    boolean var10 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0f+ "'", var8.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.0f+ "'", var9.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextGamma(115.88842315603809d, 1.7904651608248163d);
//     int var7 = var0.nextZipf(8, 98.28206305872513d);
//     double var10 = var0.nextWeibull(97.97864407980379d, 9999.0d);
//     double var12 = var0.nextT(1.7904651608248163d);
//     double var15 = var0.nextCauchy(5.7663381855453295d, 9.834337537501083d);
//     var0.reSeed();
//     double[] var18 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var18);
//     double[] var21 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var21);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var21);
//     double[] var24 = new double[] { };
//     double[] var26 = new double[] { 100.0d};
//     org.apache.commons.math3.util.MathArrays.checkPositive(var26);
//     double var28 = org.apache.commons.math3.util.MathArrays.distance1(var24, var26);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26, var29, false);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var33 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var23, var26);
//     double var35 = var33.cumulativeProbability(0.90076811327417d);
//     double var38 = var33.probability((-1.3489657315897874d), 10.024409082583382d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var39 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var33);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 215.22253334177097d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 9977.907297057496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.7293611456373694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.5476837610270358d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1.0d);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var11 = var1.nextUniform(0.0d, 984.6226564837881d, false);
//     var1.reSeed((-3350761049902189056L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.54876913898127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 98.8314402089541d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 511.49730819922394d);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
    var1.reSeedSecure(10L);
    var1.reSeedSecure();
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var1.nextUniform(98.46516229978855d, 98.42176142483318d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    double[] var1 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var1);
    double[] var4 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var4);
    double[] var7 = new double[] { };
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var7, var9);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var9, var12, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var9);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var9);
    double var17 = var16.getSupportUpperBound();
    boolean var18 = var16.isSupportLowerBoundInclusive();
    double var20 = var16.density(10.01298813086332d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.1027640215523336d, 0.0d, 16.55908715748299d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextInt(0, 10);
//     double var6 = var0.nextGaussian(100.0d, 115.88842315603809d);
//     var0.reSeedSecure();
//     double var9 = var0.nextT(290.77256675474683d);
//     double var12 = var0.nextBeta(0.3441412950324493d, 0.5104454862955553d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 290.1825638988824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.5838969291293141d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7459982499522542d);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var0, var6);
    double var9 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    double[] var10 = new double[] { };
    double[] var12 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var14 = org.apache.commons.math3.util.MathArrays.distance1(var10, var12);
    org.apache.commons.math3.util.MathArrays.checkPositive(var12);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var12);
    double[] var18 = null;
    double[] var20 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var20);
    double[] var23 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeDivide(var20, var23);
    double[] var26 = new double[] { };
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var26, var28);
    org.apache.commons.math3.util.MathArrays.OrderDirection var31 = null;
    org.apache.commons.math3.util.MathArrays.checkOrder(var28, var31, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var35 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var25, var28);
    double[] var37 = var35.sample(9);
    double var38 = var35.getSupportLowerBound();
    double var40 = var35.density(1.2316468095843844d);
    double var42 = var35.inverseCumulativeProbability(1.0d);
    double var43 = var35.getSupportLowerBound();
    double[] var45 = var35.sample(2);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var18, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var45);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var6 = new long[] { 0L, 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var6);
    long[][] var8 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.3955019469796721d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)10074.793969498272d, (java.lang.Object[])var8);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)43059505226525080L);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5693868189359972d, (java.lang.Number)5.34310832800162E-4d, false);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }
// 
// 
//     int[] var1 = new int[] { 100};
//     int[] var3 = new int[] { 100};
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
//     int[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var3);
//     int[] var7 = null;
//     int var8 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var7);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = new int[] { 100};
//     int[] var4 = new int[] { 100};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var4);
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
//     int[] var10 = new int[] { 100};
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance(var4, var10);
//     int[] var14 = new int[] { 0};
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(var14);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var14);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var4, var14);
//     int var19 = org.apache.commons.math3.util.MathArrays.distance1(var0, var14);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(-1L), (java.lang.Object)1L);
    java.lang.Object var3 = var2.getValue();
    org.apache.commons.math3.util.Pair var4 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl();
    var5.reSeed();
    boolean var7 = var2.equals((java.lang.Object)var5);
    org.apache.commons.math3.util.Pair var8 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var9 = var2.getFirst();
    java.lang.Object var10 = var2.getValue();
    java.lang.Object var11 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1L+ "'", var3.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 1L+ "'", var10.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1L)+ "'", var11.equals((-1L)));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextCauchy(98.45317552126936d, 0.01408195728001127d);
//     double var7 = var1.nextWeibull(9.927198205545196d, 98.2718673777206d);
//     double var9 = var1.nextChiSquare(5.184603928878863d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform(9978.946905068287d, 0.34218225734736135d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 98.47262856897225d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 84.05642919578496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4.579394953735681d);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     java.lang.String var6 = var1.nextHexString(10);
//     double var9 = var1.nextWeibull(223.5165307360314d, 4.02337093150714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f66d74e00a"+ "'", var6.equals("f66d74e00a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.9806842939274003d);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    double[] var0 = new double[] { };
    double[] var2 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var2);
    double var4 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
    double[] var6 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var6);
    double[] var9 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var9);
    double[] var11 = org.apache.commons.math3.util.MathArrays.ebeDivide(var6, var9);
    double[] var12 = new double[] { };
    double[] var14 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var12, var14);
    org.apache.commons.math3.util.MathArrays.checkPositive(var14);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var14);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var2, var19);
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    double[] var22 = new double[] { };
    double[] var24 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var22, var24);
    double[] var28 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var22, var28);
    double[] var31 = new double[] { };
    double[] var33 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var31, var33);
    double[] var37 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var31, var37);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = null;
    boolean var43 = org.apache.commons.math3.util.MathArrays.checkOrder(var37, var40, false, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var44 = null;
    boolean var46 = org.apache.commons.math3.util.MathArrays.isMonotonic(var37, var44, false);
    double[] var47 = new double[] { };
    double[] var49 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var49);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var47, var49);
    double[] var53 = new double[] { 100.0d};
    org.apache.commons.math3.util.MathArrays.checkPositive(var53);
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var47, var53);
    double var56 = org.apache.commons.math3.util.MathArrays.safeNorm(var53);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var53);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var37);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2L, (java.lang.Number)23405.381799800452d, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2L+ "'", var5.equals(2L));

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     var1.reSeedSecure(10L);
//     var1.reSeedSecure();
//     double var7 = var1.nextGamma(91.73734938536145d, 98.96880118978186d);
//     var1.reSeedSecure();
//     long var10 = var1.nextPoisson(101.37047542893089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9838.700411127755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 98L);
// 
//   }

}
