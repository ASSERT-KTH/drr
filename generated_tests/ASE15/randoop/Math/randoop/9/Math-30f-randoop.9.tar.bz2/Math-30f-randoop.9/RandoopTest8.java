
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)2.0575813619290484d, var2, (java.lang.Number)(-0.07330776103109524d));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(2822328434162903041L, 612566992979336832L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 612566992979336832L);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    int var14 = var1.start();
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var19 = var16.getElements();
    var16.setExpansionMode(1);
    double[] var22 = var16.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setElement((-98874598), (-1.1217129806834838d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)32.76554149835665d, (java.lang.Number)1.2751417367324678d, (java.lang.Number)6.605358949815338d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("bc6d528f6402506e0b4d9614c762c56b2e927d88b5d9b3b2879500a6a4bf61801c81fd3f437a2b850972563fce779f1c68e6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-709046808), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var12 = var1.nextGaussian(2.0599789360373797d, 0.3674212569981512d);
//     var1.reSeedSecure(52L);
//     long var16 = var1.nextPoisson(14.4057782350127d);
//     double var19 = var1.nextGaussian(0.0d, 60.91002254613769d);
//     double var21 = var1.nextChiSquare(17.155926200260083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 50.3721693343659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7599804096152283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.2661778379074384d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 36.36200645053072d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 12.071810980921303d);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-3.367919281375523d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.367919281375523d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0665895490501696d, (java.lang.Number)0.4505451791095725d, (java.lang.Number)(-0.32267104745890796d));
    java.lang.Number var4 = var3.getHi();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-0.32267104745890796d)+ "'", var4.equals((-0.32267104745890796d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(9.030385460342578E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.030385460345032E-7d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var11 = var9.addElementRolling(0.0d);
    var9.addElement((-0.7014095186799629d));
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var15);
    var14.addSuppressed((java.lang.Throwable)var16);
    boolean var18 = var9.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.516052726632908d));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-102), (java.lang.Number)1.5707507790769917d, true);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-102)+ "'", var4.equals((-102)));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(42L, 1372243629353364160L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.8486406421420443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9467629965706595d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.7040575157077567d, (java.lang.Number)18L, false);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var8 = var1.nextExponential(5.169339496286199d);
//     double var11 = var1.nextWeibull(0.7199192644760765d, 3.9626681941800967d);
//     long var14 = var1.nextLong(0L, 383L);
//     double var16 = var1.nextT(3.8930113471345405E-251d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f1ed76347bb58985ff601a28238ea44a544a427919e11ef7b1db917c18af74bb5afb5e0306479bd7f66b4867a48911ea8825"+ "'", var3.equals("f1ed76347bb58985ff601a28238ea44a544a427919e11ef7b1db917c18af74bb5afb5e0306479bd7f66b4867a48911ea8825"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-122));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.88939533712122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.806438509142826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 236L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-3.9697714513835585E36d));
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    int var21 = var20.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var20);
    java.lang.String var23 = var20.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    int var13 = var1.start();
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(3.9443045E-30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    var2.reseedRandomGenerator(1131479055207487616L);
    double var10 = var2.getMean();
    double var11 = var2.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.8011436155469337d));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(221.75025852563533d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 221.0d);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-833879679), (-833879679));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-8.326149374430196d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.785357026127657d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.843070443306361d);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-50.13907499210205d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-50.0d));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.00974196E-28f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2037062E-35f);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    java.lang.String var12 = var11.toString();
    java.lang.Class var13 = var11.getDeclaringClass();
    int var14 = var11.ordinal();
    java.lang.Class var15 = var11.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.250776376882071d, (-4.582384203074734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.2507763768820706d);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     var1.reSeed(8L);
//     double var27 = var1.nextChiSquare(0.7628169534658366d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var1.nextCauchy((-1.235344810822468d), (-5.753850879804868d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "77e8b6af3ad508b8c7f17cf40505dd5bd78216fc9d854de642451a917a2c001e083adaed98e6eede69d1edf1133e03656458"+ "'", var3.equals("77e8b6af3ad508b8c7f17cf40505dd5bd78216fc9d854de642451a917a2c001e083adaed98e6eede69d1edf1133e03656458"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7753398338560246d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.3961007407889157d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.749055572784356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.034945824610484996d);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     var1.reSeed((-1L));
//     double var12 = var1.nextExponential(0.3068313011297756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8e7f728415797245c62fe4a106e87cc56e13687a251edc053fa689d6d1d38562546fa135f745f7e2fa8d4b03743138bf3493"+ "'", var3.equals("8e7f728415797245c62fe4a106e87cc56e13687a251edc053fa689d6d1d38562546fa135f745f7e2fa8d4b03743138bf3493"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.673119979659748d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-10.285933062828963d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.45737447892943917d);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     var1.reSeedSecure(3L);
//     double var15 = var1.nextCauchy(2.4923224105534505d, 73.48387693522042d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var1.nextPermutation((-105), 190);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1144634447));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 50.584237767846055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 398.2221025895561d);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var11 = var10.isSupportUpperBoundInclusive();
    boolean var12 = var1.equals((java.lang.Object)var11);
    double[] var13 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var16.setExpansionMode(0);
    double[] var19 = var16.getElements();
    var1.addElements(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.3510904610648433d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double[] var6 = var2.sample(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.cumulativeProbability(0.17177063758307148d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.03985412967898143d, 4.7838434081409E-7d, 110.404056353086d, (-1450));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)12.152754637483802d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)7L, (java.lang.Number)(-0.3930649841662833d), (java.lang.Number)(-857875795));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(21, (-475858716));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 21);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(206.07232134437706d, (-0.015351873678033034d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.015351873678033034d));

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var9 = var1.nextGamma((-0.9469118583888082d), 0.444936230537876d);
//     double var12 = var1.nextCauchy(9.585079465807741d, 169.2916819352381d);
//     double var14 = var1.nextExponential(20.083359914474784d);
//     org.apache.commons.math3.random.RandomGenerator var15 = null;
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl(var15);
//     double var18 = var16.nextExponential(100.0d);
//     int var21 = var16.nextZipf(10, 100.0d);
//     int var24 = var16.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var27 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var28 = var16.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var27);
//     double var29 = var27.getStandardDeviation();
//     double var30 = var27.getSupportLowerBound();
//     double var31 = var27.getSupportUpperBound();
//     double var32 = var27.getStandardDeviation();
//     double var33 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var27);
//     double var34 = var27.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "fc6a90e77796667af57f38c33b28b553447b0eab6859f562daa8c7f640fd1bc3164ddce47cf7496cb6996a450379d28b627d"+ "'", var3.equals("fc6a90e77796667af57f38c33b28b553447b0eab6859f562daa8c7f640fd1bc3164ddce47cf7496cb6996a450379d28b627d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-127));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9092972421467385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-21.13729803387885d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 18.19747831838364d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 80.97799665979373d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 6.66026150024682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1.8486104073152074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-0.8011436155469337d));
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)137.03314037205797d, (java.lang.Number)79.26372034878028d, true);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 79.26372034878028d+ "'", var4.equals(79.26372034878028d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0);
    java.math.BigInteger var8 = null;
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var12);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)var12, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var17 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)var12);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 0);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var31);
    org.apache.commons.math3.exception.OutOfRangeException var35 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)var31, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var36 = new org.apache.commons.math3.exception.NotPositiveException(var20, (java.lang.Number)var31);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 1131479055207487616L);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 340591140L);
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 383L);
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var42);
    org.apache.commons.math3.exception.util.Localizable var46 = null;
    org.apache.commons.math3.exception.util.Localizable var47 = null;
    org.apache.commons.math3.exception.util.Localizable var48 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var49 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathArithmeticException var50 = new org.apache.commons.math3.exception.MathArithmeticException(var48, (java.lang.Object[])var49);
    org.apache.commons.math3.exception.MathInternalError var51 = new org.apache.commons.math3.exception.MathInternalError(var47, (java.lang.Object[])var49);
    org.apache.commons.math3.exception.MathArithmeticException var52 = new org.apache.commons.math3.exception.MathArithmeticException(var46, (java.lang.Object[])var49);
    org.apache.commons.math3.exception.MaxCountExceededException var53 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)var19, (java.lang.Object[])var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     int var12 = var1.nextSecureInt((-2), 99);
//     java.lang.String var14 = var1.nextSecureHexString(27985566);
//     long var16 = var1.nextPoisson(157.6294922026596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 189.2998938549862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 156L);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(168.13282973261943d, (-21.9080482473599d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.525161361065415d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(3.761582E-37f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.761582E-37f);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-9.52391259992606d), 0.00373025328201656d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.52391259992606d);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-9.249581534328904d), (java.lang.Number)4.9E-324d, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     boolean var6 = var4.getBoundIsAllowed();
//     java.lang.Throwable var7 = null;
//     var4.addSuppressed(var7);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     double var21 = var1.nextChiSquare(0.18340211571916795d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(3.9034157645529923d, 0.039766406469604984d);
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     long var27 = var1.nextPoisson(0.6168592909529225d);
//     double var30 = var1.nextGamma(4.800185947710126E-4d, 124.89888240637714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "da7d700c0d1e81d0ce1fec9d418b31e0148f28aefc7174aaf8959486147aea392cf1963f547dd58458d97a624632f972cae4"+ "'", var3.equals("da7d700c0d1e81d0ce1fec9d418b31e0148f28aefc7174aaf8959486147aea392cf1963f547dd58458d97a624632f972cae4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.564329739725007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.0066251183076937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.184720719887854d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3.8994173017771705d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3.098926204407904E-278d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(796684296743799824L, 1372243629353364160L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1372243629353364160L);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var1.nextInt((-23), (-703550053));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "aa6972fafedf0d04c1798bdecda09c7adf11dba0a040906f4bbd366c8a41605b50d8c7b20d0d019a0becd8db666071a38521"+ "'", var3.equals("aa6972fafedf0d04c1798bdecda09c7adf11dba0a040906f4bbd366c8a41605b50d8c7b20d0d019a0becd8db666071a38521"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.30674668406546796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextGaussian((-1024.0d), 4.787491742782046d);
//     double var16 = var0.nextUniform(0.05531224118406357d, 1.2613714995468743d);
//     double var19 = var0.nextGamma(0.0d, 9.05428369392931d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5278402013232949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.696676599321067d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.14499302250252807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1025.4218887167563d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5060270166134361d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0966461056120986d, (java.lang.Number)0.01678363785097637d, (java.lang.Number)1.0979297897463275E-4d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1133));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.setNumElements(2325);
    double var5 = var1.getElement(9);
    double var7 = var1.substituteMostRecentElement(7.421527624138719d);
    double[] var8 = var1.getInternalValues();
    double var10 = var1.addElementRolling(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     double var18 = var1.nextChiSquare(4.87681109080397d);
//     var1.reSeedSecure();
//     double var21 = var1.nextExponential(81.93186623463397d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-246944818));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 37.32563573407755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.66149579189573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8.686960022335152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.5067086056189165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 110.752279603782d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     long var11 = var1.nextLong(51L, 128L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a66c5465bdb0a26923ecf5f0fd193c6275648df90b6ea75266784f5b2550a496b912801e8db8659057eef7f132657b54d188"+ "'", var3.equals("a66c5465bdb0a26923ecf5f0fd193c6275648df90b6ea75266784f5b2550a496b912801e8db8659057eef7f132657b54d188"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.517828993158275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 14.546980626028288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 62L);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.2507763768820706d, 0.7343705104784745d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.367550283603454d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(31L, 41L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1271L);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    java.lang.String var14 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var15 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var12);
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    java.lang.String var24 = var23.name();
    java.lang.String var25 = var23.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var23);
    org.apache.commons.math3.random.RandomGenerator var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var27);
    double[] var29 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    float var31 = var30.getExpansionFactor();
    double[] var32 = var30.getInternalValues();
    var30.clear();
    float var34 = var30.getContractionCriteria();
    double[] var35 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    var36.discardFrontElements(0);
    boolean var41 = var36.equals((java.lang.Object)(short)1);
    double[] var43 = new double[] { 10.0d};
    var36.addElements(var43);
    var30.addElements(var43);
    double[] var46 = var28.rank(var43);
    double[] var47 = var17.rank(var43);
    var1.addElements(var47);
    double[] var49 = var1.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(5.960466E-8f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "AVERAGE"+ "'", var24.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    java.lang.Number var2 = var1.getMax();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    java.lang.Number var5 = var1.getMax();
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)22.140692632779267d, (java.lang.Number)31.60067015628112d, false);
    var1.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var11 = var9.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-90L)+ "'", var2.equals((-90L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-90) exceeded"+ "'", var3.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-90) exceeded"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-90) exceeded"+ "'", var4.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-90) exceeded"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-90L)+ "'", var5.equals((-90L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 31.60067015628112d+ "'", var11.equals(31.60067015628112d));

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextF(0.15085749711366045d, 5.811390651303676d);
//     java.lang.String var15 = var0.nextSecureHexString(2325);
//     double var17 = var0.nextT(4.490553647691121d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextChiSquare((-0.9999711870413756d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.726688511987616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.229603071809517d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.4275307762332349d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 8.049185534554906E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "3cc8d9f663ea567e9b8ac1f453193b0e098db38e8a366faab28d5d6354ffec94ce0c5a3b819f70fc60040dd344859656bb4f57eb4111a51a3741dfe21916e486b6ac5f169b29aaa41f4295c9835aa55606a586da4e1989b5c5b1f4c69571820e2ac2ca78a9ca0c51e452e586ffb8e2e5b1f75892f1e1961cc031490412bdb1718a8253dace2b788bb782a239cf8027256781289fc996241a6d10f98cecc78b23f8cfb0cb8ea99c3b297b48e4367d2a280c6e3312e41e9beaccd0e595ef3dfaa93bbebf2980267ae97813ef1ae45df8cfd9fe0016e0d57bf2e36b69cbf6957992879783b5603fdce39cad9de8d6ef756e3aeb9331d5e8b7e70a268ee526e0991541e92dc9328874c8717cf9cf7de194813cb1f3caba32338ce127f8868f32e269abcc85f0f27e71913c7b6f2d7354aad1f8b0fed5820c3578cb7f7987ee7bc9dfab96ad9531f42518752b3bfc84b2ac67201fc507d8f9e9ece6334fb71c9a5d5679106fb5f3b80e52ec390124a45a3a76191449fd0ae202eee7d344100b5e1ca9008d6c48e4382fd025c3815e31cbf2c436804ff1e3370afa15106bf69c036e5c08df219fa2bbe3acebba7cf050059184e3396b6f285ca408b0ce19a336c9b3d92a2f9ce1701fbd7cf4a460c4b2625a272b072ddc495bad4bbe5f5a13d42bc6b3dd7ba107d162de8a56440e940b893f89982f493d96d49d322a60dce8e6028a85b2cf60131697fea58dfff1c888c812a5045ffb7fc37c04a446c502b6739b91eb63d30eb0f64c43e33ca9171fc187f2aad3f800d013abc3e0d8ddd8c66a50d4bc75005bd401070e3f4447b96d1ac75b90ba6bf80418619574e9cf7d2712a00ffaf48d3a98e54b6a738526db39d542c258e6ef777872cccd61fe22e64edcd7ddc58e66f2311b0cf926b4ed93471a3bc3f592cfeba97a40ec380fac826ddede6b92749b6166cc74bb69966aaac741e2badced8e9cebe6055e2c5b64dd80642ef48df75aef9096fc229d6347214ca874462be0c85f04596949188ff172fa4629dde13ba688357dd516bd89e9aa6674c17eb485aba1d5d9d55db200948df1a02e39ed456796ed8850cc28f8f8c2ad1f319a96efecba60bf072e329b1e5065f912ae15acd3aa1966df33c932970dc21eb11efba2ceeb63e96314fd5bf4f36d296c470395fb54e638dbfb0d7d6e6b825452ff46823e12abdfdf476b1466b23b607d0bb5c757a26cea64d9def46f352b3665477c309d2f02043cc2a5058b08509677f857552950e3a518311f846643788984bd5d946cddde5b3594ffcce5d20866df84430458f3127ebdcb09228145b21b19fc2f63acd5ce2ab2ef4a1f820cda228a8c0fee3911ef162077e4ea05ad63e09faded82f5cdd13d1660e1a3a839eb2f84dcd2e0a07a32d3b67b193b784f9a6a094032cd253b87ca3a22cc35c9f14423c3de098aa4ba34b9e49ad7cd9d17712002729c3252424478653d4fee9ca5eeb15d9d8958b380db0a47b9d680550d5c7b67f3987c125c79d24a28449b9b599b3a1f4a4dfc460643fcdc8e7e9c0dc39bdb80cfd5c65f576a98b2943f4b9acd13401b686dce62bcff4c4020fc8ccc9a3665bd79d33d68734febeaf703fcb3e4549682bc4fb9ea890d5b556e92d16de"+ "'", var15.equals("3cc8d9f663ea567e9b8ac1f453193b0e098db38e8a366faab28d5d6354ffec94ce0c5a3b819f70fc60040dd344859656bb4f57eb4111a51a3741dfe21916e486b6ac5f169b29aaa41f4295c9835aa55606a586da4e1989b5c5b1f4c69571820e2ac2ca78a9ca0c51e452e586ffb8e2e5b1f75892f1e1961cc031490412bdb1718a8253dace2b788bb782a239cf8027256781289fc996241a6d10f98cecc78b23f8cfb0cb8ea99c3b297b48e4367d2a280c6e3312e41e9beaccd0e595ef3dfaa93bbebf2980267ae97813ef1ae45df8cfd9fe0016e0d57bf2e36b69cbf6957992879783b5603fdce39cad9de8d6ef756e3aeb9331d5e8b7e70a268ee526e0991541e92dc9328874c8717cf9cf7de194813cb1f3caba32338ce127f8868f32e269abcc85f0f27e71913c7b6f2d7354aad1f8b0fed5820c3578cb7f7987ee7bc9dfab96ad9531f42518752b3bfc84b2ac67201fc507d8f9e9ece6334fb71c9a5d5679106fb5f3b80e52ec390124a45a3a76191449fd0ae202eee7d344100b5e1ca9008d6c48e4382fd025c3815e31cbf2c436804ff1e3370afa15106bf69c036e5c08df219fa2bbe3acebba7cf050059184e3396b6f285ca408b0ce19a336c9b3d92a2f9ce1701fbd7cf4a460c4b2625a272b072ddc495bad4bbe5f5a13d42bc6b3dd7ba107d162de8a56440e940b893f89982f493d96d49d322a60dce8e6028a85b2cf60131697fea58dfff1c888c812a5045ffb7fc37c04a446c502b6739b91eb63d30eb0f64c43e33ca9171fc187f2aad3f800d013abc3e0d8ddd8c66a50d4bc75005bd401070e3f4447b96d1ac75b90ba6bf80418619574e9cf7d2712a00ffaf48d3a98e54b6a738526db39d542c258e6ef777872cccd61fe22e64edcd7ddc58e66f2311b0cf926b4ed93471a3bc3f592cfeba97a40ec380fac826ddede6b92749b6166cc74bb69966aaac741e2badced8e9cebe6055e2c5b64dd80642ef48df75aef9096fc229d6347214ca874462be0c85f04596949188ff172fa4629dde13ba688357dd516bd89e9aa6674c17eb485aba1d5d9d55db200948df1a02e39ed456796ed8850cc28f8f8c2ad1f319a96efecba60bf072e329b1e5065f912ae15acd3aa1966df33c932970dc21eb11efba2ceeb63e96314fd5bf4f36d296c470395fb54e638dbfb0d7d6e6b825452ff46823e12abdfdf476b1466b23b607d0bb5c757a26cea64d9def46f352b3665477c309d2f02043cc2a5058b08509677f857552950e3a518311f846643788984bd5d946cddde5b3594ffcce5d20866df84430458f3127ebdcb09228145b21b19fc2f63acd5ce2ab2ef4a1f820cda228a8c0fee3911ef162077e4ea05ad63e09faded82f5cdd13d1660e1a3a839eb2f84dcd2e0a07a32d3b67b193b784f9a6a094032cd253b87ca3a22cc35c9f14423c3de098aa4ba34b9e49ad7cd9d17712002729c3252424478653d4fee9ca5eeb15d9d8958b380db0a47b9d680550d5c7b67f3987c125c79d24a28449b9b599b3a1f4a4dfc460643fcdc8e7e9c0dc39bdb80cfd5c65f576a98b2943f4b9acd13401b686dce62bcff4c4020fc8ccc9a3665bd79d33d68734febeaf703fcb3e4549682bc4fb9ea890d5b556e92d16de"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.034585993688783d));
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 8.4703295E-22f, 7.6293945E-6f, 27);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.4923224105534505d, (-7.755907420366454d), 125.4107442965159d, (-56));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)10.354991816072031d);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(289.0254829751079d, (-0.053114013672176386d), 0.0d, (-276758528));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7628169534658366d);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var8 = var1.nextExponential(5.169339496286199d);
//     double var11 = var1.nextWeibull(0.7199192644760765d, 3.9626681941800967d);
//     long var13 = var1.nextPoisson(21.16768605653453d);
//     long var16 = var1.nextSecureLong(383L, 472333773399159424L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextZipf(0, 18.993225154621676d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d47b56778d2bb9d4b988c709178306267036f89692da4417525a640911f4b96202eb2e0943bb6ed276e69277c776df8f90e1"+ "'", var3.equals("d47b56778d2bb9d4b988c709178306267036f89692da4417525a640911f4b96202eb2e0943bb6ed276e69277c776df8f90e1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.5724171772148388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.3365229974577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 25L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 437469930024368576L);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.01293541302399879d, (java.lang.Number)(-0.9501083378171749d), (java.lang.Number)2.1798967300524996d);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextWeibull(0.3674212569981512d, 14.237606813581872d);
//     double var16 = var0.nextWeibull(9.585079465807741d, 349.18148094808896d);
//     double var18 = var0.nextT(1.4627348451982898d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextUniform(0.5105879151683443d, (-26.68975299077054d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13.049050933987356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-5.255912400137774d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.03758267169347055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21.59417822592327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 310.3230356243554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.32684765029093066d);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.7290651857988871d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6661727441103436d));

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextChiSquare(1.8039440580589192d);
//     var1.reSeed(383L);
//     double var21 = var1.nextGaussian(138.83948441857555d, 0.8260180801643263d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var1.nextPermutation((-651230979), 285460);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9a799225c34d9ab445006dd927dde26235d5e6452ce10f72dda23508a1500e54db0ce3c5600eddad3320da7f91f3012f524a"+ "'", var3.equals("9a799225c34d9ab445006dd927dde26235d5e6452ce10f72dda23508a1500e54db0ce3c5600eddad3320da7f91f3012f524a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.0541469802550716d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 37L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.6451531770931305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 137.6770997990163d);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.apache.commons.math3.stat.inference.MannWhitneyUTest var0 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var1 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var4.setExpansionMode(0);
    double[] var7 = var4.getElements();
    double[] var8 = var4.getElements();
    double[] var9 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    double[] var13 = var10.getElements();
    var10.setElement(100, 1.0d);
    var10.setNumElements(21);
    double[] var19 = var10.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var0.mannWhitneyUTest(var8, var19);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1558790486165778433L, 1031910952960952064L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8929190990895382527L));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)124.89888240637714d, (java.lang.Number)(-0.3228627622110278d), true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var6);
    java.lang.Number var9 = var3.getArgument();
    java.lang.Number var10 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 124.89888240637714d+ "'", var9.equals(124.89888240637714d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-0.3228627622110278d)+ "'", var10.equals((-0.3228627622110278d)));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.5031503861892657d, 1.7834879445067402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6305606317696482d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-354871708), 16.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)307.0874963081727d, (java.lang.Number)1.0595918734695307d, false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(104.59606098392227d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0195153296062265d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    var1.addSuppressed((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var13 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var7, (java.lang.Object[])var13);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(111.82519541140871d, 82.17028018348806d, 0.10761667291885976d, (-530087935));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(50.84511147094841d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 51L);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    boolean var4 = var2.equals((java.lang.Object)8.310101398016423d);
    java.lang.Class var5 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "c47b3684750ad6de3d79c6d16e90dfc104d15e92e065aafa90bf7a23cac09af0c45d85e048bf3398af713c4672c54f239f0b");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     double var25 = var1.nextExponential(2.901500319130624d);
//     double var29 = var1.nextUniform(0.5278402013232949d, 37.012780247655094d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f7ef34dcd391f610b33077bc04158570d600b66670839a324f1c536501b9d26096cbb623b58f7472720a798467390dbe4aa0"+ "'", var3.equals("f7ef34dcd391f610b33077bc04158570d600b66670839a324f1c536501b9d26096cbb623b58f7472720a798467390dbe4aa0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5256608113731609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-3.373897578178189d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.2396502377057137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.9655298522687169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 24.749239419764017d);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    int var21 = var18.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    java.lang.Class var23 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    java.lang.String var32 = var31.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var36);
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var40);
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var42);
    java.lang.String var44 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "MAXIMAL"+ "'", var44.equals("MAXIMAL"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.9999996848245061d+ "'", var2.equals(0.9999996848245061d));

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     double var19 = var12.getMean();
//     double var20 = var12.getMean();
//     double[] var22 = var12.sample(22);
//     boolean var23 = var12.isSupportUpperBoundInclusive();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var25 = var12.sample((-1178076066));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 316.3764665003481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-19.385763318631415d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.346060044906691d, 16.555692067908634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.346060044906691d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.6237741930861675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.02834020597826777d);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextExponential((-4.445804110563701d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(12, (-119781892));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var1.nextHypergeometric(27985587, 530087946, 25);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "c47df457e1080464d745a73394ac6abbe6326534a1adbfba1bbeac1d2a7e98e1a28b584cd3482562fec1713a15c8f8445841"+ "'", var3.equals("c47df457e1080464d745a73394ac6abbe6326534a1adbfba1bbeac1d2a7e98e1a28b584cd3482562fec1713a15c8f8445841"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.860012151188422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.0011749299695574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 130L);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.429005667865433d, 0.7199192644760765d, (-17.461239085951068d));
    double var4 = var3.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    float var15 = var1.getContractionCriteria();
    double var17 = var1.substituteMostRecentElement(0.0d);
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    float var22 = var21.getContractionCriteria();
    int var23 = var21.start();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var21.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var21);
    float var26 = var21.getContractionCriteria();
    double var28 = var21.addElementRolling(0.01938334035953785d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0L, (java.lang.Number)(byte)100, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.09464894507997236d), (java.lang.Number)23, false);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.036260226286122d, (java.lang.Number)(-5.734484207278836d), (java.lang.Number)41.1579177839406d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-96.56639765669303d), 5507.300722709412d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-96.56639765669301d));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var27 = var26.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31);
    org.apache.commons.math3.stat.ranking.TiesStrategy var33 = var32.getTiesStrategy();
    java.lang.String var34 = var33.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var27, var33);
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var27, var38);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var38);
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = var42.getTiesStrategy();
    boolean var45 = var43.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var43);
    java.lang.Class var47 = var43.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var43);
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "AVERAGE"+ "'", var34.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "b66e348b1f954efbada93ac6dcca39234eb5cdc96c2474ccc9261f5e617e49acd5893863ffc922ead68e5749a6491eaec820");
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(101, 7.1054274E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(27, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionFactor(0.001953125f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1450, 2.4999998f, 0.001953125f, 171588);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-703550053));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(692748758, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-3.481613158473225d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.0033538654028802167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9962155823397173d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "987c30fb61444a27fb50b8e1677fce4f56c320650082ce2fba6f13e43e5cd38d0534fc463615d300740e8e5684154ea80e60");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-5.1836381890078265d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-857768823595114231L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 857768823595114231L);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("ec69700f1ce0ede987b834f5fbf85299356fcdc1c4f10dbec170d05d856faa1679557dcc6ded7885d8ab9a62476734c8e173");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-3.6886817027076773d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-2.9108919318919306d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-166.78182231609028d));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-2.541845232969382d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9996752493870293d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(3116, 285453);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    float var7 = var1.getExpansionFactor();
    var1.contract();
    int var9 = var1.getNumElements();
    var1.setExpansionFactor(1.0000001f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var1.substituteMostRecentElement(168.94440888412288d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(12L, 472333773399159424L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5668005280789913088L);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(7.555787E22f, 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9342815E25f);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var23 = var22.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var22);
    int var25 = var22.getNumElements();
    var22.setContractionCriteria(10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 76);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double[] var8 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements((-208374245));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }


    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    java.math.BigInteger var12 = null;
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0L);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var14);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 2025644137419103217L);
    org.apache.commons.math3.exception.NumberIsTooSmallException var21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-87), (java.lang.Number)var19, true);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 368456645954731072L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    int var14 = var12.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(208374199, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 208373176);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.055170656854222d, var2, (java.lang.Number)(-1.0319973615215225d));
//     java.lang.Number var5 = var4.getArgument();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    double[] var7 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(41.089653231008974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.024635574587679235d);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     long var9 = var1.nextLong(8L, 17L);
//     double var12 = var1.nextWeibull(11.298541236500686d, 41.79124149463175d);
//     double var14 = var1.nextT(0.8813735870195429d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var1.nextPermutation((-709046803), 490123985);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56.41629988944388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-60.908345091284936d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 40.88219837842813d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.3651984330430406d));
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     long var13 = var0.nextSecureLong(0L, 1298433376908083868L);
//     double var16 = var0.nextCauchy(7.308656079578379E-273d, 6.546219607973257E79d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-9.56061940508766d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-24.218398207341234d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5078376599125612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1023863903247170432L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 5.9150377648297426E79d);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var11 = var1.nextExponential(4.596554432623215E-4d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var1.nextHexString((-3));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 201.72116463353723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5256511165108071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4484071339103008E-5d);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-117325921), (-589261714));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(3157123192626590833L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.0d, (java.lang.Number)92.67232803812807d);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var10);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var8, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var5, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)6.424313061133897d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (-0.542236881900813d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.9E-324d));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    var1.contract();
    var1.setNumElements(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(0.001953125f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6199502593430926d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6199502593430926d);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var17 = var1.nextChiSquare(0.24433316542704286d);
//     int var20 = var1.nextBinomial(29, 0.6689087058498807d);
//     var1.reSeedSecure((-878105194433072128L));
//     int var25 = var1.nextSecureInt(0, 27985567);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 119.04879126226176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.162606824094015d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.7346630225956203E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 21734204);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure(3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform((-2.0d), (-11.954152857547939d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 47.42710642829082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1793943235563604224L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.0959781239730493d);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-89));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.039745047845647995d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.03976599570803282d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(9.585079465807741d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.366058867973822E-42d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportUpperBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = var2.sample(737032375);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var21);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var21);
    java.lang.Class var24 = var5.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var27 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = var28.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var28.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var30);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     double var13 = var1.nextUniform((-0.015775579295520044d), 342.4199650603462d);
//     var1.reSeed(3239152727494122237L);
//     double var18 = var1.nextF(11.579430653027496d, 0.320727889436511d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1120854439));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 226.96863533028528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 195.06923060850906d);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-447873150));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("107b947b6c58ff6fbeca02af7b88e883a5690e95639ecb7137290f6fdc900b6a8877032d589069d5c346a40a6b8a945bc0b9");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportConnected();
//     double var9 = var2.sample();
//     double var10 = var2.getSupportUpperBound();
//     boolean var11 = var2.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.2535556429137853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.536360203330769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.3234892E-22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-73));

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     double var16 = var1.nextUniform((-0.9648561103505955d), 382.7463252293418d);
//     java.lang.String var18 = var1.nextSecureHexString(24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "cbf9d200795210ca0177b0e3bb463431507bd13bf890f9b1db0f36e41780c82284e704498a4f71ecebf2fde329e41e1c5638"+ "'", var3.equals("cbf9d200795210ca0177b0e3bb463431507bd13bf890f9b1db0f36e41780c82284e704498a4f71ecebf2fde329e41e1c5638"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.624062833886359d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 91.12451348604478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "562cef7c38e611f42f324572"+ "'", var18.equals("562cef7c38e611f42f324572"));
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)32.00870039102856d, (java.lang.Number)2.0387629128547156d, (java.lang.Number)0.9371881303795073d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.9371881303795073d+ "'", var5.equals(0.9371881303795073d));

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.061016029084578975d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.06876387055827732d));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.001985279391598982d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9977598550367094d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0000001f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var3.setExpansionMode(0);
    double[] var6 = var3.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var7.setContractionCriteria(3.4028235E38f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var7.getElement(208373176);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     double var13 = var1.nextUniform((-0.015775579295520044d), 342.4199650603462d);
//     var1.reSeed(3239152727494122237L);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1594198));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 174.7562345635601d);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-18L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    var1.setElement(0, (-3.149426875672435d));
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var8 = var1.nextT(18.574573866010756d);
//     double var11 = var1.nextGamma(2.251752586176186d, 1.0652279546366723d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(118.79738255689736d, 0.28583983826614007d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 34.622149065076435d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-20.844927068794284d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.9804401076465198d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.9393860096058315d);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     boolean var11 = var9.isSupportConnected();
//     double[] var13 = var9.sample(100);
//     double var14 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 790.4688570973954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575109002786518d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12.599623132639815d);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.23328726966373098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.clear();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1131479055207487616L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 340591140L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 383L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 233L);
    org.apache.commons.math3.exception.MaxCountExceededException var27 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    boolean var13 = var11.equals((java.lang.Object)7.105427357601001E-15d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.String var27 = var26.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var31);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var31);
    int var34 = var31.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = var35.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var10 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var11 = var10.toString();
    var8.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var11.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getMean();
    double var3 = var0.getMean();
    double var4 = var0.getMean();
    double var5 = var0.getSupportLowerBound();
    double var7 = var0.inverseCumulativeProbability(0.49066183479387093d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.023409446834488937d));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3067312546548822528L, 5900L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     double var17 = var1.nextGaussian((-18.088595094266818d), 0.7603951015204126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 234.2365238299253d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9907940785793795d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.970523107938981E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-19.103312397910123d));
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(692748758);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.sample();
//     double var12 = var2.probability((-3.8208663712048767d));
//     double var13 = var2.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-19.56465423474856d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-16.352354178612572d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.8011436155469337d));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.random.RandomGenerator var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var21);
    java.lang.String var23 = var1.name();
    int var24 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "MAXIMAL"+ "'", var23.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation(24, 6316);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.73348227424742d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.753183462607463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7014200313650311d);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(233L, 6690628879615364881L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6690628879615365114L);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     double var8 = var1.nextExponential(4.588491263677662d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong(472333773399159424L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1c7fd2c72f63ae654a5e56d18c6ca5dbbc0481ef70983afeb28d411e81bccf30cacc5bd2923e0817adc79f7b9e7da2c965c6"+ "'", var3.equals("1c7fd2c72f63ae654a5e56d18c6ca5dbbc0481ef70983afeb28d411e81bccf30cacc5bd2923e0817adc79f7b9e7da2c965c6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.35595553072785474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.06074307277735274d);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var15 = var1.nextChiSquare(107.02504705938293d);
//     var1.reSeed();
//     var1.reSeed(18L);
//     double var21 = var1.nextCauchy(0.2624379242664361d, 4.688882052202322d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var23 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1140550768));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14.581453193790294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-73.72787542112562d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 84.1928403586087d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-9.887627131741318d));
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-20.584701822975802d), 0.9133991976953298d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8035533310545828d);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var54 = var53.getNumericalVariance();
//     boolean var55 = var53.isSupportConnected();
//     double var57 = var53.probability(2.3701879770272534E153d);
//     double var60 = var53.cumulativeProbability(0.0d, 1.1052977241209225d);
//     boolean var61 = var53.isSupportConnected();
//     double var62 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var65 = var1.nextInt(3, (-72));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f5e856b6b735a142d66dbfd70bc984d87c0a8a8fde6723ef17443ef5da4deab771e85fb6411bd7f3137190daad5502233e21"+ "'", var3.equals("f5e856b6b735a142d66dbfd70bc984d87c0a8a8fde6723ef17443ef5da4deab771e85fb6411bd7f3137190daad5502233e21"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7155508386251523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.7919013291951688d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 151L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 10.505606263579326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 4.682510943678116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 3.3509264127196183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-2.825927835605943d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.5014168136611797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.04367094510594999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-17.518947602828298d));
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(41.26238762808184d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("dbfc70794647941fc30afa5eb4f086ce22765d8cab004a0297af3049332fa68f8d2cdcd8eaedbb3866b0dd3d7856390f5a99");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1131479055207487616L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 340591140L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 383L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 233L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, (-87));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, false);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(45.9548879662945d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 46L);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(151.3856642268372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.6305606317696482d, (java.lang.Number)(-1.5758777181428963E-7d), true);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.5380973041871195d, 20.132657385759426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5380973041871195d);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     var1.reSeedSecure(3L);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var1.nextInversionDeviate(var13);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    var0.addSuppressed((java.lang.Throwable)var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-0.37178906336540557d), (java.lang.Number)857768823595114240L, (java.lang.Number)3.178422655297915d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    int var15 = var1.start();
    java.lang.Object var16 = null;
    boolean var17 = var1.equals(var16);
    boolean var19 = var1.equals((java.lang.Object)(-89));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-83903276));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.1071487177940904d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt(9, 41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextHypergeometric(285379740, (-536561727), 86);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22.909276696966785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    java.lang.String var4 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, (-3.120710690201015E10d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.141592653589793d);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(7.336638374906062d, 1268.568243354647d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextZipf((-122), (-0.957514521684863d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1081.9189784181563d));
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(70, 651230987);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(1079717575831374079L);
//     var1.reSeedSecure(2025644137419103233L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextBeta((-0.9575217061535137d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.5698875662547995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1673878138811389440L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 70.128465066815d);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var1.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     double var5 = var2.density(18.409703235248998d);
//     double var7 = var2.probability(9.34227543668857d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     double var9 = var2.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2.4743206658287757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(9.569646281391545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.84266620301083d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(37.32794332256712d, 2.229989737073975d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3203.4638291527576d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.649985789771895d, (java.lang.Number)44L, true);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(6.605358949815338d, (-3.288891279473443d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(90L, 769971757032977664L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-769971757032977574L));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.4861383310202259d, 490413.7343269309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 490413.7343269309d);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(3.761582E-37f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.clear();
    float var16 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.2607308223677581d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.551115123125783E-17d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    double[] var1 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setNumElements(1);
    int var6 = var2.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    var2.setNumElements(0);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    var11.discardFrontElements(0);
    boolean var16 = var11.equals((java.lang.Object)(short)1);
    float var17 = var11.getExpansionFactor();
    var11.contract();
    var11.addElement(1.8309158782730581d);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0f);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.02834020597826777d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5424523257905163d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)22.140692632779267d, (java.lang.Number)31.60067015628112d, false);
    java.lang.Number var4 = var3.getMax();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 31.60067015628112d+ "'", var4.equals(31.60067015628112d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.Number var7 = var3.getHi();
    java.lang.Number var8 = var3.getLo();
    java.lang.Number var9 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-709046808)+ "'", var4.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.8813735870195429d+ "'", var5.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-709046808)+ "'", var7.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.8813735870195429d+ "'", var8.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-709046808)+ "'", var9.equals((-709046808)));

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(6.424313061133897d, (-13.140978601720313d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.424313061133897d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt(9, 41);
//     double var9 = var1.nextGaussian(15.012691254866375d, 0.7812766771598918d);
//     var1.reSeed();
//     double var13 = var1.nextGaussian(0.5918979018069402d, 0.06403547272509107d);
//     var1.reSeedSecure((-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 165.471895704899d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 15.43809552300471d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.5963287412731423d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability(0.0d);
    double var3 = var0.getSupportUpperBound();
    double var4 = var0.getStandardDeviation();
    double var5 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.27639525682685306d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(670369391491839749L, 669511644467544448L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     double var3 = var0.getNumericalMean();
//     double var5 = var0.cumulativeProbability(0.8487758449442926d);
//     double var6 = var0.getNumericalVariance();
//     boolean var7 = var0.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1640962102084285d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8019969832524574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var15 = var1.nextChiSquare(107.02504705938293d);
//     var1.reSeed();
//     var1.reSeed(18L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextCauchy(1.1052977241209225d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-469369567));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 44.79501689748771d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 50.10597817667326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 95.7025965923035d);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.030178632257170913d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    boolean var10 = var8.equals((java.lang.Object)3.4948795302692948d);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var8.copy();
    var8.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.0796184868787933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.08287385827202351d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 3628800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addElement(3.0679934645157405d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-50), (-836439155));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-836439155));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("867fb44bd9c1557eb7275545aa102316b24f5f1b757f8ffbb2862faf02d9ddc7635a36aa86b49741c1fcaf2b63ccc23cd128");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)5.254166121220852d, (java.lang.Number)21.38764323879742d, false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-703550053), 530087618);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(5293152609383083007L, 1995746824403479552L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1995746824403479552L);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     int var9 = var1.nextZipf(1024, 6.605358949815338d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextT((-0.6475123562155876d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "57fef4caec12f33e3b4fd766819c6159018b471e064493eb6c62bd39f9314e521c3b21b6f2c96118c8903195eeb78122f321"+ "'", var3.equals("57fef4caec12f33e3b4fd766819c6159018b471e064493eb6c62bd39f9314e521c3b21b6f2c96118c8903195eeb78122f321"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.09234161393094392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-7), (-1.0f), 7.555787E22f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var6 = var3.getElements();
    var3.setExpansionMode(1);
    double[] var9 = var3.getInternalValues();
    var1.addElements(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var13);
    var13.setElement(16, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(58.69316265648805d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.09112570884927E25d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.20927720816005937d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.990700775852194d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var2 = var1.getMin();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(4.80479657786247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.80479657786247d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    int var21 = var20.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var20);
    java.lang.String var23 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "MAXIMAL"+ "'", var23.equals("MAXIMAL"));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.substituteMostRecentElement(9.048221320149707d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.14910849225381428d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.8935385556892277d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(53.370636111819316d, 0.6285281184398758d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 53.370636111819316d);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-50.00832479015131d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(90L, 1147538942986031104L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(285453, 0.9999999f, 2.384186E-7f, (-634401246));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var9 = var1.nextCauchy(29.171528454339946d, 9.0d);
//     double var12 = var1.nextGamma(0.0482540721020254d, 0.926915123177908d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var14 = var1.nextSecureHexString((-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 37.660144199504145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-27.04121365248707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 16.5585398603665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.004400677716981497d);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextT(6.066191094237188E76d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextZipf((-50), 132.0913336957408d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 256.9431048025732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.550680149158422E-10d);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var12 = var1.nextGaussian(2.0599789360373797d, 0.3674212569981512d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextCauchy((-11.579626535984998d), (-7.281916021825313d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 223.9881193766587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.6494602912416985d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.439643100158169d);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(5.960466E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604666E-8f);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.7402527450394184d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(2325, 0.99999994f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
//     double var3 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.7933938059508854d));
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var1.nextExponential((-0.10262895457439379d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14.008120275325982d);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.lang.Number var17 = var16.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0+ "'", var17.equals(0));

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(3.1622776601683795d, (-1.6255363870684183d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     double[] var4 = var1.getElements();
//     var1.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
//     boolean var11 = var1.equals((java.lang.Object)var8);
//     boolean var13 = var1.equals((java.lang.Object)'#');
//     float var14 = var1.getContractionCriteria();
//     var1.contract();
//     var1.setNumElements(100);
//     double[] var18 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     double[] var22 = var19.getElements();
//     var19.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException(var26, (java.lang.Object[])var27);
//     boolean var29 = var19.equals((java.lang.Object)var26);
//     boolean var31 = var19.equals((java.lang.Object)'#');
//     float var32 = var19.getContractionCriteria();
//     var19.contract();
//     var19.setNumElements(100);
//     double[] var36 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
//     var37.setNumElements(1);
//     int var41 = var37.getExpansionMode();
//     double var43 = var37.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double[] var44 = var37.getElements();
//     var19.addElements(var44);
//     int var46 = var19.start();
//     double[] var47 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     float var49 = var48.getExpansionFactor();
//     double[] var50 = var48.getInternalValues();
//     var48.clear();
//     float var52 = var48.getContractionCriteria();
//     double[] var53 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray(var53);
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     var54.discardFrontElements(0);
//     boolean var59 = var54.equals((java.lang.Object)(short)1);
//     double[] var61 = new double[] { 10.0d};
//     var54.addElements(var61);
//     var48.addElements(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var48);
//     org.apache.commons.math3.random.RandomGenerator var65 = null;
//     org.apache.commons.math3.random.RandomDataImpl var66 = new org.apache.commons.math3.random.RandomDataImpl(var65);
//     double var68 = var66.nextExponential(100.0d);
//     int var71 = var66.nextZipf(10, 100.0d);
//     int var74 = var66.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var77 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var78 = var66.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var77);
//     double var79 = var77.getStandardDeviation();
//     double var81 = var77.cumulativeProbability((-2.0439843355597187d));
//     double[] var83 = var77.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var84 = new org.apache.commons.math3.util.ResizableDoubleArray(var83);
//     double[] var85 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var86 = new org.apache.commons.math3.util.ResizableDoubleArray(var85);
//     float var87 = var86.getExpansionFactor();
//     double[] var88 = var86.getInternalValues();
//     var84.addElements(var88);
//     var48.addElements(var88);
//     var1.addElements(var88);
//     int var92 = var1.getNumElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 113.787943109784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == (-15.758642348945616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 100);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    java.lang.String var5 = var1.name();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.String var18 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var31.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var33);
    java.lang.Class var35 = var32.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var36);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.NaNStrategy var40 = var39.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.TiesStrategy var43 = var42.getTiesStrategy();
    java.lang.String var44 = var43.name();
    java.lang.String var45 = var43.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var40, var43);
    org.apache.commons.math3.random.RandomGenerator var47 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var40, var47);
    double[] var49 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var50 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
    float var51 = var50.getExpansionFactor();
    double[] var52 = var50.getInternalValues();
    var50.clear();
    float var54 = var50.getContractionCriteria();
    double[] var55 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var56 = new org.apache.commons.math3.util.ResizableDoubleArray(var55);
    org.apache.commons.math3.util.ResizableDoubleArray var57 = new org.apache.commons.math3.util.ResizableDoubleArray(var56);
    var56.discardFrontElements(0);
    boolean var61 = var56.equals((java.lang.Object)(short)1);
    double[] var63 = new double[] { 10.0d};
    var56.addElements(var63);
    var50.addElements(var63);
    double[] var66 = var48.rank(var63);
    org.apache.commons.math3.util.ResizableDoubleArray var67 = new org.apache.commons.math3.util.ResizableDoubleArray(var63);
    double[] var68 = var37.rank(var63);
    double[] var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var70 = var30.mannWhitneyU(var63, var69);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "AVERAGE"+ "'", var44.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "AVERAGE"+ "'", var45.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-6.349539183359093d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-50));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("cbfff0246f76bc2b794fdc483d9790181673126fc3ae8dae796b4a4af32b946ee03e517acfe5919fa4fe4ff30b3da8e0c27a");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var8 = var7.getExpansionMode();
    var7.setContractionCriteria(2.4999998f);
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    float var15 = var14.getContractionCriteria();
    int var16 = var14.start();
    double[] var17 = var14.getInternalValues();
    var7.addElements(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     long var26 = var1.nextSecureLong((-857768823595114231L), 1571400668722899200L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f3e91415da6877e14ab2631f5b63e7a2352ffa4f56e3806a68c4536cb117a1d1e93b2f25fb16031d4f016d685e99c0d480d7"+ "'", var3.equals("f3e91415da6877e14ab2631f5b63e7a2352ffa4f56e3806a68c4536cb117a1d1e93b2f25fb16031d4f016d685e99c0d480d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.01381148162405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.52197024353081d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.264394074722743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 949290864516597248L);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(7.336638374906062d, 1268.568243354647d);
//     int var6 = var0.nextInt((-72), (-23));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt((-589261714), (-700251660));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-347.05324840109773d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-71));
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     boolean var17 = var12.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12.324993866974532d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.564566759994077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(86, (-42));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(651230987, 0.0f, 99.99999f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(4152318856435597312L, 14L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.00974196E-28f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(5.871300865235717E76d, 147.42422773918375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-49.91899287546627d));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    double[] var8 = new double[] { 10.0d};
    var1.addElements(var8);
    float var10 = var1.getContractionCriteria();
    boolean var12 = var1.equals((java.lang.Object)3.141592653589793d);
    var1.setNumElements(99);
    double[] var15 = var1.getInternalValues();
    int var16 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var54 = var53.getNumericalVariance();
//     boolean var55 = var53.isSupportConnected();
//     double var57 = var53.probability(2.3701879770272534E153d);
//     double var60 = var53.cumulativeProbability(0.0d, 1.1052977241209225d);
//     boolean var61 = var53.isSupportConnected();
//     double var62 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("d5fdf47d931c3b420fa48b48d39d2bd9052e079d818cc79e99f80c18deb833e0fbe7b18e4a2a046edd6354defe6212685111", "b26f96f0932105e93234358ad57798f89ca797d245857fb3b2e65b9c1e9249e8aee0a4e6a6989566ce3f53fe7521d8ae2493");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "31eab46c5c1483415539fceb2e322d449050b81e9ca078fcefd5f4d3d21bee8169fb155e081049c129f10083a3dc344a862d"+ "'", var3.equals("31eab46c5c1483415539fceb2e322d449050b81e9ca078fcefd5f4d3d21bee8169fb155e081049c129f10083a3dc344a862d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.04081543907474828d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.4232959943993022d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 137L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 50.06247663608989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 22.79084985579057d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-14.864503673399406d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-12.864410694193296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-0.3065425139546952d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.04367094510594999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-17.006655214643697d));
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var10 = var7.getElements();
    var7.setExpansionMode(1);
    double[] var13 = var7.getElements();
    var1.addElements(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-634401246));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(149.62657017252755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39026474973986547d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.999999999992233d, (-9.768391413749107d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    double[] var7 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var8.setNumElements(51);
    int var11 = var8.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test281"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)10.631760722610178d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 47);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test283"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("2a6c50f1788571ede563be777c866059b76472dea63f157507b30ca63cb4441b96b64e32bdfa35566c1937efdfc268717ec7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test284"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-117325921), 285379740);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 285379740);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test285"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    var1.addElement(1.814973475650107d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var1.getElement((-354874608));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var9 = var1.nextGamma(5.964535219365547d, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextBeta((-3.5360647592206d), 8.329457145152158d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "346956bc3f243529807afcdf2db73eb3c851963e89cb2efa0fed027a66239b4be194408ae88d0b5883209ddd03a44101c66d"+ "'", var3.equals("346956bc3f243529807afcdf2db73eb3c851963e89cb2efa0fed027a66239b4be194408ae88d0b5883209ddd03a44101c66d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5960612385583905d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0d);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.69223559424451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.69223559424451d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test288"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(30.62875275103174d, (-0.6429321610121361d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-30.62875275103174d));

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("4a7f50fa955fa9bb9ba9cf00c67bca4c5f014fdf14872d314dd79ba1c062ae705bca254c6efbc7c0f4b970607a3f43d6d89c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.6593074703968533d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-37.77553545518616d));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test291"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.getElement((-12573));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test292"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var11 = var10.isSupportUpperBoundInclusive();
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var1.copy();
    var13.discardMostRecentElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test293"); }
// 
// 
//     java.lang.Number var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.8427007929497151d), false);
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     java.lang.String var5 = var3.toString();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var6, (java.lang.Number)0.0f, (java.lang.Number)(-2025644137419103232L), true);
//     org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
//     boolean var12 = var10.getBoundIsAllowed();
//     boolean var13 = var10.getBoundIsAllowed();
//     var3.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
//     java.lang.String var19 = var18.toString();
//     org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var18);
//     var16.addSuppressed((java.lang.Throwable)var18);
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     org.apache.commons.math3.exception.util.Localizable var23 = null;
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     org.apache.commons.math3.exception.util.Localizable var25 = null;
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.exception.util.Localizable var27 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var28 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException(var27, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.NullArgumentException var30 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var25, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.MathIllegalStateException var32 = new org.apache.commons.math3.exception.MathIllegalStateException(var24, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.NullArgumentException var33 = new org.apache.commons.math3.exception.NullArgumentException(var23, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.MathIllegalStateException var34 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var22, (java.lang.Object[])var28);
//     var10.addSuppressed((java.lang.Throwable)var16);
//     java.lang.String var36 = var10.toString();
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextGaussian((-1024.0d), 4.787491742782046d);
//     var0.reSeed(35L);
//     double var18 = var0.nextBeta(0.07585338988964041d, 0.8605007565405773d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.505614543220331d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 23.062551127871476d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.04734767182619667d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1017.9875743294303d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.013784977804316343d);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextWeibull(0.3674212569981512d, 14.237606813581872d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextZipf((-102), 128.0330607122881d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.962577685077383d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-3.4675081724862147d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.015782138412827777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 29.2377913340879d);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     long var9 = var1.nextLong(8L, 17L);
//     double var12 = var1.nextWeibull(11.298541236500686d, 41.79124149463175d);
//     double var14 = var1.nextT(0.8813735870195429d);
//     var1.reSeed(181L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextCauchy(87.39167675879528d, (-7.476164603953202d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 174.93159169528826d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-18.49797145222143d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 44.708947497166996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.6991112946705351d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test297"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var4.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test298"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(6690628879615365114L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test299"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.001953125f, 1.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.001953125f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test300"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    java.lang.String var2 = var1.name();
    int var3 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "MAXIMAL"+ "'", var2.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-17.89215974098645d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17.0d));

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test302"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    var14.discardFrontElements(0);
    double[] var17 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    double[] var21 = var18.getElements();
    var18.setExpansionMode(1);
    double[] var24 = var18.getElements();
    int var25 = var18.start();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var18);
    var14.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test303"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-101), (-794L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test304"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var5);
//     java.lang.Throwable[] var9 = var8.getSuppressed();
//     org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-0.9944307436962432d), (java.lang.Object[])var9);
//     java.lang.String var11 = var10.toString();
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5607966601082315d));

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-107), (-508462808));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test307"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.006839822594761993d), 6.651199047971083d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.inverseCumulativeProbability((-138.86055859565863d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test308"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.6236244533177808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     double var21 = var1.nextChiSquare(0.18340211571916795d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(3.9034157645529923d, 0.039766406469604984d);
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var26 = var24.getStandardDeviation();
//     double var27 = var24.getStandardDeviation();
//     boolean var28 = var24.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f9e8925b333c7c384fe088b39d574da5fda5573577fc25e1f485494ebf1f8402b8a09da1f3b6206e811289222c85e9af5430"+ "'", var3.equals("f9e8925b333c7c384fe088b39d574da5fda5573577fc25e1f485494ebf1f8402b8a09da1f3b6206e811289222c85e9af5430"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.013076789830464d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.061416339602715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.7016162687235155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3.9777023375840317d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test310"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(3157123192626590833L, 6690628879615365114L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6690628879615365114L);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(354871708, (-87));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test312"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(132L, 47L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 85L);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test313"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var15.getElement(555);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(11.398199585377032d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 44580.52595807717d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test315"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var1 = var0.toString();
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var11);
    var0.addSuppressed((java.lang.Throwable)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var1.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test316"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(13.562540322321134d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.0d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test317"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(3L, 1570898251515862528L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1570898251515862528L);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test318"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.0957541239726638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test319"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4, 21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test320"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1300225094), (-692747454));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-692747454));

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test321"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-4));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(6.275922619569235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4127855127788755d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test323"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.25180003E16f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 54);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test324"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
//     double var3 = var2.getSupportLowerBound();
//     double var4 = var2.getNumericalMean();
//     double var5 = var2.getSupportUpperBound();
//     double var6 = var2.sample();
//     double var8 = var2.cumulativeProbability(0.998224836000892d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var2.inverseCumulativeProbability(3.87105949957558d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.368002332946865d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6063003343010451d);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test325"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    java.lang.Class var24 = var21.getDeclaringClass();
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var26);
    org.apache.commons.math3.random.RandomGenerator var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var35);
    int var38 = var4.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "MAXIMAL"+ "'", var25.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test326"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test327"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.2067540341991065d);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test328"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.000001f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test329"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)Double.POSITIVE_INFINITY, (java.lang.Number)3239152727494122237L, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     double var13 = var7.getStandardDeviation();
//     double var14 = var7.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "51f8b4dfbc318636e7ea37e7a8f9b3ed684f496247c2fa003164f73c332a2f906d3f16b91081968bbc4060bc5c468c375ad0"+ "'", var3.equals("51f8b4dfbc318636e7ea37e7a8f9b3ed684f496247c2fa003164f73c332a2f906d3f16b91081968bbc4060bc5c468c375ad0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.304836724920181d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.1067106780811284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.6636640408830469d);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextT((-0.3537723744093205d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "fdeb9093b7f6b93a05ef39cf196a65a8a82eae27eac85c5128b8069e6d953fd258126ac6577f6be93f4e1c74342fd9a0b411"+ "'", var3.equals("fdeb9093b7f6b93a05ef39cf196a65a8a82eae27eac85c5128b8069e6d953fd258126ac6577f6be93f4e1c74342fd9a0b411"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.7632674287387815d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.4432907366930972d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 8L);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test332"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test333"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 128);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var15 = var9.cumulativeProbability(0.0d);
//     double var16 = var9.getSupportUpperBound();
//     double var17 = var9.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1e7e52434b66e3cc8c929c7094d527e1fdb6d3a5b4a8a0cec816c67545ad1d7bc84518cced3d0f088eaa190c9d14648e09d4"+ "'", var3.equals("1e7e52434b66e3cc8c929c7094d527e1fdb6d3a5b4a8a0cec816c67545ad1d7bc84518cced3d0f088eaa190c9d14648e09d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-16));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-20.166573984193167d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5319268497029056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-2.435803277195565d));
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test335"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.9972498351617085d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test336"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var1.copy();
    double var13 = var1.addElementRolling(1.2751417367324678d);
    var1.addElement(0.5298418234538922d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test337"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var11 = var2.cumulativeProbability(6.6994687043218795d);
//     double[] var13 = var2.sample(35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-5.476753078381883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.7733910864430201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.14910849225381428d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.14801794357040268d));

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8365255467284846d, (-10.493906564710056d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.508725310098971d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test340"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1298433376908083968L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test341"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(195.06923060850906d, 3.0623659596966077d, 5.886799008150671d, 15129380);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test342"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    var1.addSuppressed((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var21 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var20, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, (java.lang.Number)(byte)1, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.NullArgumentException var24 = new org.apache.commons.math3.exception.NullArgumentException(var17, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var16, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var15, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var14, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var7, (java.lang.Object[])var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.7191313639662047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5704415184068578d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test344"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(235, (-1250175769));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test345"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     java.lang.String var7 = var1.nextSecureHexString(68921);
//     var1.reSeedSecure(52521875L);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var1.nextInversionDeviate(var10);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test346"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.2040650648887217d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.2839001047328926d));

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2233365893676313d, 9.041403690850107d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.13448711223197027d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test348"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.7810891464032748d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test349"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-46), 215720602);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test350"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.8011436155469337d), 1.8039440580589192d, 2.564329739725007d, 171588);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test351"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.6293945E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-17));

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test352"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)7.308656079578379E-273d, (java.lang.Number)11.990700775852194d, true);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test353"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.304836724920181d, 0.8543384296348814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.40384013434958166d));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.1250773759805557d, 3.568938887225696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.125077375980556d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var6);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test356"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    java.lang.Class var19 = var16.getDeclaringClass();
    java.lang.Object var20 = null;
    boolean var21 = var16.equals(var20);
    boolean var23 = var16.equals((java.lang.Object)1.9019602310721515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test357"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.28810261483568433d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test358"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var4 = var3.toString();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    var1.addSuppressed((java.lang.Throwable)var3);
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("76a461e39299af1a0bc1164c7bf69472da594018ff8653f645d");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.11973437935564067d), (java.lang.Number)1570898251515862528L, false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test361"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(153928164, 132L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.529861066965232d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 126.0524578989994d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test363"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(10.902797375512776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4767734460645228d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test364"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(10.354991816072031d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.354991816072031d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextSecureInt(27964641, 297623103);
//     long var6 = var0.nextSecureLong(0L, 6858108921003146464L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial((-1450), 232.72244958396632d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 134533990);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 382616812179469056L);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test366"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.4838304367134261d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test367"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var3 = var2.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(1126);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test368"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)(-2.0d), (java.lang.Number)4.165587190894948d, false);
//     java.lang.Number var6 = var5.getArgument();
//     java.lang.Throwable[] var7 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     long var8 = var1.nextPoisson(20.113485464130214d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextBeta(0.0d, 64.79621894654292d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10.609210795957047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-19.638385210212128d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 20L);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test370"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.getSupportUpperBound();
//     double var11 = var2.getStandardDeviation();
//     double var13 = var2.density((-13.960377471674942d));
//     double var15 = var2.density(10.684409586864229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-6.923484662625308d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.01678363785097637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.020627847657988998d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test371"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    java.lang.String var5 = var2.name();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var10 = var7.getElements();
    var7.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var15 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var15);
    boolean var17 = var7.equals((java.lang.Object)var14);
    boolean var19 = var7.equals((java.lang.Object)'#');
    var7.contract();
    float var21 = var7.getContractionCriteria();
    boolean var22 = var2.equals((java.lang.Object)var7);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = var7.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test372"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 10.357389281882071d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test373"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(32, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test374"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-0.9575511737800637d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0d));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test375"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var1.copy();
    var10.addElement(2.3701879770272534E153d);
    int var13 = var10.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var15 = var9.cumulativeProbability(0.0d);
//     double var17 = var9.cumulativeProbability((-0.5298418234538922d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "27ef1437087c72f82c02aa22dad9410e493be95de6b0a82bbaa316c5b592b951912223eb6d6e312d70b95a62fd1dc7781c90"+ "'", var3.equals("27ef1437087c72f82c02aa22dad9410e493be95de6b0a82bbaa316c5b592b951912223eb6d6e312d70b95a62fd1dc7781c90"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-68));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-11.427932373624625d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5319268497029056d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.5108220479565326d);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test377"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-0.837742738248129d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7638825627911818d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test378"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(15.853366771480385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.731511408989768d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test379"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    int var5 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test380"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999f, 5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test381"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(9.612299306927577d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999910485601d);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test382"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    double[] var8 = new double[] { 10.0d};
    var1.addElements(var8);
    float var10 = var1.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(709046808);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test383"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.6305606317696482d, 9.535013981775808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.132322790614487E-5d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test384"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(8.329457145152157d, 8.829955403168867E10d);
    double var4 = var2.probability(60.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test385"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 87.00830641248655d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     var1.reSeedSecure((-1379843843793974016L));
//     long var18 = var1.nextPoisson(0.9999964251419585d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.6868677270019514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.930194700099281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.861480719641655d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test387"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, var5, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    boolean var11 = var2.equals((java.lang.Object)var10);
    float var12 = var2.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.5f);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test388"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.sample();
//     boolean var11 = var2.isSupportLowerBoundInclusive();
//     double var12 = var2.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.40848406435031376d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-12.969096594532768d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.0d);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test389"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.2233365893676313d, (-2.9660085377496547E-34d), (-12.140317893400974d), 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test390"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     double var24 = var1.nextWeibull(6.605358949815338d, 6.066191094237188E76d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var1.nextPascal(1024, (-2.3376262036449926d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9c7f32c1a2da09fc85c08318d5677ac4e53411803ab34c1f900f156bc668482f3c57b3b084415e97bbee413ae36092c9912f"+ "'", var3.equals("9c7f32c1a2da09fc85c08318d5677ac4e53411803ab34c1f900f156bc668482f3c57b3b084415e97bbee413ae36092c9912f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.3155795522088773d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 6.805158042444093E76d);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test391"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getMean();
    double var6 = var2.cumulativeProbability(21.21962015148548d);
    double var7 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9861700430704337d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == Double.NEGATIVE_INFINITY);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test392"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var14);
    java.lang.Class var16 = var1.getDeclaringClass();
    java.lang.Class var17 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var20 = var19.getTiesStrategy();
    java.lang.String var21 = var20.name();
    java.lang.String var22 = var20.name();
    java.lang.String var23 = var20.name();
    double[] var24 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var28 = var25.getElements();
    var25.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var32 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var33 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var34 = new org.apache.commons.math3.exception.MathIllegalStateException(var32, (java.lang.Object[])var33);
    boolean var35 = var25.equals((java.lang.Object)var32);
    boolean var37 = var25.equals((java.lang.Object)'#');
    var25.contract();
    float var39 = var25.getContractionCriteria();
    boolean var40 = var20.equals((java.lang.Object)var25);
    java.lang.String var41 = var20.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "AVERAGE"+ "'", var21.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("da7d700c0d1e81d0ce1fec9d418b31e0148f28aefc7174aaf8959486147aea392cf1963f547dd58458d97a624632f972cae4", "4dff1235b6775f81ea7e1fa6ccc4b96e1c9611bb1dcb1007f455a56b2d3b474afd04f6b2215e2c7ece333ee52581f2fe7a30");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 267.8662527510452d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21.438807607773384d);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test394"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var9 = var1.nextGamma((-0.9469118583888082d), 0.444936230537876d);
//     var1.reSeedSecure((-48L));
//     long var14 = var1.nextLong(0L, 1079717575831374027L);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var1.nextPascal((-118), 2.9172543562621576E307d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "64687678de5e08cee8a9cf681e4db39ee824025b69a0eeccd5299178fa435454483805f626fb72b87fa93617ccaf47d35173"+ "'", var3.equals("64687678de5e08cee8a9cf681e4db39ee824025b69a0eeccd5299178fa435454483805f626fb72b87fa93617ccaf47d35173"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-84));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.2052042962651432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 675182418852764160L);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeed(100L);
//     var1.reSeed(1372243629353364160L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23.298382642313342d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.851918785866637d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test396"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getNumericalVariance();
    double var6 = var2.getStandardDeviation();
    var2.reseedRandomGenerator(40L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     double var22 = var12.inverseCumulativeProbability(0.0d);
//     double var23 = var12.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70.98959414942463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-28.003530249041166d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.512467284111852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 10.0d);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test398"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(27, 10.0f);
    float var3 = var2.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-692747484));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.5f);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test399"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getNumericalVariance();
    double[] var7 = var2.sample(339);
    boolean var8 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1023), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test401"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-90L));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test402"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getSupportLowerBound();
    boolean var6 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test403"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var14);
    java.lang.Class var16 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var18, var19);
    java.lang.Class var21 = var18.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.TiesStrategy var24 = var23.getTiesStrategy();
    java.lang.String var25 = var24.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18, var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    java.lang.String var29 = var28.toString();
    java.lang.String var30 = var28.toString();
    java.lang.String var31 = var28.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AVERAGE"+ "'", var25.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test404"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.2925215486360828d, 1.1954447131492332d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.14522925497583408d));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextHypergeometric(1249363969, (-530087935), (-536427449));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-938299315));
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test406"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-870081414414930687L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.75761123840619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 116.46738053665295d);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test408"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.getNumericalVariance();
//     boolean var4 = var2.isSupportConnected();
//     double var5 = var2.sample();
//     double var6 = var2.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-10.216510979651966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test409"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 100L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 37);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 100L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 233L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var14 = var1.nextExponential(3.0406595525191155E24d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var1.nextSecureLong(41L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "67e816b915a56f209fac1aecb3f28ffcaa7c1dfb059f6d86c9f00b1ca70ae6400286d3ead3f1b52928c0012372861f4ec10b"+ "'", var3.equals("67e816b915a56f209fac1aecb3f28ffcaa7c1dfb059f6d86c9f00b1ca70ae6400286d3ead3f1b52928c0012372861f4ec10b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-120));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-14.196869560579655d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.7358968138262595E24d);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test411"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(15129380, (-89));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15129380);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test412"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setExpansionMode(354871708);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(15.084505322592051d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.77785640626048d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test414"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(18.409703235248998d, 0.89778867249966d);
    double var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 18.409703235248998d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test415"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(21, 1.2676508E30f, 7.555786E22f, (-709046808));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test416"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 100L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 37);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 100L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 1571400668722899200L);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.exception.util.Localizable var21 = null;
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
    java.math.BigInteger var27 = null;
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 0);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, var31);
    org.apache.commons.math3.exception.OutOfRangeException var35 = new org.apache.commons.math3.exception.OutOfRangeException(var21, (java.lang.Number)var31, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var36 = new org.apache.commons.math3.exception.NotPositiveException(var20, (java.lang.Number)var31);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 1131479055207487616L);
    org.apache.commons.math3.exception.util.Localizable var41 = null;
    java.math.BigInteger var42 = null;
    java.math.BigInteger var44 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 0L);
    java.math.BigInteger var46 = org.apache.commons.math3.util.ArithmeticUtils.pow(var44, 0);
    java.math.BigInteger var47 = null;
    java.math.BigInteger var49 = org.apache.commons.math3.util.ArithmeticUtils.pow(var47, 0L);
    java.math.BigInteger var51 = org.apache.commons.math3.util.ArithmeticUtils.pow(var49, 0);
    java.math.BigInteger var52 = org.apache.commons.math3.util.ArithmeticUtils.pow(var46, var51);
    org.apache.commons.math3.exception.OutOfRangeException var55 = new org.apache.commons.math3.exception.OutOfRangeException(var41, (java.lang.Number)var51, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    java.math.BigInteger var56 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, var51);
    java.lang.Number var57 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var59 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var19, (java.lang.Number)var38, var57, true);
    java.math.BigInteger var60 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, var38);
    java.math.BigInteger var62 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 51L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test417"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(2.384186E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.842171E-14f);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(6.140201583197084d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test419"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     double var25 = var1.nextExponential(2.901500319130624d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.nextPascal(1018498664, (-0.014492690881482822d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d9fc30c849ec2d0371056c77e70c2936894441422f1017d039b595362acc47d2e28e5e5b56340bd7135cae077c99cd85f907"+ "'", var3.equals("d9fc30c849ec2d0371056c77e70c2936894441422f1017d039b595362acc47d2e28e5e5b56340bd7135cae077c99cd85f907"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.1560558384605324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-6.2047915619274026d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.055002724638342694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.8209054413365837d);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test421"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(148.0215970089364d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.993976500008677d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, var6, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)87.39167675879528d, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)(-0.6366118803678479d), var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test423"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(99);
    boolean var3 = var1.equals((java.lang.Object)(-1018498667));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test424"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-0.7402527450394184d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.714851868661008d));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(199.45604482198485d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 199.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test426"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var23 = var22.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var22);
    boolean var26 = var14.equals((java.lang.Object)38.91834511324607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test427"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3.0682658467848274d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test428"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = var2.getTiesStrategy();
    java.lang.String var4 = var3.name();
    java.lang.String var5 = var3.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test429"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-113), (java.lang.Number)1018498664, (java.lang.Number)(-0.16724901641086987d));

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test430"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var8 = var1.nextT(18.574573866010756d);
//     double var10 = var1.nextChiSquare(0.01678363785097637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99.3133273502142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-20.066928300914707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.5980683503427487d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test431"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getInternalValues();
    float var9 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test432"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-1.8486104073152074d), (-46));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.6270333923366812E-14d));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test433"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var5 = var2.getMean();
    double var7 = var2.cumulativeProbability(3.262910457220339d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.6577776263574078d);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test434"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.0f, (java.lang.Number)(byte)100, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("987c30fb61444a27fb50b8e1677fce4f56c320650082ce2fba6f13e43e5cd38d0534fc463615d300740e8e5684154ea80e60");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test436"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(13.367857581056686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9352999394629802d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test437"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(76.32868024571914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test438"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var9, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test439"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 6690628879615364881L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test440"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportLowerBoundInclusive();
    double var13 = var2.cumulativeProbability(0.19078245570961805d, 0.9086114901844922d);
    double var15 = var2.probability((-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.028371161400805228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test441"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var7.discardFrontElements(0);
    boolean var12 = var7.equals((java.lang.Object)(short)1);
    double[] var14 = new double[] { 10.0d};
    var7.addElements(var14);
    var1.addElements(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var17.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test442"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.1429436239750525E-4d, (-1.4164668197118897d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1429436239750523E-4d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test443"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var15 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)var10);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    boolean var17 = var15.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var21 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var20, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, (java.lang.Number)(byte)1, (java.lang.Object[])var21);
    java.lang.Number var24 = var23.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var23.getContext();
    var15.addSuppressed((java.lang.Throwable)var23);
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var15.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (byte)1+ "'", var24.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.815439572917573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7584091325131628d);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test445"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-43.426927513122834d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test446"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(474370825216844736L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test447"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(36.30332682389813d, (-0.7389091227614462d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.07036251515606991d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test448"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9999999f, (-7.249376137847348d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999998f);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test449"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(5L, 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 23L);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test450"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(1.3372564655227763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05860215775450189d);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test451"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.37178906336540557d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test452"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setExpansionMode((-4318));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var11 = var1.nextT(1.3877787807814457E-17d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var15 = var14.sample();
//     boolean var16 = var14.isSupportLowerBoundInclusive();
//     double var17 = var14.getStandardDeviation();
//     double var19 = var14.inverseCumulativeProbability(0.0d);
//     double var20 = var14.getSupportLowerBound();
//     double var21 = var14.getSupportUpperBound();
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextT((-7.722607725190411d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 238.2703737608498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.3701879770272776E153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-16.241981937461624d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-6.053139089116671d));
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var5 = var1.nextExponential(18.993225154621676d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextF((-13.144706748784028d), 77.43499018943342d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "13fe363a0c5402c982187eddf1b0d4661f6d79cf3ad1a3c32018934dccf2656efa47a7bb63d505ea70a48c9387c3ff05cde5"+ "'", var3.equals("13fe363a0c5402c982187eddf1b0d4661f6d79cf3ad1a3c32018934dccf2656efa47a7bb63d505ea70a48c9387c3ff05cde5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 13.187221379682063d);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test455"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 1918124033);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.math.BigInteger var15 = null;
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0);
    java.math.BigInteger var20 = null;
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var24);
    org.apache.commons.math3.exception.OutOfRangeException var28 = new org.apache.commons.math3.exception.OutOfRangeException(var14, (java.lang.Number)var24, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var29 = new org.apache.commons.math3.exception.NotPositiveException(var13, (java.lang.Number)var24);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var24);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 2147483647);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var32, 1558809787132314112L);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 2025644137419103217L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test456"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.4023702955412078d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test457"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.addElement((-0.9469118583888082d));
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    float var13 = var12.getExpansionFactor();
    double[] var14 = var12.getInternalValues();
    var12.clear();
    float var16 = var12.getContractionCriteria();
    double[] var17 = var12.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(7.555787E22f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     double var14 = var12.nextExponential(100.0d);
//     int var17 = var12.nextZipf(10, 100.0d);
//     int var20 = var12.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var24 = var12.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var25 = var23.getStandardDeviation();
//     double var27 = var23.inverseCumulativeProbability(0.24433316542704286d);
//     double var28 = var23.sample();
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var31 = var23.probability(0.0d);
//     double var32 = var23.getNumericalVariance();
//     double var33 = var23.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-527110117));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 59.042109272409164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.8221511915215819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.0684508415305403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 20.05049236175199d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-0.8011436155469337d));
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test459"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(41L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test460"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(29L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test461"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(7.5557864E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0071993E15f);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test462"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1274, 285453);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-284179));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test463"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    double[] var16 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    var17.setNumElements(1);
    int var21 = var17.getExpansionMode();
    double var23 = var17.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double[] var24 = var17.getElements();
    double[] var25 = var14.rank(var24);
    var1.addElements(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test464"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getExpansionFactor();
    float var15 = var1.getExpansionFactor();
    double[] var16 = var1.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test465"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    var1.contract();
    double var17 = var1.addElementRolling(0.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test466"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextZipf((-102), 123.55745291466343d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test467"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1371062271), 1819287553);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test468"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(16.0f, (-1.4E-45f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4E-45f));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test469"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(4.666957397222287E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6739696202819672E14d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test470"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(283815432669308992L, (-8243746768543604470L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(byte)1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NotPositiveException var7 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.0d);
    var5.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var5.getContext();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var12 = null;
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var10, (java.lang.Number)4.055170656854222d, var12, (java.lang.Number)(-1.0319973615215225d));
    java.lang.Number var15 = var14.getHi();
    java.lang.Number var16 = var14.getLo();
    java.lang.Number var17 = var14.getHi();
    var5.addSuppressed((java.lang.Throwable)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0319973615215225d)+ "'", var15.equals((-1.0319973615215225d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1.0319973615215225d)+ "'", var17.equals((-1.0319973615215225d)));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test472"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 1);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 140L);
    java.lang.Number var22 = null;
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)var18, (java.lang.Number)13.04928621092435d, var22);
    org.apache.commons.math3.exception.util.Localizable var24 = null;
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    org.apache.commons.math3.exception.util.Localizable var29 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var30 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException(var29, (java.lang.Object[])var30);
    java.lang.Throwable[] var32 = var31.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var33 = new org.apache.commons.math3.exception.MathArithmeticException(var28, (java.lang.Object[])var32);
    org.apache.commons.math3.exception.MathIllegalArgumentException var34 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var27, (java.lang.Object[])var32);
    org.apache.commons.math3.exception.NullArgumentException var35 = new org.apache.commons.math3.exception.NullArgumentException(var26, (java.lang.Object[])var32);
    org.apache.commons.math3.exception.NullArgumentException var36 = new org.apache.commons.math3.exception.NullArgumentException(var25, (java.lang.Object[])var32);
    org.apache.commons.math3.exception.MathIllegalStateException var37 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var23, var24, (java.lang.Object[])var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     long var8 = var1.nextLong(0L, 6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextT((-20.22785835440593d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4L);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(6698.963634846525d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9082289918837452d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(27.119299518045697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9148088392516812d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test476"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    java.lang.String var18 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var16);
    java.lang.Class var21 = var16.getDeclaringClass();
    java.lang.String var22 = var16.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    double[] var24 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    float var26 = var25.getExpansionFactor();
    int var27 = var25.getExpansionMode();
    double[] var28 = var25.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var29 = var23.rank(var28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, (-1250178908));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test478"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var3.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var3.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(286183440979776224L, 857768823595114231L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test480"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.534692133985469d, 4.796970182353903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.11100633859097042d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test481"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)128L, (java.lang.Number)8.296885318080307d, true);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextHypergeometric((-1371062271), 31, (-42));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 128.00864050382933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4306551653127468d);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-106), 199.99998f, 1.4E-45f, 34);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test484"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)82.16419961411961d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test485"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-5.753850879804868d), (java.lang.Number)(-0.09464894507997236d), true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.09464894507997236d)+ "'", var6.equals((-0.09464894507997236d)));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(208373176, 10.0f, 0.0f, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test487"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(20.132657385759426d, (-118));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.058451206144207E-35d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test488"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(8.310101398016423d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(24.47180405695537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test490"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)6L, (java.lang.Number)1.0333147966386297E40d, (java.lang.Number)1.1438861775190186d);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test491"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var15 = var12.getSupportLowerBound();
//     double var16 = var12.getNumericalMean();
//     double var18 = var12.probability(1.1954447131492332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56.49565183601406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9.064783604953828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.0d);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test492"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-4318), (-98));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test493"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(18.574573866010756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.517011214858203d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.6931471805599453d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test495"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(15, 490123985);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test496"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(6.436916340478475d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.125077375980556d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test498"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-284179), (-556289202));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test499"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.2156545907991276d, (java.lang.Number)(-100.0d), (java.lang.Number)0.06446622075849562d);
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    var4.addSuppressed((java.lang.Throwable)var6);
    java.lang.Number var8 = var6.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-90L)+ "'", var8.equals((-90L)));

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test500"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(67.543095364092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 215.81393916580518d);

  }

}
