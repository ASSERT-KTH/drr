
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.4208278429062815d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.3736573464313751d));
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = var14.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextChiSquare((-0.7706191458620877d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "57fb760d542f37cabeba0cbedd4545bcf120b5429d0694881841f8cf11adced4caeada903b347377b593ee662b66057cbdae"+ "'", var3.equals("57fb760d542f37cabeba0cbedd4545bcf120b5429d0694881841f8cf11adced4caeada903b347377b593ee662b66057cbdae"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5406233722883402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(368456645954731072L, (-3103219178563426303L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2734762532608695231L));

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalVariance();
//     var2.reseedRandomGenerator(35L);
//     double var8 = var2.getNumericalMean();
//     boolean var9 = var2.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.05998383756582615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.1915196979223146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8773310642040573d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = null;
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 0);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var14);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 1918124033);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.math.BigInteger var20 = null;
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0);
    java.math.BigInteger var25 = null;
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0L);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var27, 0);
    java.math.BigInteger var30 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, var29);
    org.apache.commons.math3.exception.OutOfRangeException var33 = new org.apache.commons.math3.exception.OutOfRangeException(var19, (java.lang.Number)var29, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var34 = new org.apache.commons.math3.exception.NotPositiveException(var18, (java.lang.Number)var29);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 0);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var29);
    java.math.BigInteger var38 = null;
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 0L);
    java.math.BigInteger var42 = org.apache.commons.math3.util.ArithmeticUtils.pow(var40, 0);
    java.math.BigInteger var43 = null;
    java.math.BigInteger var45 = org.apache.commons.math3.util.ArithmeticUtils.pow(var43, 0L);
    java.math.BigInteger var47 = org.apache.commons.math3.util.ArithmeticUtils.pow(var45, 0);
    java.math.BigInteger var48 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, var47);
    java.math.BigInteger var50 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, 1918124033);
    org.apache.commons.math3.exception.util.Localizable var51 = null;
    org.apache.commons.math3.exception.util.Localizable var52 = null;
    java.math.BigInteger var53 = null;
    java.math.BigInteger var55 = org.apache.commons.math3.util.ArithmeticUtils.pow(var53, 0L);
    java.math.BigInteger var57 = org.apache.commons.math3.util.ArithmeticUtils.pow(var55, 0);
    java.math.BigInteger var58 = null;
    java.math.BigInteger var60 = org.apache.commons.math3.util.ArithmeticUtils.pow(var58, 0L);
    java.math.BigInteger var62 = org.apache.commons.math3.util.ArithmeticUtils.pow(var60, 0);
    java.math.BigInteger var63 = org.apache.commons.math3.util.ArithmeticUtils.pow(var57, var62);
    org.apache.commons.math3.exception.OutOfRangeException var66 = new org.apache.commons.math3.exception.OutOfRangeException(var52, (java.lang.Number)var62, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var67 = new org.apache.commons.math3.exception.NotPositiveException(var51, (java.lang.Number)var62);
    java.math.BigInteger var69 = org.apache.commons.math3.util.ArithmeticUtils.pow(var62, 0);
    java.math.BigInteger var70 = org.apache.commons.math3.util.ArithmeticUtils.pow(var42, var62);
    java.math.BigInteger var71 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var42);
    java.math.BigInteger var72 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 96L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(18.95256260573965d, 1.3629757414633832d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18.95256260573965d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(3.761582E-37f, 1.5111573E23f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.761582E-37f);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     double var16 = var1.nextUniform((-0.9648561103505955d), 382.7463252293418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextUniform(148.0215970089364d, (-1.216637673260437d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8c7db266f4ff1fdcbcfe0fcb4b827556531fba159a96dfc9385ef85276d8dab5703736ac7533a20f1c996417c3cb7857db6e"+ "'", var3.equals("8c7db266f4ff1fdcbcfe0fcb4b827556531fba159a96dfc9385ef85276d8dab5703736ac7533a20f1c996417c3cb7857db6e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.1195612668218877d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 57.248103775966875d);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(199.99998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 200);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var17 = var1.nextWeibull(10.953429709299042d, 2.515911276041704d);
//     var1.reSeedSecure(274448725870672832L);
//     double var21 = var1.nextExponential(3.319689815435739d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextUniform(7.78496993386617d, 3.504049273836974d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "41fe565566a4e91cab5e382c81a4fddbb19c159ba56e984f8bb288901c12e8085f7564a19f96293a05c88b011a875f343e4f"+ "'", var3.equals("41fe565566a4e91cab5e382c81a4fddbb19c159ba56e984f8bb288901c12e8085f7564a19f96293a05c88b011a875f343e4f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.406098300743545d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.097039816023728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 19.26002363533558d);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(9.774221397952208E24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.774221397952208E24d);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-17.461239085951068d), 0.04381777757346322d, 1.027344269331039d, (-50));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    double[] var13 = new double[] { 1.0d};
    var1.addElements(var13);
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var19 = var16.getElements();
    var16.setElement(100, 1.0d);
    double[] var23 = var16.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    org.apache.commons.math3.util.ResizableDoubleArray var25 = var24.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var24);
    float var27 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(28);
    double[] var30 = var29.getInternalValues();
    var1.addElements(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    java.lang.Class var12 = var11.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var14 = java.lang.Enum.<java.lang.Enum>valueOf(var12, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     var1.reSeedSecure(3L);
//     double var15 = var1.nextCauchy(2.4923224105534505d, 73.48387693522042d);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var1.nextInversionDeviate(var17);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.3286542677377272d, (java.lang.Number)10.631760722610178d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var3 = var2.getExpansionMode();
    var2.setContractionCriteria(7.5557864E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(8L, 4152318856435597312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4152318856435597312L);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 1);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1571400668722899200L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1571400668722899200L);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.math.BigInteger var24 = null;
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0L);
    java.math.BigInteger var28 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0);
    java.math.BigInteger var29 = null;
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var29, 0L);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var31, 0);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, var33);
    org.apache.commons.math3.exception.NumberIsTooLargeException var37 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var23, (java.lang.Number)var28, (java.lang.Number)(-0.743169379036474d), false);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var28, 90L);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var1.copy();
    double var13 = var1.addElementRolling(1.2751417367324678d);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-508462808), (-47));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-508462808));

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var9 = var1.nextF(0.9999998943584386d, 6.275922619569235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextCauchy(5.182686170533977d, (-1020.8946023707998d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 81.06968603840141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.118195360984407d);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-24.218398207341234d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2979638482010167d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.setNumElements(2325);
    double var5 = var1.getElement(9);
    int var6 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.083598781996881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    float var15 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextCauchy(2.367550283603454d, (-0.42854955824218965d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 182.6357262029587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-25.689433156763137d));
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.2040925330189667d, 48.01304976345278d, 4.457532927493736d, (-3));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.743169379036474d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Throwable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var7);
    var2.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextChiSquare(1.8039440580589192d);
//     var1.reSeed(383L);
//     double var21 = var1.nextGaussian(138.83948441857555d, 0.8260180801643263d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var25 = var24.getNumericalVariance();
//     double var26 = var24.getNumericalMean();
//     double var27 = var24.getNumericalVariance();
//     double[] var29 = var24.sample(339);
//     double var31 = var24.cumulativeProbability(0.7599804096152283d);
//     double var32 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "85fc540d252e635a6a5fae0c319a5615c1ef089ad8a8d70946c920e726b29ec7cf0786241438ab00764c5692542e889054c1"+ "'", var3.equals("85fc540d252e635a6a5fae0c319a5615c1ef089ad8a8d70946c920e726b29ec7cf0786241438ab00764c5692542e889054c1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.567802647478593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 45L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.3932643278709607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 137.6770997990163d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.5620277887843872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-9.933788574174818d));
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     double var18 = var1.nextChiSquare(4.87681109080397d);
//     long var21 = var1.nextSecureLong(0L, 1298433376908083868L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextT((-0.6661727441103436d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-835723718));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 56.056089848183696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-17.917035373397965d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.792551029993696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4.248494130107657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 960070612522902912L);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     var1.reSeedSecure(16L);
//     double var20 = var1.nextF(1.1749909266386545d, 2.370187977027263E153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "91fed60e7aab352b2f65649b8b92a832618fbbee0f94ec8444613bcab834b5a9d4b8ad425408bf3dd55c766e64ecbc73db20"+ "'", var3.equals("91fed60e7aab352b2f65649b8b92a832618fbbee0f94ec8444613bcab834b5a9d4b8ad425408bf3dd55c766e64ecbc73db20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.062233552771116d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2.702140802813673d);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var8 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var9 = var8.toString();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    var6.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var18 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var17, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var13, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var12, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var26 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var9.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     double var17 = var12.sample();
//     double var19 = var12.density(0.28583983826614007d);
//     boolean var20 = var12.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.3760302787060805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10.82673123518577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.7815077740712453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.03965924109521295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    java.lang.Throwable[] var2 = var0.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.3435381703512802d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var17 = var1.nextWeibull(10.953429709299042d, 2.515911276041704d);
//     int var20 = var1.nextInt((-102), 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var23 = var1.nextSecureLong(289053154620198912L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ca7df0917b90a50274e1f6296c75d3a9ced170fe36b96072db93c5ca824544405cca6b944b28c23814e116fdab6471c4742c"+ "'", var3.equals("ca7df0917b90a50274e1f6296c75d3a9ced170fe36b96072db93c5ca824544405cca6b944b28c23814e116fdab6471c4742c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.8683317702093296d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.73772099299853d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-76));
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(5559.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(25, 27985587);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-27985562));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-692747454));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.001953125f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3283064E-10f);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(0.5963287412731423d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3990404461491871d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(41.79124149463175d, 4.644483341943245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.3814544845586106E7d);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     long var8 = var1.nextPoisson(1.4174588054909787d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var1.nextInversionDeviate(var9);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    boolean var5 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var19 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var18, (java.lang.Object[])var19);
    boolean var21 = var11.equals((java.lang.Object)var18);
    boolean var23 = var11.equals((java.lang.Object)'#');
    float var24 = var11.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var26 = var11.getInternalValues();
    boolean var27 = var8.equals((java.lang.Object)var11);
    float var28 = var8.getContractionCriteria();
    int var29 = var8.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-26.880829598189976d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardMostRecentElements(30);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(3.552713678800501E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(4.056482E31f, 10.000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.000001f);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-76), (java.lang.Number)2.061450821959295d, false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    int var8 = var1.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var1.getElement((-692747454));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure(0L);
//     double var17 = var1.nextUniform(7.105427357601002E-15d, 15.104412573075516d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextPascal(83, (-27.216906819128404d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "89f8d208ff3391453b6f57cff1104fce5969d9a17b19688ef09ce12a97f38c7e6770211596e9d853b24a77aad804363cbacb"+ "'", var3.equals("89f8d208ff3391453b6f57cff1104fce5969d9a17b19688ef09ce12a97f38c7e6770211596e9d853b24a77aad804363cbacb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6737576842200226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 14.556568458276397d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(53.78712722644688d, (-9.881489780601854d), (-27.235566339247473d), 164954282);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(214.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    double[] var5 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(5.960466E-8f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    java.lang.Number var4 = var1.getMin();
    java.lang.Number var5 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-424592841), 1.2676508E30f, 3.9443053E-30f, (-89));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextChiSquare(1.8039440580589192d);
//     var1.reSeed(383L);
//     int var21 = var1.nextBinomial(0, 0.014387441792572614d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var1.nextBeta(Double.NaN, 0.037251186335391095d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "326e16225e2e2305a4ad087a6803ab42435bb8b1c1f159ee897ed45a69f13c25561ee4c6ef6716ed1f2e6d2c85ea516b8862"+ "'", var3.equals("326e16225e2e2305a4ad087a6803ab42435bb8b1c1f159ee897ed45a69f13c25561ee4c6ef6716ed1f2e6d2c85ea516b8862"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8603151232665223d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 48L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.057774101209486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)41);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(6.861867836844019d, 118.79738255689736d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05769699418459255d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    int var14 = var1.start();
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var19 = var16.getElements();
    var16.setExpansionMode(1);
    double[] var22 = var16.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    double var25 = var1.addElementRolling((-58.59689188993539d));
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(6.651199047971083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(13.847988007904629d, 3.67525936970099E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.847988007904629d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)4.516570815787564E13d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)4.5E-44f);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    java.lang.String var18 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var16);
    java.lang.Class var21 = var16.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    java.lang.Class var24 = var21.getDeclaringClass();
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var26);
    org.apache.commons.math3.random.RandomGenerator var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var35);
    java.lang.Class var38 = var4.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var40 = java.lang.Enum.<java.lang.Enum>valueOf(var38, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "MAXIMAL"+ "'", var25.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-447873150), 7.105428E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(11.527213271902509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.400708312796405d);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var28 = var1.nextT(0.6037929298964898d);
//     var1.reSeedSecure(383L);
//     double var33 = var1.nextF(18.22869624306649d, 27.706861095958992d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8278148cd8a358c5e4a57160deb44169ff20114e7708b955fb05c5dd8d545357eb45cb7f72e27a076e8104e9bf1ccf794c15"+ "'", var3.equals("8278148cd8a358c5e4a57160deb44169ff20114e7708b955fb05c5dd8d545357eb45cb7f72e27a076e8104e9bf1ccf794c15"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.651184584194689d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-2.8487713692180168d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 10.882971942411611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2.150967619710966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.8493240704366435d);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.474405350182293d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-12.707418793867609d), (java.lang.Number)7.368762894278631d, true);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(31.280864222824523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.39983632582086426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var4);
    java.lang.Number var7 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-90L)+ "'", var7.equals((-90L)));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(16, 208374199);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(205.6328195051572d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 205.63281950515722d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var8.discardFrontElements(0);
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var12.discardMostRecentElements(0);
    double[] var17 = var12.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var8, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(138.86055859565863d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.6266303996390405d);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-3.3302781735942943d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     java.lang.String var15 = var1.nextHexString(47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1028090269));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 48.75687740267732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-73.41451101650729d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "a78b62417ca9bc09c91468927692b8e103834c00b406bb2"+ "'", var15.equals("a78b62417ca9bc09c91468927692b8e103834c00b406bb2"));
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-5.753850879804868d), (java.lang.Number)(-0.09464894507997236d), true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.09464894507997236d)+ "'", var6.equals((-0.09464894507997236d)));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.07605621448482834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07612956082959756d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-12.383635660552127d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.238084975582433d);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     double var21 = var1.nextUniform(0.409278872838869d, 7.6644334196952775d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var1.nextGaussian(0.0d, (-0.042626492304348895d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d07a748878c97052e2e7262363d72427554f9290bbebb5671b892074592699c9246ccaf1ac162e07f3b96ba289510f4f0df9"+ "'", var3.equals("d07a748878c97052e2e7262363d72427554f9290bbebb5671b892074592699c9246ccaf1ac162e07f3b96ba289510f4f0df9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.4785153554690572d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.8120650509828213d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 7.264650055996576d);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextF(0.6256445019194884d, 14.306620465386846d);
//     double var12 = var1.nextGamma(5.695804147945084d, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull((-0.9575279383622874d), 0.5078376599125612d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 5.6349958844727155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575150425962784d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.383798502492445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.9999998f, 1.00974196E-28f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999998f);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(1.808206298994568E14d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-2025644137419103232L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(125.30215811146536d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 125L);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.sample();
//     double var11 = var2.getMean();
//     boolean var12 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-11.863152533673432d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.96132962368031d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)4.055170656854222d, var3, (java.lang.Number)(-1.0319973615215225d));
    java.lang.Number var6 = var5.getHi();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.0319973615215225d)+ "'", var6.equals((-1.0319973615215225d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.0d, (-0.5582262697631099d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(3L, 368456645954731072L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-368456645954731069L));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setExpansionFactor(2.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     double var18 = var12.density(18.22869624306649d);
//     double var19 = var12.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 24.378746084629157d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.0012757095260287d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.006524456322800204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(4665724868967888867L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4665724868967888867L);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var5, (java.lang.Number)(-0.743169379036474d), false);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 90L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.7340280101233242d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.669865786995543d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-3.583932529718906d), 16.555692067908634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.93917094266984d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var11 = null;
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, var13);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 2025644137419103217L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 100L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-700251660), 1249363969);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    var1.discardMostRecentElements(62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var1.getElement((-1075233378));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var3 = var0.cumulativeProbability(10.953429709299042d);
//     double var5 = var0.probability((-8.167985375624562d));
//     double var6 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.3489648294178177d));
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(5.433764530217515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09483708183037856d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.9721523E-31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3509887E-38f);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.1071487177940904d, 196.6432931864693d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.005630179404321656d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-46));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 46);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)99, (java.lang.Number)(-0.31192009619497924d), false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getArgument();
    java.lang.Number var8 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.31192009619497924d)+ "'", var5.equals((-0.31192009619497924d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.31192009619497924d)+ "'", var6.equals((-0.31192009619497924d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 99+ "'", var7.equals(99));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-0.31192009619497924d)+ "'", var8.equals((-0.31192009619497924d)));

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportConnected();
//     double var9 = var2.sample();
//     boolean var10 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.364899042135118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 15.339396715773137d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(7, (-703550053));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    var4.setElement(20925, (-7.249376137847348d));
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var9.setNumElements(1);
    int var13 = var9.getExpansionMode();
    double var15 = var9.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var17 = var9.addElementRolling(100.0d);
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    double[] var22 = var19.getElements();
    var19.setElement(100, 1.0d);
    double[] var26 = var19.getElements();
    var9.addElements(var26);
    var9.setNumElements(68921);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var9.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var4, var9);
    float var34 = var4.getExpansionFactor();
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = var35.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var37 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36, var37);
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var38.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var40.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41, var42);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
    java.lang.String var48 = var47.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var47);
    org.apache.commons.math3.stat.ranking.NaNStrategy var50 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50);
    org.apache.commons.math3.stat.ranking.TiesStrategy var52 = var51.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var52);
    org.apache.commons.math3.random.RandomGenerator var55 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var55);
    boolean var57 = var4.equals((java.lang.Object)var39);
    double var59 = var4.addElementRolling(0.9962155823397173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "AVERAGE"+ "'", var48.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(75747568359496048L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 75747568359496048L);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(7.308656079578379E-273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 626.6166709773577d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var2 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var7 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
//     java.lang.String var13 = var12.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
//     java.lang.String var20 = var1.name();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var21 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var21);
//     double[] var23 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
//     org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
//     double[] var27 = var24.getElements();
//     var24.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var31 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var32 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var33 = new org.apache.commons.math3.exception.MathIllegalStateException(var31, (java.lang.Object[])var32);
//     boolean var34 = var24.equals((java.lang.Object)var31);
//     boolean var36 = var24.equals((java.lang.Object)'#');
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = var24.copy();
//     double[] var38 = var24.getElements();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var39 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var40.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var42 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var42);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
//     java.lang.String var45 = var44.name();
//     java.lang.String var46 = var44.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var44);
//     org.apache.commons.math3.random.RandomGenerator var48 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41, var48);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var50 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var52 = var51.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var53 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
//     java.lang.String var56 = var55.name();
//     java.lang.String var57 = var55.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var58 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var52, var55);
//     org.apache.commons.math3.random.RandomGenerator var59 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var52, var59);
//     double[] var61 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     float var63 = var62.getExpansionFactor();
//     double[] var64 = var62.getInternalValues();
//     var62.clear();
//     float var66 = var62.getContractionCriteria();
//     double[] var67 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var68 = new org.apache.commons.math3.util.ResizableDoubleArray(var67);
//     org.apache.commons.math3.util.ResizableDoubleArray var69 = new org.apache.commons.math3.util.ResizableDoubleArray(var68);
//     var68.discardFrontElements(0);
//     boolean var73 = var68.equals((java.lang.Object)(short)1);
//     double[] var75 = new double[] { 10.0d};
//     var68.addElements(var75);
//     var62.addElements(var75);
//     double[] var78 = var60.rank(var75);
//     double[] var79 = var49.rank(var75);
//     org.apache.commons.math3.distribution.NormalDistribution var82 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var83 = var82.sample();
//     double var85 = var82.density(18.409703235248998d);
//     double var87 = var82.probability(9.34227543668857d);
//     var82.reseedRandomGenerator(90L);
//     double var90 = var82.getMean();
//     double[] var92 = var82.sample(4);
//     double[] var93 = var49.rank(var92);
//     double var94 = var22.mannWhitneyUTest(var38, var92);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(5460.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5460L);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.sample();
//     double var12 = var2.probability((-3.8208663712048767d));
//     var2.reseedRandomGenerator(4381138221295217153L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.2689215154457405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.9290736518833507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement((-147267201), (-33.6483557398617d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextCauchy(82.16419961411961d, 0.056750019064709015d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(7218835434699862529L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextGaussian(9.085765977460639d, (-1.0800722952087016d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 137.79920402872685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.957521568827941d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 82.0458349729356d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1450);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1450);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setExpansionFactor(2.0f);
    double[] var5 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    var6.setNumElements(2325);
    double var10 = var6.addElementRolling((-2.0437212001672944E-10d));
    double var12 = var6.substituteMostRecentElement((-28.430126749359413d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-2.0437212001672944E-10d));

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1271L, 13L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16523L);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = var29.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var30, var31);
    java.lang.Class var33 = var30.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    java.lang.String var37 = var36.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var41 = var40.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var42 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41, var42);
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var45 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var46 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.TiesStrategy var47 = var46.getTiesStrategy();
    java.lang.String var48 = var47.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var49 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var41, var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30, var47);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var51 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var53 = var52.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var54 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var55 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53, var54);
    org.apache.commons.math3.stat.ranking.NaNStrategy var56 = var55.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var58 = var57.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var59 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var58, var59);
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var58);
    org.apache.commons.math3.stat.ranking.NaNStrategy var62 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var62);
    org.apache.commons.math3.stat.ranking.TiesStrategy var64 = var63.getTiesStrategy();
    java.lang.String var65 = var64.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var66 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var58, var64);
    org.apache.commons.math3.stat.ranking.NaNStrategy var67 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var68 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var67);
    org.apache.commons.math3.stat.ranking.TiesStrategy var69 = var68.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var70 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var58, var69);
    org.apache.commons.math3.stat.ranking.NaturalRanking var71 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var56, var69);
    org.apache.commons.math3.stat.ranking.NaturalRanking var72 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var73 = var72.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var74 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var75 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var73, var74);
    java.lang.Class var76 = var73.getDeclaringClass();
    java.lang.String var77 = var73.name();
    org.apache.commons.math3.random.RandomGenerator var78 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var79 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var73, var78);
    org.apache.commons.math3.random.RandomGenerator var80 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var81 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var73, var80);
    org.apache.commons.math3.stat.ranking.NaturalRanking var82 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var83 = var82.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var84 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var85 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var83, var84);
    org.apache.commons.math3.stat.ranking.NaNStrategy var86 = var85.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var87 = var85.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var88 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var73, var87);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var89 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var56, var87);
    org.apache.commons.math3.stat.ranking.NaNStrategy var90 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var91 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var90);
    org.apache.commons.math3.stat.ranking.TiesStrategy var92 = var91.getTiesStrategy();
    java.lang.String var93 = var92.name();
    java.lang.String var94 = var92.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var95 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var56, var92);
    org.apache.commons.math3.stat.ranking.NaturalRanking var96 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "AVERAGE"+ "'", var48.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "AVERAGE"+ "'", var65.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var77 + "' != '" + "MAXIMAL"+ "'", var77.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + "AVERAGE"+ "'", var93.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var94 + "' != '" + "AVERAGE"+ "'", var94.equals("AVERAGE"));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.addElement(7.347999939986007d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-2.8236712811560465d));
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var2, (java.lang.Number)7548397703210479121L);
    var1.addSuppressed((java.lang.Throwable)var4);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    java.lang.String var5 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability(0.0d);
    boolean var3 = var0.isSupportConnected();
    double var4 = var0.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     int var9 = var1.nextZipf(1024, 6.605358949815338d);
//     var1.reSeed();
//     double var13 = var1.nextWeibull(8436285.0d, 3.0623660255387573d);
//     double var16 = var1.nextUniform(0.0d, 4.434676320188898d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var19 = var1.nextLong(1131479055207487616L, 350134950387303632L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "606e96e19090731aec3551c9d698b6b06eb2894a14155a18c2553b6574d72144adb3ccfe1f50f99f7a5b22c583f8200e3c7c"+ "'", var3.equals("606e96e19090731aec3551c9d698b6b06eb2894a14155a18c2553b6574d72144adb3ccfe1f50f99f7a5b22c583f8200e3c7c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8549305326297955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.062366065670165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.131748547697344d);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(3067312546548822528L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3067312546548822528L);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-7385977944948490239L), 3067312546548822528L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextChiSquare(1.8039440580589192d);
//     var1.reSeed(383L);
//     int var21 = var1.nextBinomial(0, 0.014387441792572614d);
//     double var24 = var1.nextWeibull(111.82519541140871d, 0.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var27 = var1.nextLong(6858108921003146464L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7a6d50121cc515fe7dae5afcac4f87f9a7c0238acb514ef0ff7a168029f226ca2889c4c94405d5da02f90cd5410415b0b2fe"+ "'", var3.equals("7a6d50121cc515fe7dae5afcac4f87f9a7c0238acb514ef0ff7a168029f226ca2889c4c94405d5da02f90cd5410415b0b2fe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.9623040069875635d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 35L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.598294058065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.4899570972762194d);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-93));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.0782079037160504d, 10.650889475874267d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0018246766473257125d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)4665724868967888896L, (java.lang.Number)0.8195982740349386d, (java.lang.Number)(-5.966735624802988d));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-2.329835095969994d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.981238493615607d));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = var9.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    java.lang.String var22 = var21.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var23 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var21);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var10, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-700251660), (java.lang.Number)2.4041148384872266d, false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 1.3234891E-22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3234891E-22f);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var12 = var1.nextGaussian(2.0599789360373797d, 0.3674212569981512d);
//     var1.reSeedSecure(52L);
//     long var16 = var1.nextPoisson(14.4057782350127d);
//     int var19 = var1.nextPascal(1126, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10.212465365568146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.41878783868362035d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.1391729469070038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 8L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2147483647);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1270, (java.lang.Number)4, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    double[] var7 = var1.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(6.747760046153423E115d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.915152417354522d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(1.0429276322537393d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7150964186137165d);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     int var20 = var1.nextSecureInt((-1450), 21);
//     double var23 = var1.nextGaussian(6.063012596579243E-4d, 12.972658968705218d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9e78f074123bec4265b4e2745feb1b1ed3338ad2a7baf50e60258668485e7c335e5c9cd09a28b65d084233b119bb4aa1945c"+ "'", var3.equals("9e78f074123bec4265b4e2745feb1b1ed3338ad2a7baf50e60258668485e7c335e5c9cd09a28b65d084233b119bb4aa1945c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.3666971905177148d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-1117));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 18.781212382028066d);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.3467095247430105d, 1.0058529949977943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3467095247430105d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.053114013672176386d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(100.10338921080671d, 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9706960653718343E-112d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    java.lang.Class var24 = var21.getDeclaringClass();
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var26);
    org.apache.commons.math3.random.RandomGenerator var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var35);
    org.apache.commons.math3.exception.util.Localizable var38 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var40 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var41 = var40.getMin();
    org.apache.commons.math3.exception.util.Localizable var42 = null;
    org.apache.commons.math3.exception.util.Localizable var43 = null;
    org.apache.commons.math3.exception.util.Localizable var44 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var45 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var46 = new org.apache.commons.math3.exception.MathIllegalStateException(var44, (java.lang.Object[])var45);
    org.apache.commons.math3.exception.MathIllegalStateException var47 = new org.apache.commons.math3.exception.MathIllegalStateException(var43, (java.lang.Object[])var45);
    org.apache.commons.math3.exception.MathIllegalStateException var48 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var40, var42, (java.lang.Object[])var45);
    java.lang.Throwable[] var49 = var48.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var50 = new org.apache.commons.math3.exception.MathInternalError(var38, (java.lang.Object[])var49);
    org.apache.commons.math3.exception.util.ExceptionContext var51 = var50.getContext();
    boolean var52 = var35.equals((java.lang.Object)var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "MAXIMAL"+ "'", var25.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + 0+ "'", var41.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.8444137398760581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8444137398760581d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var11 = var1.nextT(1.3877787807814457E-17d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var15 = var14.sample();
//     boolean var16 = var14.isSupportLowerBoundInclusive();
//     double var17 = var14.getStandardDeviation();
//     double var19 = var14.inverseCumulativeProbability(0.0d);
//     double var20 = var14.getSupportLowerBound();
//     double var21 = var14.getSupportUpperBound();
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     org.apache.commons.math3.distribution.NormalDistribution var25 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var26 = var25.getNumericalVariance();
//     boolean var27 = var25.isSupportConnected();
//     double[] var29 = var25.sample(100);
//     var25.reseedRandomGenerator((-1L));
//     double var32 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 46.416454230079715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.3701879770273364E153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-9.580722203180763d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-3.958173966425657d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-6.545793914133272d));
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var17 = var1.nextWeibull(10.953429709299042d, 2.515911276041704d);
//     int var20 = var1.nextInt((-709046803), 1);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextUniform(5100.499999999999d, 1.3932643278709607d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d67dd42023e1f5b83bd5b23a2f3c7f369bd2227f22081134cfbe672252dfc100d66c9a2108bccd2281e0be7ef5071b937a94"+ "'", var3.equals("d67dd42023e1f5b83bd5b23a2f3c7f369bd2227f22081134cfbe672252dfc100d66c9a2108bccd2281e0be7ef5071b937a94"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.3605319705943235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.5122776134135925d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-193335403));
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(40.69420911675787d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double var3 = var2.getSupportLowerBound();
    double var4 = var2.getMean();
    double var6 = var2.density((-7.249376137847348d));
    double var8 = var2.density(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4920673008707643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.295380730502794E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.20538156256369908d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     int var11 = var1.nextSecureInt((-1371062271), 190);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "f868121944bfdf0b90886899618af4b9474c4ab02a253b2be43c3b182238818b7c9990042e5ee6e6dfaf7e9058e4211a40db");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "686972f4f2a61c5b67705b69cc324fee29039d482c2fe54b44232f1b42c796568e4b4e74fa38ab2b3d1453b54bd723cffeed"+ "'", var3.equals("686972f4f2a61c5b67705b69cc324fee29039d482c2fe54b44232f1b42c796568e4b4e74fa38ab2b3d1453b54bd723cffeed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.464839198547472d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.835920376052814d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-771626715));
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.addElement((-0.9469118583888082d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-3.10540118145466d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999887532428864d));

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(4.2557905504595155d, (-5.476753078381883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setElement(100, 1.0d);
    double[] var18 = var11.getElements();
    var1.addElements(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var4.substituteMostRecentElement(0.0953010394379372d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var3 = var1.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-84));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     long var8 = var1.nextLong(0L, 6L);
//     var1.reSeed(6412798644893787649L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var1.nextF((-158.62814411276702d), 8.02983219447358d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(274448725870672832L, 41L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy var1 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var1);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }
// 
// 
//     org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-1.0d));
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     var1.reSeed(0L);
//     var1.reSeedSecure();
//     java.lang.String var17 = var1.nextSecureHexString(1);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "51ffd66f21a1d91cbfd5b2e8a3647c4ee65d1531ed1c762ca2b08a9b37e3cf0b5ca60425ade9d3d057ab776b541166c73951"+ "'", var3.equals("51ffd66f21a1d91cbfd5b2e8a3647c4ee65d1531ed1c762ca2b08a9b37e3cf0b5ca60425ade9d3d057ab776b541166c73951"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.072464564014131d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "d"+ "'", var17.equals("d"));
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var14 = var9.getNumericalVariance();
//     double var16 = var9.cumulativeProbability(0.02466363414863508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d3fb145f248583defa59fa1ceb8d0009a8cee384d2d6d8a6f74afe722f77f6e7650388ac4c4d535bf37b7c2908cf36bae06f"+ "'", var3.equals("d3fb145f248583defa59fa1ceb8d0009a8cee384d2d6d8a6f74afe722f77f6e7650388ac4c4d535bf37b7c2908cf36bae06f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-21));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.338661665572164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5329075359185451d);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var17 = var1.nextWeibull(10.953429709299042d, 2.515911276041704d);
//     int var20 = var1.nextInt((-102), 0);
//     double var23 = var1.nextGaussian(5.433764530217515d, 59.42686498524283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "226854a074b5f3741d6e7a0fad93324c71c47b913e9edf98a0150fa08a4270a0234d236965c877f7cf3fd08036fa205c4006"+ "'", var3.equals("226854a074b5f3741d6e7a0fad93324c71c47b913e9edf98a0150fa08a4270a0234d236965c877f7cf3fd08036fa205c4006"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.085036915703352d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.0987191225887187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-45));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 114.55405965305599d);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2900), (-589261714));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-589264614));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-1.6783533352775395d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6783533352775395d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    int var21 = var18.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var25);
    java.lang.Class var27 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    java.lang.String var31 = var30.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var35);
    double[] var38 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    var39.discardMostRecentElements(0);
    double[] var44 = var39.getElements();
    double[] var45 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var45);
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
    org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
    var48.setExpansionMode(0);
    double[] var51 = var48.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var53 = var37.mannWhitneyU(var44, var51);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var7);
    double[] var9 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    float var11 = var10.getExpansionFactor();
    int var12 = var10.getExpansionMode();
    double[] var13 = var10.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var14 = var8.rank(var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var3 = var1.getExpansionMode();
    double[] var4 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    float var8 = var7.getContractionCriteria();
    int var9 = var7.start();
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var7.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var10.copy();
    double[] var12 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var13.setNumElements(1);
    int var17 = var13.getExpansionMode();
    double var19 = var13.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var21 = var13.addElementRolling(100.0d);
    var13.clear();
    int var23 = var13.getExpansionMode();
    double[] var24 = var13.getInternalValues();
    var11.addElements(var24);
    var1.addElements(var24);
    float var27 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.Class var12 = var11.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var14 = java.lang.Enum.<java.lang.Enum>valueOf(var12, "bc6f12c3ef488a5d4ad803ef9910c605cbb859271049da2b8c5825ddab90db51bf08815c4c491028ff783024ff923f9ba485");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.04321612109578537d, 93.08786818892479d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9512661701313443d);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var18 = var17.sample();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     var17.reseedRandomGenerator(682784375L);
//     double var23 = var17.inverseCumulativeProbability(0.7242441387499587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 382.99036537001194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1782768701750026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.013389314301386856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 14.341887835158026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-5.5738191023776285d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5.153820119447314d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-84), (-206885));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     double var21 = var1.nextChiSquare(0.18340211571916795d);
//     double var24 = var1.nextGaussian((-4.580797191943736d), 0.06311533379311396d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var1.nextBinomial(1819287553, 111.10643218159737d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "3a6e300f348979c53c7c2223fd9b10a308f0efcc750755ad1c95db3f90d23f1c5eea078e304747c2d417e86bac6331d37025"+ "'", var3.equals("3a6e300f348979c53c7c2223fd9b10a308f0efcc750755ad1c95db3f90d23f1c5eea078e304747c2d417e86bac6331d37025"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.988595659000416d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.15424956014795227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-4.55515748340573d));
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextCauchy(30.22353858942031d, 1.9142161307821561d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial((-127), 0.5566299156929325d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.8903939522309874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.2730016509750819d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.1706170675878494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 32.359368687919584d);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.9575061341402422d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1106712032083552d));

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-0.034870322040000575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)8.310390625902146d);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability(19.278190722344966d);
//     boolean var16 = var12.isSupportConnected();
//     double var17 = var12.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 32.23142625526961d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.205114549541203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9776748171139936d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    var1.setNumElements(9);
    double var10 = var1.addElementRolling(1.5557982028522581d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements((-536427449));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-9.56061940508766d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-9.560619405087659d));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(8.702267689224303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999447494877d);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)34.0d, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-25), 1.0000001f, 1.3234892E-22f, (-44));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-11), 1270);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var3.setExpansionMode(0);
    var3.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setContractionCriteria(3.944305E-30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.9467629965706595d, 1.9798058966512196E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9467629965706595d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)168.94440888412288d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1450);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9109.570966773374d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var1.nextPermutation(25, 1126);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 66.86526682663904d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1743283481885092096L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 47.551192722314084d);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var11 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MaxCountExceededException var13 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, (java.lang.Number)(byte)1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var4, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.util.ExceptionContext var22 = var21.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    int var11 = var1.ordinal();
    java.lang.String var12 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var15 = var1.nextChiSquare(107.02504705938293d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var18 = var1.nextHexString((-98874598));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-771529812));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 40.28863240900115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 57.94938413750387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 97.17648806957324d);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     double var19 = var1.nextGamma((-27.235566339247477d), 0.31763013614892044d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextT((-96.56639765669301d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-990038159));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 56.782180433439365d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-7.507485813853034d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.949880297894032d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.0f, (java.lang.Number)(byte)100, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.0f+ "'", var4.equals(2.0f));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.644319170694769d, (-700251660));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("f06f760d66fe01d75748ca75073a4c8de196aa6b10f69952b1ce7dc3172cb6dd3d75dac8b8cf52564602fb87016e7567dc6f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     boolean var18 = var9.isSupportLowerBoundInclusive();
//     double var19 = var9.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20.76693587075935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-17.50677175118926d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 3.695401548178659d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4.171214858108831d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 100.0d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.629395E-6f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.6293945E-6f);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0d, 4.848621613711392d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999999929672d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.7834879445067402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7834879445067404d);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.015730424653173966d, (-2.1191725702837423d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "562cef7c38e611f42f324572");
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 70);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability(0.0d);
    double var3 = var0.getSupportUpperBound();
    boolean var4 = var0.isSupportLowerBoundInclusive();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var6 = var0.sample((-27964641));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)(-0.8427007929497151d), false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-1.8111190107155866d), 0.008501119845704857d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5661025118863345d));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-107), 7.1054274E-15f, 4.5916E-41f, 27985567);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(51L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 51L);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, (-433411940));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability(0.0d);
    double var3 = var0.getSupportUpperBound();
    double var4 = var0.getStandardDeviation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.inverseCumulativeProbability(4708.010255921329d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var9, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var15 = var1.nextChiSquare(107.02504705938293d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextInt(1455, (-1178076066));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1209836283));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 59.49222207016293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 40.80719679422598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 107.82738668997814d);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt((-703556403), 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextPascal((-1250178908), 10.647765883852417d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 134.4941569360266d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-134263047));
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.06812197096180644d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.903101428224258d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-3.149426875672435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9999915700052269d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.9777023375840317d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6703546647110433d));

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0000002f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     long var14 = var1.nextPoisson(4.072261697491794E-5d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     double var14 = var12.nextExponential(100.0d);
//     int var17 = var12.nextZipf(10, 100.0d);
//     int var20 = var12.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var24 = var12.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var25 = var23.getStandardDeviation();
//     double var27 = var23.inverseCumulativeProbability(0.24433316542704286d);
//     double var28 = var23.sample();
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     long var31 = var1.nextPoisson(1.3877787807814457E-17d);
//     org.apache.commons.math3.distribution.IntegerDistribution var32 = null;
//     int var33 = var1.nextInversionDeviate(var32);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2.0439843355597187d), (java.lang.Number)52.001078291710975d, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-29.67087421651356d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5371059940497327d));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var2);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var5 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     double var8 = var2.getSupportLowerBound();
//     double var9 = var2.getSupportUpperBound();
//     double var10 = var2.getStandardDeviation();
//     double var12 = var2.probability((-3.496695663378208d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-6.6089036741935026d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-857875772));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b3e9b4f1c5836ddea69d3122a3219093f1dd3d189469bd4bebc4a4ea57f7383d46666a4a7d9160e267186606674018a01ea0"+ "'", var3.equals("b3e9b4f1c5836ddea69d3122a3219093f1dd3d189469bd4bebc4a4ea57f7383d46666a4a7d9160e267186606674018a01ea0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(8.416931451170521d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.845684524945627d);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-2375779087806406849L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.05531224118406357d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.2709136332227942d), 9.05428369392931d, 32.00870039102856d, (-1175508555));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    java.lang.String var28 = var27.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var27);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = var31.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var33 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32, var33);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var36 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var36);
    org.apache.commons.math3.stat.ranking.TiesStrategy var38 = var37.getTiesStrategy();
    java.lang.String var39 = var38.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var32, var38);
    int var41 = var38.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var38);
    org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var44 = var43.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var44, var45);
    java.lang.Class var47 = var44.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var50 = var49.getTiesStrategy();
    java.lang.String var51 = var50.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var50);
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var44, var50);
    org.apache.commons.math3.stat.ranking.TiesStrategy var54 = var53.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var53.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var55);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var55);
    org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "AVERAGE"+ "'", var39.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "AVERAGE"+ "'", var51.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    java.lang.Class var29 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var31 = java.lang.Enum.<java.lang.Enum>valueOf(var29, "org.apache.commons.math3.exception.NumberIsTooLargeException: -5.754 is larger than the maximum (-0.095)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    double[] var4 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    double[] var8 = var5.getElements();
    var5.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var13 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, (java.lang.Object[])var13);
    boolean var15 = var5.equals((java.lang.Object)var12);
    boolean var17 = var5.equals((java.lang.Object)'#');
    var5.discardFrontElements(37);
    double[] var20 = var5.getElements();
    var1.addElements(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement((-147267201), 50.94909583146956d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, var2, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var2 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
//     java.lang.Class var8 = var7.getDeclaringClass();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var17 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
//     java.lang.String var23 = var22.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var22);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var27);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     boolean var34 = var32.equals((java.lang.Object)8.310101398016423d);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var32);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var37.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var39 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var40 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38, var39);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var42 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var43 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var42);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var44 = var43.getTiesStrategy();
//     java.lang.String var45 = var44.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var46 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var38, var44);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var47 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var49 = var48.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var50 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49, var50);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var52 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var49);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var53 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var53);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var55 = var54.getTiesStrategy();
//     java.lang.String var56 = var55.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var57 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var49, var55);
//     int var58 = var55.ordinal();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var59 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38, var55);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var61 = var60.getNanStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var62 = null;
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var63 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var61, var62);
//     java.lang.Class var64 = var61.getDeclaringClass();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var65 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var66 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var65);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var67 = var66.getTiesStrategy();
//     java.lang.String var68 = var67.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var69 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var67);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var70 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var61, var67);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var71 = var70.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.TiesStrategy var72 = var70.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var73 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var72);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var74 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var38, var72);
//     org.apache.commons.math3.random.RandomGenerator var75 = null;
//     org.apache.commons.math3.random.RandomDataImpl var76 = new org.apache.commons.math3.random.RandomDataImpl(var75);
//     double var78 = var76.nextExponential(100.0d);
//     double var81 = var76.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var84 = var76.nextCauchy(29.171528454339946d, 9.0d);
//     double var86 = var76.nextExponential(38.13608131498478d);
//     boolean var87 = var72.equals((java.lang.Object)38.13608131498478d);
//     java.lang.String var88 = var72.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var89 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "AVERAGE"+ "'", var45.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "AVERAGE"+ "'", var56.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var68 + "' != '" + "AVERAGE"+ "'", var68.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 66.57408258376356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == (-24.1521812440291d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 28.06788557714265d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 2.8175911682698978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var88 + "' != '" + "AVERAGE"+ "'", var88.equals("AVERAGE"));
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    java.lang.Number var10 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var10, (java.lang.Number)(-0.8427007929497151d), false);
    var8.addSuppressed((java.lang.Throwable)var13);
    java.lang.String var15 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-0.843)"+ "'", var15.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-0.843)"));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportUpperBoundInclusive();
    double var12 = var2.density(5.964535219365547d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.inverseCumulativeProbability(2.3701879770272203E153d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.031733077854635645d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-56.49404560541292d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.06355509807076716d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.Class var12 = var11.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var11 = var8.inverseCumulativeProbability(0.0d);
//     double var12 = var8.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 444.2028206425408d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3135504472810691d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(4.213518201370181d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0d);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-15.007540346423013d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(24.749239419764017d, (-17.31533392446027d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.1812745646900726d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    java.lang.String var5 = var1.name();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var6);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.String var18 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var22);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var28);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-37.77553545518616d), (java.lang.Number)82.10205579628098d, (java.lang.Number)9.82265018026397d);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     long var9 = var1.nextLong(8L, 17L);
//     double var12 = var1.nextWeibull(11.298541236500686d, 41.79124149463175d);
//     double var14 = var1.nextT(0.8813735870195429d);
//     var1.reSeed(181L);
//     var1.reSeedSecure(368456645954731072L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("187ad2757dfba95b1579a24d265580a675d274a961d3dd21acaf5395d4f8310c066717cd662526ff7cae6877c5c80c0826f7", "226854a074b5f3741d6e7a0fad93324c71c47b913e9edf98a0150fa08a4270a0234d236965c877f7cf3fd08036fa205c4006");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 6.899557631358724d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-19.94229531788943d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 44.32368806551971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2.8639831278105823d));
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-4.080798137442308d));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    float var15 = var1.getContractionCriteria();
    double var17 = var1.substituteMostRecentElement(0.0d);
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    float var22 = var21.getContractionCriteria();
    int var23 = var21.start();
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var21.copy();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var21);
    float var26 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.5f);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextSecureInt(27964641, 297623103);
//     long var6 = var0.nextSecureLong(0L, 6858108921003146464L);
//     var0.reSeed(41L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextCauchy(0.0d, (-2.296763228752664d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 127840154);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5416548596642822144L);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var9 = var1.nextCauchy(29.171528454339946d, 9.0d);
//     double var11 = var1.nextExponential(38.13608131498478d);
//     double var14 = var1.nextCauchy(1.5410312241221764d, 3.4948795302692948d);
//     int var17 = var1.nextSecureInt((-117325921), (-83903276));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var19 = var1.nextSecureHexString((-634401246));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 177.89832126015915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-24.097321755670368d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 19.29775135158922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 37.9946353045947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.050857490354583756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-101830731));
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    double[] var12 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    float var14 = var13.getExpansionFactor();
    double[] var15 = var13.getInternalValues();
    var13.clear();
    float var17 = var13.getContractionCriteria();
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var19.discardFrontElements(0);
    boolean var24 = var19.equals((java.lang.Object)(short)1);
    double[] var26 = new double[] { 10.0d};
    var19.addElements(var26);
    var13.addElements(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    double[] var30 = var10.rank(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var23 = var22.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var22);
    double var26 = var22.substituteMostRecentElement((-0.9932484371644573d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-16.654923532858998d), 16.04724703051165d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6076765023473492d));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-105), (-274265352));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-274265352));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(161.62052203953047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.0821542740407075d);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     boolean var19 = var12.isSupportConnected();
//     var12.reseedRandomGenerator(90L);
//     double var22 = var12.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20.460445827119457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-14.017647049295244d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 10.0d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements((-1143914887));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextT(6.066191094237188E76d);
//     double var11 = var1.nextGaussian(6.0502044810397875d, 1.9142161307821561d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var1.nextSecureHexString((-73));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14.899933279912903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.74055240957065E-10d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.3834358356376475d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.596120551218976d, (java.lang.Number)86.74240888600346d, false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 1918124033);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.math.BigInteger var16 = null;
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0);
    java.math.BigInteger var21 = null;
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
    java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var25);
    org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var15, (java.lang.Number)var25, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var30 = new org.apache.commons.math3.exception.NotPositiveException(var14, (java.lang.Number)var25);
    java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var25);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 1249363969);
    java.math.BigInteger var37 = org.apache.commons.math3.util.ArithmeticUtils.pow(var35, 543525818476686592L);
    java.math.BigInteger var39 = org.apache.commons.math3.util.ArithmeticUtils.pow(var37, 1450);
    org.apache.commons.math3.exception.NumberIsTooSmallException var41 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)15.522638926784573d, (java.lang.Number)1450, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     double var14 = var1.nextExponential(2.654532116546876d);
//     double var16 = var1.nextChiSquare(2.3607289386991592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8678d666b26c020da9f789046698eddc5cc1a856af8a194b1fa6c2b95fb778d8e3e6c8c830e8fba33b8390b49d0a67e66dc2"+ "'", var3.equals("8678d666b26c020da9f789046698eddc5cc1a856af8a194b1fa6c2b95fb778d8e3e6c8c830e8fba33b8390b49d0a67e66dc2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.5395543867255745d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.4869628694677966d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.2738369799853206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.2933263943926314d);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    var1.contract();
    var1.setNumElements(100);
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var19.setNumElements(1);
    int var23 = var19.getExpansionMode();
    double var25 = var19.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double[] var26 = var19.getElements();
    var1.addElements(var26);
    int var28 = var1.start();
    org.apache.commons.math3.util.ResizableDoubleArray var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var29);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-96.56639765669303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5532.847028510513d));

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    int var14 = var1.ordinal();
    java.lang.Class var15 = var1.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    java.lang.String var4 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-475858716), (-106));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 5.717858802944031d);
    boolean var9 = var4.equals((java.lang.Object)5.717858802944031d);
    java.lang.Class var10 = var4.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)5470.920438815667d, (java.lang.Number)9.664627594214629d, false);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(145.07341190090915d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8471755108053737d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.9999999f, 1.2676508E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setExpansionMode((-1133));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)151.64330039654138d);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     boolean var6 = var2.isSupportUpperBoundInclusive();
//     boolean var7 = var2.isSupportConnected();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var9 = var2.sample((-556289202));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-8.216547303506575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var17 = var16.getNumericalVariance();
//     boolean var18 = var16.isSupportConnected();
//     double var21 = var16.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
//     double var23 = var16.density(0.0d);
//     boolean var24 = var16.isSupportUpperBoundInclusive();
//     double var26 = var16.density(5.964535219365547d);
//     double var27 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var29 = var1.nextChiSquare((-1.3407807929942597E154d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a9eb5249c1f58c9c89037b2ac097db7d1f0a55e87b9f52cd251f6f1a3f5072bc6522a697cbb4f0678ae4694ef7e48368f092"+ "'", var3.equals("a9eb5249c1f58c9c89037b2ac097db7d1f0a55e87b9f52cd251f6f1a3f5072bc6522a697cbb4f0678ae4694ef7e48368f092"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3041654227746802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.06146076675140928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.031733077854635645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-2.428038591275714d));
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-25));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(145.07341190090915d, (-17.29539539206854d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.710248764360841d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(0L, 1313988029218217472L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1313988029218217472L);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1L), 591436115971011712L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-591436115971011713L));

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(29, (-82));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2378);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, (-8929190990895382527L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1765921446827724705L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter((-0.0f), 0.3068313011297756d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var2 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
//     org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
//     org.apache.commons.math3.exception.util.ExceptionContext var10 = var8.getContext();
//     java.lang.String var11 = var8.toString();
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.getNumericalVariance();
//     double var4 = var2.getNumericalMean();
//     double var5 = var2.getSupportLowerBound();
//     double var6 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6496950801190526d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-87));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)190.3667852171033d, (java.lang.Number)119);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 119+ "'", var4.equals(119));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    int var10 = var1.getNumElements();
    var1.addElement(1.7590683406011705d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-16));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)99.99999f, false);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(5.9150377648297426E79d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 184.37486740908614d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    java.lang.String var2 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"+ "'", var2.equals("org.apache.commons.math3.exception.MathArithmeticException: arithmetic exception"));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    double[] var15 = var14.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(7, 2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(153928164, 1918124033);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1764195869));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.3234891E-22f, 1.0045506211464423d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3234892E-22f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.056811020017610465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0584557645420212d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(285L, 1023863903247170432L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1023863903247170147L));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(253881326706450433L, (-703550053));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)5.03622754778507d, (java.lang.Number)355687428096000L, (java.lang.Number)8.296885318080307d);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var8);
//     double var10 = var8.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 193.18170094495684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 18L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.009689357835013906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var5.setContractionCriteria(2.0f);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    int var12 = var11.getExpansionMode();
    double[] var13 = var11.getInternalValues();
    var5.addElements(var13);
    float var15 = var5.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    boolean var24 = var22.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var22);
    double[] var26 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    int var29 = var27.getExpansionMode();
    double[] var30 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    float var34 = var33.getContractionCriteria();
    int var35 = var33.start();
    org.apache.commons.math3.util.ResizableDoubleArray var36 = var33.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var37 = var36.copy();
    double[] var38 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    var39.setNumElements(1);
    int var43 = var39.getExpansionMode();
    double var45 = var39.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var47 = var39.addElementRolling(100.0d);
    var39.clear();
    int var49 = var39.getExpansionMode();
    double[] var50 = var39.getInternalValues();
    var37.addElements(var50);
    var27.addElements(var50);
    double[] var53 = var27.getInternalValues();
    double[] var54 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
    float var56 = var55.getExpansionFactor();
    int var57 = var55.getExpansionMode();
    double[] var58 = var55.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var59 = var25.mannWhitneyU(var53, var58);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.0287115883872695d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.854280313149045d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-87), 95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8265);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    double[] var20 = new double[] { (-1.0d)};
    double[] var21 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    var22.setNumElements(1);
    int var26 = var22.getExpansionMode();
    double var28 = var22.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var30 = var22.addElementRolling(100.0d);
    double[] var31 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var32);
    double[] var35 = var32.getElements();
    var32.setElement(100, 1.0d);
    double[] var39 = var32.getElements();
    var22.addElements(var39);
    double var41 = var18.mannWhitneyUTest(var20, var39);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    double var44 = var42.substituteMostRecentElement(0.9575217061535137d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.08631729905748209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.0d);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     double var16 = var1.nextExponential(68.80167001187898d);
//     double var18 = var1.nextChiSquare(125.30215811146536d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var20 = var1.nextHexString((-21));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41.28089747389288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3062664704236566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 25.180956271003282d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 72.16659711317236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 132.7194142814772d);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     double var17 = var12.sample();
//     double var19 = var12.density(0.28583983826614007d);
//     boolean var20 = var12.isSupportLowerBoundInclusive();
//     boolean var21 = var12.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.2586105956911806d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.4547119024356623d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.754587991983106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.03965924109521295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setElement(100, 1.0d);
    double[] var18 = var11.getElements();
    var1.addElements(var18);
    var1.setNumElements(68921);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(530087618);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     long var19 = var1.nextSecureLong(0L, 16L);
//     double var21 = var1.nextT(2.0044040509068734E-15d);
//     java.lang.String var23 = var1.nextSecureHexString(3116);
//     java.lang.String var25 = var1.nextHexString(11);
//     double var27 = var1.nextChiSquare(5.2287814812793784E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1052494225));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 33.80970689299692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-52.74203622878664d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10.46920650960968d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.3407807929942597E154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "02179a1918517ec678f01aa5031583fc5b5fca805bdc832ad5bda3fa518fcfa233c03a1945105d2a660d484a1cb585caa2a1967295ec915c86a5287665e954b9a9a403c933c55cedc5e43e7a52040d7370a7ff7de1bc9aad641292ca5868af272850ed01bcfdb1ed8b2d0b1e26de5fcd2bddf310f3ecb84a0fd5c1ca9212c3c15808b3a0abd6fd3fe6b8765e00a4c9a53be2a14a6d206fe1e08bf4257087ee60af9e9ba0efbd0829f1640c9102ae8da4c620d1a2c424bb9ef16de70b32489de930c78abd2ce6cfdcba08368b40fb6203d066563bd55b5f9dea28a5194102554bb403f08595209f54ec73176f50f7bea65a0aee88e1b7d721f0a613c2ec1f3f5a308cc30d4cc684a202f95d8ce7406c7a1aed802282a21beec0cb2be126ad0e921541089e1e0b4e729896558bfb002a5e267f4f1915bb2a9fab3d0d13f2ba2650b5943a1e7dfc24b0c8f9afbb938a9250573a23dbb03c14ff079cda869a6a4600817879c75086e9f8301db8a8c806e54b7aafede2d441a7e13723dcb6f9b64a4d87f39b9fca20607871ce39be063d0d4cb81f6b10d9a8500c91752eedee988b0cb1740702a5999ce94561d8978bfe334f10a1e1a448c4282d2c58cffd28345a025fce9a40ccbb18cc6c452dfa3deef99394dbd1c57036b1d55681f88ee5f8a17c4f1f14b7a84f66b728a17579041509e9c88daf7a3c540971b14c6611a899c8bb1d532bd697201d836de581ef9f6c66dcf223ac48114c0708a8ebf866467d917021ea45099e3ea0b5a9087fda373c87ae5928d30b0c9170ae2df1d5b36b961ccd4ea151186e94329c4915160aa3ae6369e2d3b3d95f438f213ff13fba89baf465c61debdb4a67c405d2e5c29ae62f4f848e4e3308f3ea9c65f23568104cbe5e17f16d72ce9500e94859f10a162c04a6b17073f35d540897eeafd0a7ef45837c48457f48a20c9761c8e1b10fbcba7c9c67ed22e85d80bfbccb3cd5027be757881514a23d468c25338122571b8a951934b3d28cbc1f8e063203789a214da285a0b232d0ade794d95ab0642c01dc49a09fa6b22ac65242ee953a27a39004da604c344154f8cc9d6831cd3fbb21476ac908aa221c2278a22dd72de92305f7cbf49b74b0b9c9a6b0881ead1b33c09e6d7d80a642d5fdbacbd78bf0d7c60a8cd464d6044ca7813bbb86931f2bfd2e93506411b09b14c24fdf32aa49375f09addfd60f1604730c4b49cd573508090a6adb556d864c42ef05368be783c1202cb09b247953bebdd8692a46ce5f47288ab66ba7ed1778b554924b5032fbe951c9de6aaeae47508729b58e8d8e69d91e6ff7e57473d0440d3ef685214bee654d9f869778434d7b064ac5af461faa419723846d0e1c1af5fc3ed58253311c61375a72a0f108ff01c6a7e01445b425302176a279037a885f92432d52cc1df2b0f1e1fa9ebda29c7c3b73ca8d1bb02eb1c3abb655ef5a0f30b3d0935d130729e7f452763d730e1bc1eab5e67c97e166f6359d9e85bd347a16be52feb17a47f04a2c2c145e2e081be3a3e2d27636e3d07a8d769cc18e03c59ea8fdef2cd07464c23deeeeb59d5266fa3dd0057f43218e78d1553e6f15b70037845e63e28bdcc9b09a2767cc942bff30e22f2ced477d76771e38d45bd720f23860192d5b53f86b0be70de4b708b735ec32610d5eb2b9ad3ee1ff642d224caeb287bc38526950f2fc45f8f29dee5b0a795d8332a8aee6fed56bfede74bc66323bdfdebe2624e82e7aefae6652bacf6d5bdb7f7ba0cdfe16def207ecf27d85aa3f44d36c0a0589d836e012f81b28fbc64b3ddf857054c7ca63e3fdb341caa8b50f0002d9259615c398b607c2d754b2f23576d4c2245f7cc6a305a404638ce4045a59cfb197cb4819999e6c29dd704aca13dc0904d43ed17621784512c180de756ab7bee117394d8c527b3b135d27030f9e360bb032559a45e21fbc7b98d7e85d1fdc15506fceaf578be7cfab955cfac791a0ff3cb9e99e7220eea551e78fb5052d2b792e070dcd96cce45cee0791882a78cefbb78e2717a0c5479d4423c1d98bb5685e38259d762cf687eb9d565799246f783688d85196993ba832209c740aaef5c6497cfc0906252c2a546a89fc36f539ba73d7736c0e4b9be02ff1888ac16618e6681e20ca06cacfd512043c8461ef5cf240c96a31cdb2150dcb7e397edc0f8ecafebb3a99"+ "'", var23.equals("02179a1918517ec678f01aa5031583fc5b5fca805bdc832ad5bda3fa518fcfa233c03a1945105d2a660d484a1cb585caa2a1967295ec915c86a5287665e954b9a9a403c933c55cedc5e43e7a52040d7370a7ff7de1bc9aad641292ca5868af272850ed01bcfdb1ed8b2d0b1e26de5fcd2bddf310f3ecb84a0fd5c1ca9212c3c15808b3a0abd6fd3fe6b8765e00a4c9a53be2a14a6d206fe1e08bf4257087ee60af9e9ba0efbd0829f1640c9102ae8da4c620d1a2c424bb9ef16de70b32489de930c78abd2ce6cfdcba08368b40fb6203d066563bd55b5f9dea28a5194102554bb403f08595209f54ec73176f50f7bea65a0aee88e1b7d721f0a613c2ec1f3f5a308cc30d4cc684a202f95d8ce7406c7a1aed802282a21beec0cb2be126ad0e921541089e1e0b4e729896558bfb002a5e267f4f1915bb2a9fab3d0d13f2ba2650b5943a1e7dfc24b0c8f9afbb938a9250573a23dbb03c14ff079cda869a6a4600817879c75086e9f8301db8a8c806e54b7aafede2d441a7e13723dcb6f9b64a4d87f39b9fca20607871ce39be063d0d4cb81f6b10d9a8500c91752eedee988b0cb1740702a5999ce94561d8978bfe334f10a1e1a448c4282d2c58cffd28345a025fce9a40ccbb18cc6c452dfa3deef99394dbd1c57036b1d55681f88ee5f8a17c4f1f14b7a84f66b728a17579041509e9c88daf7a3c540971b14c6611a899c8bb1d532bd697201d836de581ef9f6c66dcf223ac48114c0708a8ebf866467d917021ea45099e3ea0b5a9087fda373c87ae5928d30b0c9170ae2df1d5b36b961ccd4ea151186e94329c4915160aa3ae6369e2d3b3d95f438f213ff13fba89baf465c61debdb4a67c405d2e5c29ae62f4f848e4e3308f3ea9c65f23568104cbe5e17f16d72ce9500e94859f10a162c04a6b17073f35d540897eeafd0a7ef45837c48457f48a20c9761c8e1b10fbcba7c9c67ed22e85d80bfbccb3cd5027be757881514a23d468c25338122571b8a951934b3d28cbc1f8e063203789a214da285a0b232d0ade794d95ab0642c01dc49a09fa6b22ac65242ee953a27a39004da604c344154f8cc9d6831cd3fbb21476ac908aa221c2278a22dd72de92305f7cbf49b74b0b9c9a6b0881ead1b33c09e6d7d80a642d5fdbacbd78bf0d7c60a8cd464d6044ca7813bbb86931f2bfd2e93506411b09b14c24fdf32aa49375f09addfd60f1604730c4b49cd573508090a6adb556d864c42ef05368be783c1202cb09b247953bebdd8692a46ce5f47288ab66ba7ed1778b554924b5032fbe951c9de6aaeae47508729b58e8d8e69d91e6ff7e57473d0440d3ef685214bee654d9f869778434d7b064ac5af461faa419723846d0e1c1af5fc3ed58253311c61375a72a0f108ff01c6a7e01445b425302176a279037a885f92432d52cc1df2b0f1e1fa9ebda29c7c3b73ca8d1bb02eb1c3abb655ef5a0f30b3d0935d130729e7f452763d730e1bc1eab5e67c97e166f6359d9e85bd347a16be52feb17a47f04a2c2c145e2e081be3a3e2d27636e3d07a8d769cc18e03c59ea8fdef2cd07464c23deeeeb59d5266fa3dd0057f43218e78d1553e6f15b70037845e63e28bdcc9b09a2767cc942bff30e22f2ced477d76771e38d45bd720f23860192d5b53f86b0be70de4b708b735ec32610d5eb2b9ad3ee1ff642d224caeb287bc38526950f2fc45f8f29dee5b0a795d8332a8aee6fed56bfede74bc66323bdfdebe2624e82e7aefae6652bacf6d5bdb7f7ba0cdfe16def207ecf27d85aa3f44d36c0a0589d836e012f81b28fbc64b3ddf857054c7ca63e3fdb341caa8b50f0002d9259615c398b607c2d754b2f23576d4c2245f7cc6a305a404638ce4045a59cfb197cb4819999e6c29dd704aca13dc0904d43ed17621784512c180de756ab7bee117394d8c527b3b135d27030f9e360bb032559a45e21fbc7b98d7e85d1fdc15506fceaf578be7cfab955cfac791a0ff3cb9e99e7220eea551e78fb5052d2b792e070dcd96cce45cee0791882a78cefbb78e2717a0c5479d4423c1d98bb5685e38259d762cf687eb9d565799246f783688d85196993ba832209c740aaef5c6497cfc0906252c2a546a89fc36f539ba73d7736c0e4b9be02ff1888ac16618e6681e20ca06cacfd512043c8461ef5cf240c96a31cdb2150dcb7e397edc0f8ecafebb3a99"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "3b39eba9b7c"+ "'", var25.equals("3b39eba9b7c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.0d);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(112.61567172469836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.discardFrontElements(37);
    var1.addElement(4.825567704784462d);
    float var18 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    double[] var29 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    var30.setNumElements(1);
    int var34 = var30.getExpansionMode();
    double var36 = var30.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var38 = var30.addElementRolling(100.0d);
    double[] var39 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    double[] var43 = var40.getElements();
    var40.setElement(100, 1.0d);
    double[] var47 = var40.getElements();
    var30.addElements(var47);
    boolean var49 = var1.equals((java.lang.Object)var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var51 = var50.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.TiesStrategy var57 = var56.getTiesStrategy();
    java.lang.String var58 = var57.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var51, var57);
    org.apache.commons.math3.stat.ranking.NaNStrategy var60 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60);
    org.apache.commons.math3.stat.ranking.TiesStrategy var62 = var61.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var62);
    org.apache.commons.math3.random.RandomGenerator var64 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var64);
    org.apache.commons.math3.stat.ranking.TiesStrategy var66 = var65.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var66);
    org.apache.commons.math3.stat.ranking.NaturalRanking var68 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var69 = var68.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var70 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var71 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var69, var70);
    org.apache.commons.math3.stat.ranking.NaNStrategy var72 = var71.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var73 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var74 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var73);
    org.apache.commons.math3.stat.ranking.TiesStrategy var75 = var74.getTiesStrategy();
    java.lang.Class var76 = var75.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var77 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var72, var75);
    org.apache.commons.math3.stat.ranking.NaturalRanking var78 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var72);
    org.apache.commons.math3.random.RandomGenerator var79 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var80 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var72, var79);
    org.apache.commons.math3.stat.ranking.NaturalRanking var81 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var72);
    org.apache.commons.math3.stat.ranking.TiesStrategy var82 = var81.getTiesStrategy();
    int var83 = var82.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var84 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "AVERAGE"+ "'", var58.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 3);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var11 = var1.nextT(1.3877787807814457E-17d);
//     var1.reSeed();
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var1.nextSample(var13, 32);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.05998383756582615d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.7346724102120235d), (java.lang.Number)45.2649758891003d, (java.lang.Number)3.0d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 3.0d+ "'", var5.equals(3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 3.0d+ "'", var6.equals(3.0d));

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-434141534));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     var1.reSeed();
//     var1.reSeed(19L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 209.95763193441817d);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     double[] var18 = var12.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     double[] var20 = var19.getInternalValues();
//     var19.clear();
//     double[] var22 = var19.getInternalValues();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 32.97401671241791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-9.873636984593317d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(737032375, (-711711710));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(215720602, (-739555469));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-523834867));

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     var1.reSeed((-1L));
//     var1.reSeed();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "68681275460258faff1ab43962f9de120f4ca855514211f72ccd7196c8d26f55e3cc619a55111d36fd4c625b9b70ef0a29cf"+ "'", var3.equals("68681275460258faff1ab43962f9de120f4ca855514211f72ccd7196c8d26f55e3cc619a55111d36fd4c625b9b70ef0a29cf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6250380682789543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.008153158445070757d);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-8929190990895382527L), 35L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3625752394978033665L);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(3.9034157645529923d, 0.039766406469604984d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    double var5 = var2.cumulativeProbability(32.49045649769782d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.0333147966386297E40d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(32.0d, 48.75687740267732d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 32.0d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportUpperBoundInclusive();
    var2.reseedRandomGenerator(15L);
    double var13 = var2.getMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var2.inverseCumulativeProbability((-18.0237441949784d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-0.8011436155469337d));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.5319268497029056d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5573685716885844d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(2822328434162903041L, 2822328434162903041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var12 = var9.getElements();
    var9.setExpansionMode(1);
    double[] var15 = var9.getInternalValues();
    var7.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var7);
    double[] var22 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    var23.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = var23.copy();
    var23.contract();
    var23.clear();
    double[] var30 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    org.apache.commons.math3.util.ResizableDoubleArray var32 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    org.apache.commons.math3.util.ResizableDoubleArray var33 = new org.apache.commons.math3.util.ResizableDoubleArray(var31);
    double[] var34 = var31.getElements();
    var31.setExpansionMode(1);
    double[] var37 = var31.getInternalValues();
    boolean var38 = var23.equals((java.lang.Object)var37);
    var1.addElements(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(2.3841858E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(8.709634523864029d, (-0.8363625025557515d), (-18.804897963419908d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextT(6.066191094237188E76d);
//     double var11 = var1.nextGaussian(6.0502044810397875d, 1.9142161307821561d);
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl(var12);
//     java.lang.String var15 = var13.nextHexString(100);
//     double var18 = var13.nextGaussian(0.0d, 2.251752586176186d);
//     int var21 = var13.nextInt((-1), 1);
//     int var24 = var13.nextSecureInt(0, 34);
//     var13.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var29 = var28.getNumericalVariance();
//     boolean var30 = var28.isSupportConnected();
//     double var33 = var28.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
//     double var35 = var28.density(0.0d);
//     boolean var36 = var28.isSupportUpperBoundInclusive();
//     double var38 = var28.density(5.964535219365547d);
//     double var39 = var13.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var28);
//     org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var43 = var42.getNumericalVariance();
//     double var44 = var42.getNumericalMean();
//     double var45 = var42.getSupportLowerBound();
//     double var46 = var13.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var42);
//     double var47 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var42);
//     boolean var48 = var42.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 53.08532354334412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-8.976773239231657E-11d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.762957961635066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "23e874e448b3450eb50670686a50fa388eda58c197feab4834430e8445e1bcaf2dd360412294d624e0216cbcdfa02ea0b2c2"+ "'", var15.equals("23e874e448b3450eb50670686a50fa388eda58c197feab4834430e8445e1bcaf2dd360412294d624e0216cbcdfa02ea0b2c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1.4206200379749838d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.06146076675140928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.031733077854635645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-3.078497949026296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == (-13.977093403213214d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == (-27.298226185417356d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.842700792949715d), (java.lang.Number)6.013076789830464d, false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var10 = var7.getElements();
    var7.setExpansionMode(1);
    double[] var13 = var7.getElements();
    var1.addElements(var13);
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    float var17 = var16.getExpansionFactor();
    double[] var18 = var16.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    double[] var20 = var1.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-1.1934926192752633d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.4977106070572046d));

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-3.5665581350160194d));
    java.lang.Number var3 = var2.getMin();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-3.5665581350160194d)+ "'", var4.equals((-3.5665581350160194d)));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    double[] var4 = new double[] { 0.0d, 10.0d};
    var1.addElements(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var23 = var22.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var22);
    double[] var25 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var26);
    var26.discardMostRecentElements(0);
    double[] var31 = var26.getElements();
    var22.addElements(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(200);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, 1031910952960952064L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1031910952960952064L));

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var52 = var1.nextUniform(10.732851303202107d, 7.337771477891332d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "2e6f320232567efcc6605a936ab60d9e88dc14adf8c44dd1068efa0aadea5af15d11b70b042e9e79f1e83af3e747ac10c724"+ "'", var3.equals("2e6f320232567efcc6605a936ab60d9e88dc14adf8c44dd1068efa0aadea5af15d11b70b042e9e79f1e83af3e747ac10c724"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.34581687690815954d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.026430075282810536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 135L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 125.84062763752155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-1.3398638517047974d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-8.826763825187935d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-4.698326423969155d));
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0);
    java.math.BigInteger var8 = null;
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var12);
    java.math.BigInteger var14 = null;
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, var16);
    org.apache.commons.math3.exception.NumberIsTooSmallException var21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)179.870724080515d, (java.lang.Number)var16, true);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var26 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)var23, (java.lang.Number)21, false);
    java.lang.Number var28 = null;
    org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)21, (java.lang.Number)12.972658968705218d, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     long var4 = var0.nextPoisson(1.2099696949580587d);
//     double var7 = var0.nextGaussian(0.017203106170644935d, 11.463386193784087d);
//     double var10 = var0.nextBeta(388245.49661804835d, 15.224172109153315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-7.426936962528748d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9999617128146819d);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(56.808443799256736d, (-10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 56.80844379925673d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.806438509142826d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(102.2007653745875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102L);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(85L, 543525818476686592L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 85L);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var16);
    java.lang.Class var18 = var15.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = var20.getTiesStrategy();
    java.lang.String var22 = var21.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.toString();
    java.lang.Class var27 = var25.getDeclaringClass();
    java.lang.String var28 = var25.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AVERAGE"+ "'", var22.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.999999999992233d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var9, (java.lang.Number)(byte)1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(15129380);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)3847543214195546753L);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(35, 99.99999f);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var14 = var9.getNumericalVariance();
//     boolean var15 = var9.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ca7c900d0e11dc2a541d760435855e2e23f1742fe72f7096b92188a45e4b32889a71b48d9c33f2d161dea304b4fb2f05da02"+ "'", var3.equals("ca7c900d0e11dc2a541d760435855e2e23f1742fe72f7096b92188a45e4b32889a71b48d9c33f2d161dea304b4fb2f05da02"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-124));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9.97680272139123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(2.842171E-14f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    java.lang.String var30 = var25.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "AVERAGE"+ "'", var30.equals("AVERAGE"));

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     double[] var3 = var1.getInternalValues();
//     var1.clear();
//     float var5 = var1.getContractionCriteria();
//     double[] var6 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     var1.addElements(var6);
//     double[] var9 = var1.getElements();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.String var18 = var17.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     java.lang.String var33 = var32.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var32);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var37);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var37);
//     double[] var40 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     var41.setNumElements(1);
//     int var45 = var41.getExpansionMode();
//     double var47 = var41.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double var49 = var41.addElementRolling(100.0d);
//     double[] var50 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     double[] var54 = var51.getElements();
//     var51.setElement(100, 1.0d);
//     double[] var58 = var51.getElements();
//     var41.addElements(var58);
//     double[] var60 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     double[] var64 = var61.getElements();
//     var61.setElement(100, 1.0d);
//     double[] var68 = var61.getElements();
//     double var69 = var39.mannWhitneyU(var58, var68);
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var73 = var72.getNumericalVariance();
//     boolean var74 = var72.isSupportConnected();
//     double[] var76 = var72.sample(100);
//     double var77 = var19.mannWhitneyU(var68, var76);
//     var1.addElements(var76);
//     int var79 = var1.getExpansionMode();
//     var1.addElement(110.404056353086d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 5100.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 5647.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 0);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.4948795302692948d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2512989059269757d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-703550053), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-703550053));

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)140.11605184655187d, (java.lang.Number)107.27633257910794d, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
//     java.lang.Throwable[] var11 = var10.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var20 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var19, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MaxCountExceededException var22 = new org.apache.commons.math3.exception.MaxCountExceededException(var17, (java.lang.Number)(byte)1, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var16, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.NullArgumentException var25 = new org.apache.commons.math3.exception.NullArgumentException(var14, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var13, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var27 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var20);
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var20);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (-1179412055));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1764195869), 5.9604645E-8f, 0.0f, 11);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextWeibull(0.3674212569981512d, 14.237606813581872d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "da7dd0550874d543fc0458beb1f2015db67c1b3880ac8774a3ed28d48124a95744cb0d19bd64056455890d0b36dc6eb07395");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9908283039031712d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-8.540097344843531d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.009338924432218215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0020218630710450666d);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(28);
    var1.addElement(4.353454100566544d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(0.9999998f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var3.setExpansionMode(0);
    var3.clear();
    var3.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.250752743375878d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.41963499970895235d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-13.144706748784028d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-3.5511676692186103d), 2.985436669727497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.985436669727497d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.150583269572738E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.392024866613949E-5d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(11.491898101271795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.491898101271795d);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     var1.reSeedSecure(18L);
//     var1.reSeed();
//     var1.reSeedSecure(2025644137419103233L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70.56605331975774d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1684656247210696d);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    double[] var9 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    float var11 = var10.getExpansionFactor();
    double[] var12 = var10.getInternalValues();
    var10.clear();
    float var14 = var10.getContractionCriteria();
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    var16.discardFrontElements(0);
    boolean var21 = var16.equals((java.lang.Object)(short)1);
    double[] var23 = new double[] { 10.0d};
    var16.addElements(var23);
    var10.addElements(var23);
    var1.addElements(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.3372564655227763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var1.copy();
    var10.addElement(2.3701879770272534E153d);
    var10.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextPascal(30, 21954.99676616325d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 256.9431096307019d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4513449763458242d);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var11 = var10.isSupportUpperBoundInclusive();
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.discardMostRecentElements((-580888836));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getStandardDeviation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.inverseCumulativeProbability(13.271500494885426d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextCauchy(3.46471888989783d, 109.86318106399013d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var19 = var1.nextPermutation((-2), (-97));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-69559088));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 49.50483941652609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 143.80677300825838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 14.326536846287334d);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(796684296743799808L, (-7385977944948490239L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var12 = var9.getElements();
    var9.setExpansionMode(1);
    double[] var15 = var9.getInternalValues();
    var7.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var7);
    double[] var22 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double var25 = var23.addElementRolling(130.18184173535712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.44502181494583404d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.34785345449505795d), 3.1289353125659936E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5707954272967684d));

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    double var11 = var2.probability(6.2180200613237d);
    double[] var13 = var2.sample(90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var54 = var53.getNumericalVariance();
//     boolean var55 = var53.isSupportConnected();
//     double var57 = var53.probability(2.3701879770272534E153d);
//     double var60 = var53.cumulativeProbability(0.0d, 1.1052977241209225d);
//     boolean var61 = var53.isSupportConnected();
//     double var62 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var53);
//     double var63 = var53.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7be912efb7b3f09f506c51038b8afa6d599b6fb81450b06697d6536c15f12840b0f284fc1c292b038dcf52cc41cf76f2536f"+ "'", var3.equals("7be912efb7b3f09f506c51038b8afa6d599b6fb81450b06697d6536c15f12840b0f284fc1c292b038dcf52cc41cf76f2536f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.7862959731896413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.16155578747076915d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 161L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 8.33503729725335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 9.72794108753474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 2.309913065774215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 4.260305395065103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.7371159192495896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.04367094510594999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 5.333758584777322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == (-0.8011436155469337d));
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 7548397703210479121L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7548397703210479121L);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(140L, 70L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-48L), (-591436115971011713L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48L));

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     double var15 = var1.nextExponential(0.05525590189455726d);
//     java.lang.String var17 = var1.nextSecureHexString(47);
//     long var19 = var1.nextPoisson(2.4923224105534505d);
//     double var22 = var1.nextGamma((-17.31533392446027d), (-0.3215992052665822d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var24 = var1.nextSecureHexString((-113));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8c7ff2937e51ba0942fd54444ab99ed4ff0bea66cb5ce822af7b2c477831c7f7262946cb29922ce8f9b7a6adb9631139e00d"+ "'", var3.equals("8c7ff2937e51ba0942fd54444ab99ed4ff0bea66cb5ce822af7b2c477831c7f7262946cb29922ce8f9b7a6adb9631139e00d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3838554978912798d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.12681322799231293d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "065ba6da9b841cc4a395a3f49e95b5b313554f0af55ec3b"+ "'", var17.equals("065ba6da9b841cc4a395a3f49e95b5b313554f0af55ec3b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.9575061341402422d), 21656131);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(59.42686498524283d, (-1133));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.0d), (java.lang.Number)(-1250178885), false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    java.lang.Number var6 = var3.getMin();
    java.lang.Number var7 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1250178885)+ "'", var6.equals((-1250178885)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1250178885)+ "'", var7.equals((-1250178885)));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var2 = var1.getMin();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     double[] var4 = var1.getElements();
//     var1.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
//     boolean var11 = var1.equals((java.lang.Object)var8);
//     boolean var13 = var1.equals((java.lang.Object)'#');
//     float var14 = var1.getContractionCriteria();
//     var1.contract();
//     var1.setNumElements(100);
//     double[] var18 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     var19.setNumElements(1);
//     int var23 = var19.getExpansionMode();
//     double var25 = var19.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double[] var26 = var19.getElements();
//     var1.addElements(var26);
//     int var28 = var1.start();
//     double[] var29 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
//     float var31 = var30.getExpansionFactor();
//     double[] var32 = var30.getInternalValues();
//     var30.clear();
//     float var34 = var30.getContractionCriteria();
//     double[] var35 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     var36.discardFrontElements(0);
//     boolean var41 = var36.equals((java.lang.Object)(short)1);
//     double[] var43 = new double[] { 10.0d};
//     var36.addElements(var43);
//     var30.addElements(var43);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var47 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var47);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var49 = var48.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var50 = var48.getNanStrategy();
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
//     double[] var55 = var53.sample(34);
//     double[] var56 = var48.rank(var55);
//     var30.addElements(var55);
//     org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray(var55);
//     double var60 = var58.substituteMostRecentElement(0.0d);
//     double[] var61 = var58.getElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == (-3.141870710865575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(530087946);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 530087946);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "4dffb21b399a4f69da76e67bcc670df92280d1c99f96470989c478f8bd40dd9568a763ad6699ffa6473c16e543980e0c46e9");
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(19L, 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    double[] var3 = var1.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-7.074217641774302d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7.0d));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(8L, 140L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.012970752564188195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0130552376584776d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var5 = var2.getStandardDeviation();
    double var6 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.802880146377583d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 121.86088977101296d);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "3c6e32e82c84dfd2e9ce3add6c5205b05556baa5e6e9b2bf792786e547a220bd23d502c2c062e05a74e141ea7a5771c9e08e"+ "'", var3.equals("3c6e32e82c84dfd2e9ce3add6c5205b05556baa5e6e9b2bf792786e547a220bd23d502c2c062e05a74e141ea7a5771c9e08e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2076972353327095d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.23016884517391906d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 151L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 60.99997436045634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-2.9460154657222675d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 4.146103703197573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.9079597267717117d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.790733841453493d);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-3.5665581350160194d));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    java.lang.Class var7 = var5.getDeclaringClass();
    int var8 = var5.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-1178076066));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(0.0010412664660371463d, (-15.0240472326323d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.001174942963033d));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.7992880682678054E307d, (-0.9593396120699825d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.7992880682678054E307d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)30.22353858942031d, (java.lang.Number)(-11), false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var5);
    java.lang.Number var7 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-11)+ "'", var7.equals((-11)));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10.022377052184d, (java.lang.Number)9.048221320149707d, (java.lang.Number)121.17268922946742d);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var18 = var17.sample();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution();
//     boolean var21 = var20.isSupportLowerBoundInclusive();
//     boolean var22 = var20.isSupportUpperBoundInclusive();
//     double var24 = var20.density((-29.67087421651356d));
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.nextSecureInt(10, (-709046803));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 27.344385444950692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2735310317407256d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 163.6919805276995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4.581967335477878d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-3.477339056223421d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2.710168840091066E-192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.28777397560378776d);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.19885430975358537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20153941093367375d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    int var10 = var9.start();
    float var11 = var9.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.5f);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed(16L);
//     int var18 = var1.nextBinomial(95, 0.0d);
//     java.lang.String var20 = var1.nextHexString(3);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var1.nextSample(var21, (-3860130));
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3067312546548822528L, 4665724868967888867L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.getMean();
//     double var3 = var0.getMean();
//     double var4 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.1088337242762238d);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("6feff234058236cad18d10ddc288f2f4810c8fe5c58b20b45572c6f8b63a7c09c12051baf248d084d716956209f6a33cc5fa");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(22, 630502273);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextF(1.4991609044182164E-7d, 38.52670062482719d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextLong(3157123192626590833L, 6L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "dbff306b61f3fee9a2d39022f44361712575392f8652e7e4ac66d276d967243e77e88be7b65dd12ca80f5bdea31749308829"+ "'", var3.equals("dbff306b61f3fee9a2d39022f44361712575392f8652e7e4ac66d276d967243e77e88be7b65dd12ca80f5bdea31749308829"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.163876451493979E-9d);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    float var23 = var22.getContractionCriteria();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var14, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.discardMostRecentElements((-7));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.5f);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)382.7463252293418d, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1031910952960952064L, 1243621435034931200L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1031910952960952064L);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(334.69977286719575d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2817310402063435E145d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.006302513166439201d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.006302554891578718d);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-1.3539651481886394d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(85L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1663107864971932160L, 11L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1663107864971932149L);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(4.5879375376937054E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.338382503416718d));

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 1.3234892E-22f, 7.5557864E22f, 1455);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(215.81393916580518d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.3790395625438805d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("efee9248ca8321c4f90035e2201b7197f1de0a2f41abf9b0497da178125e803860fc7a25c1e5a25ad8f48925d2a8ea4beb5c");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.1217129806834838d, (java.lang.Number)1.1217129806834838d, true);
    java.lang.Number var5 = var4.getArgument();
    java.lang.Number var6 = var4.getArgument();
    java.lang.Number var7 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.1217129806834838d+ "'", var5.equals(1.1217129806834838d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.1217129806834838d+ "'", var6.equals(1.1217129806834838d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.1217129806834838d+ "'", var7.equals(1.1217129806834838d));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(4381138221295217153L, 22468085766372128L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 22468085766372128L);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     java.lang.String var25 = var1.nextSecureHexString(51);
//     double var28 = var1.nextCauchy(0.0d, 0.9137600727402098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1ffbf025f9b9f80c18f781098056917db59b91c6045a5c4ba06445d95befe5541dfabe6a26d9e8b39c3a12548e9d72db4e76"+ "'", var3.equals("1ffbf025f9b9f80c18f781098056917db59b91c6045a5c4ba06445d95befe5541dfabe6a26d9e8b39c3a12548e9d72db4e76"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.553344513602646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.9527086607095838d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.2057743764129765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "ab4e48ee8d041af86c637177e47ca78699549135ec46239f57d"+ "'", var25.equals("ab4e48ee8d041af86c637177e47ca78699549135ec46239f57d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-7.158857505510626d));
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.7050545034698734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7050545034698734d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-0.9575217061535136d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9575217061535135d));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(114.57213802435264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9953961290881591d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(131.95151393788774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 132.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.740360297810529d, (-13.977093403213214d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 66.80449509377638d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(5.9604666E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.1054274E-15f);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     var1.reSeedSecure(1298433376908083968L);
//     java.lang.String var16 = var1.nextHexString(25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextZipf(0, 0.026738242272116394d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9e7c12d71041d4bf162316cbea16de5c195eb5fda1114849b7ab32153ce523521eb66a5220ed7ddf0835384f1c810f86a843"+ "'", var3.equals("9e7c12d71041d4bf162316cbea16de5c195eb5fda1114849b7ab32153ce523521eb66a5220ed7ddf0835384f1c810f86a843"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.047419325840587d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "c911bae18a7a38c08791c9d52"+ "'", var16.equals("c911bae18a7a38c08791c9d52"));
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(57L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1175753664465286927L));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(682784375L, (-7385977944948490239L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 682784375L);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.clear();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    java.lang.String var14 = var13.name();
    java.lang.String var15 = var13.name();
    java.lang.String var16 = var13.name();
    double[] var17 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    double[] var21 = var18.getElements();
    var18.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var25 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var26 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var25, (java.lang.Object[])var26);
    boolean var28 = var18.equals((java.lang.Object)var25);
    boolean var30 = var18.equals((java.lang.Object)'#');
    var18.contract();
    float var32 = var18.getContractionCriteria();
    boolean var33 = var13.equals((java.lang.Object)var18);
    var18.addElement((-4.620948969615004d));
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var9, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var9 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var10 = var9.toString();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var13 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var12, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var11, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var10.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }
// 
// 
//     org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
//     double[] var3 = null;
//     double[] var4 = var1.rank(var3);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextGaussian((-1024.0d), 4.787491742782046d);
//     double var16 = var0.nextUniform(0.05531224118406357d, 1.2613714995468743d);
//     double var19 = var0.nextGamma((-14.198220893804173d), 16.031440065675305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.425400065824855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.6357463082253636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.028833854661105544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1023.4552335976865d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.44301840158310546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.4285734652878787d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4155737075087207d));

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var5);
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-857875795), (-1126));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "c9f9922d869047a4960837c2183900a797bf8ccd42c913fed77e03fe0b4d5468c55c1e32d5ed944ca94fd9bf6b79cdddaaa8"+ "'", var3.equals("c9f9922d869047a4960837c2183900a797bf8ccd42c913fed77e03fe0b4d5468c55c1e32d5ed944ca94fd9bf6b79cdddaaa8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-609329132));
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(27, 10.0f);
    float var3 = var2.getContractionCriteria();
    double[] var4 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var6 = var5.getExpansionFactor();
    double[] var7 = var5.getInternalValues();
    var5.clear();
    var5.contract();
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    int var13 = var11.getExpansionMode();
    double[] var14 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    float var18 = var17.getContractionCriteria();
    int var19 = var17.start();
    org.apache.commons.math3.util.ResizableDoubleArray var20 = var17.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var21 = var20.copy();
    double[] var22 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var22);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    var23.setNumElements(1);
    int var27 = var23.getExpansionMode();
    double var29 = var23.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var31 = var23.addElementRolling(100.0d);
    var23.clear();
    int var33 = var23.getExpansionMode();
    double[] var34 = var23.getInternalValues();
    var21.addElements(var34);
    var11.addElements(var34);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var5, var11);
    double[] var38 = var5.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var2, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     double var16 = var1.nextUniform((-0.9648561103505955d), 382.7463252293418d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextF(0.0d, 10.707947646194901d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7c6b3073c10aef958b01e5f1743f07eb06e6e0d0775286380f15138de58c062061933ff0eae462bc01248f244a584b1924eb"+ "'", var3.equals("7c6b3073c10aef958b01e5f1743f07eb06e6e0d0775286380f15138de58c062061933ff0eae462bc01248f244a584b1924eb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4713226317383595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 194.21048339668414d);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(31L, 2025644137419103217L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5101459854364664289L));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(165.01591517285962d, 1.1749909266386545d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    int var15 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(32.94631867978169d, 83.48053700293903d, 0.0d);
    double var4 = var3.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 32.94631867978169d);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(6L, 1663107864971932160L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1663107864971932154L));

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextExponential((-0.44330043272729613d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "33ed165f8cebc40f360b0344c91898a23c8e29f543c19beb10faf31042d9684e265e76d72e8d8b9ba7b95c31f40599494684"+ "'", var3.equals("33ed165f8cebc40f360b0344c91898a23c8e29f543c19beb10faf31042d9684e265e76d72e8d8b9ba7b95c31f40599494684"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.06962701664552515d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("606c967d0ffccc57e40b0e6c7beb5ad0336f085e6216dce8f92dd9afa9a76b22f30989cc6289b8f4a721d428261541174420");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    var1.clear();
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addElement((-0.015775579295520044d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var10);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    java.lang.String var16 = var15.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.String var27 = var26.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var26);
    int var29 = var26.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var9, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 3);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.addElement(0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(6, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0953010394379372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGaussian(3.9626681941800967d, 19.79060019102854d);
//     double var9 = var1.nextCauchy(14.4057782350127d, 140.11605184655187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 18.13659338422111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-13.540458254297178d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-45.101062082856686d));
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(87.61569778054728d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
//     java.math.BigInteger var6 = null;
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
//     java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 1918124033);
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     java.math.BigInteger var16 = null;
//     java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0L);
//     java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 0);
//     java.math.BigInteger var21 = null;
//     java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0L);
//     java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var23, 0);
//     java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, var25);
//     org.apache.commons.math3.exception.OutOfRangeException var29 = new org.apache.commons.math3.exception.OutOfRangeException(var15, (java.lang.Number)var25, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
//     org.apache.commons.math3.exception.NotPositiveException var30 = new org.apache.commons.math3.exception.NotPositiveException(var14, (java.lang.Number)var25);
//     java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var25, 0);
//     java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var25);
//     org.apache.commons.math3.exception.NotPositiveException var34 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var25);
//     org.apache.commons.math3.exception.MathInternalError var35 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var34);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var21 = var1.nextUniform(0.02834020597826777d, 0.213582097693311d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 51.5166342912472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-25.61204355902295d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-4.256786706269375d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.3057771519063177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0421502731808336d);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    org.apache.commons.math3.exception.NumberIsTooSmallException var9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)10.0d, true);
    boolean var10 = var1.equals((java.lang.Object)1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    java.lang.Object[] var10 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var7, var8, var10);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, (java.lang.Number)87.39167675879528d, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, var10);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var10);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     boolean var6 = var2.isSupportConnected();
//     double var7 = var2.sample();
//     double var8 = var2.getSupportLowerBound();
//     double var10 = var2.probability(790.0d);
//     double var12 = var2.probability(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.899127044029305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3418283711056422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(54.73935145790571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 54.0d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    double[] var8 = new double[] { 10.0d};
    var1.addElements(var8);
    float var10 = var1.getContractionCriteria();
    boolean var12 = var1.equals((java.lang.Object)3.141592653589793d);
    double[] var13 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var14.discardFrontElements(0);
    boolean var19 = var14.equals((java.lang.Object)(short)1);
    float var20 = var14.getExpansionFactor();
    var14.contract();
    var14.clear();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var14);
    org.apache.commons.math3.util.ResizableDoubleArray var24 = var14.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-5101459854364664289L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5101459854364664289L));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.14389500536894387d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8419542802701501d));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextSecureInt((-122), (-3860130));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-4.0377430480682275d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4.0377430480682275d));

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);
    double var4 = var2.addElementRolling((-1.2690902893872158d));
    double[] var5 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
    float var7 = var6.getExpansionFactor();
    double[] var8 = var6.getInternalValues();
    var2.addElements(var8);
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.distribution.IntegerDistribution var22 = null;
//     int var23 = var1.nextInversionDeviate(var22);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9, 10.0f);
    boolean var4 = var2.equals((java.lang.Object)52.0d);
    float var5 = var2.getContractionCriteria();
    double[] var6 = var2.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }


    org.apache.commons.math3.util.ResizableDoubleArray var0 = null;
    double[] var1 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    double[] var5 = var2.getElements();
    var2.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var10);
    boolean var12 = var2.equals((java.lang.Object)var9);
    boolean var14 = var2.equals((java.lang.Object)'#');
    var2.contract();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var0, var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

}
