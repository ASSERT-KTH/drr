
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(140.92039618144022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5883655138730093E61d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)10.902797375512776d, var1, false);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getExpansionFactor();
    float var15 = var1.getExpansionFactor();
    int var16 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)1508, (java.lang.Number)(-1.2709816832696486d));

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.4970165853879775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    int var15 = var1.start();
    java.lang.Object var16 = null;
    boolean var17 = var1.equals(var16);
    boolean var19 = var1.equals((java.lang.Object)(-89));
    int var20 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 101);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     double var24 = var1.nextGamma((-2.3470831525555256d), (-10.04871230082253d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "51f894aaaabd881bce55496ce337e1638d4cf5498ac7ed7445eb7c680c5ff5b46b463c801ea22c07cdc88402b0dbcbcf6b9f"+ "'", var3.equals("51f894aaaabd881bce55496ce337e1638d4cf5498ac7ed7445eb7c680c5ff5b46b463c801ea22c07cdc88402b0dbcbcf6b9f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.281424192242595d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.9766352444256522d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 144L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-46.9775098485124d));
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(5.659697558657955E22d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 52.39024250179032d);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     double var17 = var12.getMean();
//     boolean var18 = var12.isSupportUpperBoundInclusive();
//     double var19 = var12.getSupportLowerBound();
//     double var20 = var12.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 62.36111584046444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.461625763127946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     double var19 = var12.getMean();
//     double var20 = var12.getMean();
//     double var21 = var12.getNumericalMean();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var12.cumulativeProbability(0.845684524945627d, (-1.575877718142896E-7d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 92.4622970535692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.520084784134521d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.8011436155469337d));
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-246944818), 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     var1.reSeed(0L);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextGaussian(0.0d, (-0.9575217061535135d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "746ff43b7fdf09c1e4e808a2d7232d23feb07fdcaf82870215a7140d127dbe9d4cef18c0aa01d0a12a30c1e627b0b4f44625"+ "'", var3.equals("746ff43b7fdf09c1e4e808a2d7232d23feb07fdcaf82870215a7140d127dbe9d4cef18c0aa01d0a12a30c1e627b0b4f44625"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.269327828237422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)10.0d, true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
//     java.lang.String var7 = var6.toString();
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    int var21 = var18.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    java.lang.Class var23 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    java.lang.String var32 = var31.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var36);
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var40);
    java.lang.String var42 = var40.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "RANDOM"+ "'", var42.equals("RANDOM"));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var6 = var3.getElements();
    var3.setExpansionMode(1);
    double[] var9 = var3.getInternalValues();
    var1.addElements(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-49));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-9.930773563341393d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-568.9914124795554d));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.cumulativeProbability(2.3004658055067035d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.6253593255612222d));
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var15 = var9.cumulativeProbability(0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double[] var17 = var9.sample((-527110117));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "0c7890a6f9b1d64b4974514f3d434dd668653cbcb84f3bdc9608ae00066c67d538d19acd068113ef047c06e4b82159141e1f"+ "'", var3.equals("0c7890a6f9b1d64b4974514f3d434dd668653cbcb84f3bdc9608ae00066c67d538d19acd068113ef047c06e4b82159141e1f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-116));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.12491528404587063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5319268497029056d);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var10 = var1.nextUniform((-2.552751428575824d), 2.9172543562621576E307d, true);
//     double var12 = var1.nextT(169.8956459570646d);
//     var1.reSeed(541811409497799232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "4e7d7255b7b9d7ccbfff01a67c3ecd7ecaf12474bd9324f87a1470cfb23126e352a8276e0c42a1e155eaa0f1e962ea25a72d"+ "'", var3.equals("4e7d7255b7b9d7ccbfff01a67c3ecd7ecaf12474bd9324f87a1470cfb23126e352a8276e0c42a1e155eaa0f1e962ea25a72d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.489594172945719d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1632358485258784E307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.39878594999532874d));
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     double[] var18 = var12.sample(25);
//     double var20 = var12.probability((-1.0765151551643635d));
//     double var22 = var12.probability((-7.738206325689978d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 230.28244358635018d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-16.392977585774826d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.0638463912421294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("1ffbf025f9b9f80c18f781098056917db59b91c6045a5c4ba06445d95befe5541dfabe6a26d9e8b39c3a12548e9d72db4e76");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var13.getTiesStrategy();
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.OutOfRangeException var19 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)62.556381183280465d, var17, (java.lang.Number)79.26372034878028d);
    java.lang.Number var20 = var19.getLo();
    boolean var21 = var15.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var8 = var7.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextF(0.6256445019194884d, 14.306620465386846d);
//     double var12 = var1.nextGamma(5.695804147945084d, 0.0d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23.04967801617147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.957534062762306d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.06313340651555453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0d);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalVariance();
//     double var6 = var2.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-9.56839957002254d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8011436155469337d));
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.550677376979932d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.665889546336865d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.633242452616744d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.918827953474944d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)4.055170656854222d, var5, (java.lang.Number)(-1.0319973615215225d));
    java.lang.Number var8 = var7.getHi();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0319973615215225d)+ "'", var8.equals((-1.0319973615215225d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-0.023409446834488937d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.023137571350927585d));

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     double[] var3 = var1.getInternalValues();
//     var1.clear();
//     float var5 = var1.getContractionCriteria();
//     double[] var6 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     var1.addElements(var6);
//     double[] var9 = var1.getElements();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.String var18 = var17.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     java.lang.String var33 = var32.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var32);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var37);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var37);
//     double[] var40 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     var41.setNumElements(1);
//     int var45 = var41.getExpansionMode();
//     double var47 = var41.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double var49 = var41.addElementRolling(100.0d);
//     double[] var50 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     double[] var54 = var51.getElements();
//     var51.setElement(100, 1.0d);
//     double[] var58 = var51.getElements();
//     var41.addElements(var58);
//     double[] var60 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     double[] var64 = var61.getElements();
//     var61.setElement(100, 1.0d);
//     double[] var68 = var61.getElements();
//     double var69 = var39.mannWhitneyU(var58, var68);
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var73 = var72.getNumericalVariance();
//     boolean var74 = var72.isSupportConnected();
//     double[] var76 = var72.sample(100);
//     double var77 = var19.mannWhitneyU(var68, var76);
//     var1.addElements(var76);
//     org.apache.commons.math3.util.ResizableDoubleArray var79 = var1.copy();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var79.setNumElements((-857875894));
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 5100.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 5761.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextCauchy(3.46471888989783d, 109.86318106399013d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextCauchy(106.90663190843676d, (-7.503865514176714d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-575374234));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 15.113451624321396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.19229945914269564d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 451.68679976402626d);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(9, 10.0f);
    boolean var4 = var2.equals((java.lang.Object)52.0d);
    float var5 = var2.getContractionCriteria();
    var2.addElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.5f);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(6.5628273583421E13d, (-0.3537723744093205d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1023863903247170432L, (java.lang.Number)1140884457841735808L, true);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 1.5557982028522581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextCauchy(82.16419961411961d, 0.056750019064709015d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(7218835434699862529L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("09f9d20dc76c10574108ad71fa50ada680fa5d9c51556ec060ce9b43d2f1e6ec287ce35a976e92b25fdfdf3d374a5db7f817", "f9e8925b333c7c384fe088b39d574da5fda5573577fc25e1f485494ebf1f8402b8a09da1f3b6206e811289222c85e9af5430");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 19.11162380127469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575194103390533d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 82.04938425421619d);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     var1.reSeedSecure(3L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var1.nextSecureLong(340591140L, 5L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-503799430));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 7.386623859109589d);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var1.addElements(var6);
    double[] var9 = var1.getElements();
    int var10 = var1.start();
    var1.contract();
    double[] var12 = var1.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(23.21029720989869d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.8177066338558525d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(6690628879615364881L, 474370825216844736L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var8 = var1.nextExponential(5.169339496286199d);
//     double var11 = var1.nextWeibull(0.7199192644760765d, 3.9626681941800967d);
//     long var14 = var1.nextLong(0L, 383L);
//     int var17 = var1.nextSecureInt((-76), 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "afea50eafd0bb6d4957ee175ff71b4e7c370ff3c7fe8731af31301afe4a5b32e2996290ca4e2de65f22bc369b817547ae98d"+ "'", var3.equals("afea50eafd0bb6d4957ee175ff71b4e7c370ff3c7fe8731af31301afe4a5b32e2996290ca4e2de65f22bc369b817547ae98d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-79));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5095514831237269d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.605387667345648d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 365L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-9));
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1918124033, (-107));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    java.lang.String var23 = var22.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    boolean var34 = var32.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var32);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var38 = var36.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)216.67158624841275d, (java.lang.Number)5.870420305892309d, true);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 216.67158624841275d+ "'", var5.equals(216.67158624841275d));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    var9.clear();
    var9.clear();
    boolean var13 = var9.equals((java.lang.Object)(-589261714));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     var1.reSeed();
//     double var20 = var1.nextExponential(66.80449509377638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "c7fef4b32a865b6c8257da3e8be551dabd8b93849e76afc0c4477cc4d9761350266d2badd17b485d415151abb7e711ce8403"+ "'", var3.equals("c7fef4b32a865b6c8257da3e8be551dabd8b93849e76afc0c4477cc4d9761350266d2badd17b485d415151abb7e711ce8403"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.825370485987536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.2270705601102425d);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(121.00194166675857d, (-18.088595094266818d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-18.088595094266818d));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(40L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40L);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     double var22 = var12.inverseCumulativeProbability(0.0d);
//     double var23 = var12.getSupportLowerBound();
//     double var24 = var12.sample();
//     boolean var25 = var12.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 204.46160841172497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.3950243686951946d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-3.6029838697259358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 13.15528332341117d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(2325);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    var1.discardFrontElements(0);
    double var21 = var1.addElementRolling(30.66543173953429d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(1918124033);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    double[] var29 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    var30.setNumElements(1);
    int var34 = var30.getExpansionMode();
    double var36 = var30.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var38 = var30.addElementRolling(100.0d);
    double[] var39 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    double[] var43 = var40.getElements();
    var40.setElement(100, 1.0d);
    double[] var47 = var40.getElements();
    var30.addElements(var47);
    boolean var49 = var1.equals((java.lang.Object)var47);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var51 = var50.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var52);
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51);
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var56 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.TiesStrategy var57 = var56.getTiesStrategy();
    java.lang.String var58 = var57.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var59 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var51, var57);
    org.apache.commons.math3.stat.ranking.NaNStrategy var60 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var61 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var60);
    org.apache.commons.math3.stat.ranking.TiesStrategy var62 = var61.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var63 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var62);
    org.apache.commons.math3.random.RandomGenerator var64 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var51, var64);
    org.apache.commons.math3.stat.ranking.TiesStrategy var66 = var65.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var66);
    int var68 = var1.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "AVERAGE"+ "'", var58.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     double var53 = var1.nextGamma((-6.719887501633209d), 2.515911276041704d);
//     double var57 = var1.nextUniform(2.9031491046806814d, 32.48590214300356d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9e7a3090f17fe74c40e189cf75316862c4e6fc618062b94f786a90914cc543304e508886af2cab3c8fab39b3a41d91323c35"+ "'", var3.equals("9e7a3090f17fe74c40e189cf75316862c4e6fc618062b94f786a90914cc543304e508886af2cab3c8fab39b3a41d91323c35"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6281953355211772d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.512522788300101d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 159L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 102.81646635520501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-10.830455915229123d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-15.340095030388026d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 2.594936470547274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-0.6276447608509261d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 2.9547483513581065d);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, var2, (java.lang.Number)1.2263654402124098d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    java.lang.Throwable[] var8 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.2263654402124098d+ "'", var6.equals(1.2263654402124098d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.3286542677377272d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3286542677377272d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalVariance();
//     var2.reseedRandomGenerator(35L);
//     double var8 = var2.getNumericalMean();
//     double var9 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-3.484469595698618d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.5649499239506754d));
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var12 = var1.nextGamma((-3.8208663712048767d), 18.73160423917461d);
//     double var14 = var1.nextChiSquare(39.299201911311215d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var1.nextPermutation((-1052494225), (-1143914887));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 304.94071176304726d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 32.806277395047175d);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     double var13 = var7.getStandardDeviation();
//     double var15 = var7.probability((-0.03880315365831265d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1279f46c565afd9c84af006295c4a1188fa5116ac1ed61136968ae337bbabb7591bed2c82885d6e443a42e68ddc3943ffac5"+ "'", var3.equals("1279f46c565afd9c84af006295c4a1188fa5116ac1ed61136968ae337bbabb7591bed2c82885d6e443a42e68ddc3943ffac5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9900706047944353d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.2816847450408295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(7.96132962368031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 456.1505867493577d);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-3.472460264586034d), 0.0d, (-0.7079687983757527d), 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var1);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, var6, var8);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    var2.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(52L, 82L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52L);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.discardFrontElements(0);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var1.copy();
    int var12 = var11.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var11.getElement(128);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     var1.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextF((-1.5661025118863345d), (-1.0066251183076937d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8fff121dee7efe84f8ca8fb871cf09d466f982778942bc40d3e8d6fcceecbf4a3bc79953ce677fc02b7eeff130619c84e79e"+ "'", var3.equals("8fff121dee7efe84f8ca8fb871cf09d466f982778942bc40d3e8d6fcceecbf4a3bc79953ce677fc02b7eeff130619c84e79e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.370192997978252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextExponential(2.4445458134648095E-6d);
//     double var12 = var1.nextUniform(0.5423156085106325d, 0.9655298522687169d, true);
//     double var14 = var1.nextT(11.477431538948135d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 42.335285840956914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.0463483498852185E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9120012023325161d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.7435499888378625d);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(10.5f, (-1.4E-45f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.5f);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-739555469), 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-128949215));

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(1079717575831374079L);
//     int var15 = var1.nextSecureInt((-78), 0);
//     long var18 = var1.nextSecureLong((-1379843843793974016L), 283815432669308992L);
//     org.apache.commons.math3.distribution.IntegerDistribution var19 = null;
//     int var20 = var1.nextInversionDeviate(var19);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var3 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.97499366781241E-6d, 0.1013846635888297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1013846635888297d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 7.425400065824855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)904.1046655149532d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(7.555786E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.555786E22f);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var12 = var9.getElements();
    var9.setExpansionMode(1);
    double[] var15 = var9.getInternalValues();
    var7.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double var24 = var22.addElementRolling(100.10338921080671d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(52L, (-4800796995668396719L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4800796995668396771L);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.552170221353791d, 0.9092972421467385d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.17030741816756875d));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.48811943471602726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.46896577241631476d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(70.98959414942463d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.255473482944022d);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     double var13 = var1.nextUniform((-0.015775579295520044d), 342.4199650603462d);
//     double var16 = var1.nextGamma(1.4797106743533206d, 0.7599804096152283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-1093969835));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 224.60847815967514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.30690467504803953d);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var8 = var1.nextExponential(5.169339496286199d);
//     long var10 = var1.nextPoisson(0.10856505939282417d);
//     double var13 = var1.nextCauchy((-18.164425867798762d), 3.683637791486292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b7e8d6f09543d0ac4c2e77eb987b3ef3762aeb38e300188dcb3876b67ec8a4894e30b0757cb490fd990cea7bafab2a46cfb6"+ "'", var3.equals("b7e8d6f09543d0ac4c2e77eb987b3ef3762aeb38e300188dcb3876b67ec8a4894e30b0757cb490fd990cea7bafab2a46cfb6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-25));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.917460394623501d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-17.192204832733577d));
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(4.515297276784079E8d, (-703550053));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.384186E-7f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.384186E-7f));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(236.63007931400642d, 2.346060044906691d);
    double var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 236.63007931400642d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5380973041871195d, (java.lang.Number)(-1.1679132800978618d), false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.math.BigInteger var3 = null;
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0L);
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0);
    java.math.BigInteger var8 = null;
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0L);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 0);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, var12);
    org.apache.commons.math3.exception.OutOfRangeException var16 = new org.apache.commons.math3.exception.OutOfRangeException(var2, (java.lang.Number)var12, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var17 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)var12);
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 1);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 1571400668722899200L);
    org.apache.commons.math3.exception.OutOfRangeException var23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.667629392416482d, (java.lang.Number)1571400668722899200L, (java.lang.Number)(-22.935230618446695d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var8 = var2.getStandardDeviation();
    double var9 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 10.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.setNumElements(2325);
    double var5 = var1.getElement(9);
    double var7 = var1.substituteMostRecentElement(7.421527624138719d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var9 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    var10.setNumElements(1);
    int var14 = var10.getExpansionMode();
    double var16 = var10.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var18 = var10.addElementRolling(100.0d);
    var10.clear();
    int var20 = var10.getExpansionMode();
    double[] var22 = new double[] { 1.0d};
    var10.addElements(var22);
    double[] var24 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var28 = var25.getElements();
    var25.setElement(100, 1.0d);
    double[] var32 = var25.getElements();
    double var33 = var8.mannWhitneyUTest(var22, var32);
    var1.addElements(var22);
    double[] var35 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var36 = new org.apache.commons.math3.util.ResizableDoubleArray(var35);
    org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
    double[] var39 = var36.getElements();
    var36.setElement(100, 1.0d);
    double[] var43 = var36.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var44);
    double var47 = var1.addElementRolling(82.10205579628098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.08947556010017466d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-11.836664972770874d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    java.lang.String var35 = var34.name();
    java.lang.String var36 = var34.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var31, var34);
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var38);
    boolean var40 = var25.equals((java.lang.Object)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.01678363785097637d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
    org.apache.commons.math3.stat.ranking.TiesStrategy var23 = var22.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 140L);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-0.8427007929497151d), false);
    java.lang.String var4 = var3.toString();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    boolean var7 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-0.843)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-0.843)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(7L, 139L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 146L);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("aa6912e8f0ddb74300e50f1f9b458af005b8755af4856356e6827adde71235040f86072850100ef28b54825cf3c0e80a6919");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    java.lang.Number var15 = var14.getLo();
    java.lang.Number var16 = var14.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)1+ "'", var15.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-0.7656658570186433d)+ "'", var16.equals((-0.7656658570186433d)));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var4.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(1.7590683406011705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7590391401857737d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.12048148365492187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28.315289611667257d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(233L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 233L);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-3.0932983275792023d), 0.024802061667175728d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var3.getTiesStrategy();
    java.lang.Class var6 = var5.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var8 = java.lang.Enum.<java.lang.Enum>valueOf(var6, "b7e8d6f09543d0ac4c2e77eb987b3ef3762aeb38e300188dcb3876b67ec8a4894e30b0757cb490fd990cea7bafab2a46cfb6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-1031910952960952064L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1031910952960952064L));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(5, 651230987);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(83, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.43233232957E12d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.235344810822468d), (-11.519289980462164d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.235344810822468d));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-2.384186E-7f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     var1.reSeed();
//     double var14 = var1.nextWeibull(0.24433316542704286d, 10.953429709299042d);
//     org.apache.commons.math3.distribution.NormalDistribution var17 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var18 = var17.sample();
//     double var19 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var17);
//     java.lang.String var21 = var1.nextHexString(62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.nextInt(0, (-106));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 150.28265144032423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9230521596664081d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.05681899727992208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-3.5723353951760304d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-9.93559565132584d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "026f89ab3a2862d9098c6575c5ea8d6c07c151ae9e02cf32fc5c87cb157b06"+ "'", var21.equals("026f89ab3a2862d9098c6575c5ea8d6c07c151ae9e02cf32fc5c87cb157b06"));
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-50), (-117325921));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-50));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(32.341075375538274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var8 = var2.getStandardDeviation();
    boolean var9 = var2.isSupportConnected();
    double var10 = var2.getNumericalMean();
    boolean var11 = var2.isSupportUpperBoundInclusive();
    double var12 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 100.0d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var5.setContractionCriteria(2.0f);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    int var12 = var11.getExpansionMode();
    double[] var13 = var11.getInternalValues();
    var5.addElements(var13);
    int var15 = var5.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-5.966735624802988d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.950346244506377d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var12.cumulativeProbability(0.023604957517463766d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 90.72102633008572d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-10.06459474358391d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(73.48387693522042d, (-0.5298418234538922d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var15);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)179.870724080515d, (java.lang.Number)var15, true);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    org.apache.commons.math3.exception.NumberIsTooLargeException var25 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var22, (java.lang.Number)21, false);
    java.lang.Number var26 = var25.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + 21+ "'", var26.equals(21));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)7);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var6 = var5.getMin();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var7, (java.lang.Object[])var9);
    var5.addSuppressed((java.lang.Throwable)var11);
    java.lang.Throwable[] var13 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0L, (java.lang.Number)(byte)100, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var30.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(23, (-24));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 23);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)2.9172543562621576E307d);
    java.lang.Number var2 = var1.getMax();
    java.lang.Number var3 = var1.getMax();
    java.lang.Number var4 = var1.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 2.9172543562621576E307d+ "'", var2.equals(2.9172543562621576E307d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 2.9172543562621576E307d+ "'", var3.equals(2.9172543562621576E307d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.9172543562621576E307d+ "'", var4.equals(2.9172543562621576E307d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(110.92196131466562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 110.92196131466562d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
    java.lang.Class var24 = var21.getDeclaringClass();
    java.lang.String var25 = var21.name();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var26);
    org.apache.commons.math3.random.RandomGenerator var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var28);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var31 = var30.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var31, var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var36 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var35);
    org.apache.commons.math3.stat.ranking.NaNStrategy var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    java.lang.String var41 = var40.name();
    java.lang.String var42 = var40.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var43 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var40);
    java.lang.Class var44 = var4.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "MAXIMAL"+ "'", var25.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AVERAGE"+ "'", var41.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "AVERAGE"+ "'", var42.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var10 = var1.nextUniform(0.7853981633974483d, 1.5380973041871195d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextExponential((-8.329457145152158d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 71.48111606182616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1108751150626754d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(74.99980161923008d, 311.52221264508484d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 320.4232501149274d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var14);
    java.lang.Class var16 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1143914887), (-1250178908));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-1.2402358893466607d), 0.6285281184398758d);
    boolean var3 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, (java.lang.Number)(byte)1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var19 = var1.nextUniform(0.0d, 86.74240888600346d, false);
//     var1.reSeed();
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 254.5378016514755d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-13.332849324650816d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 17.9780798744992d);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(15.853366771480385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    java.lang.String var23 = var22.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var16, var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16, var27);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var27);
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    boolean var34 = var32.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var35 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var32);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var38.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var40 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var40);
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
    java.lang.String var46 = var45.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var45);
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var50 = var49.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var50);
    org.apache.commons.math3.stat.ranking.NaNStrategy var52 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var53 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var52);
    org.apache.commons.math3.stat.ranking.TiesStrategy var54 = var53.getTiesStrategy();
    java.lang.String var55 = var54.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var56 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var54);
    double[] var58 = new double[] { (-1.0d)};
    double[] var59 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var60 = new org.apache.commons.math3.util.ResizableDoubleArray(var59);
    org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
    var60.setNumElements(1);
    int var64 = var60.getExpansionMode();
    double var66 = var60.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var68 = var60.addElementRolling(100.0d);
    double[] var69 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray(var69);
    org.apache.commons.math3.util.ResizableDoubleArray var71 = new org.apache.commons.math3.util.ResizableDoubleArray(var70);
    org.apache.commons.math3.util.ResizableDoubleArray var72 = new org.apache.commons.math3.util.ResizableDoubleArray(var70);
    double[] var73 = var70.getElements();
    var70.setElement(100, 1.0d);
    double[] var77 = var70.getElements();
    var60.addElements(var77);
    double var79 = var56.mannWhitneyUTest(var58, var77);
    org.apache.commons.math3.util.ResizableDoubleArray var80 = new org.apache.commons.math3.util.ResizableDoubleArray(var77);
    double[] var81 = var36.rank(var77);
    org.apache.commons.math3.stat.ranking.NaNStrategy var82 = var36.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var83 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var84 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var83);
    org.apache.commons.math3.stat.ranking.TiesStrategy var85 = var84.getTiesStrategy();
    java.lang.String var86 = var85.name();
    java.lang.String var87 = var85.name();
    java.lang.String var88 = var85.name();
    int var89 = var85.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var90 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var82, var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "AVERAGE"+ "'", var46.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "AVERAGE"+ "'", var55.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.08631729905748209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "AVERAGE"+ "'", var86.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + "AVERAGE"+ "'", var87.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "AVERAGE"+ "'", var88.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 3);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException(var9, (java.lang.Number)(byte)1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var7, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var4, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var22 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(20925, (-107));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20818);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.clear();
    boolean var7 = var1.equals((java.lang.Object)62.954703415645156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-31.941565664045594d), (-1143914887));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(692748758, (-1371062271));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)66.57408258376356d, false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var7 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)8.077752138320707E-70d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var12 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var12);
//     java.lang.Throwable[] var16 = var15.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var8, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var16);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getExpansionMode();
    double[] var4 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor((-2.384186E-7f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextWeibull(0.3674212569981512d, 14.237606813581872d);
//     double var16 = var0.nextWeibull(9.585079465807741d, 349.18148094808896d);
//     double var18 = var0.nextT(1.4627348451982898d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextSecureInt(215720602, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-8.051538067379104d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 17.330189199501188d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.013622312583992116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 46.96611584014897d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 376.3119555995412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.085933886796582d);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)37.37309493413008d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     double var3 = var0.getNumericalMean();
//     double var5 = var0.cumulativeProbability(0.8487758449442926d);
//     var0.reseedRandomGenerator((-90L));
//     boolean var8 = var0.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2890718452302538d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8019969832524574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(8.556666160011074d, 4.171214858108831d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.6573644948547667E-9d));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(208.78828661730054d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.449508179080025d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.16155578747076915d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.16297616827007755d));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var15 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)var10);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var15.getContext();
    boolean var17 = var15.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var21 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var20, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MaxCountExceededException var23 = new org.apache.commons.math3.exception.MaxCountExceededException(var18, (java.lang.Number)(byte)1, (java.lang.Object[])var21);
    java.lang.Number var24 = var23.getMax();
    org.apache.commons.math3.exception.util.ExceptionContext var25 = var23.getContext();
    var15.addSuppressed((java.lang.Throwable)var23);
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    org.apache.commons.math3.exception.util.Localizable var28 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var32 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var28, (java.lang.Number)1.1217129806834838d, (java.lang.Number)22.516457954788187d, true);
    java.lang.Throwable[] var33 = var32.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var34 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var27, (java.lang.Object[])var33);
    boolean var35 = var15.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (byte)1+ "'", var24.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(10.707947646194901d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2723000544257705d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-2), 16.0f, 2.25180003E16f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getLo();
    java.lang.String var5 = var3.toString();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.8813735870195429d+ "'", var4.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 100 out of [0.881, -709,046,808] range"+ "'", var5.equals("org.apache.commons.math3.exception.OutOfRangeException: 100 out of [0.881, -709,046,808] range"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.8813735870195429d+ "'", var6.equals(0.8813735870195429d));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextSecureInt(27964641, 297623103);
//     org.apache.commons.math3.distribution.NormalDistribution var4 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var5 = var4.getNumericalMean();
//     double var6 = var4.sample();
//     double var7 = var4.getNumericalMean();
//     double var9 = var4.cumulativeProbability(0.8487758449442926d);
//     boolean var10 = var4.isSupportUpperBoundInclusive();
//     var4.reseedRandomGenerator(625L);
//     boolean var13 = var4.isSupportUpperBoundInclusive();
//     double var14 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 186509216);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.2777444570680316d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.8019969832524574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-2.026696066487972d));
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     var1.reSeed(8L);
//     double var27 = var1.nextChiSquare(0.7628169534658366d);
//     long var29 = var1.nextPoisson(40.69420911675787d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "967f94f46c360e546ec9de238fc7f36d3a00754e242266abb7a597746e107b33298282c15a67fdc109428cd834a486e27217"+ "'", var3.equals("967f94f46c360e546ec9de238fc7f36d3a00754e242266abb7a597746e107b33298282c15a67fdc109428cd834a486e27217"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.23605360696596497d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2.742090524662933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.5282875453379976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.034945824610484996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 47L);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(104, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 104);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var3);
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var3);
//     java.lang.String var7 = var6.toString();
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var19 = var1.nextUniform(0.0d, 86.74240888600346d, false);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextUniform(0.6063003343010451d, (-2.1191725702837423d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 61.880422069564034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.9238970028700808d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 40.40410281797081d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(5.755168834146613d, (-1.2099696949580587d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.880985884377669d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var3.getContractionCriteria();
    int var5 = var3.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var3.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var6.copy();
    int var8 = var7.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt(9, 41);
//     double var9 = var1.nextGaussian(15.012691254866375d, 0.7812766771598918d);
//     int var12 = var1.nextInt((-1052494225), 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 213.73248505196457d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 14.806698278089403d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1040026098));
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(119);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(4.2557905504595155d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3400090345117326d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.3607289386991592d, 2.367550283603454d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.367550283603454d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var9 = var8.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.Class var13 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var9, var12);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     var1.reSeedSecure(16L);
//     int var20 = var1.nextZipf(17, 1.1429436239750525E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "bc6970779744735f57ae9de713e4c60c643db4f787d752c3be64b8e40149cbefbb5f700dae92e97ef3bae1f75eacae6682d4"+ "'", var3.equals("bc6970779744735f57ae9de713e4c60c643db4f787d752c3be64b8e40149cbefbb5f700dae92e97ef3bae1f75eacae6682d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.11504392564354371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 15);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.String var20 = var1.name();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var21);
    boolean var24 = var1.equals((java.lang.Object)(-1.4977106070572046d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "MAXIMAL"+ "'", var20.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(9.82265018026397d, (-0.7706191458620877d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.724207578810511d));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.random.RandomGenerator var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    java.lang.Class var25 = var24.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     long var8 = var1.nextPoisson(20.113485464130214d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var1.nextZipf(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 32.478313340320184d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-20.824732949676754d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 22L);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = var1.copy();
    double[] var3 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    float var7 = var4.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var4);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0000001f, 7.555786E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.555786E22f);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(2.594936470547274d, 0.0653481946547574d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.random.RandomGenerator var8 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var13);
    java.lang.Class var15 = var12.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var18);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    java.lang.String var23 = var22.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var24 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "AVERAGE"+ "'", var23.equals("AVERAGE"));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2072.0837507721994d, 37.37309493413008d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2072.420762885554d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    java.lang.String var9 = var8.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var14);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var15.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var17);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.String var27 = var26.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var26);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var29 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(5L, 355687428096000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1778437140480000L);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull(0.05320428192666695d, (-13.17690971916771d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7e6d123cc9258bc866847dfc652088943d527ae15fad870aaed3afd0ee695fb069821196b1a42b16dc102bbda7deeac27fb2"+ "'", var3.equals("7e6d123cc9258bc866847dfc652088943d527ae15fad870aaed3afd0ee695fb069821196b1a42b16dc102bbda7deeac27fb2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.913135019416188d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     org.apache.commons.math3.distribution.NormalDistribution var53 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var54 = var53.getNumericalVariance();
//     boolean var55 = var53.isSupportConnected();
//     double var57 = var53.probability(2.3701879770272534E153d);
//     double var60 = var53.cumulativeProbability(0.0d, 1.1052977241209225d);
//     boolean var61 = var53.isSupportConnected();
//     double var62 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var53);
//     double var63 = var53.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ddfb101a85ecb6e8a39ead7a30ba2e9723fe88b77260102be70b133507f6637d06c12ac98513081b00798194b54a559b2d91"+ "'", var3.equals("ddfb101a85ecb6e8a39ead7a30ba2e9723fe88b77260102be70b133507f6637d06c12ac98513081b00798194b54a559b2d91"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.0984556327393742d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1.625324556040733d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 158L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 82.51402230099063d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 4.817607322406202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-2.022332743425019d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-0.47624382660796927d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-1.1300602398039246d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0.04367094510594999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 6.2613663988168335d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == (-0.5881633716460656d));
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    boolean var24 = var22.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var22);
    java.lang.Class var26 = var22.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var28 = java.lang.Enum.<java.lang.Enum>valueOf(var26, "9df8b0f9b771a17b0468159f8b31861f4e1ed9b69b14d79fa25c9aba5124dc34f47eced22b65ddc4efb2ead65dfe6a99e744");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, var6, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)87.39167675879528d, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var2, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-8.177433058271745d), var8);
    java.lang.Number var13 = var12.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (-8.177433058271745d)+ "'", var13.equals((-8.177433058271745d)));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.9999999f, 164954282);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    int var9 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double[] var10 = var8.getInternalValues();
    var8.setContractionCriteria(9.0071993E15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextWeibull(0.3674212569981512d, 14.237606813581872d);
//     double var16 = var0.nextWeibull(9.585079465807741d, 349.18148094808896d);
//     double var18 = var0.nextT(1.4627348451982898d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextBeta(52.7844917282716d, (-1.6854015858994302d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-6.765935748429332d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-8.488855744291548d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.06540936454403883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.020875544028024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 324.02223731133205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.1323172611600325d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, var5, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)115.53308557545296d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9993158623734482d, 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.015943594350899648d);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    int var21 = var18.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    java.lang.Class var23 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    java.lang.String var32 = var31.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var25, var31);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34);
    org.apache.commons.math3.stat.ranking.TiesStrategy var36 = var35.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var37 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var36);
    org.apache.commons.math3.random.RandomGenerator var38 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25, var38);
    org.apache.commons.math3.stat.ranking.TiesStrategy var40 = var39.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var40);
    java.lang.Class var42 = var40.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var44 = java.lang.Enum.<java.lang.Enum>valueOf(var42, "03faf42fbebea5b3a7ef494a969687bc99a6b50b3d0eef649981099e8f8f48ec30c33b24db6f6e46c5463b0426d144e5bfb7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-2375779087806406849L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2375779087806406849L);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextGamma(60.22939531600713d, 102.07214597085877d);
//     double var32 = var1.nextBeta(0.8221511915215819d, 0.2621024666303587d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d278d4778c64b1fbd3999f94dc380619b5240f1b72e30ad2911d95a639d865798eba727e91b30370025341800502d0ce6873"+ "'", var3.equals("d278d4778c64b1fbd3999f94dc380619b5240f1b72e30ad2911d95a639d865798eba727e91b30370025341800502d0ce6873"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.48942691486816103d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3.8231591010349812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-14.946691496201478d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 4988.314178256191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.00367964988261353d);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     boolean var19 = var12.isSupportUpperBoundInclusive();
//     double var20 = var12.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11.748174564984627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.7509759405288358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 100.0d);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.42170562608721146d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.44861988174384126d));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(3.761582E-37f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.761582E-37f);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getArgument();
    java.lang.Number var7 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-709046808)+ "'", var4.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.8813735870195429d+ "'", var5.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-709046808)+ "'", var7.equals((-709046808)));

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     int var12 = var1.nextSecureInt((-2), 99);
//     var1.reSeed((-857768823595114231L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 62.94703973687796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     double var31 = var1.nextExponential(66.57408258376356d);
//     var1.reSeed(22L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e5ed341af682382ba37c3351783d08622aef00b6e4f152a01f35968e0f8729ce4953acd54cbda3baad78d8ff42dd8f664ce9"+ "'", var3.equals("e5ed341af682382ba37c3351783d08622aef00b6e4f152a01f35968e0f8729ce4953acd54cbda3baad78d8ff42dd8f664ce9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.227499927878396d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-17.07717610728478d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.2692109749019627d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 100.15667689340151d);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, (-1075233378));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var28 = var1.nextT(0.6037929298964898d);
//     var1.reSeedSecure(383L);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a26e76789c55113ed23bdd90d88691f0b12913597b6967d5d10f419e4a11e0bc7449a45cfe1c2c8e5c88d93ecdf2115b4d74"+ "'", var3.equals("a26e76789c55113ed23bdd90d88691f0b12913597b6967d5d10f419e4a11e0bc7449a45cfe1c2c8e5c88d93ecdf2115b4d74"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.0244641250081257d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-7.182439338268642d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-16.02707730688398d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 3.3366636361113495d);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(3847543214195546753L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3847543214195546753L);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.45737447892943917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5799204203912447d);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     var0.reSeedSecure();
//     double var13 = var0.nextExponential(181.81077072903946d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("aa6912e8f0ddb74300e50f1f9b458af005b8755af4856356e6827adde71235040f86072850100ef28b54825cf3c0e80a6919", "5bfbb2412984cefe1250bea644518b446117de063ccd3c9b7b944df5dd4481da1e72eb0d35e4a836a00a2e3e86a5cb521a65");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.501054751033567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 15.74843332944447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.015292177730238927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 161.36550035835765d);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(6338);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var9.getSupportLowerBound();
//     double var19 = var9.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11.788655275967708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-18.9926807455208d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 6.793835008407551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-26.346613835997235d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)0.9496591903088292d, true);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     double var21 = var12.getNumericalVariance();
//     double var23 = var12.cumulativeProbability(0.926915123177908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56.788555583069964d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.49226458660112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-3.1146991313190253d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.5685979900872472d);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt(9, 41);
//     double var9 = var1.nextGaussian(15.012691254866375d, 0.7812766771598918d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 53.95652006931071d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 14.883813690877988d);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var7 = var6.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.discardFrontElements((-711711710));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.298853076409707d);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextPascal(41, 37.32563573407755d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "01fd961277f3e9bd76fcb2f494b2f6edac30ff1ff4cf8950be848a7e8068be29434fb5d9408ffb1b9cf23c584c810d35bd65"+ "'", var3.equals("01fd961277f3e9bd76fcb2f494b2f6edac30ff1ff4cf8950be848a7e8068be29434fb5d9408ffb1b9cf23c584c810d35bd65"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.10021593279617541d);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var14 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var13, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MaxCountExceededException var16 = new org.apache.commons.math3.exception.MaxCountExceededException(var11, (java.lang.Number)(byte)1, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var10, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var6.getContext();
    boolean var21 = var1.equals((java.lang.Object)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     double var32 = var1.nextWeibull(93.48737381944967d, 30.66543173953429d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var35 = var1.nextWeibull((-5.966735624802988d), 0.023600574802198477d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "fdef32353f8d0e98f26aeece8a7f683e3389e38c4b42eeb6a2f9f5713d1099f0e321460e11015efeddd6c227ca51f57e38e9"+ "'", var3.equals("fdef32353f8d0e98f26aeece8a7f683e3389e38c4b42eeb6a2f9f5713d1099f0e321460e11015efeddd6c227ca51f57e38e9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.1295274260213681d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-14.665437948754883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-5.862522123162981d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 31.01301277170927d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(10.902797375512776d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.217409890509807d);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var17 = var16.getNumericalVariance();
//     boolean var18 = var16.isSupportConnected();
//     double var21 = var16.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
//     double var23 = var16.density(0.0d);
//     boolean var24 = var16.isSupportUpperBoundInclusive();
//     double var26 = var16.density(5.964535219365547d);
//     double var27 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     org.apache.commons.math3.distribution.NormalDistribution var30 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var31 = var30.getNumericalVariance();
//     double var32 = var30.getNumericalMean();
//     double var33 = var30.getSupportLowerBound();
//     double var34 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var30);
//     double var35 = var30.getNumericalMean();
//     double[] var37 = var30.sample(27985587);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b46f546071d07da8ad7092250d5b37f4ff806c1a31819b0dc59a132eb788df5114a5556c6fa62e0cff3ece1f1373c49dbe59"+ "'", var3.equals("b46f546071d07da8ad7092250d5b37f4ff806c1a31819b0dc59a132eb788df5114a5556c6fa62e0cff3ece1f1373c49dbe59"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.806605039304644d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.06146076675140928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.031733077854635645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 9.566428456976555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 2.425389325489738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     double var21 = var1.nextUniform(0.409278872838869d, 7.6644334196952775d, true);
//     var1.reSeed();
//     double var25 = var1.nextGamma((-12.0d), (-10.817465674450201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "967a36b8013530270b85b8f4c008392ca91c0b29137b6ede3a4c236ae06c510dd78f3f7d875988267a6bf128b69473e2cc06"+ "'", var3.equals("967a36b8013530270b85b8f4c008392ca91c0b29137b6ede3a4c236ae06c510dd78f3f7d875988267a6bf128b69473e2cc06"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.778109057254509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.7669957858957446d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3.498154920545411d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NaN);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test214"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var11 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var6, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.NullArgumentException var15 = new org.apache.commons.math3.exception.NullArgumentException(var5, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathArithmeticException var20 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.util.Localizable var21 = null;
//     java.lang.Object[] var22 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var20, var21, var22);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test215"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.6400093249157379d), 10.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test216"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var11 = var9.addElementRolling(0.0d);
    var9.addElement((-0.7014095186799629d));
    var9.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test217"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log1p((-11.836664972770874d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test218"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-2.5512009829392066d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 103.43548656299504d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test219"); }


    float var2 = org.apache.commons.math3.util.FastMath.min((-0.99999994f), 1.3234891E-22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.99999994f));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test220"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(0);
    var1.addElement(0.19885430975358537d);
    double[] var11 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(1.2676508E30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test221"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(5.915152417354522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     var1.reSeed();
//     double var10 = var1.nextF(2.0386115111602696d, 22.140692632779267d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(0.0d, (-7.755907420366454d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 52.4915431276209d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575224625676478d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.5346747141787291d);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test223"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(181L, 1079717575831374079L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2685354528034092643L));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test224"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(30, (-124));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, var2, (java.lang.Number)1.2263654402124098d);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.2263654402124098d+ "'", var6.equals(1.2263654402124098d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.2263654402124098d+ "'", var7.equals(1.2263654402124098d));

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test226"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var29);
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.NaNStrategy var34 = var33.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
    java.lang.String var38 = var37.name();
    java.lang.String var39 = var37.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var40 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var34, var37);
    org.apache.commons.math3.random.RandomGenerator var41 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var41);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
    boolean var47 = var45.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var34, var45);
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var45);
    org.apache.commons.math3.stat.ranking.NaturalRanking var50 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "AVERAGE"+ "'", var38.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "AVERAGE"+ "'", var39.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test227"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-107), (-536427449));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-536427449));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-2.2779476403433505d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.92956503391649d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test229"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(102L, 692747454);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test230"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(121.14282026907436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0939108047031163d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test231"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.33256135666854103d, 68.80167001187898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0048335856770492965d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(9.525456313941802E131d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.839248513904501E43d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test233"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.09534185796406705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0016640293364417475d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test234"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5, var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test235"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6412798644893787649L, 81L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 81L);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test236"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var10 = var1.nextUniform((-2.552751428575824d), 2.9172543562621576E307d, true);
//     double var13 = var1.nextGaussian(1.0031174857053113d, 2.4404062499464234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "326e96583ba93a327be58285da2707ae4b38f5dac6425511fd66b274567e19fb2a75bc3561be3492c334b813b7fe146ed581"+ "'", var3.equals("326e96583ba93a327be58285da2707ae4b38f5dac6425511fd66b274567e19fb2a75bc3561be3492c334b813b7fe146ed581"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9549675222006099d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.7167982938635036E307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.0948864270759913d));
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test237"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(27.595255027706855d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.010462557199466d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test238"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var14 = var1.nextExponential(3.0406595525191155E24d);
//     long var16 = var1.nextPoisson(71.73148974086561d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var1.nextSecureInt(8265, (-447873150));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "6de8b0913eb6490b25eafa84faf5f0e7db797103ab4eabc182288ce814ed913e4163dc1d72b245c6031260298776b8526870"+ "'", var3.equals("6de8b0913eb6490b25eafa84faf5f0e7db797103ab4eabc182288ce814ed913e4163dc1d72b245c6031260298776b8526870"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7.851780791171131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.122932734155703E24d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 63L);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test240"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var33 = var1.nextWeibull((-17.579035444652284d), (-7.944689521552087d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "c27af4524cfb63a0851d800091f6202fae3c55e2aa2e60604a294aca7a06fc9adfba2c721fa142db51cb0685a39184a3b63e"+ "'", var3.equals("c27af4524cfb63a0851d800091f6202fae3c55e2aa2e60604a294aca7a06fc9adfba2c721fa142db51cb0685a39184a3b63e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.11042794685547498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.4958295175539131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.8009087907986899d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1.8367660271053364E-9d);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     var1.reSeed((-1L));
//     double var13 = var1.nextUniform(4.491885680229876d, 151.64330039654138d);
//     var1.reSeedSecure(1131479055207487616L);
//     var1.reSeedSecure(286183440979776224L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d878b24c117ab5b6c7a20017691aa23242dc28d3d44af2e3e54746e7f4b6e6bc1624abe94fec9ac9db6eb8381dd5c8b599d1"+ "'", var3.equals("d878b24c117ab5b6c7a20017691aa23242dc28d3d44af2e3e54746e7f4b6e6bc1624abe94fec9ac9db6eb8381dd5c8b599d1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.6781862258567535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.3406544169102783d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 39.740383438894604d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test242"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    var2.reseedRandomGenerator(1131479055207487616L);
    double var10 = var2.getSupportUpperBound();
    boolean var11 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test243"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var19 = var17.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var19);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var28 = var27.getTiesStrategy();
    java.lang.String var29 = var28.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var22, var28);
    int var31 = var28.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test244"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)var5, (java.lang.Number)(-0.743169379036474d), false);
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test245"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     double[] var4 = var1.getElements();
//     var1.setElement(100, 1.0d);
//     double[] var8 = var1.getElements();
//     var1.addElement((-0.9469118583888082d));
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     double var14 = var12.nextExponential(100.0d);
//     int var17 = var12.nextZipf(10, 100.0d);
//     int var20 = var12.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var24 = var12.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var25 = var23.getStandardDeviation();
//     double var27 = var23.cumulativeProbability((-2.0439843355597187d));
//     double[] var29 = var23.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
//     org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
//     var1.addElements(var29);
//     boolean var34 = var1.equals((java.lang.Object)200);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.587959550857759d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-12.886289563910944d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test246"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(53L, 1131479055207487616L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test247"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var22 = java.lang.Enum.<java.lang.Enum>valueOf(var20, "61ecb60be2e93eba6ed561ff759896384ae7aa936de2b2054aa6d3da3d01814cb12124e4832534a3be60cb2984408cc41fe5");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.0020509715811141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0020488712102778015d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.9575061341402422d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test250"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    var1.contract();
    double[] var16 = var1.getInternalValues();
    int var17 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test251"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    int var7 = var1.getNumElements();
    double[] var8 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements((-27985567));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test252"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2332), 95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 95);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test253"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-3.9552261426499937d), (-46.9775098485124d), 2.9172543562621576E307d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     var1.reSeed();
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var1.nextSample(var19, 153928164);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(7.971443695387604d, 1.4970165853879775d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3851610702249393d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.9626681941800967d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6019435384727256d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test257"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1.1459234617400742d), (java.lang.Number)3.2723000544257705d, true);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test258"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(8, (-82));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test259"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)10.0d, true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var8 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var16 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MaxCountExceededException var18 = new org.apache.commons.math3.exception.MaxCountExceededException(var13, (java.lang.Number)(byte)1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NullArgumentException var19 = new org.apache.commons.math3.exception.NullArgumentException(var12, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var6, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(235, 0.9999999f, 4.056482E31f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test261"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-3));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test262"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    double[] var5 = var3.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test263"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var8 = var6.sample(34);
    double[] var9 = var1.rank(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = var12.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var12.getTiesStrategy();
    boolean var15 = var10.equals((java.lang.Object)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setExpansionFactor(7.5557864E22f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(55.36071345067003d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 55.0d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test265"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.2507763768820706d, 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.7492236231179294d));

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability(4.87681109080397d);
//     double var16 = var12.getNumericalMean();
//     double var17 = var12.getNumericalVariance();
//     var12.reseedRandomGenerator(96L);
//     double var21 = var12.cumulativeProbability(4.913518432650243d);
//     double var22 = var12.getNumericalVariance();
//     double var24 = var12.cumulativeProbability(15.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12.890608166231631d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-12.764387399316536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7149130721399563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.7161581687611127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.9429596605261948d);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(1.1471428264102244d, 0.5298418234538922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.94199529643178d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test268"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)19L, (java.lang.Number)52.217050732695114d, true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 52.217050732695114d+ "'", var5.equals(52.217050732695114d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test269"); }


    double var1 = org.apache.commons.math3.special.Gamma.logGamma(2.7755575615628914E-17d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 38.123094930796995d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test270"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-692747454), 76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-692747530));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test271"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 0);
    java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, 1131479055207487616L);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 340591140L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 591436115971011712L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.6798922678206463d, 11.102913882643712d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.6798922678206467d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test273"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-739555469), (-997090893));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-1231361484), 3116);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test275"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(2325);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test276"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    java.math.BigInteger var13 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 100L);
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 37);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, 100L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var18 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)var10);
    boolean var19 = var18.getBoundIsAllowed();
    java.lang.Number var20 = var18.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0+ "'", var20.equals(0));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test277"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.00974196E-28f, 1.2676508E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.00974196E-28f);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     java.lang.String var25 = var1.nextHexString(6316);
//     double var28 = var1.nextF(8.47462739104943d, 975.5856699789977d);
//     var1.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "bc6ed2962c6ae20629c9e42516d7fb77643592eb024c4f8a686bcff80ebce0f1a0c4de63afca4bd659a8d777f9e16cfe388e"+ "'", var3.equals("bc6ed2962c6ae20629c9e42516d7fb77643592eb024c4f8a686bcff80ebce0f1a0c4de63afca4bd659a8d777f9e16cfe388e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.6826598181290358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-7.817883685869759d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2.8903018610501747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.5012892861643903d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test279"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("8a7c30c5f367373dd8e7bfb26b58a4601edfaace2704655a45b499f309e7113dccda4cfbfb1ac58e711493a8105c19b013c9");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test280"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.8389695826349715d, (java.lang.Number)(-8.745881625601406d), (java.lang.Number)11.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test281"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = var1.getInternalValues();
    float var7 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test282"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)3L, (java.lang.Number)5.77363775057318d, true);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test283"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.4999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test284"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     double var8 = var2.getSupportLowerBound();
//     double var9 = var2.getSupportUpperBound();
//     double var10 = var2.getStandardDeviation();
//     double var11 = var2.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-4.4021909841959905d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12.920216500631991d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.25952243470135083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     double var18 = var1.nextChiSquare(4.87681109080397d);
//     var1.reSeedSecure();
//     long var22 = var1.nextLong((-878105194433072128L), 670369391491839749L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var1.nextBinomial((-42), (-9.52391259992606d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-420416749));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 15.261604693986275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 154.75923696590945d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.336708856003675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5.795169634745371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 215083735370444704L);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test287"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportUpperBoundInclusive();
    var2.reseedRandomGenerator(15L);
    double var13 = var2.getNumericalVariance();
    boolean var14 = var2.isSupportLowerBoundInclusive();
    boolean var15 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test288"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    int var5 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test289"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(2.1391729469070038d, 13.857538798990914d, (-1.0038370563294414d));

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test290"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.4110676145269512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.100330640679813d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test291"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)(-7.742899382369662E-6d), (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test292"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var11 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)154.0949430728794d, (java.lang.Object[])var7);
    java.lang.Number var12 = var11.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 154.0949430728794d+ "'", var12.equals(154.0949430728794d));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test293"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.28583983826614007d, (java.lang.Number)0.06812197096180644d, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.06812197096180644d+ "'", var4.equals(0.06812197096180644d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var8 = var1.nextT(18.574573866010756d);
//     double var11 = var1.nextGamma(2.251752586176186d, 1.0652279546366723d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform(0.06446622075849562d, (-0.14053685347494785d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 410.8712641952271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-34.69898079834676d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.7360936481779808d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5946843356932865d);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test295"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-2.143683965850281d));

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test296"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.25180003E16f, (-651230979));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test297"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(5714513404809878201L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test298"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0f), (java.lang.Number)2.9172543562621576E307d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test299"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0665895490501696d, (java.lang.Number)0.4505451791095725d, (java.lang.Number)(-0.32267104745890796d));
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.4505451791095725d+ "'", var4.equals(0.4505451791095725d));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.36139807852275185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test301"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-12573), 0.9999999f, 0.019531252f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     org.apache.commons.math3.random.RandomGenerator var11 = null;
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl(var11);
//     double var14 = var12.nextExponential(100.0d);
//     int var17 = var12.nextZipf(10, 100.0d);
//     int var20 = var12.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var23 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var24 = var12.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     double var25 = var23.getStandardDeviation();
//     double var27 = var23.inverseCumulativeProbability(0.24433316542704286d);
//     double var28 = var23.sample();
//     double var29 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var23);
//     var1.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("a26954c33e43e727be6ff4594d527b7466865a2bd4553e2776c7f8e22552c6d62b1344fc9848b890c0451514228d6922c22a", "65eb36a62667cb878e4edc45bd2e0c06d1f7616e3b9cf219d18829055805ce843c6e8a6a920f669eaa419d362435284d57a0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-61076215));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 20.793863038926748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-6.065700601917264d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-7.725459552628436d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 4.8225933177975016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-1.660378503533875d));
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     boolean var19 = var12.isSupportConnected();
//     double[] var21 = var12.sample(63);
//     double var22 = var12.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 133.1291863712752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17.779776436756674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-2.0922523830445465d));
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test304"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-433411940), (-1126));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test305"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(6.541862173782476E-7d, 76.32868024571914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 76.32868024571914d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test306"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    java.lang.Class var23 = var20.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = var27.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    java.lang.String var32 = var31.name();
    java.lang.String var33 = var31.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var28, var31);
    org.apache.commons.math3.random.RandomGenerator var35 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28, var35);
    double[] var37 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    float var39 = var38.getExpansionFactor();
    double[] var40 = var38.getInternalValues();
    var38.clear();
    float var42 = var38.getContractionCriteria();
    double[] var43 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
    var44.discardFrontElements(0);
    boolean var49 = var44.equals((java.lang.Object)(short)1);
    double[] var51 = new double[] { 10.0d};
    var44.addElements(var51);
    var38.addElements(var51);
    double[] var54 = var36.rank(var51);
    org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
    double[] var56 = var25.rank(var51);
    double[] var57 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var58 = new org.apache.commons.math3.util.ResizableDoubleArray(var57);
    float var59 = var58.getExpansionFactor();
    double[] var60 = var58.getInternalValues();
    var58.clear();
    float var62 = var58.getContractionCriteria();
    double[] var63 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var64 = new org.apache.commons.math3.util.ResizableDoubleArray(var63);
    org.apache.commons.math3.util.ResizableDoubleArray var65 = new org.apache.commons.math3.util.ResizableDoubleArray(var64);
    var64.discardFrontElements(0);
    boolean var69 = var64.equals((java.lang.Object)(short)1);
    double[] var71 = new double[] { 10.0d};
    var64.addElements(var71);
    var58.addElements(var71);
    double var74 = var18.mannWhitneyUTest(var51, var71);
    double[] var75 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var76 = new org.apache.commons.math3.util.ResizableDoubleArray(var75);
    org.apache.commons.math3.util.ResizableDoubleArray var77 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
    org.apache.commons.math3.util.ResizableDoubleArray var78 = new org.apache.commons.math3.util.ResizableDoubleArray(var76);
    double[] var79 = var76.getElements();
    double[] var80 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var81 = new org.apache.commons.math3.util.ResizableDoubleArray(var80);
    org.apache.commons.math3.util.ResizableDoubleArray var82 = new org.apache.commons.math3.util.ResizableDoubleArray(var81);
    var81.setNumElements(1);
    int var85 = var81.getExpansionMode();
    double var87 = var81.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var89 = var81.addElementRolling(100.0d);
    var81.clear();
    int var91 = var81.getExpansionMode();
    int var92 = var81.getExpansionMode();
    double[] var93 = var81.getInternalValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var94 = var18.mannWhitneyU(var79, var93);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AVERAGE"+ "'", var32.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test307"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var3);
    org.apache.commons.math3.stat.ranking.TiesStrategy var5 = var4.getTiesStrategy();
    java.lang.String var6 = var5.name();
    java.lang.String var7 = var5.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var8 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var5);
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var9);
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    float var13 = var12.getExpansionFactor();
    double[] var14 = var12.getInternalValues();
    var12.clear();
    float var16 = var12.getContractionCriteria();
    double[] var17 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    var18.discardFrontElements(0);
    boolean var23 = var18.equals((java.lang.Object)(short)1);
    double[] var25 = new double[] { 10.0d};
    var18.addElements(var25);
    var12.addElements(var25);
    double[] var28 = var10.rank(var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var29 = var10.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "AVERAGE"+ "'", var6.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test308"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     double var5 = var2.density(18.409703235248998d);
//     double var7 = var2.probability(9.34227543668857d);
//     double var9 = var2.inverseCumulativeProbability(0.07276079903139297d);
//     double var10 = var2.getSupportLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-9.143219931368488d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-15.356479515056561d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     long var19 = var1.nextSecureLong(0L, 16L);
//     double var21 = var1.nextT(2.0044040509068734E-15d);
//     java.lang.String var23 = var1.nextSecureHexString(3116);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var1.nextHypergeometric(16, 1126, (-293720005));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-768422411));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 31.175069735732347d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 96.68462429932701d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9.517949595327549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1.3407807929942106E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "d0998d59662568c25a3cdad94201057ad142f529b64517f75ddd44260ef306693e821d9cc11df9eb8d5d26fedbd8975a28eb5d55dff3853b5b4ec9e4ebb7bfa6381a7bee10d2bf7f598bb35c6c647a1d31532a76977e2242557393f70e042b3da278f7f99739cdad61494cf855c19517e51fcfc90b0c1c56d0f4f17b18659aa2fbdcddee7c4a7d6ce4a432a61f0a555c71139d32d74190f64c87c22912760ac75e02c3ed47daa7616e993adee5a78d64c9a2045c853b88a44f912ec95a17738a9053a36ff13320b230b576f0e88f90245d65ab71041dc53e566626cbd0d4c3fa07d7e55c1940045ac020186cf2e248e998a48b793ec7bf6bbd5ce5cce7a0182421149ad3a966ca80ded996e7b22719cee861bf760eed66eb801be80f1f30457ead3dc64d2309b6bec7546ab827852a83b317b59044e9d39e0df34c3046bb869e686ddb563d1b612106424152f312c23418eeabb18dc37a8374907551ae15cac9efcf84814f1837f03662712c3d31f0875aa525c37cbfe3d50d625c71232ca0172fc2b98e277abd027254f88a8a650432af27eee79a2d74f5d93cf5b16289f55e458858ed5fc14d05baeba39fef8e51d7199083b2a01c11b294f97a13504e3a6df1ba5979595bcd8ae19cafa0d1e7eb8a04ac98f06374c7d86f7307bbbadd35d428ccdc038d28c78caa038634a6793f9ea3a98bf421b23527421393e93ad8b1e6a54670f4cf41faf174b48b3b3a4f62078c84b6e6da41f20108d3b46385fc0b49cae39f4882889e60a96d73614806c39a6a8717d7f3588c8249055edbf30db6084e96d4fa2b5dff26398522770735a9a7c3d84e4093a67566657808c9f168a10197deab65189f958af44a72d80385ac9b1051b9c6a2b4007b8a0900ee37c0f91bd54a501877cba4d4036664adef96cfec4bb76ab55ad7b573300078aa7289174afcc3af28a9f5e469ed98465605a21d0726a9bb8dd6b7794437438f8e02485608cc51c5831a8c169549ff29306069baf6de3c42b0e54ca4a80c493befd0e779c95f0dcc15c67cdd4fce9282fc7761bcd005fe3bbeb981df1d5b58a094e2530a9e9fca9986242644e231d0e1a200b4a5efd7467754315d4c0c8f7c0ae7f9cd181b20f3ff1911c7938c84f8f550577717f1517e6835ecf9d851ccefd88ffffbe75f750a748af50a134163489271a7f0775fe447caf92bb6140a4aba7a0f851d7e7b585c2a0361d83ab7524abe92f2c4bf9ca18f0429b4f2b3e8f0b25da46afd33bff25a51492224b9522d28286067afa8f219d1ad49c8ff4b58698aaf205a575ca510767adae08a8ddbf5aff36e9e599091b82c33c54624d048467e1009efaa737d2d0f89c5bcca6a39364d7e0aff84297ff7f1b4be8cf0af2c8b0b5165250e2a21bf34d5e2ba2c90b4e937b9eab78a7cb5a60e7717dc5604ac07b0b79c19f0124654475b4abf7f1322e076d7d1315a034072b8c919edd91520d52dbf0048eabd875f54811bbc5043bc2cd1be0bb5a32e238f096d70ccf1e56e428d34d8d52d75b464ef11e192e1d8128c69765754a5a721d824311b807dcec3e12cba9b38b0736b6f0fdb3f0cbacfa03506d669f9e1d6d0f75cf6a890acab5ef20ef2476ea449f3fe1838cb37bc44d785197d1fc8c69f35bf230f891b165814921d327632e89d2859edff9bc48e9e65ca8789237e50cf42f17ef3e764ec1c0667f832f7bb90c4d72aa9fbe30f8000f7cfd78d2483dccbf8acbfe6588c612ae58622c965f03a26a6286707a5c236835063b6bfbc273bcb1da6d6f43d0cb1772e342f7c02dabd1183814f9a794031666dbe526adee483a7bd73299afff4cb4d77703e8b5531b6edb5070016cb132d5be8657cda1aefa8b924ac4d2bb9738087944b5f67bc394d600f0f2545f890f158cb13f2528534243847ad61fda570f36882e7dec27a9bfc9c2cfcfd61b933aac7733207197bf7d413a375238e31c4175e53d57bceaea41ed8f0a2c6b622197dc370981cc22df1bdaea1a8299b4842a403aabbce7b80e5225b47e1502767261b1841caf0117bd61b78486a4d7aa11fab906622ece07f5eba3c4b54b829d71e190485f9b363cbf721ddf6623ba67efea70738b0c890383ff4ff84a6dd264d4e4186a097b48e806861a66d4ca35032840ba5df1d78292195f27cc61cea8a551d3b6e1846398ab96f472a6c4c32d846983f"+ "'", var23.equals("d0998d59662568c25a3cdad94201057ad142f529b64517f75ddd44260ef306693e821d9cc11df9eb8d5d26fedbd8975a28eb5d55dff3853b5b4ec9e4ebb7bfa6381a7bee10d2bf7f598bb35c6c647a1d31532a76977e2242557393f70e042b3da278f7f99739cdad61494cf855c19517e51fcfc90b0c1c56d0f4f17b18659aa2fbdcddee7c4a7d6ce4a432a61f0a555c71139d32d74190f64c87c22912760ac75e02c3ed47daa7616e993adee5a78d64c9a2045c853b88a44f912ec95a17738a9053a36ff13320b230b576f0e88f90245d65ab71041dc53e566626cbd0d4c3fa07d7e55c1940045ac020186cf2e248e998a48b793ec7bf6bbd5ce5cce7a0182421149ad3a966ca80ded996e7b22719cee861bf760eed66eb801be80f1f30457ead3dc64d2309b6bec7546ab827852a83b317b59044e9d39e0df34c3046bb869e686ddb563d1b612106424152f312c23418eeabb18dc37a8374907551ae15cac9efcf84814f1837f03662712c3d31f0875aa525c37cbfe3d50d625c71232ca0172fc2b98e277abd027254f88a8a650432af27eee79a2d74f5d93cf5b16289f55e458858ed5fc14d05baeba39fef8e51d7199083b2a01c11b294f97a13504e3a6df1ba5979595bcd8ae19cafa0d1e7eb8a04ac98f06374c7d86f7307bbbadd35d428ccdc038d28c78caa038634a6793f9ea3a98bf421b23527421393e93ad8b1e6a54670f4cf41faf174b48b3b3a4f62078c84b6e6da41f20108d3b46385fc0b49cae39f4882889e60a96d73614806c39a6a8717d7f3588c8249055edbf30db6084e96d4fa2b5dff26398522770735a9a7c3d84e4093a67566657808c9f168a10197deab65189f958af44a72d80385ac9b1051b9c6a2b4007b8a0900ee37c0f91bd54a501877cba4d4036664adef96cfec4bb76ab55ad7b573300078aa7289174afcc3af28a9f5e469ed98465605a21d0726a9bb8dd6b7794437438f8e02485608cc51c5831a8c169549ff29306069baf6de3c42b0e54ca4a80c493befd0e779c95f0dcc15c67cdd4fce9282fc7761bcd005fe3bbeb981df1d5b58a094e2530a9e9fca9986242644e231d0e1a200b4a5efd7467754315d4c0c8f7c0ae7f9cd181b20f3ff1911c7938c84f8f550577717f1517e6835ecf9d851ccefd88ffffbe75f750a748af50a134163489271a7f0775fe447caf92bb6140a4aba7a0f851d7e7b585c2a0361d83ab7524abe92f2c4bf9ca18f0429b4f2b3e8f0b25da46afd33bff25a51492224b9522d28286067afa8f219d1ad49c8ff4b58698aaf205a575ca510767adae08a8ddbf5aff36e9e599091b82c33c54624d048467e1009efaa737d2d0f89c5bcca6a39364d7e0aff84297ff7f1b4be8cf0af2c8b0b5165250e2a21bf34d5e2ba2c90b4e937b9eab78a7cb5a60e7717dc5604ac07b0b79c19f0124654475b4abf7f1322e076d7d1315a034072b8c919edd91520d52dbf0048eabd875f54811bbc5043bc2cd1be0bb5a32e238f096d70ccf1e56e428d34d8d52d75b464ef11e192e1d8128c69765754a5a721d824311b807dcec3e12cba9b38b0736b6f0fdb3f0cbacfa03506d669f9e1d6d0f75cf6a890acab5ef20ef2476ea449f3fe1838cb37bc44d785197d1fc8c69f35bf230f891b165814921d327632e89d2859edff9bc48e9e65ca8789237e50cf42f17ef3e764ec1c0667f832f7bb90c4d72aa9fbe30f8000f7cfd78d2483dccbf8acbfe6588c612ae58622c965f03a26a6286707a5c236835063b6bfbc273bcb1da6d6f43d0cb1772e342f7c02dabd1183814f9a794031666dbe526adee483a7bd73299afff4cb4d77703e8b5531b6edb5070016cb132d5be8657cda1aefa8b924ac4d2bb9738087944b5f67bc394d600f0f2545f890f158cb13f2528534243847ad61fda570f36882e7dec27a9bfc9c2cfcfd61b933aac7733207197bf7d413a375238e31c4175e53d57bceaea41ed8f0a2c6b622197dc370981cc22df1bdaea1a8299b4842a403aabbce7b80e5225b47e1502767261b1841caf0117bd61b78486a4d7aa11fab906622ece07f5eba3c4b54b829d71e190485f9b363cbf721ddf6623ba67efea70738b0c890383ff4ff84a6dd264d4e4186a097b48e806861a66d4ca35032840ba5df1d78292195f27cc61cea8a551d3b6e1846398ab96f472a6c4c32d846983f"));
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextF(0.6256445019194884d, 14.306620465386846d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF(6.710248764360841d, (-0.318274109447741d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.961988484861715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575250721108683d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.058393773882399684d);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.262160985455642E75d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 75.10111475160868d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test312"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.2131325514702223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3500868086646019d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test313"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-112), 1.00974196E-28f, 0.9999998f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test314"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    float var14 = var1.getContractionCriteria();
    var1.contract();
    var1.setNumElements(100);
    double[] var18 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    var19.setNumElements(1);
    int var23 = var19.getExpansionMode();
    double var25 = var19.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double[] var26 = var19.getElements();
    var1.addElements(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-2332));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test315"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(52521875L, 235);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-8144422758862763477L));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test316"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("e7ec54cd0c73d669e78b12d5c4ea22a5d286495e7859c423a519e3503c035e5d36a0421fc886836b88e6af4a57a28d0442c6");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test317"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    int var3 = var2.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var2.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test318"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.333758584777322d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 103.60526144257621d);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-27.235566339247473d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.9980077443970803d));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test320"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    double[] var13 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.clear();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test321"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)137.03314037205797d, (java.lang.Number)79.26372034878028d, true);
    boolean var4 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var8);
    java.lang.Number var12 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 137.03314037205797d+ "'", var12.equals(137.03314037205797d));

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     double var32 = var1.nextUniform((-2.525393179271314d), 0.985635209558184d);
//     org.apache.commons.math3.distribution.IntegerDistribution var33 = null;
//     int var34 = var1.nextInversionDeviate(var33);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test323"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var4 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var7 = var6.toString();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    var4.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var16 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NullArgumentException var18 = new org.apache.commons.math3.exception.NullArgumentException(var14, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var13, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var10, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NullArgumentException var24 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathArithmeticException var25 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var7.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-692747484), 3.4028235E38f, (-1.0f), (-23));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test325"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-254803968L), 769971757032977664L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test326"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(171588, 2.384186E-7f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.2057743764129765d, (-0.14910849225381428d), (-1.724207578810511d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test328"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    var1.setNumElements(35);
    double[] var9 = var1.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure();
//     var1.reSeedSecure(1079717575831374079L);
//     long var15 = var1.nextSecureLong(1558790486165778433L, 1571400668722899200L);
//     double var18 = var1.nextF(22.811880526480223d, 490413.7343269309d);
//     var1.reSeed(52L);
//     long var22 = var1.nextPoisson(2.7376903150969456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 247.505334558385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 827089930562494336L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 106.09472188023533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1571023637928507904L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.6101106806013743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test330"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(776490.9932348088d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.44896567422759E7d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test331"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0d, (-7.648016424037842d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test332"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    double var11 = var2.probability(6.2180200613237d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var2.inverseCumulativeProbability(3.10091716033504d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test333"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.2689215154457405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8080159057502068d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test334"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(90, (-703550053));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test335"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.Class var8 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var4, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.random.RandomGenerator var11 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4, var11);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var14 = var13.getTiesStrategy();
    java.lang.String var15 = var14.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.8548477524839477d, (-3.078497949026296d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.078497949026296d));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test337"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getNumericalVariance();
    double var6 = var2.getStandardDeviation();
    double var7 = var2.getNumericalMean();
    double var8 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == Double.NEGATIVE_INFINITY);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test338"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    var1.setNumElements(2325);
    double var5 = var1.getElement(9);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var8 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var6, (java.lang.Number)1.727261859883329d);
    boolean var9 = var1.equals((java.lang.Object)var8);
    float var10 = var1.getExpansionFactor();
    boolean var12 = var1.equals((java.lang.Object)(-0.7706191458620877d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test339"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var7 = var6.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var7, var8);
    boolean var10 = var5.equals((java.lang.Object)var8);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest();
    double[] var12 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var13);
    var13.setNumElements(1);
    int var17 = var13.getExpansionMode();
    double var19 = var13.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var21 = var13.addElementRolling(100.0d);
    var13.clear();
    int var23 = var13.getExpansionMode();
    double[] var25 = new double[] { 1.0d};
    var13.addElements(var25);
    double[] var27 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    double[] var31 = var28.getElements();
    var28.setElement(100, 1.0d);
    double[] var35 = var28.getElements();
    double var36 = var11.mannWhitneyUTest(var25, var35);
    var5.addElements(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.08947556010017466d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test340"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(41, (-2.384186E-7f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var8 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var8);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.NullArgumentException var14 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test342"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-5.734484207278836d), 9.064783604953828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test343"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var8 = var6.sample(34);
    double[] var9 = var1.rank(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = var10.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(128.22878775917496d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4435709265843271E55d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test345"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getExpansionMode();
    double[] var4 = var1.getElements();
    var1.setContractionCriteria(7.555787E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test346"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    double[] var8 = new double[] { 10.0d};
    var1.addElements(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setNumElements((-206885));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.5882267128651635d, 39.260498562156265d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.093411884750471E21d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test348"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-56), 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1400);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test349"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var7.discardFrontElements(0);
    boolean var12 = var7.equals((java.lang.Object)(short)1);
    double[] var14 = new double[] { 10.0d};
    var7.addElements(var14);
    var1.addElements(var14);
    var1.setNumElements(22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test350"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.918918213896427d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7191181184006279d));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test351"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test352"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(113.38808312715275d, 12.801827480081469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 113.38808312715274d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test353"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-17.31533392446027d), 2.0684508415305403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4519019868691099d));

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     boolean var21 = var12.isSupportUpperBoundInclusive();
//     boolean var22 = var12.isSupportLowerBoundInclusive();
//     double var24 = var12.density(0.09169855452891158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 33.44876589292802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.984787474193065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 20.298877885486085d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.03973553267858104d);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test355"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1.2690902893872158d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test356"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.8363625025557515d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-21.869272591487576d), (java.lang.Number)0.5603205770826893d, (java.lang.Number)0.7772054281156179d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test358"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.09534185796406705d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 29.184899402659433d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test359"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    int var15 = var1.start();
    java.lang.Object var16 = null;
    boolean var17 = var1.equals(var16);
    int var18 = var1.start();
    int var19 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test360"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(9.536743E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536744E-7f);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test361"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     double var21 = var1.nextUniform(0.409278872838869d, 7.6644334196952775d, true);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var1.nextWeibull(0.0d, 0.3838429838828998d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e5e9760067dcdb841748aee309a7855f220dd20a2d38fb4a8826c7c5b5f63e727136e961e64b8af97328d34ae6197f361ca5"+ "'", var3.equals("e5e9760067dcdb841748aee309a7855f220dd20a2d38fb4a8826c7c5b5f63e727136e961e64b8af97328d34ae6197f361ca5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.270461669432727d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.009424900798203418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.8083533286068665d);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test362"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var21 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var22 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var21);
    java.lang.Class var23 = var20.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.String var27 = var26.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var26);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test363"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(2.0837188945684284d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test364"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(110.92196131466562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5684148374056222d));

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     double var23 = var1.nextChiSquare(38.13608131498478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "3e6e72570eb31b41240ad0d75da779019b35d478db3422fb79597e466762d5bb18034621160686dda3c828f068712164ad2e"+ "'", var3.equals("3e6e72570eb31b41240ad0d75da779019b35d478db3422fb79597e466762d5bb18034621160686dda3c828f068712164ad2e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.1557015683410975d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 35.111582216327314d);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     double var10 = var1.nextWeibull(1.2751417367324678d, 1.290755113254164d);
//     double var13 = var1.nextUniform((-18.80489796341991d), (-0.5086137103625639d));
//     org.apache.commons.math3.distribution.NormalDistribution var16 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var17 = var16.sample();
//     boolean var18 = var16.isSupportLowerBoundInclusive();
//     double var19 = var16.getStandardDeviation();
//     double var21 = var16.inverseCumulativeProbability(0.0d);
//     double var22 = var16.getSupportLowerBound();
//     double var23 = var16.getMean();
//     double var24 = var16.getNumericalMean();
//     var16.reseedRandomGenerator(1023863903247170432L);
//     double var27 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 360.49022039921033d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.43795102877585523d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.8128773312397715d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-8.49027649121863d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-33.083585158317d));
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test367"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     double[] var3 = var1.getInternalValues();
//     org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
//     double[] var5 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var5);
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     double[] var9 = var6.getElements();
//     double[] var10 = var6.getElements();
//     var4.addElements(var10);
//     int var12 = var4.start();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
//     java.lang.String var16 = var15.name();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var20 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var25 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var25);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var28 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
//     java.lang.String var31 = var30.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var30);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var33 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var33);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var34.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var35);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var35);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var38 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var39 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var38);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var40 = var39.getNanStrategy();
//     double[] var41 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(var42);
//     var42.setNumElements(1);
//     int var46 = var42.getExpansionMode();
//     double var48 = var42.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double[] var49 = var42.getElements();
//     double[] var50 = var39.rank(var49);
//     org.apache.commons.math3.random.RandomGenerator var51 = null;
//     org.apache.commons.math3.random.RandomDataImpl var52 = new org.apache.commons.math3.random.RandomDataImpl(var51);
//     double var54 = var52.nextExponential(100.0d);
//     int var57 = var52.nextZipf(10, 100.0d);
//     int var60 = var52.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var63 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var64 = var52.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var63);
//     double var65 = var63.getStandardDeviation();
//     double var67 = var63.cumulativeProbability((-2.0439843355597187d));
//     double[] var69 = var63.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var70 = new org.apache.commons.math3.util.ResizableDoubleArray(var69);
//     double var71 = var37.mannWhitneyU(var50, var69);
//     org.apache.commons.math3.util.ResizableDoubleArray var72 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     double[] var73 = var17.rank(var50);
//     var4.addElements(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "AVERAGE"+ "'", var16.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 244.80031069384944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-2.200443484467763d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 14.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     double var25 = var1.nextExponential(2.901500319130624d);
//     java.lang.String var27 = var1.nextSecureHexString(128);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var1.nextWeibull((-0.053114013672176386d), (-2.162606824094015d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e068149ec558ca4b4c8be33db22e4147a87ea56e2b9fd51155a80d4f538591c01268ae1266c435a912bb4cc0fccdcd240711"+ "'", var3.equals("e068149ec558ca4b4c8be33db22e4147a87ea56e2b9fd51155a80d4f538591c01268ae1266c435a912bb4cc0fccdcd240711"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.738357151823267d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-4.2701377779358385d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.030373853157423605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.2738968822965946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "08cd0a262772b5d1d05fe0951073b0c91f89706df21381c910629fea667ea978f3f21466c56dabbbf956d89a8a8bdab3feb9a253b33f305cdccf0deee6117eeb"+ "'", var27.equals("08cd0a262772b5d1d05fe0951073b0c91f89706df21381c910629fea667ea978f3f21466c56dabbbf956d89a8a8bdab3feb9a253b33f305cdccf0deee6117eeb"));
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test369"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    org.apache.commons.math3.distribution.NormalDistribution var8 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, 5.717858802944031d);
    boolean var9 = var4.equals((java.lang.Object)5.717858802944031d);
    java.lang.String var10 = var4.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "MAXIMAL"+ "'", var10.equals("MAXIMAL"));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test370"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 1918124033);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.math.BigInteger var17 = null;
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0);
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var26);
    org.apache.commons.math3.exception.OutOfRangeException var30 = new org.apache.commons.math3.exception.OutOfRangeException(var16, (java.lang.Number)var26, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var31 = new org.apache.commons.math3.exception.NotPositiveException(var15, (java.lang.Number)var26);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 0);
    java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var26);
    java.math.BigInteger var36 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 1249363969);
    java.math.BigInteger var38 = org.apache.commons.math3.util.ArithmeticUtils.pow(var36, 543525818476686592L);
    java.math.BigInteger var40 = org.apache.commons.math3.util.ArithmeticUtils.pow(var38, 1450);
    org.apache.commons.math3.exception.OutOfRangeException var42 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-158.62814411276702d), (java.lang.Number)1450, (java.lang.Number)2.594936470547274d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     var1.reSeed((-1L));
//     double var13 = var1.nextF(0.5498050729812682d, 6.562827358342101E13d);
//     var1.reSeedSecure(139L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "fe6ef231f1f08e01d8e7b3e1c511d3f696819f56c7dd753fd771c836a379e443468c774c8debdaaff1ff73aebb5a3c1ff18b"+ "'", var3.equals("fe6ef231f1f08e01d8e7b3e1c511d3f696819f56c7dd753fd771c836a379e443468c774c8debdaaff1ff73aebb5a3c1ff18b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.1975471597122276d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.32268658185549d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.03378947459080738d);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.1874210643132008d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9274073941565335d));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test373"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(16);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test374"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = var12.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var14);
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    java.lang.String var20 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "MAXIMAL"+ "'", var20.equals("MAXIMAL"));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test375"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-1578.2087974778344d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test376"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var14);
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var16);
    org.apache.commons.math3.stat.ranking.NaNStrategy var18 = var17.getNanStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test377"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(41, (-44));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test378"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(4418.743213553135d, 11.579430653027497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4418.743213553135d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test379"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-293720005), (-1450));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test380"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var2 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)382.7463252293418d, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)2025644137419103232L, (java.lang.Number)(byte)1, false);
    java.lang.Number var9 = var8.getArgument();
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Number var11 = var8.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 2025644137419103232L+ "'", var9.equals(2025644137419103232L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (byte)1+ "'", var11.equals((byte)1));

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test381"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalVariance();
//     var2.reseedRandomGenerator(35L);
//     double var8 = var2.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.5363322488294877d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     double[] var18 = var12.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     double[] var20 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
//     float var22 = var21.getExpansionFactor();
//     double[] var23 = var21.getInternalValues();
//     var19.addElements(var23);
//     float var25 = var19.getContractionCriteria();
//     boolean var27 = var19.equals((java.lang.Object)1508);
//     double var29 = var19.substituteMostRecentElement((-3.687085271979007d));
//     var19.discardFrontElements(23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var19.discardFrontElements((-530087935));
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 70.22409531057957d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2.3991718087142395d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 11.246207884659583d);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test383"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.discardFrontElements(37);
    int var16 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(1250175839);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 37);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test384"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.854280313149045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.349682736151669d);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     boolean var17 = var12.isSupportUpperBoundInclusive();
//     double var18 = var12.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 76.07083654126993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-9.44028762659985d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.8011436155469337d));
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test386"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.8330263831561218d, 1.2270705601102425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9808877159763503d);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test387"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     double var14 = var1.nextExponential(2.654532116546876d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextBinomial((-1594198), 5.964535219365547d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "606d368d181a4dc3ca3686c1075f5c576b9324d16ae6a88232b8bd1763b9a9a85f8c30bac8e4e20c3f74a95f7c90b068ff05"+ "'", var3.equals("606d368d181a4dc3ca3686c1075f5c576b9324d16ae6a88232b8bd1763b9a9a85f8c30bac8e4e20c3f74a95f7c90b068ff05"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.1273932528187631d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.173580075436722d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0793126030600483d);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test388"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 53);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test389"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.String var3 = var1.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "MAXIMAL"+ "'", var3.equals("MAXIMAL"));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test390"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(16.0f, 3.944305E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16.0f);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test391"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.25180003E16f, 4.0564817E31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.25180003E16f);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test392"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-87), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var10 = var1.nextUniform(0.45607367119017356d, 4.287277367940195d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 65.57896552472494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575199908009506d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.8786420280604297d);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test394"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.4938632689660762d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test395"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(16.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test396"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Number var9 = null;
    java.lang.Object[] var11 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var12 = new org.apache.commons.math3.exception.MaxCountExceededException(var8, var9, var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    var5.addSuppressed((java.lang.Throwable)var13);
    org.apache.commons.math3.exception.util.ExceptionContext var16 = var5.getContext();
    java.lang.Object[] var17 = new java.lang.Object[] { var5};
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test397"); }


    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    java.math.BigInteger var13 = null;
    java.math.BigInteger var15 = org.apache.commons.math3.util.ArithmeticUtils.pow(var13, 0L);
    java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, var15);
    org.apache.commons.math3.exception.NumberIsTooSmallException var20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)179.870724080515d, (java.lang.Number)var15, true);
    java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 8);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 355687428096000L);
    org.apache.commons.math3.exception.NumberIsTooSmallException var28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.03861151116027d, (java.lang.Number)355687428096000L, true);
    java.lang.Number var29 = var28.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 355687428096000L+ "'", var29.equals(355687428096000L));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test398"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    boolean var2 = var0.isSupportUpperBoundInclusive();
    double var3 = var0.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test399"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     org.apache.commons.math3.random.RandomGenerator var3 = null;
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl(var3);
//     double var6 = var4.nextExponential(100.0d);
//     double var9 = var4.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     int var12 = var4.nextPascal(20925, 0.10814152117337966d);
//     boolean var13 = var1.equals((java.lang.Object)0.10814152117337966d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setContractionCriteria(1.2037062E-35f);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 218.93797441197555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-20.8553020861847d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 173536);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test400"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var2 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    java.lang.Class var3 = var1.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test401"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)115.88236082957272d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var8 = var1.nextExponential(5.169339496286199d);
//     double var11 = var1.nextWeibull(0.7199192644760765d, 3.9626681941800967d);
//     long var13 = var1.nextPoisson(1.7409553232269794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b46ff4cbe415032f7d5ebbd7cbd4e778ee8831f210c5f1e8b4495bf309d7aca1c2de6aa126051b35e4280c440790393469f2"+ "'", var3.equals("b46ff4cbe415032f7d5ebbd7cbd4e778ee8831f210c5f1e8b4495bf309d7aca1c2de6aa126051b35e4280c440790393469f2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-115));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.920894132071567d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.0690388034952d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3L);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test403"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.9977598550367094d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8417688073134254d);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test404"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var16 = var14.getStandardDeviation();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var14.inverseCumulativeProbability((-0.9460426621626962d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "27ec94c5506a7580ef32862e16a111bbe7b37cd051eec52516d96d95de033ed71df28715f22ac0466683136dd67f1a4c66d4"+ "'", var3.equals("27ec94c5506a7580ef32862e16a111bbe7b37cd051eec52516d96d95de033ed71df28715f22ac0466683136dd67f1a4c66d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1964678859753187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.6132882125506091d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.math.BigInteger var1 = null;
    java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
    java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
    java.math.BigInteger var6 = null;
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
    org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var15 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)var10);
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.math.BigInteger var17 = null;
    java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0L);
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0);
    java.math.BigInteger var22 = null;
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0L);
    java.math.BigInteger var26 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
    java.math.BigInteger var27 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, var26);
    java.math.BigInteger var29 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 100L);
    java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 37);
    java.math.BigInteger var33 = org.apache.commons.math3.util.ArithmeticUtils.pow(var26, 100L);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var34 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var16, (java.lang.Number)var26);
    java.math.BigInteger var35 = org.apache.commons.math3.util.ArithmeticUtils.pow(var10, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test406"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = var21.getTiesStrategy();
    boolean var24 = var22.equals((java.lang.Object)8.310101398016423d);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var25 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var22);
    java.lang.Class var26 = var22.getDeclaringClass();
    int var27 = var22.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 3);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test407"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var12 = var9.getElements();
    var9.setExpansionMode(1);
    double[] var15 = var9.getInternalValues();
    var7.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var7);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var24 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var25 = new org.apache.commons.math3.util.ResizableDoubleArray(var24);
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    org.apache.commons.math3.util.ResizableDoubleArray var27 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    double[] var28 = var25.getElements();
    var25.setElement(100, 1.0d);
    double[] var32 = var25.getElements();
    var7.addElements(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test408"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.discardFrontElements(37);
    double[] var16 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement((-1040026098), 0.9999617128146819d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test409"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var14 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var11, (java.lang.Number)(-0.8427007929497151d), false);
    java.lang.Throwable[] var15 = var14.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var10, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var16.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test410"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var5.setContractionCriteria(2.0f);
    int var8 = var5.start();
    int var9 = var5.start();
    var5.addElement((-17.006517569654257d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test411"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.8759104446184633d, (java.lang.Number)(-10.817465674450201d), true);
    java.lang.Number var4 = var3.getArgument();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.8759104446184633d+ "'", var4.equals(1.8759104446184633d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1.876 is smaller than the minimum (-10.817)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1.876 is smaller than the minimum (-10.817)"));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test412"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)5100.5d);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var52 = var1.nextChiSquare((-10.891698820007564d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "386ff04fd03eaaf66f336f14e5775bf7a15633716b198967633dc1f503bbe33f074e724211c73c0308538efc3a20fd761f9d"+ "'", var3.equals("386ff04fd03eaaf66f336f14e5775bf7a15633716b198967633dc1f503bbe33f074e724211c73c0308538efc3a20fd761f9d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.0454530536487126d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.9665045903908158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 153L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 50.94276321228861d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 7.07800171495418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 11.559948091493176d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-10.963591722996053d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-0.5966761191444233d));
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test414"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    java.lang.Class var29 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var31 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var30);
    org.apache.commons.math3.stat.ranking.NaNStrategy var32 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    java.lang.String var35 = var34.name();
    java.lang.String var36 = var34.name();
    boolean var37 = var1.equals((java.lang.Object)var36);
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var38.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var40 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var40);
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
    java.lang.String var46 = var45.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var45);
    org.apache.commons.math3.stat.ranking.NaturalRanking var48 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var45);
    java.lang.String var49 = var45.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AVERAGE"+ "'", var35.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "AVERAGE"+ "'", var36.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "AVERAGE"+ "'", var46.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "AVERAGE"+ "'", var49.equals("AVERAGE"));

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test415"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var9.getSupportLowerBound();
//     double var20 = var9.cumulativeProbability(0.06955813697336244d);
//     boolean var21 = var9.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 69.30693888055801d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-22.862778445368885d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.19294115013142d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 16.315810013525418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.534692133985469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test417"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-1.3148171550122274d), (java.lang.Number)0.04381777757346322d, (java.lang.Number)11.269688201645035d);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 11.269688201645035d+ "'", var4.equals(11.269688201645035d));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test418"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.027344269331039d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0273442693310393d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test419"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.2689215154457405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     double var14 = var1.nextChiSquare(0.3167381609374493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "3feb7053cb778bc63f06dd8d8bf1d41c899bb962cb5b7704ff7e60355def7953ade0bcc0b79404f5a40f2dc17f57a2760911"+ "'", var3.equals("3feb7053cb778bc63f06dd8d8bf1d41c899bb962cb5b7704ff7e60355def7953ade0bcc0b79404f5a40f2dc17f57a2760911"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.581098837977635d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04182600888294269d);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test421"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-857875795), (-1250175769));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test422"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 158L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test423"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-102), 1400);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-102));

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test424"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    boolean var10 = var2.isSupportUpperBoundInclusive();
    double var11 = var2.getNumericalVariance();
    double var12 = var2.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == Double.NEGATIVE_INFINITY);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test425"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getHi();
    java.lang.Number var7 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-709046808)+ "'", var4.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.8813735870195429d+ "'", var5.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-709046808)+ "'", var6.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.8813735870195429d+ "'", var7.equals(0.8813735870195429d));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test426"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(13, (-2900));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 37700);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test427"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, (-1040026098));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test428"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    java.lang.Number var7 = var3.getHi();
    java.lang.Number var8 = var3.getLo();
    java.lang.Number var9 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-709046808)+ "'", var4.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.8813735870195429d+ "'", var5.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-709046808)+ "'", var7.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.8813735870195429d+ "'", var8.equals(0.8813735870195429d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0.8813735870195429d+ "'", var9.equals(0.8813735870195429d));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test429"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(34.46125862453039d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5417863747969005d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test430"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Throwable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var6 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var1, (java.lang.Number)12.891967632422372d, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test431"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(16.555692067908634d, 318.769031612473d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.1297261886231245E-121d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test432"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(3.0679934645157405d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3847233102934625d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test433"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var5);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test434"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(7.105427357601002E-15d, 13.55892620578028d);
    double var3 = var2.getMean();
    boolean var4 = var2.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 7.105427357601002E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test435"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.490553647691121d, var2, true);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test436"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)471897693666707008L);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (471,897,693,666,707,008) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (471,897,693,666,707,008) exceeded"));

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test437"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.534692133985469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.620677878984587d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test438"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.8080159057502068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test439"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution((-4.445804110563701d), 1.5490453007510074d, 0.0d);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test440"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(195.06923060850906d, (-1.0717582239339953d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test441"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-27985567), 19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 835014177);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test442"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1371062271), 4.056482E31f, 2.25180003E16f, 8);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test443"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Number var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 1.0d};
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var5, var6, var8);
    org.apache.commons.math3.exception.MaxCountExceededException var10 = new org.apache.commons.math3.exception.MaxCountExceededException(var3, (java.lang.Number)87.39167675879528d, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var0, var1, var8);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    java.math.BigInteger var14 = null;
    java.math.BigInteger var16 = org.apache.commons.math3.util.ArithmeticUtils.pow(var14, 0L);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var16, 0);
    java.math.BigInteger var19 = null;
    java.math.BigInteger var21 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, 0L);
    java.math.BigInteger var23 = org.apache.commons.math3.util.ArithmeticUtils.pow(var21, 0);
    java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, var23);
    org.apache.commons.math3.exception.OutOfRangeException var27 = new org.apache.commons.math3.exception.OutOfRangeException(var13, (java.lang.Number)var23, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var28 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)var23);
    java.lang.Number var29 = var28.getMin();
    var0.addSuppressed((java.lang.Throwable)var28);
    java.lang.Throwable[] var31 = var0.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var32 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0+ "'", var29.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test444"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-354871708), 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1792611939);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var12 = var1.nextGamma((-3.8208663712048767d), 18.73160423917461d);
//     java.lang.String var14 = var1.nextHexString(51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 180.63275593803192d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "71d6a928855567f0d06115f8407da97999ecf454ed14d08ead0"+ "'", var14.equals("71d6a928855567f0d06115f8407da97999ecf454ed14d08ead0"));
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test446"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     var1.reSeed();
//     double var32 = var1.nextChiSquare(0.014387441792572614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9dfa306034f25981e27932f64826a785610ed05bf306d9d55f1b58a20c2fb7509752da3c1035bafd98524a3ff03eb0f2f69b"+ "'", var3.equals("9dfa306034f25981e27932f64826a785610ed05bf306d9d55f1b58a20c2fb7509752da3c1035bafd98524a3ff03eb0f2f69b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.745132532699578d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.1953430759074664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-1.7131037514458347d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.043883918666642416d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test447"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)99, (java.lang.Number)(-0.31192009619497924d), false);
    java.lang.Number var5 = var4.getMax();
    java.lang.Number var6 = var4.getMax();
    java.lang.Number var7 = var4.getArgument();
    boolean var8 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.31192009619497924d)+ "'", var5.equals((-0.31192009619497924d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-0.31192009619497924d)+ "'", var6.equals((-0.31192009619497924d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 99+ "'", var7.equals(99));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test448"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var9 = var2.density(0.0d);
    var2.reseedRandomGenerator(3239152727494122237L);
    double var13 = var2.density(0.8688149355987415d);
    boolean var14 = var2.isSupportLowerBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.039766406469604984d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.03934181094094517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test449"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test450"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(159L, 45L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7155L);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test451"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    java.lang.String var14 = var1.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "MAXIMAL"+ "'", var14.equals("MAXIMAL"));

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(119.43016996104801d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var18 = var9.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 142.37678687319126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-22.36604761224315d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.236857394135334d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 9.575466514940842d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 100.0d);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test454"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     boolean var8 = var2.isSupportLowerBoundInclusive();
//     boolean var9 = var2.isSupportConnected();
//     double var10 = var2.getSupportUpperBound();
//     double var11 = var2.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.805028450913351d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)11.398199585377032d, (java.lang.Number)0.056811020017610465d, false);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test456"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc((-61.75727964488316d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test457"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("dffa10ac58e9ffa33ca4421ff565be807cf3312a7b4047b39c8fd7b7a53026768502c52c80d8a3b3e86071a5470661cfdd65");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(25.73489718643052d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5319581243260931d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1250178885), (java.lang.Number)(-48L), true);
    boolean var5 = var4.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test460"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.addElement((-0.9469118583888082d));
    var1.setNumElements(21);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var15 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var13, (java.lang.Object[])var16);
    boolean var18 = var1.equals((java.lang.Object)var17);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = var1.copy();
    double var21 = var1.addElementRolling(0.45737447892943917d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test462"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    float var15 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     double[] var18 = var12.sample(25);
//     double var20 = var12.probability((-1.0765151551643635d));
//     boolean var21 = var12.isSupportLowerBoundInclusive();
//     double var22 = var12.sample();
//     double var23 = var12.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41.91346815090189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.381982969042869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 3.184468154635312d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5.2697005479110315d);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test464"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2685354528034092643L), 1023863903247170432L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7643065632300934657L);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test465"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    float var7 = var1.getExpansionFactor();
    var1.contract();
    int var9 = var1.getNumElements();
    var1.setExpansionFactor(1.0000001f);
    double[] var12 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setExpansionMode(90);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test466"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.discardFrontElements(37);
    int var16 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-21));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 37);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test467"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(62);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test468"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     java.lang.String var7 = var1.nextSecureHexString(68921);
//     var1.reSeedSecure(52521875L);
//     org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var11 = var10.getNumericalMean();
//     double var12 = var10.sample();
//     var10.reseedRandomGenerator(1765921446827724705L);
//     double[] var16 = var10.sample(14);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.38274636389540045d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.3504882563948977d);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test469"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
//     java.math.BigInteger var5 = null;
//     java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
//     java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
//     java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 1918124033);
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     java.math.BigInteger var15 = null;
//     java.math.BigInteger var17 = org.apache.commons.math3.util.ArithmeticUtils.pow(var15, 0L);
//     java.math.BigInteger var19 = org.apache.commons.math3.util.ArithmeticUtils.pow(var17, 0);
//     java.math.BigInteger var20 = null;
//     java.math.BigInteger var22 = org.apache.commons.math3.util.ArithmeticUtils.pow(var20, 0L);
//     java.math.BigInteger var24 = org.apache.commons.math3.util.ArithmeticUtils.pow(var22, 0);
//     java.math.BigInteger var25 = org.apache.commons.math3.util.ArithmeticUtils.pow(var19, var24);
//     org.apache.commons.math3.exception.OutOfRangeException var28 = new org.apache.commons.math3.exception.OutOfRangeException(var14, (java.lang.Number)var24, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
//     org.apache.commons.math3.exception.NotPositiveException var29 = new org.apache.commons.math3.exception.NotPositiveException(var13, (java.lang.Number)var24);
//     java.math.BigInteger var31 = org.apache.commons.math3.util.ArithmeticUtils.pow(var24, 0);
//     java.math.BigInteger var32 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var24);
//     java.math.BigInteger var33 = null;
//     java.math.BigInteger var34 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var33);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test470"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(Float.POSITIVE_INFINITY, 0.9999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999999f);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test471"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.9339600716829778E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9337730857128728E-4d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test472"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.0584557645420212d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextExponential(161.62052203953047d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextCauchy(0.7343705104784745d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "01fa14d2fa0b9f636561e1f4efd9518133458dee43d7831f6eefd935f9f9c3c009bdb104e4d81c026f29331e4f3abaf946f6"+ "'", var3.equals("01fa14d2fa0b9f636561e1f4efd9518133458dee43d7831f6eefd935f9f9c3c009bdb104e4d81c026f29331e4f3abaf946f6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.2144942041393294d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 45L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 246.25821202653162d);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.5684148374056222d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test475"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.105428E-15f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test476"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(4.168886698498386d, (-0.1557015683410975d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test477"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.017056808209066184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     double var24 = var1.nextWeibull(13.14778027539684d, 0.6593239723930994d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var26 = var1.nextT((-2.714851868661008d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "19fe509831a0b57ee5f4768db9cb40053069e981e3ffade7faadaac8cead78835c527bf25dac4ece02cebc251129444d7658"+ "'", var3.equals("19fe509831a0b57ee5f4768db9cb40053069e981e3ffade7faadaac8cead78835c527bf25dac4ece02cebc251129444d7658"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.2629685676848872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.6092532863317448d);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test479"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-2685354528034092643L), (-2734762532608695231L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5420117060642787874L));

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test480"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    int var12 = var1.getExpansionMode();
    var1.contract();
    int var14 = var1.start();
    int var15 = var1.start();
    java.lang.Object var16 = null;
    boolean var17 = var1.equals(var16);
    float var18 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.5f);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test481"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(2.553344513602646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test482"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.6703546647110433d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1140884457841735808L, 734551466112453504L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var28 = var1.nextT(0.6037929298964898d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("09f9d20dc76c10574108ad71fa50ada680fa5d9c51556ec060ce9b43d2f1e6ec287ce35a976e92b25fdfdf3d374a5db7f817", "bc5176a01667a3c26f960b68492e46ebec761b2d01776134f29b4ba9d0ea0008f378d328df5f73ca242c2920c863a3de6076daf5bc1e428a7a068b390bb81df38d51f31380e5c7b47d4118d108a95a297c485f8b72c1454e3546828bdb5c8847e6bac30b45f61f44bbc6706f05bdf22ecb6ba901d2dbc29fb8e72865f7f1c1dae27825ba9932ae6fda5b136a9bcb06d97b7e07c1be53e7f4e82de849ee54f7c04c021b103c8d8209b4151494b99a0a00ac73d450b88ae39c2a7a849a7c60c92174212ac267c3bd4016f7f817cdd6d29a5f9b087468388e70faf4c04bad75959449d2cfcd34a3fa339877a7319c5fd9c8c320641e24d49b619a9eca85bb957cd52777db32980e7481fc7b7f21624268954d9e2a37a9e70bc97b1ddfa27d244513f80ed123ea522dc846e5bed16ba195a2034e989022fc18989b56601a7c8b847d2915f257132deed1043bd93fee40addeac309d3b0cfd90d9d50bb8c694534539cdb772e4d2841e02e683cd85693e663bb9a91b93994b78a24f1b5b32aebd371faca5d19b3a6b44db67f3f1db4eef4f83ada5d1751e18d55b195fa2edbe2ebf29565e6efaf6faaa87472db758a8c683ccfd31d2e3f23c191b47cb557c27d1afa5cb8198f66025f11592ae404ff32e1b4a9491210ec4b4d56077ca82a8a92e77d211c796bd4b2ba26d7028e49bfb42a384b5b379ff29df72b206284746216b0ca706d36b74e83fe2015658a6a00ba1eb0f1524e6c45fd8a596ee9b0dbcadd52547314f21cc0fa32f258fb3ae2384e0e7711144cee07017ac9811a56a9e2f341266c218ea666e367bfbbfbb484d78c9dbb02581ba71982f363aadfec2a85886c6524d234f143d3172c53f90834211fa2a87428d754f08a8658958bf2596b3e7c3503781a5ac351ade42a4130c2bf17cfc3226e263614f693fa84615c16cd1f2727464d4530661ab86cce4a400bbfbcbc2be06222eef29fa6fedd7250f0772e16769e633a254142bcc130a20e2401eef1c936c28736694d8ed1842cebf0a5b85b4e848bd9f28ef978b359ab8e3cd211ca8e91c90ceb4897f14e97c6c1e108ef6d2aad3252a16250a9d31af61344ffca5e3a901bdbec4c8bd4b7934757181e159c5a4186486a4eec83d9266161d5f1cf504c2d4251479955ed1ab0e9495413e4d0b41abbe5fbe025609183db971aea184ba48419e815f8877d0dc1a2a643b9d1a7e97f9e65ef568690aeaf16714876a68b5ac90babdf0208bfe4287e7b90e182c35756f19127ca6e6f09616a205006438967589a848737047c053b7ce13ade9e6d12d0e7e6690da992725e364984bfa912470285ea28200d6044ea3cd262cdffbe0a83bc6a1449c27e8d7942ae6b2cfca55a1fc6dac69825cdc6afda63b7365dff549abcb70347a5be8bd05d63c2b4ee8d22fb206d0c8e897f68f9633d0c85a8ab50084e1123276617035811d6dbe6797b9ba770b42b9c834fd913799b609402f3ced37a5b3998056626fb29fdf36f0fc36ec3cf78dc1ac3c98ee331e6b2a389a0a16316f5598f67d7d9cede004e8dabcc8b466715587b2bf4afb142980a44553d9561cb8deeace6bee18ecc2a70d248894a4efdc370b609e1105cfc87cad2690e256c73b866185314730058ea041d8bb6a135e95908cb2a280d571b2dd0c08207ba9cc6c8927d7583f5607c53bfd425b4d7b426a1f800bc7aec88a1360863dfdaada96735aee7caea80aae3c3fc71bc91fd1a8627f5f03ba2dd3bbc8c1d90ff8dc475ee5c4ccc522a4b4ea59770b5238d7160b8b8507072545d158ea3eeb8cd346d09812c2c40d12334a1c8e946093a51320f8473e385b4cf962f6c781ce25588917ac1b3bc2e04f0bf8c8641a61d4aba9f8ef0d786f30bbaff828272fe5a6b5a9403ce5b75c9cc3e08505f95cbd48acc68e67648d015a62f03ea9fe9658b8dc1b5326c222f6a939529a281045746d25197f7216e98c443417d5523dff719473f333a0480cf6c24f3a05cb7581166e45670cd426397549d62b28f0e7671960a2222bf48049bf0ddb28757ecb0a1792ed374cb38e8e518dee2faab4b6bafd466ce8eb89c242d1fdc7dea92e9e022847840a16db852dbb7aa54a282bc04347c95cbf53e390683c3e055019f61fa4df4ba805d642ae222882353ba1113c44906c233aab20218e3276b4ead8251d53883aac0deb75bb1f4b5e3b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "71ec96a5b4485f8dd9eb01cc692707e5e8c9f6d0d65f30ad9b558a0d6d4c0c3e87907c4a88ab46996a7515727e3b543e8314"+ "'", var3.equals("71ec96a5b4485f8dd9eb01cc692707e5e8c9f6d0d65f30ad9b558a0d6d4c0c3e87907c4a88ab46996a7515727e3b543e8314"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.706949937790717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 3.141985930586974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-3.5359832670462854d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-3.132188281317436d));
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test485"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    var1.clear();
    boolean var5 = var1.equals((java.lang.Object)(-0.569453864216163d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements((-536561727));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.43233232957E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4323323295700005E12d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test487"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test488"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    int var21 = var18.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var26 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var25);
    java.lang.Class var27 = var24.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var28 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var28);
    org.apache.commons.math3.stat.ranking.TiesStrategy var30 = var29.getTiesStrategy();
    java.lang.String var31 = var30.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.NaturalRanking var33 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var34 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var35 = var33.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var37 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var35);
    org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var39 = var38.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var40 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var41 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var40);
    org.apache.commons.math3.stat.ranking.NaturalRanking var42 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39);
    org.apache.commons.math3.stat.ranking.NaNStrategy var43 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var44 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var43);
    org.apache.commons.math3.stat.ranking.TiesStrategy var45 = var44.getTiesStrategy();
    java.lang.String var46 = var45.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var47 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var45);
    org.apache.commons.math3.stat.ranking.NaNStrategy var48 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var49 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var48);
    org.apache.commons.math3.stat.ranking.TiesStrategy var50 = var49.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var51 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var39, var50);
    java.lang.String var52 = var39.toString();
    java.lang.String var53 = var39.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var54 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var55 = var54.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var56 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var57 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55, var56);
    org.apache.commons.math3.stat.ranking.NaturalRanking var58 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55);
    org.apache.commons.math3.stat.ranking.NaNStrategy var59 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var60 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var59);
    org.apache.commons.math3.stat.ranking.TiesStrategy var61 = var60.getTiesStrategy();
    java.lang.String var62 = var61.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var63 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var55, var61);
    org.apache.commons.math3.stat.ranking.NaNStrategy var64 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var65 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var64);
    org.apache.commons.math3.stat.ranking.TiesStrategy var66 = var65.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var67 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var55, var66);
    java.lang.String var68 = var55.toString();
    org.apache.commons.math3.stat.ranking.NaturalRanking var69 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var70 = var69.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var71 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var72 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var70, var71);
    java.lang.Class var73 = var70.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var74 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var75 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var74);
    org.apache.commons.math3.stat.ranking.TiesStrategy var76 = var75.getTiesStrategy();
    java.lang.String var77 = var76.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var78 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var76);
    org.apache.commons.math3.stat.ranking.NaturalRanking var79 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var70, var76);
    org.apache.commons.math3.stat.ranking.NaturalRanking var80 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var81 = var80.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var82 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var83 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var81, var82);
    org.apache.commons.math3.stat.ranking.NaNStrategy var84 = var83.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var85 = var83.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var86 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var70, var85);
    org.apache.commons.math3.stat.ranking.NaNStrategy var87 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var88 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var87);
    org.apache.commons.math3.stat.ranking.TiesStrategy var89 = var88.getTiesStrategy();
    int var90 = var89.ordinal();
    org.apache.commons.math3.stat.ranking.NaturalRanking var91 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var70, var89);
    org.apache.commons.math3.stat.ranking.TiesStrategy var92 = var91.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var93 = var91.getTiesStrategy();
    java.lang.String var94 = var93.toString();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var95 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var55, var93);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var96 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var39, var93);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var97 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var93);
    java.lang.String var98 = var93.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AVERAGE"+ "'", var31.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "AVERAGE"+ "'", var46.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "MAXIMAL"+ "'", var52.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "MAXIMAL"+ "'", var53.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "AVERAGE"+ "'", var62.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + "MAXIMAL"+ "'", var68.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var77 + "' != '" + "AVERAGE"+ "'", var77.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var94 + "' != '" + "AVERAGE"+ "'", var94.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var98 + "' != '" + "AVERAGE"+ "'", var98.equals("AVERAGE"));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test489"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.11100633859097042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1105537251776405d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(12.245599971256812d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568394002505E-15d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test491"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.probability(2.3701879770272534E153d);
    double var9 = var2.cumulativeProbability(0.0d, 1.1052977241209225d);
    boolean var10 = var2.isSupportConnected();
    double var11 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.04367094510594999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.0d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(4.609460230481858d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.681124677850425d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test493"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var8 = var7.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var9 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8, var9);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    java.lang.String var12 = var11.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RANDOM"+ "'", var12.equals("RANDOM"));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(10.492940157313079d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999984619233d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test495"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.2916191771201945E-9d, (-3.062233552771116d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.1415926531680034d);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test496"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.probability(2.3701879770272534E153d);
    double var9 = var2.cumulativeProbability(0.0d, 1.1052977241209225d);
    double var10 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.04367094510594999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test497"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(54.62495358587747d, 382.7463252293418d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4866606937277864d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test498"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    java.lang.String var5 = var4.name();
    boolean var7 = var4.equals((java.lang.Object)1455);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "MAXIMAL"+ "'", var5.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test499"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0f, 235);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test500"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    double var7 = var1.addElementRolling(10.647765883852417d);
    int var8 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

}
