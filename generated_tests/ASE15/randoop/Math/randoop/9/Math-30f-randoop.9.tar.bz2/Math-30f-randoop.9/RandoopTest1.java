
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.743169379036474d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(10.631760722610178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-1079717575831374079L), (-2025644137419103232L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(5.964535219365547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18249332238610877d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-1), 0.0f, 2.5f, 21);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(12.619549777941744d, (-0.31192009619497924d), 2.2033961708364793d, 25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.5410312241221764d, 161.62052203953047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.029305881086436798d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(82.16419961411961d, 1.0652279546366723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 82.16419961411961d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.3239643710462448d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.05531224118406357d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05536875319285179d);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var15 = var12.getSupportLowerBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var12.cumulativeProbability(0.0d, (-20.942511449578625d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 88.13754372442956d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-4.539276687701201d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NEGATIVE_INFINITY);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    double var10 = var8.addElementRolling((-5.966735624802988d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var1.nextGaussian((-0.6135250304572957d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ae6ab07b7809d5e49176a6274ad6c8ceb70b72c8661146bbd6b351721882d567f4e800f211ad3c1c26447c065dd2af5a86d1"+ "'", var3.equals("ae6ab07b7809d5e49176a6274ad6c8ceb70b72c8661146bbd6b351721882d567f4e800f211ad3c1c26447c065dd2af5a86d1"));
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(1L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(41.1579177839406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9501083378171749d));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.5105879151683443d, 0.4505451791095725d, (-48.283198828346514d), 3116);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(4.0564817E31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0564817E31f);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextWeibull(15.460567089740497d, (-3.500621146179967d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 95.59936697409775d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 11L);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(3.941334262707623E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.001985279391598982d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var5.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.45449212268513506d, (-6.012650514045718d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0661468148762574d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3L, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 81L);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-48L), 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52L);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var1.nextHypergeometric(6, 3116, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9a78b2239838b3ea043627b7ce7bc3e86a85ef2bf0f3e5021b1a32809b9cdf77c2fadd2358a4421992c72ce2f82a6a67db1d"+ "'", var3.equals("9a78b2239838b3ea043627b7ce7bc3e86a85ef2bf0f3e5021b1a32809b9cdf77c2fadd2358a4421992c72ce2f82a6a67db1d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.7387274519488511d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.0f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(99, 0.0f, 1.2676505E30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(3.9443045E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-98));

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.0490427775533642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal((-1246114372), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var1.nextGaussian((-5.554992858506394d), (-33.45962083513478d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "2debb01c91dc24857232cf14f40a9f040ae12d1d42ac28d728eaaf9f74fa729237b792af2b41d3779a25820acccadc4264e5"+ "'", var3.equals("2debb01c91dc24857232cf14f40a9f040ae12d1d42ac28d728eaaf9f74fa729237b792af2b41d3779a25820acccadc4264e5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-117));
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-14.306620465386846d), 4.787491742782046d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.306620465386846d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-3), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3));

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(81L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.88165097273383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-3.8650718561370216d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.015634435663060296d);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.28595303919034754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.28595303919034754d);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-2025644137419103232L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
//     java.math.BigInteger var6 = null;
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
//     org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
//     org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var14);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(52.217050732695114d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 52.0d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-5293152609383083007L), (-2025644137419103232L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-12.921651213657304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999999999880483d));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    int var4 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements((-3));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric(6350, 99, (-1246114372));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    var1.setNumElements(21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement(1918124033, (-33.45962083513478d));
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(0, (-1246114372));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(388245.49661804835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12.869393141762847d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)1+ "'", var3.equals((short)1));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-1.5990882529556831d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.0d));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(60.22939531600713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 60.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-5293152609383083007L), (-475858716));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-1246114372), (-285567));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(6316);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 48959.60849928691d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3116, 2325);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var17 = var1.nextChiSquare(0.24433316542704286d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextHypergeometric(25, 34, 6350);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14.021209942640178d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-18.27664498085198d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0028942820971266624d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var6 = var1.nextHexString((-709046808));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5d, 2.9031491046806814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.945891159565852d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.8019969832524574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9306309476632383d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(8.310390625902146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.616242248904851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999996848245061d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(48.40854295060508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8448884605811494d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
//     java.math.BigInteger var3 = null;
//     java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, var3);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2025644137419103233L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2025644137419103233L);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.3167381609374493d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.34580018289384457d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(3.9443045E-30f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443045E-30f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(2.511625001684894d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7290651857988871d));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(15.104412573075516d, 0.8448884605811494d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0407924575577585E-14d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     var0.reSeedSecure();
//     int var14 = var0.nextInt(25, 6350);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(3, 15);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-12.015884141058736d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.685252310914224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.04063073182370108d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 267);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(5.871300865235717E76d, 4.87681109080397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)(-285567), (java.lang.Number)4.288817095277553d);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextF((-3.149426875672435d), (-20.942511449578625d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2896874807521622d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 11.59163699698423d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.3616824051746083d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(81L, 20L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(41, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 68921);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(7, (-475858716));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(4.288817095277553d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9116266451657968d));

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray((-1246114372), 4.0564817E31f, 0.99999994f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.2676505E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2676505E30f);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.2676506E30f, 3.9443045E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443045E-30f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var2.cumulativeProbability(92.67232803812807d, 0.409278872838869d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13.611154483612507d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(11);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(44.007788545081404d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.4760430967139901E18d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(5.871300865235717E76d, (-5.554992858506394d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var1.nextWeibull(0.0d, 0.8487758449442926d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e3eb94018ae79f1a1f91df44c6ac261dcf05635ab3bcc5f984192ad5bf4e29fd0ab61d4859a2f31f2151e27f31fb5f4e5988"+ "'", var3.equals("e3eb94018ae79f1a1f91df44c6ac261dcf05635ab3bcc5f984192ad5bf4e29fd0ab61d4859a2f31f2151e27f31fb5f4e5988"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.9159440920972126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(Float.POSITIVE_INFINITY, (-15.379210584652093d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028235E38f);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 3.9443045E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("fde8b02df6adf47ea7780d79628ddc4d5f4e408c9c4e9a6c4844ca31d3a4f644767a6ff47d4170c6ab18e21a72630766870e");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.000001f);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-33.45962083513478d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 4.0564817E31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0564817E31f);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    int var4 = var2.ordinal();
    java.lang.String var5 = var2.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(0L, (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90L);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var1.nextPascal(21, 18.409703235248998d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 45.8646288198679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575192898069786d));
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(14.4057782350127d, 71.73148974086561d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2025644137419103233L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var1.nextPermutation(1, 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "abe9123639a8c2eb6263e6b4e4d556ac36d19770fa5ab7fd5f0840a2f000ffdc4fac4185438a2f6bdd7174ed721b27fc5d0f"+ "'", var3.equals("abe9123639a8c2eb6263e6b4e4d556ac36d19770fa5ab7fd5f0840a2f000ffdc4fac4185438a2f6bdd7174ed721b27fc5d0f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.2860200270925484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 96);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(7.368762894278631d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9972498351617085d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-2025644137419103232L), 41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-475858716), 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-475858716));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-48L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48L));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(68921, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 68921.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.15878594727189455d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.17767626729284788d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(5L, 2025644137419103233L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5L);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(90L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(16L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     double var15 = var1.nextExponential(0.05525590189455726d);
//     java.util.Collection var16 = null;
//     java.lang.Object[] var18 = var1.nextSample(var16, (-127));
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-2.5234561182532795d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.275903843016983d);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var1.nextSecureLong(10L, 5L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 126.05555417444307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 16L);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    int var4 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode(11);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.24433316542704286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(45.9548879662945d, 41.1579177839406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.796970182353903d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.10856505939282417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.10814152117337966d);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(81L, 796684296743799808L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7385977944948490239L));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(7.421527624138719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6929619485051077d);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var1.nextBeta((-2.296763228752664d), 4.796970182353903d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-209895956));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 60.8165712396914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 34.4525184149721d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10.581204688510276d);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-12.921651213657304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.34785345449505795d));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(6.4760430967139901E18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.811309730230008d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)1);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(3.4028235E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.4028235E38f);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1246114372), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.getElement((-285567));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.140692632779267d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.99999994f, (-1246114372));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(27, (-1246114372));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("eac4def4ab9ac0336fc96");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.6293945E-6f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(100L, 2025644137419103217L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9920261657645205d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6966928874609568d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-3), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.Class var3 = var2.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var5 = java.lang.Enum.<java.lang.Enum>valueOf(var3, "MAXIMAL");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     java.lang.String var4 = var0.nextHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextSecureLong(16L, (-2025644137419103232L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "35e"+ "'", var4.equals("35e"));
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6689087058498807d, 0.7853981633974483d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6689087058498808d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(3.9443045E-30f, 0.4505451791095725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.944305E-30f);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(3.944305E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.9443053E-30f);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(9, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 63);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(63, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextWeibull(51.245022111424404d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "5c7bf07e12019dda2037f48f3ddc3a8b97f1c4fde1748d35acad9c6ded8577f77d8189e8e5477fa4fd28ad35fb2a9aa2390e"+ "'", var3.equals("5c7bf07e12019dda2037f48f3ddc3a8b97f1c4fde1748d35acad9c6ded8577f77d8189e8e5477fa4fd28ad35fb2a9aa2390e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7615322163922873d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(0.10856505939282417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86.26126875387966d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.653003061395369E15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.653003061395369E15d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(6350, (-424592841));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-12573), 10.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-33.45962083513478d));

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100L, (java.lang.Number)(-127), false);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(3.9443053E-30f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443053E-30f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    float var7 = var1.getExpansionFactor();
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var1.getElement(15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(3.5503307537534594d, 0.25899527163410974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25899527163410974d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5f);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1071487177940904d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(10.0f, Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9996235311546176d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8412675181971214d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.25899527163410974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.28583983826614007d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-857875772), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-857875772));

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var4.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setElement((-12573), 1.5707963267948966d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-1024.0d), 5.902131729148383d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024.0170092136889d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(6316);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6316);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(3116);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(3.944305E-30f, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3234891E-22f);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextF(34.18399124084686d, (-0.9501083378171749d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "89fbb217020a8aaa6411628a5312b7fdc52abab2dc68d5cf16c402f4834be0627f5bf74d87a6667db7ece99cbd5ede7f3004"+ "'", var3.equals("89fbb217020a8aaa6411628a5312b7fdc52abab2dc68d5cf16c402f4834be0627f5bf74d87a6667db7ece99cbd5ede7f3004"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5973636408360563d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    int var4 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.getElement(1270);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardMostRecentElements(0);
    int var6 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var17 = var1.nextChiSquare(0.24433316542704286d);
//     int var20 = var1.nextBinomial(29, 0.6689087058498807d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var1.nextBinomial(4, 92.67232803812807d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 376.30284217010706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9.934550236562224d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.4362355666453187E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 17);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(3.262910457220339d, 4.9E-324d, (-96.56639765669303d), 7);
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var1.getElement(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1L);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-100.0d), 3.554557535700598E74d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.05525590189455726d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05525590189455725d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.05525590189455726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextExponential((-1.1217129806834838d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var4 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(0);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(0, 99);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(1270, 34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 153.96375823857784d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var13 = var0.nextSecureHexString((-12573));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.177149595671697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8793131167223559d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.7803058376403159d));
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(1.0490427775533642d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.499312767637402d));

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-3.481613158473225d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.0d));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.9015003191306246d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.072261697491794E-5d);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var1.nextSample(var13, (-285567));
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-709046808), 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-709046803));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(3.9443053E-30f, 3.9443053E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443053E-30f);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.06446622075849562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0665895490501696d);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(13.221586840309266d, (-9.97957116873205d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.902131729148383d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.277215394896082d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta((-0.48609186402077603d), 32.28295038812199d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.963890365200829d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-3.6845785043159394d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-8.079484040117867d));
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    float var15 = var1.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(1.4E-45f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-5.592657401586155d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.592657401586155d));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double[] var8 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int[] var12 = var1.nextPermutation(99, 25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var1.nextBinomial(0, 137.03314037205797d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "59f9721ea8f0136fc3d7d57d84cb9d9a078449cd60f7230ebf2c7ba3d986a812547b89376ab7db7f18a52eda6f9486de30a1"+ "'", var3.equals("59f9721ea8f0136fc3d7d57d84cb9d9a078449cd60f7230ebf2c7ba3d986a812547b89376ab7db7f18a52eda6f9486de30a1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7498071862804598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo((-48L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(35L, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52521875L);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(6.478855030016662d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6L);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.7081217519889299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2613714995468743d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-6.509833404337565d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-372.98597940182316d));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(14.237606813581872d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07276079903139297d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-1.1217129806834838d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9008454368428132d));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("13ff962121d58b7d9fc41a90fb09151918f9e9edeb0845ce1929a655fb00e6b51c3ca3800fd052ae6c7d82bf6be5db3ec0bd");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(7, 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    double[] var7 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = var6.rank(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1918124033, 99);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     double var3 = var0.getMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.47295685506987295d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(14.237606813581872d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements((-101));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.9575217061535136d), (-7.525707841821965d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9575217061535136d));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(3.0661468148762574d, 0.25899527163410974d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0661468148762574d);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-285567));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(5.717858802944031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.44430201837607d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(14.4057782350127d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    double[] var23 = var20.getElements();
    var20.setExpansionMode(1);
    double[] var26 = var20.getElements();
    double[] var27 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var28 = new org.apache.commons.math3.util.ResizableDoubleArray(var27);
    org.apache.commons.math3.util.ResizableDoubleArray var29 = new org.apache.commons.math3.util.ResizableDoubleArray(var28);
    var28.setNumElements(1);
    int var32 = var28.getExpansionMode();
    double var34 = var28.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var36 = var28.addElementRolling(100.0d);
    double[] var37 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var39 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var38);
    double[] var41 = var38.getElements();
    var38.setElement(100, 1.0d);
    double[] var45 = var38.getElements();
    var28.addElements(var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var47 = var18.mannWhitneyU(var26, var45);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-5.592657401586155d), 4.796970182353903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var6 = java.lang.Enum.<java.lang.Enum>valueOf(var4, "a66c747ae6c4e8451b4b1bc2da639ac6d2bcf9babaec2f8d1c0dcec6bbd2716680bac11a63c6404590b00832adebb6548fb3");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(10.737739771706677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)Double.NaN, (java.lang.Number)2.251752586176186d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 2.251752586176186d+ "'", var4.equals(2.251752586176186d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    var1.addElements(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(63);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(48.40854295060508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9593396120699826d));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(2.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.0502044810397875d);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.9469118583888082d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-48L), 81L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    int var5 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.substituteMostRecentElement(1.0490427775533642d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(6.6994687043218795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8255428484529448d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)18.811309730230008d);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var1.nextSecureLong(1079717575831374079L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(2025644137419103217L, 1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1765921446827724705L);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)0.8813735870195429d, (java.lang.Number)(-709046808));
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getHi();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-709046808)+ "'", var4.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-709046808)+ "'", var5.equals((-709046808)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.8813735870195429d+ "'", var6.equals(0.8813735870195429d));

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextLong(2025644137419103233L, (-1079717575831374079L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-100503782));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 65.92576644637502d);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.inverseCumulativeProbability(0.24433316542704286d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var12.inverseCumulativeProbability((-2.1928841181204515d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 93.82928908157109d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-9.896097604523622d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-7.725459552628436d));
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(8.881784197001252E-16d, (-7.249376137847348d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextT(6.066191094237188E76d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextChiSquare((-3.141592653589793d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22.042757681654646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 5.349549817985301E-10d);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.2676505E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(52L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90L);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var9 = var1.nextGamma((-0.9469118583888082d), 0.444936230537876d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var1.nextPermutation((-475858716), 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a9e8b28940843856a717de992664620ac84252ea73f02c019118717a77c8a3ecbdb49280343e535c3a0fde401205da397e5f"+ "'", var3.equals("a9e8b28940843856a717de992664620ac84252ea73f02c019118717a77c8a3ecbdb49280343e535c3a0fde401205da397e5f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-61));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.7934576340192033d);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-96.56639765669303d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5.263404819294253d));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(50.94909583146956d, 0.3109533698211559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.2971670618811463d));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double var3 = var2.getSupportLowerBound();
    double var4 = var2.getMean();
    boolean var5 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4920673008707643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-101), (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var1.nextGaussian(0.0d, (-14.306620465386846d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7a6c501086bc2897fe19c9cd987aa30d45bdab3264475884993739334428dc508e44907e84a7c3475e78ad4e4d9d70cb20e0"+ "'", var3.equals("7a6c501086bc2897fe19c9cd987aa30d45bdab3264475884993739334428dc508e44907e84a7c3475e78ad4e4d9d70cb20e0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.558921461300996d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    org.apache.commons.math3.exception.NotStrictlyPositiveException var16 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var17 = var16.getMin();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var21 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var20, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var19, (java.lang.Object[])var21);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var18, (java.lang.Object[])var21);
    boolean var25 = var1.equals((java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0+ "'", var17.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.getElement((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException(var0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.0d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.994882708773989d, 1.0031174857053113d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7812766771598918d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-1L), 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8L);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(46.15017443662932d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, (-1246114372));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getElements();
    int var3 = var1.start();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.31192009619497924d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.32267104745890796d));

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(3.141592653589793d, 6.0502044810397875d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2.9086118274499944d));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { "7a68f2371ae1e1005c331212e6594b375ac12980c2456411077d5acafe0ca02121a71ffd8e53aff8bc7ea581ffd9c74f4e91"};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextChiSquare((-0.499312767637402d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 177.91694703884565d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.3234891E-22f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(0, 10.000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(48.40854295060508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.957624806685474d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.029305881086436798d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-0.7014095186799629d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1L));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.3846891693829083d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.926915123177908d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-7385977944948490239L), (-90L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-7385977944948490239L));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.8937409545102801d, 0.4920673008707643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4920673008707643d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-6.012650514045718d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.4938574539986456d));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextSecureInt(11, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "d3f9343896a038374fa9512ca66a37d9ddc22dba998afadf2ddf40d3539c05752a799ae109fcee9843e2de3e289075b647be"+ "'", var3.equals("d3f9343896a038374fa9512ca66a37d9ddc22dba998afadf2ddf40d3539c05752a799ae109fcee9843e2de3e289075b647be"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.46840860054885686d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.5873147141314963d);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(21954.99676616325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707507790769917d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.5f, (-1024.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4999998f);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.9972498351617085d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.3239643710462448d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)9.585079465807741d, (java.lang.Number)29.171528454339946d, (java.lang.Number)6.6994687043218795d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.7081217519889299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6593074703968533d));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 35);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    double[] var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.substituteMostRecentElement((-0.8427007929497151d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var6 = var5.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setExpansionFactor(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(3.944305E-30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    org.apache.commons.math3.util.ResizableDoubleArray var14 = new org.apache.commons.math3.util.ResizableDoubleArray(var12);
    var12.discardMostRecentElements(0);
    double[] var17 = var12.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = var10.rank(var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(13.562540322321134d, 0.08631729905748209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 13.562540322321134d);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-3.141592653589793d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-9.97957116873205d), 153.96375823857784d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(63, (-709046808));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma(21.21962015148548d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0482540721020254d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    double[] var20 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var20);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = new org.apache.commons.math3.util.ResizableDoubleArray(var21);
    double[] var24 = var21.getElements();
    var21.setExpansionMode(1);
    double[] var27 = var21.getElements();
    double[] var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var29 = var19.mannWhitneyUTest(var27, var28);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextUniform(8.310101398016423d, (-20.13425831022753d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 56.507820457242765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-18.167951335630157d));
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(100, (-1.0f));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(10, 6350, 41);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-11.995008035828592d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.9822834154187798d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0565508944491568d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextWeibull((-0.9999999999880483d), 0.05525590189455725d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7068b490c8d7615f471639e2900defb0a8394343b88f2228ff982845617a8030799e366000011697a862c2278d447f8d99f7"+ "'", var3.equals("7068b490c8d7615f471639e2900defb0a8394343b88f2228ff982845617a8030799e366000011697a862c2278d447f8d99f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.451605967341339d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.6689087058498808d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7199192644760765d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var6);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setExpansionMode(1);
    double[] var17 = var11.getInternalValues();
    var9.addElements(var17);
    double[] var19 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var7.mannWhitneyU(var17, var19);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-3.4912013887630056d), (-18.49783622745589d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3.4912013887630056d));

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(100.0d, 0.029305881086436798d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9669413185600446d));

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var5.probability(2.9015003191306246d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5.870420305892309d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-4.511861907636127d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0f, (-1246114372));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-15.379210584652093d), (-0.842700792949715d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.6255363870684183d));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.0652279546366723d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var5);
    var1.addSuppressed((java.lang.Throwable)var7);
    java.lang.Number var9 = var1.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var1.getContext();
    java.lang.Number var11 = var1.getMin();
    java.lang.Number var12 = var1.getMin();
    boolean var13 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0+ "'", var9.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0+ "'", var12.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.4505451791095725d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.06446622075849562d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-50), 4.0564817E31f, 3.944305E-30f, 16);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-8.342677074928472d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-8.342677074928472d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8829460668859715d));

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh((-1024.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.10814152117337966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3877787807814457E-17d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    double[] var8 = new double[] { 10.0d};
    var1.addElements(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(5);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(2, 0.0f, Float.POSITIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.7763568394002505E-15d, (-285567));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-3.500621146179967d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var1.nextZipf((-1246114372), 6.6994687043218795d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "11fc96ef3b7b3fe00df7e4e42b19f94cee4ce8ec30411a26358893203d0d7098deb71a088109423bf0607594d3461f0d3759"+ "'", var3.equals("11fc96ef3b7b3fe00df7e4e42b19f94cee4ce8ec30411a26358893203d0d7098deb71a088109423bf0607594d3461f0d3759"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.691114507110868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 33);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.001985279391598982d, (-18.49783622745589d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var2 = var1.getMin();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var5);
    var1.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(5.717858802944031d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8444137398760581d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.056811020017610465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.056750019064709015d);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(6, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(342.4199650603462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.2033961708364793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2033961708364798d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addElement((-0.7014095186799629d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2025644137419103233L, 35L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(2325, 27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 20925);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(3.9443045E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.944305E-30f);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(2025644137419103217L, (-7385977944948490239L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.9604645E-8f, 41.1579177839406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960465E-8f);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 3.9443045E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 40320.0d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(60.22939531600713d, (-0.9469118583888082d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5865167876725306d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1020.8946023707998d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var1.nextBeta((-0.499312767637402d), 0.4250390327064186d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "246dd421107828dc43a346ba8925177cc99a53fd34ae6d506d82eb5989320623eb4aa5f2948b20c1ce5c97594d926572a763"+ "'", var3.equals("246dd421107828dc43a346ba8925177cc99a53fd34ae6d506d82eb5989320623eb4aa5f2948b20c1ce5c97594d926572a763"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9143367513802484d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.9999996848245061d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999998424122406d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1079717575831374079L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3239152727494122237L);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-1), (-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var2 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    java.lang.Object[] var5 = new java.lang.Object[] { var4};
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)0.6689087058498807d, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    double var1 = org.apache.commons.math3.special.Gamma.trigamma((-0.15878594727189455d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 41.79124149463175d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(0.056811020017610465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06403547272509107d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (-0.843)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.TiesStrategy var4 = var3.getTiesStrategy();
    int var5 = var4.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(8.881784197001252E-16d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog((-98));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(90L, 3239152727494122237L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { 9.717962678996846d};
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.21026326803771d, 3.554557535700598E74d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1844690163969658E-74d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1270, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 340591140L);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(29, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    java.lang.Class var7 = var5.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var9 = java.lang.Enum.<java.lang.Enum>valueOf(var7, "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-113), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.3674212569981512d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0.3674212569981512d+ "'", var2.equals(0.3674212569981512d));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.18568883177235446d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18359772074703207d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, (-1250178885));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(3.9443045E-30f, 5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443045E-30f);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(52.0d, 0.3348783370934335d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52.001078291710975d);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.lanczos(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(8L, 100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 800L);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(7.421527624138719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     double var4 = var2.getNumericalMean();
//     double var5 = var2.getSupportLowerBound();
//     double var7 = var2.density((-0.34785345449505795d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.0415674659346443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03985326335832463d);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.491885680229876d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 89.28965897542128d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(4.596554432623215E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999998943584386d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(81L, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6690628879615364881L);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.4E-45f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(183.7831100704683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.546219607973257E79d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1L, 81L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 81L);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var6 = var2.getSupportUpperBound();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var2.cumulativeProbability(0.0d, (-22.83906333439039d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 3.870533141263707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getNumElements();
    org.apache.commons.math3.util.ResizableDoubleArray var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray.copy(var3, var5);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble(2, 6316);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-1.5338330044989135d), 32.94631867978169d, 1.5410312241221764d, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 52521875L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 52521875L);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-6.509833404337565d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9999955673893874d));

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-12573), (-12573));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-12573));

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8bf972cbd8a6833da0a6d90bd54571515f2131bce29bc60b50bbe616aa5d9eb4bd0d9969037239a1b661a28d00a762139a6a"+ "'", var3.equals("8bf972cbd8a6833da0a6d90bd54571515f2131bce29bc60b50bbe616aa5d9eb4bd0d9969037239a1b661a28d00a762139a6a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.9017801357261543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 86);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1270, 1.0f, 7.6293945E-6f, (-700251660));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(1968802768399923712L, 670369391491839744L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1298433376908083968L);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-6.382261505253501d));

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)52.217050732695114d);
    java.lang.Number var2 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 52.217050732695114d+ "'", var2.equals(52.217050732695114d));

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, (-50));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-3.0d), 0.994882708773989d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.015351873678033034d));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1250178885), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1079717575831374079L), (java.lang.Number)(-2), false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(13.562540322321134d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3847728247431226d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.17767626729284788d, (-0.5638799963082057d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    boolean var6 = var2.equals((java.lang.Object)(-1.3106591446783056d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(2, Float.POSITIVE_INFINITY, 1.2676505E30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.1054274E-15f);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     double var16 = var1.nextGaussian(10.0d, 0.5203870299333744d);
//     long var19 = var1.nextSecureLong(0L, 16L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var1.nextSecureHexString((-98));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-987460740));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 35.66092099037706d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21.631352724030286d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10.259305552779896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7L);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)2.7755575615628914E-17d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Enum var2 = java.lang.Enum.<java.lang.Enum>valueOf(var0, "99fcb00d6d5b7f8bf54f00bb735ec3b126fec07b81ca8375d07aa60f915448da5cebcb39a27aa595b62153f889779209f7ed");
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(77.12161787665714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4418.743213553135d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double var2 = org.apache.commons.math3.special.Erf.erf((-0.7205034392111951d), (-147.2496438325565d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.3082287291988043d));

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.105427357601002E-15d, (-0.48609186402077603d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.105427357601001E-15d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(3.277215394896082d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999964251419585d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(21.135042997261277d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 21.0d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-285567), (-98));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27985566);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)81L, (java.lang.Number)(-90L), true);
//     java.lang.Throwable var5 = null;
//     var4.addSuppressed(var5);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-475858716), 27985566);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-447873150));

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(12, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.828712071641684d);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1250178885), 6316);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 490123985);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (-90) exceeded");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, (-447873150));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-447873150));

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(32.28295038812199d, 3.0819349383815045d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.32394442803036927d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(1.1844690163969658E-74d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3365301621724433E-74d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-424592841), 2.5f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-2.2100466270217347d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(8, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 8);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.4305461357838371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.44337357354325d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-100.0d), 38.13608131498478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 107.02504705938293d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.9999955673893874d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403060357760492d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.8420375366826974d, 77.43499018943342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.010873693502615977d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-15.379210584652093d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.32286276221102783d));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(89.28965897542128d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.1850015020856235d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextUniform(41.79124149463175d, 0.06146076675140928d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "35eff4dc8fe727899d98df7285a7193fc383718bfa82905fc28b549c5fb6aac53062e8563ab48ae87f932818be07061aba05"+ "'", var3.equals("35eff4dc8fe727899d98df7285a7193fc383718bfa82905fc28b549c5fb6aac53062e8563ab48ae87f932818be07061aba05"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.6392382722489136d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.3553821332786191d));
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-15.379210584652093d), 13.221586840309266d, (-0.5086137103625639d), 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-0.569453864216163d), (-24.381372673272917d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(12, 0.0f, 1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(670369391491839744L, 5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 670369391491839749L);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     double var16 = var14.getStandardDeviation();
//     var14.reseedRandomGenerator((-2025644137419103232L));
//     double var19 = var14.getSupportUpperBound();
//     double var20 = var14.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "f868121944bfdf0b90886899618af4b9474c4ab02a253b2be43c3b182238818b7c9990042e5ee6e6dfaf7e9058e4211a40db"+ "'", var3.equals("f868121944bfdf0b90886899618af4b9474c4ab02a253b2be43c3b182238818b7c9990042e5ee6e6dfaf7e9058e4211a40db"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.939687141316521d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.5582262697631099d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.0d);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var17 = var1.nextChiSquare(0.24433316542704286d);
//     int var20 = var1.nextBinomial(29, 0.6689087058498807d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var1.nextBinomial(2, 81.93186623463397d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 197.0576195556047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.294413783349691d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.19013046230116112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 22);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-1250178885));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-18.0237441949784d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-3.585605877551174d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    float var7 = var1.getExpansionFactor();
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(3.9443045E-30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.7081217519889299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.8562680473806946d));

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("51fcd6fa903b49f36bb107c802cf78cdfa1804a0e9723a5946ae76a45ccd17eeabe558d825db034fdc387445ae36b9bc47b7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-127), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.2676505E30f, 3.9443053E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9443053E-30f);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-127), 490123985);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.7242441387499587d, 2.3847728247431226d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.4923224105534505d);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    double var4 = var2.getSupportLowerBound();
    double var5 = var2.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-17.579035444652284d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.8011436155469337d));
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.16227766016837952d, (-2.0439843355597187d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0623660255387573d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.2852674744692656d, 4.491885680229876d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0010683551813067025d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(52.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-0.48609186402077603d), 1.2099696949580587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2099696949580587d);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     java.math.BigInteger var0 = null;
//     java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 15);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP((-1.6255363870684183d), 92.67232803812807d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-285567));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(4.0564817E31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, (-2025644137419103232L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-3), 11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(98.34594008196873d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.588491263677662d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.6037929298964898d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    double[] var7 = var1.getInternalValues();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(25, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "127e56891497aaf2d3ac9a7339d469afe469d4ee4a4413cc06ea5b79b67426b3f332eddfa37b9469983395ec6a472cf3bb2b"+ "'", var3.equals("127e56891497aaf2d3ac9a7339d469afe469d4ee4a4413cc06ea5b79b67426b3f332eddfa37b9469983395ec6a472cf3bb2b"));
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, 7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(90.54881795295192d, 1.5865167876725306d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.6689087058498808d, (java.lang.Number)Double.NaN, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.6689087058498808d+ "'", var5.equals(0.6689087058498808d));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(1270, (-50));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-63500));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-12.921651213657304d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.4445458134648095E-6d);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.0d, (-100.0d), (-5.263404819294253d), (-101));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-0.7290651857988871d), 10.737739771706677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.762462146276535d);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }
// 
// 
//     double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(0.9996235311546176d, (-1.6255363870684183d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.99999994f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(1.8937409545102801d, (-2.0439843355597187d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.8937409545102801d));

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     double var9 = var1.nextGamma((-0.9469118583888082d), 0.444936230537876d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextUniform((-0.9575170352300982d), (-19.545787007406858d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e1ebd495ae5de493fa4b49044bddba995a99606b749c907e3504eb9440640ecd65dccecb0635d4fc487eaaa9c7c186810ce2"+ "'", var3.equals("e1ebd495ae5de493fa4b49044bddba995a99606b749c907e3504eb9440640ecd65dccecb0635d4fc487eaaa9c7c186810ce2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-35));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9361026704106308d);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(179.870724080515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6967477223995986d));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(3.944305E-30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.761582E-37f);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)68921, (java.lang.Number)18.73160423917461d, true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNumElements((-12573));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd((-7385977944948490239L), (-7385977944948490239L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7385977944948490239L);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(5.960465E-8f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(22.433204357820724d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.39153327781671177d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(5.169339496286199d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 175.7986834449043d);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(38.13608131498478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(670369391491839744L, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric((-56), 2325, (-101));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(10L, 340591140L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 340591140L);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(0, Float.POSITIVE_INFINITY, 1.0000001f, 25);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(10, 1.2676506E30f, 1.3234891E-22f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3L, 800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3847543214195546753L);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }
// 
// 
//     double var1 = org.apache.commons.math3.special.Gamma.logGamma((-0.6400093249157379d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(16L, (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 16L);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.2676505E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 99);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(48959.60849928691d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.491898101271794d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.getElement((-3));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.5d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.960466E-8f);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed(16L);
//     double var19 = var1.nextUniform(2.0d, 14.237606813581872d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var1.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "987f304570447dfb20f51cd7aa94db0d8bdb13c263b1835842bcf18d63f363e7fc18a6438813d8230c64c77f111f7481a7da"+ "'", var3.equals("987f304570447dfb20f51cd7aa94db0d8bdb13c263b1835842bcf18d63f363e7fc18a6438813d8230c64c77f111f7481a7da"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.4124002844703942d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12.152754637483802d);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(0L, 2025644137419103233L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2025644137419103233L);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.029305881086436798d, (-4.800114953065839d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    java.lang.String var5 = var2.name();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var10 = var7.getElements();
    var7.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var15 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var15);
    boolean var17 = var7.equals((java.lang.Object)var14);
    boolean var19 = var7.equals((java.lang.Object)'#');
    var7.contract();
    float var21 = var7.getContractionCriteria();
    boolean var22 = var2.equals((java.lang.Object)var7);
    org.apache.commons.math3.util.ResizableDoubleArray var23 = var7.copy();
    var7.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(1968802768399923712L, 90L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(2.9172543562621576E307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("99fcb00d6d5b7f8bf54f00bb735ec3b126fec07b81ca8375d07aa60f915448da5cebcb39a27aa595b62153f889779209f7ed");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1918124033, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1918124033);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(79.26372034878028d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.06588791181404d);

  }

}
