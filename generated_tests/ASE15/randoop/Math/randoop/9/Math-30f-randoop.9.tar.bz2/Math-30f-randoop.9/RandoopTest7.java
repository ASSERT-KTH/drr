
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.8541763619588167d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.99999994f, 2.842171E-14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.99999994f);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(4152318856435597312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4152318856435597312L);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.addElementRolling(3.262910457220339d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.4E-45f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed(16L);
//     int var18 = var1.nextBinomial(95, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var1.nextT((-1.1459234617400742d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "3de8d0ef6f54d2b0d6dcdc8c0d8f1018121602bba80d1610b63aea5ca4ffee2b9a837f17107bba5115d09217b3dac656659d"+ "'", var3.equals("3de8d0ef6f54d2b0d6dcdc8c0d8f1018121602bba80d1610b63aea5ca4ffee2b9a837f17107bba5115d09217b3dac656659d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.9767793625527d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(0.2826121345438895d, 173.61985447484932d, 0.8974256635155496d, (-354871708));
      fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException");
    } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(4.802880146377583d, 0.8487758449442926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.802880146377582d);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     double var15 = var9.probability(53.78712722644688d);
//     boolean var16 = var9.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "107c56ca4a6bddcc8092c24416bb1833aa376eaf09c3485ee47b97ed267f4a4449057e2d64562e58fd298e4f89e534c8127c"+ "'", var3.equals("107c56ca4a6bddcc8092c24416bb1833aa376eaf09c3485ee47b97ed267f4a4449057e2d64562e58fd298e4f89e534c8127c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-112));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 5.529861066965232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(4.5918E-41f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.10814152117337966d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0058529949977943d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(73.48387693522042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 74.0d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.5698197646053373d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.5698197646053371d));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.probability(2.3701879770272534E153d);
    double var7 = var2.getMean();
    double var9 = var2.cumulativeProbability(6.828712071641684d);
    double var11 = var2.cumulativeProbability(99.66210960879508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.7772639987765143d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(651230987);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 651230987);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionMode((-96));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-28.430126749359413d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.15516341247348966d);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.cumulativeProbability(0.0d);
//     double var4 = var0.probability((-0.6467142473032144d));
//     double var5 = var0.sample();
//     double var7 = var0.density(2.633242452616744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.6663373223778527d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.012451409615697382d);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialLog(1270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7810.893058144583d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-0.7656658570186433d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.MaxCountExceededException var5 = new org.apache.commons.math3.exception.MaxCountExceededException(var0, (java.lang.Number)3.9034157645529923d, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.contract();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var8 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    double[] var12 = var9.getElements();
    var9.setExpansionMode(1);
    double[] var15 = var9.getInternalValues();
    var7.addElements(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var7, var19);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var22 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = var23.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var26 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var25);
    org.apache.commons.math3.stat.ranking.TiesStrategy var27 = var26.getTiesStrategy();
    java.lang.String var28 = var27.name();
    java.lang.String var29 = var27.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var30 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var24, var27);
    org.apache.commons.math3.random.RandomGenerator var31 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24, var31);
    double[] var33 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    float var35 = var34.getExpansionFactor();
    double[] var36 = var34.getInternalValues();
    var34.clear();
    float var38 = var34.getContractionCriteria();
    double[] var39 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var40 = new org.apache.commons.math3.util.ResizableDoubleArray(var39);
    org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
    var40.discardFrontElements(0);
    boolean var45 = var40.equals((java.lang.Object)(short)1);
    double[] var47 = new double[] { 10.0d};
    var40.addElements(var47);
    var34.addElements(var47);
    double[] var50 = var32.rank(var47);
    var1.addElements(var50);
    org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "AVERAGE"+ "'", var28.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "AVERAGE"+ "'", var29.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(86.26126875387966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((-2332));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var5 = var1.nextExponential(1.2040925330189667d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextF((-6.082783622781294d), (-15.379210584652093d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8e79d0a9a7640e4101cc1f887b7b9b8480f86ac88f8e391853e5ee51c5f2d60fb3d3c39a710abe1c0c93363289a8f3848a7e"+ "'", var3.equals("8e79d0a9a7640e4101cc1f887b7b9b8480f86ac88f8e391853e5ee51c5f2d60fb3d3c39a710abe1c0c93363289a8f3848a7e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.13454526822454993d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-6350), (-589261714));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1018498667));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(670369391491839744L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 670369391491839744L);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.probability(2.3701879770272534E153d);
    double var8 = var2.cumulativeProbability(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5319268497029056d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var4 = var3.getExpansionMode();
    boolean var6 = var3.equals((java.lang.Object)15129380);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.2780113262919923d, 0.26622506799283374d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.053114013672176386d));

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var1.nextInversionDeviate(var8);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1450, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1455);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(40L, 1968802768399923712L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-1450));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var1.nextSecureHexString((-739555469));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 47.21806209505903d);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(4665724868967888867L, 146L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4665724868967888867L);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(31, 10.000001f, 7.105428E-15f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var21 = var1.nextCauchy((-0.6967477223995986d), 4.796970182353903d);
//     double var23 = var1.nextExponential(1.1442883656203053d);
//     java.lang.String var25 = var1.nextHexString(6316);
//     java.util.Collection var26 = null;
//     java.lang.Object[] var28 = var1.nextSample(var26, 2325);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(99.66210960879508d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(3.9626681941800963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.490553647691121d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(49L, 1079717575831374079L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    var1.addElement((-0.9469118583888082d));
    double[] var11 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    float var13 = var12.getExpansionFactor();
    double[] var14 = var12.getInternalValues();
    var12.clear();
    float var16 = var12.getContractionCriteria();
    double[] var17 = var12.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.00974196E-28f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.031514511454554896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.310427114815022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-10.027595521621988d), (java.lang.Number)31L, true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1079717575831374079L), (java.lang.Number)(-1371062271), false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.2848078505062461d, 47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.808206298994568E14d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-5.9083223018271465d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8.745881625601406d));

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Number var3 = null;
//     java.lang.Object[] var5 = new java.lang.Object[] { 1.0d};
//     org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException(var2, var3, var5);
//     org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var5);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var14 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-90L));
//     org.apache.commons.math3.exception.util.Localizable var15 = null;
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var17 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var16, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathArithmeticException var20 = new org.apache.commons.math3.exception.MathArithmeticException(var12, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var11, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var10, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, (java.lang.Object[])var17);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(796684296743799824L, 24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    java.lang.Number var16 = var15.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var15.getContext();
    java.lang.Throwable[] var18 = var15.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.util.Localizable var20 = null;
    java.lang.Throwable var21 = null;
    org.apache.commons.math3.exception.util.Localizable var22 = null;
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var24 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathInternalError var25 = new org.apache.commons.math3.exception.MathInternalError(var23, (java.lang.Object[])var24);
    org.apache.commons.math3.exception.MathIllegalStateException var26 = new org.apache.commons.math3.exception.MathIllegalStateException(var21, var22, (java.lang.Object[])var24);
    org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException(var20, (java.lang.Object[])var24);
    var19.addSuppressed((java.lang.Throwable)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (short)1+ "'", var16.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(20925);
    double[] var2 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var6 = var3.getElements();
    var1.addElements(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(285460, (-7));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 285453);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.math.BigInteger var1 = null;
//     java.math.BigInteger var3 = org.apache.commons.math3.util.ArithmeticUtils.pow(var1, 0L);
//     java.math.BigInteger var5 = org.apache.commons.math3.util.ArithmeticUtils.pow(var3, 0);
//     java.math.BigInteger var6 = null;
//     java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 0L);
//     java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var8, 0);
//     java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, var10);
//     org.apache.commons.math3.exception.OutOfRangeException var14 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)var10, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
//     java.lang.Number var15 = var14.getLo();
//     org.apache.commons.math3.exception.util.ExceptionContext var16 = var14.getContext();
//     java.lang.Number var17 = var14.getLo();
//     java.lang.String var18 = var14.toString();
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var18 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var13, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(83.76087698387963d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 84.0d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.7770066469080517d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 139L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var12, 25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var18 = var12.cumulativeProbability(0.8025006418195274d, 1.2099696949580587d);
//     boolean var19 = var12.isSupportLowerBoundInclusive();
//     boolean var20 = var12.isSupportLowerBoundInclusive();
//     boolean var21 = var12.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 62.954703415645156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-16.728864951398567d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.015991244473643723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(6L, 800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-794L));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog((-424592841), (-997090893));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.discardFrontElements(37);
    int var16 = var1.start();
    org.apache.commons.math3.util.ResizableDoubleArray var17 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.discardFrontElements((-536561727));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(236L, 1298433376908083968L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 236L);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var6 = var5.getNumericalMean();
//     double var7 = var5.sample();
//     var5.reseedRandomGenerator(1765921446827724705L);
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var1.nextSecureLong(1564627524542950912L, 233L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.7643025767578787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.9537222398800025d));
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    double var2 = org.apache.commons.math3.special.Erf.erf(1.624722426154622d, 0.012970752564188195d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.9637862799363136d));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(21.16768605653453d, 1.0812805407747197d, 14.358495960921964d, 1918124033);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt(9, 41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var1.nextBinomial((-27985567), (-2.3470831525555256d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "4a7cd0b3fa21c62fd376b58c1a0a879f08396e566e9600cd67335f918f31e057475245dcedc5529b293dc9cca7d3aeb34e26"+ "'", var3.equals("4a7cd0b3fa21c62fd376b58c1a0a879f08396e566e9600cd67335f918f31e057475245dcedc5529b293dc9cca7d3aeb34e26"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.5654255993735773d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("967a5651a24c1e6027d0cfd2461467805101f4b81e65ecd19846bfc4989514c8c2facd9c0278ec4959f630c1dc5411115ed7");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var2 = var0.cumulativeProbability(0.0d);
//     double var3 = var0.getSupportUpperBound();
//     boolean var4 = var0.isSupportLowerBoundInclusive();
//     double var5 = var0.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == (-0.16918880264999447d));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    java.lang.String var4 = var2.name();
    java.lang.String var5 = var2.name();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    double[] var10 = var7.getElements();
    var7.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var15 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var15);
    boolean var17 = var7.equals((java.lang.Object)var14);
    boolean var19 = var7.equals((java.lang.Object)'#');
    var7.contract();
    float var21 = var7.getContractionCriteria();
    boolean var22 = var2.equals((java.lang.Object)var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "AVERAGE"+ "'", var4.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "AVERAGE"+ "'", var5.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var7.discardFrontElements(0);
    boolean var12 = var7.equals((java.lang.Object)(short)1);
    double[] var14 = new double[] { 10.0d};
    var7.addElements(var14);
    var1.addElements(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    var17.addElement(0.08947556010017466d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setExpansionFactor(100.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    float var7 = var1.getExpansionFactor();
    var1.contract();
    int var9 = var1.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var1.substituteMostRecentElement(0.3732847937589188d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)Double.NaN, (java.lang.Number)2.251752586176186d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     double var8 = var2.getSupportLowerBound();
//     double var9 = var2.getSupportUpperBound();
//     double var10 = var2.getStandardDeviation();
//     boolean var11 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16.04724703051165d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    java.lang.String var8 = var6.name();
    java.lang.String var9 = var6.name();
    int var10 = var6.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = var13.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    java.lang.String var18 = var17.name();
    java.lang.String var19 = var17.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var14, var17);
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14, var21);
    double[] var23 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var24 = new org.apache.commons.math3.util.ResizableDoubleArray(var23);
    float var25 = var24.getExpansionFactor();
    double[] var26 = var24.getInternalValues();
    var24.clear();
    float var28 = var24.getContractionCriteria();
    double[] var29 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var30 = new org.apache.commons.math3.util.ResizableDoubleArray(var29);
    org.apache.commons.math3.util.ResizableDoubleArray var31 = new org.apache.commons.math3.util.ResizableDoubleArray(var30);
    var30.discardFrontElements(0);
    boolean var35 = var30.equals((java.lang.Object)(short)1);
    double[] var37 = new double[] { 10.0d};
    var30.addElements(var37);
    var24.addElements(var37);
    double[] var40 = var22.rank(var37);
    org.apache.commons.math3.util.ResizableDoubleArray var43 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);
    double var45 = var43.addElementRolling((-1.2690902893872158d));
    double[] var46 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var47 = new org.apache.commons.math3.util.ResizableDoubleArray(var46);
    float var48 = var47.getExpansionFactor();
    double[] var49 = var47.getInternalValues();
    var43.addElements(var49);
    org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var52 = var11.mannWhitneyUTest(var37, var49);
      fail("Expected exception of type org.apache.commons.math3.exception.NoDataException");
    } catch (org.apache.commons.math3.exception.NoDataException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(18.95256260573965d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.0f, (java.lang.Number)(byte)100, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 2 is smaller than, or equal to, the minimum (100)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 2 is smaller than, or equal to, the minimum (100)"));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 471897693666707013L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 471897693666707013L);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-739555469), (-105));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(18.063323782415544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0016693440309514d));

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000001f, 4.75761123840619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.09534185796406705d, 8.498382098277256d, 11.527213271902509d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.1025501384266319d, 5.486885501403971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17.437610908227523d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.0d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     int var24 = var1.nextZipf(30, 9.525456313941802E131d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var1.nextBinomial((-117325921), 1.8759104446184633d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "947876b027d912ae265bc403526e6de31caa844a6523431af6a3174cb7623dc67d36c760919e72314c525fd6161701caa9d3"+ "'", var3.equals("947876b027d912ae265bc403526e6de31caa844a6523431af6a3174cb7623dc67d36c760919e72314c525fd6161701caa9d3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4671758417275158d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(2.1803439373744755d, 13.367857581056686d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999666385734052d);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.505889130163068d, 0.23328726966373098d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9999778094653066d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(21656131, (-1.0f), 1.0000002f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var3 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var4 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var2, var3);
    java.lang.Class var5 = var2.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.TiesStrategy var8 = var7.getTiesStrategy();
    java.lang.String var9 = var8.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var8);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2, var8);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var12 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(857768823595114240L, 35L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 35L);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var7);
    var7.discardFrontElements(0);
    boolean var12 = var7.equals((java.lang.Object)(short)1);
    double[] var14 = new double[] { 10.0d};
    var7.addElements(var14);
    var1.addElements(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setNumElements((-1250175769));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(4.515297276784079E8d, 168.5485605020819d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707959535114777d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.discardFrontElements(0);
    boolean var6 = var1.equals((java.lang.Object)(short)1);
    var1.setNumElements(35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements(1024);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.5f, 1.0000001f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0000001f);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-6.097084853559156d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1131479055207487616L, 1564627524542950912L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = var1.copy();
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var1.getElement(68921);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-21.38764323879742d), (java.lang.Number)(-0.07330776103109524d), true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var10 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException(var8, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.07330776103109524d)+ "'", var5.equals((-0.07330776103109524d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(15, 1.9721523E-31f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.8011436155469337d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.338451472921389d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    var14.contract();
    var14.discardMostRecentElements(25);
    boolean var20 = var14.equals((java.lang.Object)"7a9efd8313e817ff351c8f205bb5617555fdb1c9a40aad8e15cd88751796abd7285aed76f2fdc7ef3d87e22a5636451551d");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.0f));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.0d, (java.lang.Number)92.67232803812807d);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.0d+ "'", var4.equals(3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }


    double var1 = org.apache.commons.math3.special.Erf.erf(26.527318809710245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     var1.reSeedSecure();
//     long var8 = var1.nextLong(0L, 6L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var1.nextLong(42L, (-870081414414930687L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 6L);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     int var24 = var1.nextZipf(30, 9.525456313941802E131d);
//     var1.reSeedSecure(20L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "ae6f9254b189c98a5be4615804d422baca067265721a63c6ef0921eaaa3d6a18869c3f688b44ef6d82638d80445e2f5686e3"+ "'", var3.equals("ae6f9254b189c98a5be4615804d422baca067265721a63c6ef0921eaaa3d6a18869c3f688b44ef6d82638d80445e2f5686e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.699188241777489d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(10L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2L);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.2208572833603635d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2208572833603633d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(1298433376908083868L, (-254803968L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var12);
    org.apache.commons.math3.random.RandomGenerator var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var14);
    java.lang.Class var16 = var1.getDeclaringClass();
    org.apache.commons.math3.random.RandomGenerator var17 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed();
//     double var17 = var1.nextWeibull(10.953429709299042d, 2.515911276041704d);
//     var1.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8a7c30c5f367373dd8e7bfb26b58a4601edfaace2704655a45b499f309e7113dccda4cfbfb1ac58e711493a8105c19b013c9"+ "'", var3.equals("8a7c30c5f367373dd8e7bfb26b58a4601edfaace2704655a45b499f309e7113dccda4cfbfb1ac58e711493a8105c19b013c9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.3539651481886394d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2.2659000912882274d);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)6L, (java.lang.Number)49.42388728941576d, (java.lang.Number)2.85491701904754d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.85491701904754d+ "'", var5.equals(2.85491701904754d));

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var11 = var1.nextT(1.3877787807814457E-17d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var15 = var14.sample();
//     boolean var16 = var14.isSupportLowerBoundInclusive();
//     double var17 = var14.getStandardDeviation();
//     double var19 = var14.inverseCumulativeProbability(0.0d);
//     double var20 = var14.getSupportLowerBound();
//     double var21 = var14.getSupportUpperBound();
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     int var25 = var1.nextInt((-536561727), (-285567));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var27 = var1.nextPoisson((-0.542236881900813d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 105.17285612800258d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.3701879770272504E153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8.0250243078002d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-6.100695966305502d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-341868592));
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     double[] var3 = var1.getInternalValues();
//     var1.clear();
//     float var5 = var1.getContractionCriteria();
//     double[] var6 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     var1.addElements(var6);
//     double[] var9 = var1.getElements();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.String var18 = var17.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     java.lang.String var33 = var32.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var32);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var37);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var37);
//     double[] var40 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     var41.setNumElements(1);
//     int var45 = var41.getExpansionMode();
//     double var47 = var41.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double var49 = var41.addElementRolling(100.0d);
//     double[] var50 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     double[] var54 = var51.getElements();
//     var51.setElement(100, 1.0d);
//     double[] var58 = var51.getElements();
//     var41.addElements(var58);
//     double[] var60 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     double[] var64 = var61.getElements();
//     var61.setElement(100, 1.0d);
//     double[] var68 = var61.getElements();
//     double var69 = var39.mannWhitneyU(var58, var68);
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var73 = var72.getNumericalVariance();
//     boolean var74 = var72.isSupportConnected();
//     double[] var76 = var72.sample(100);
//     double var77 = var19.mannWhitneyU(var68, var76);
//     var1.addElements(var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setExpansionFactor(0.0f);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
//     } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 5100.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 5550.0d);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextGaussian(7.336638374906062d, 1268.568243354647d);
//     var0.reSeedSecure(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextBinomial((-739555469), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-583.5176545636615d));
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(18.865724139639422d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18.86572413963942d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var6 = var2.probability(2.3701879770272534E153d);
    double var7 = var2.getStandardDeviation();
    double[] var9 = var2.sample(16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.10533913124445467d, (-0.8994161155771262d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.10533913124445467d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.3841858E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1270, 2.3841858E-7f, 1.2676505E30f, 651230987);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(34, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4318));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-206885));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.6123797044686811d), (-7.944689521552087d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.6123797044686811d));

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     double var21 = var1.nextChiSquare(0.18340211571916795d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(3.9034157645529923d, 0.039766406469604984d);
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     double var27 = var24.cumulativeProbability(13.14778161976146d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "0dfbd0181758816e5a2f6003c1e6e354a69cd3b5d91724ee31597c2713803888496bc23e3e6b1a269e0976b6bc2300c26406"+ "'", var3.equals("0dfbd0181758816e5a2f6003c1e6e354a69cd3b5d91724ee31597c2713803888496bc23e3e6b1a269e0976b6bc2300c26406"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.481405440325721d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.2403694702490275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 6.241107950514922E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3.9231740583019166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(23.21029720989869d, (-2.8848419948965436d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-23.21029720989869d));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin((-0.15984079619916874d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.1591610342600845d));

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var12.inverseCumulativeProbability(904.1046655149532d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 266.2570895906791d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10.530704883682972d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-12.941878240746696d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     var1.reSeedSecure((-1L));
//     long var7 = var1.nextPoisson(13.14778027539684d);
//     double var10 = var1.nextCauchy(1.1520443903650324d, 1.6715630545231195d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var1.nextSample(var11, 0);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var12 = var1.nextGamma((-3.8208663712048767d), 18.73160423917461d);
//     double var14 = var1.nextChiSquare(39.299201911311215d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.nextBinomial((-354871708), (-1.1459234617400742d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 40.39458732561938d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 42.95612136604172d);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getNumericalVariance();
//     var2.reseedRandomGenerator(35L);
//     double var8 = var2.getNumericalMean();
//     double var11 = var2.cumulativeProbability((-0.8540450816950081d), 2.251752586176186d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.4056684892878506d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.12203766294196501d);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    boolean var13 = var11.equals((java.lang.Object)7.105427357601001E-15d);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var6 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var5, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var6);
    var2.addSuppressed((java.lang.Throwable)var8);
    java.lang.Throwable[] var10 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.7837378979264542d, 4.0558666602253535d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.745899459734663d));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    java.lang.String var12 = var11.toString();
    java.lang.String var13 = var11.toString();
    java.lang.String var14 = var11.name();
    java.lang.String var15 = var11.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "AVERAGE"+ "'", var12.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AVERAGE"+ "'", var14.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "AVERAGE"+ "'", var15.equals("AVERAGE"));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    int var10 = var7.ordinal();
    java.lang.String var11 = var7.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AVERAGE"+ "'", var11.equals("AVERAGE"));

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(4293093838549312512L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4293093838549312512L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(4.574109589240505d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     float var2 = var1.getExpansionFactor();
//     double[] var3 = var1.getInternalValues();
//     var1.clear();
//     float var5 = var1.getContractionCriteria();
//     double[] var6 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var7 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
//     var1.addElements(var6);
//     double[] var9 = var1.getElements();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var12);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
//     java.lang.String var18 = var17.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var11, var17);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var21 = var20.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21, var22);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var21);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
//     org.apache.commons.math3.stat.ranking.NaNStrategy var26 = var25.getNanStrategy();
//     org.apache.commons.math3.random.RandomGenerator var27 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var28 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var27);
//     org.apache.commons.math3.stat.ranking.NaturalRanking var29 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
//     java.lang.String var33 = var32.name();
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var34 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var26, var32);
//     org.apache.commons.math3.stat.ranking.NaNStrategy var35 = null;
//     org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var35);
//     org.apache.commons.math3.stat.ranking.TiesStrategy var37 = var36.getTiesStrategy();
//     org.apache.commons.math3.stat.ranking.NaturalRanking var38 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var26, var37);
//     org.apache.commons.math3.stat.inference.MannWhitneyUTest var39 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var21, var37);
//     double[] var40 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var41 = new org.apache.commons.math3.util.ResizableDoubleArray(var40);
//     org.apache.commons.math3.util.ResizableDoubleArray var42 = new org.apache.commons.math3.util.ResizableDoubleArray(var41);
//     var41.setNumElements(1);
//     int var45 = var41.getExpansionMode();
//     double var47 = var41.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double var49 = var41.addElementRolling(100.0d);
//     double[] var50 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var51 = new org.apache.commons.math3.util.ResizableDoubleArray(var50);
//     org.apache.commons.math3.util.ResizableDoubleArray var52 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     org.apache.commons.math3.util.ResizableDoubleArray var53 = new org.apache.commons.math3.util.ResizableDoubleArray(var51);
//     double[] var54 = var51.getElements();
//     var51.setElement(100, 1.0d);
//     double[] var58 = var51.getElements();
//     var41.addElements(var58);
//     double[] var60 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var61 = new org.apache.commons.math3.util.ResizableDoubleArray(var60);
//     org.apache.commons.math3.util.ResizableDoubleArray var62 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray var63 = new org.apache.commons.math3.util.ResizableDoubleArray(var61);
//     double[] var64 = var61.getElements();
//     var61.setElement(100, 1.0d);
//     double[] var68 = var61.getElements();
//     double var69 = var39.mannWhitneyU(var58, var68);
//     org.apache.commons.math3.distribution.NormalDistribution var72 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var73 = var72.getNumericalVariance();
//     boolean var74 = var72.isSupportConnected();
//     double[] var76 = var72.sample(100);
//     double var77 = var19.mannWhitneyU(var68, var76);
//     var1.addElements(var76);
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 5100.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 5559.0d);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(102.2007653745875d, (-1.235344810822468d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.003293299630453611d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)8.077752138320707E-70d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var5 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     int var6 = var1.nextSecureInt((-127), 34);
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.getNumericalVariance();
//     double var11 = var9.getNumericalMean();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     double var13 = var9.getNumericalVariance();
//     boolean var14 = var9.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1df8b0d11c197e77ce3e6252849b10d95d808da19feb131dbc5282fe6f395851cd96d0bd79e8f4485c85b0d18380a3546dff"+ "'", var3.equals("1df8b0d11c197e77ce3e6252849b10d95d808da19feb131dbc5282fe6f395851cd96d0bd79e8f4485c85b0d18380a3546dff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-102));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.10905415644638801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     int var20 = var1.nextSecureInt((-1450), 21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var1.nextBinomial((-1075233378), (-12.05804025823432d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "23ee967d2627867953c95ac35d642cc34f301253f89dad365e8deebb45c17c9245c464c75e975f1c235c4878f4efdac2d882"+ "'", var3.equals("23ee967d2627867953c95ac35d642cc34f301253f89dad365e8deebb45c17c9245c464c75e975f1c235c4878f4efdac2d882"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6830779636719432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-486));
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.20501159734253516d), (-26.510678265115082d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-26.510678265115082d));

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var28 = var1.nextT(0.6037929298964898d);
//     java.util.Collection var29 = null;
//     java.lang.Object[] var31 = var1.nextSample(var29, 21);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextChiSquare(1.8039440580589192d);
//     var1.reSeed(383L);
//     int var21 = var1.nextBinomial(0, 0.014387441792572614d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var24 = var1.nextF(106.54920855006304d, (-0.3781719905353782d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b9ea32972cf5d3c19bdb9a1f61fd84fb655b26bcc20fea16dcfde80453e70caa8feb6ed37dd3135b749bc2d53111a134cf88"+ "'", var3.equals("b9ea32972cf5d3c19bdb9a1f61fd84fb655b26bcc20fea16dcfde80453e70caa8feb6ed37dd3135b749bc2d53111a134cf88"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.25054340410557d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 42L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8719938586871978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    double[] var13 = new double[] { 1.0d};
    var1.addElements(var13);
    double var16 = var1.addElementRolling(0.0d);
    var1.addElement(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log((-15.737760496737463d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(53.0d, 0.12349098807090365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.022366117582332465d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray((-1246114372), 1.3234891E-22f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial((-354874608));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportUpperBoundInclusive();
    boolean var5 = var2.isSupportLowerBoundInclusive();
    double var7 = var2.density((-0.3526745915936687d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.03985412967898143d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(53.78712722644688d, 34.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0010412664660371463d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var17 = var1.nextChiSquare(0.24433316542704286d);
//     double var20 = var1.nextUniform((-12.921651213657304d), 0.18249332238610877d);
//     double var22 = var1.nextExponential(0.039766406469604984d);
//     double var24 = var1.nextExponential(2.511625001684894d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.nextHypergeometric(208374245, (-82), 27985567);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 91.52227443083126d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.289787543272089d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.531145146053512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-7.987103096871241d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0015505661897666405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.0466686286991458d);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(4.5E-44f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)29);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed(16L);
//     double var19 = var1.nextUniform(2.0d, 14.237606813581872d, true);
//     double var22 = var1.nextBeta(34.05302161042214d, 444.2084452322706d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var1.nextSecureLong(12L, 3L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "9878b26938da6c4647f1e01547c77ad3ea94363044447f5410f479765e20179893f0e4ee2ff2afa3ce29249c4e91974f74e2"+ "'", var3.equals("9878b26938da6c4647f1e01547c77ad3ea94363044447f5410f479765e20179893f0e4ee2ff2afa3ce29249c4e91974f74e2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.9495509971385854d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12.152754637483802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.08516996514094463d);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double var3 = var2.getSupportLowerBound();
    double var4 = var2.getNumericalMean();
    double var5 = var2.getSupportUpperBound();
    double var7 = var2.probability(675135.6375433733d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4920673008707643d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.0498592479285436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(90.54881795295192d, (-67.96152955301187d), Double.POSITIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(3628800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);
    double var4 = var2.addElementRolling((-1.2690902893872158d));
    double[] var5 = var2.getElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    int var3 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    var1.setNumElements(2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setContractionCriteria(1.0000001f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(15129380);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportUpperBoundInclusive();
    boolean var5 = var2.isSupportLowerBoundInclusive();
    boolean var6 = var2.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.NaNStrategy var2 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.32286276221102783d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33456957862406717d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var10.getTiesStrategy();
    java.lang.String var13 = var12.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements(530087946);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(161.62052203953047d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 161.0d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)22.140692632779267d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(30.819280522497568d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.679224265044103d));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2676508E30f);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution(7.105427357601002E-15d, 13.55892620578028d);
    var2.reseedRandomGenerator((-48L));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-530087935), (-1143914887));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     org.apache.commons.math3.distribution.NormalDistribution var7 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var9 = var7.cumulativeProbability(0.0d);
//     double var10 = var7.getSupportUpperBound();
//     double var11 = var7.getStandardDeviation();
//     double var12 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var7);
//     var1.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "5dfcb2ceb727c32a4c6cbdbf4931a5cafb0bfa51f76a2ab58e91a023a5c023b35b02e1319d94349ab05e8d394293941aa6f8"+ "'", var3.equals("5dfcb2ceb727c32a4c6cbdbf4931a5cafb0bfa51f76a2ab58e91a023a5c023b35b02e1319d94349ab05e8d394293941aa6f8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.4471492279185045d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.35157335980161264d);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.015290415188601286d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9998831038792017d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)19.722304453637022d, false);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
//     java.lang.String var6 = var5.toString();
//     org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
//     var3.addSuppressed((java.lang.Throwable)var5);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var15 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var13, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var12, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var11, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var10, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var9, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var15);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     java.lang.Throwable var25 = null;
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.exception.util.Localizable var27 = null;
//     org.apache.commons.math3.stat.ranking.TiesStrategy[] var28 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
//     org.apache.commons.math3.exception.MathArithmeticException var29 = new org.apache.commons.math3.exception.MathArithmeticException(var27, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.MathIllegalStateException var30 = new org.apache.commons.math3.exception.MathIllegalStateException(var25, var26, (java.lang.Object[])var28);
//     org.apache.commons.math3.exception.MathIllegalStateException var31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var23, var24, (java.lang.Object[])var28);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeed(100L);
//     double var18 = var1.nextGaussian(10.953429709299042d, 11.579430653027496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 379.81871206246376d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-8.574153924169648d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 16.402428284803136d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.023600574802198477d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.023604957517463766d);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var18 = var1.nextGamma(125.4107442965159d, 5100.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextF((-7.738206325689978d), 0.3635014859484314d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 28.083786575222234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3.896339824305343d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 558855.8940030513d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-0.8522537233117267d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6922450337923093d));

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextGaussian((-1024.0d), 4.787491742782046d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextCauchy(4418.743213553135d, (-2.8236712811560465d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16.04682628993479d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.0702007020882816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.04400318097914707d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1020.9171160301252d));
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(9.334017078796073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.0d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    java.lang.String var12 = var11.toString();
    org.apache.commons.math3.stat.ranking.NaNStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy var14 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var14);
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var15.getTiesStrategy();
    java.lang.String var17 = var16.name();
    java.lang.String var18 = var16.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var20 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var11, var16);
    java.lang.Class var21 = var16.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var23 = java.lang.Enum.<java.lang.Enum>valueOf(var21, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "AVERAGE"+ "'", var17.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "AVERAGE"+ "'", var18.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 1.624722426154622d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     org.apache.commons.math3.distribution.NormalDistribution var9 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var10 = var9.sample();
//     double var12 = var9.density(18.409703235248998d);
//     double var14 = var9.probability(9.34227543668857d);
//     var9.reseedRandomGenerator(90L);
//     double var17 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var9);
//     boolean var18 = var9.isSupportLowerBoundInclusive();
//     double var19 = var9.getStandardDeviation();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 55.73247144428453d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-32.12685023548044d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.297481313685244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3.5873232552831404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 10.0d);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(1995746824403479552L, 42L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-3.496695663378208d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(285453, 4.5918E-41f, 2.25180003E16f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(7.5557864E22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    var1.setNumElements(9);
    var1.discardMostRecentElements(0);
    float var11 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10.000001f);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(13.583522096629824d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6798922678206463d);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = var3.getNanStrategy();
    java.lang.Class var5 = var4.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var7 = java.lang.Enum.<java.lang.Enum>valueOf(var5, "fc69d0b8f36f1cd695670bc635643fceea7692ab046ced520c740d350c3c4ac34153dea8b811a5af5007a776355cd003ed93");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     var1.reSeed((-48L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "dc7e3200b7db10445de9a73851fed8fbe13fa08f22a55c6e09ba1d241aa71934b76c4a0126caefec54381237881c6668dffe"+ "'", var3.equals("dc7e3200b7db10445de9a73851fed8fbe13fa08f22a55c6e09ba1d241aa71934b76c4a0126caefec54381237881c6668dffe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5765140033950913d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7611529404613979d);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     int var11 = var1.nextSecureInt((-1371062271), 190);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextUniform((-1.235344810822468d), (-1.3106591446783056d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "8679168adfce3f8026a88bcf460d73521480843f2a26ff257bba1b85f34a4dda09aa57be6fbe13fafb3b1e72ba5bac80c59d"+ "'", var3.equals("8679168adfce3f8026a88bcf460d73521480843f2a26ff257bba1b85f34a4dda09aa57be6fbe13fafb3b1e72ba5bac80c59d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.6387686730277913d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8003121101727465d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-594535409));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.10091716033504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1316979259062954d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     long var21 = var1.nextPoisson(148.98623399852667d);
//     org.apache.commons.math3.random.RandomGenerator var22 = null;
//     org.apache.commons.math3.random.RandomDataImpl var23 = new org.apache.commons.math3.random.RandomDataImpl(var22);
//     double var25 = var23.nextExponential(100.0d);
//     int var28 = var23.nextZipf(10, 100.0d);
//     int var31 = var23.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var34 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var35 = var23.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var37 = var34.cumulativeProbability((-1.0d));
//     double var38 = var34.getNumericalVariance();
//     double var39 = var34.getMean();
//     double var40 = var34.sample();
//     double var42 = var34.density(0.06446622075849562d);
//     boolean var43 = var34.isSupportUpperBoundInclusive();
//     double var45 = var34.probability((-3.9783650131768225d));
//     double var47 = var34.cumulativeProbability((-0.9353982831981948d));
//     double var48 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var34);
//     double var50 = var1.nextT(196.6432931864693d);
//     long var53 = var1.nextLong(0L, 96L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "96785611fee8fb3c1afb23f35cb6ea3e62a4300510b58e309a587fc22b98cf1ec51e9467f36758747085496bf63b7eb24680"+ "'", var3.equals("96785611fee8fb3c1afb23f35cb6ea3e62a4300510b58e309a587fc22b98cf1ec51e9467f36758747085496bf63b7eb24680"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.8892270861118283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.17557588063053528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 132L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 115.53308557545296d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 6.4713018620362845d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-8.167985375624562d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0.49464417456556514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1.7730075750417766d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == (-0.16724901641086987d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 9L);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(1.5276447739012384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.751090905264462d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray((-4), 2.0f, 3.4028235E38f, (-101));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-4665724868967888867L), 41L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.0d, 3.616242248904851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var10 = var1.nextUniform((-2.552751428575824d), 2.9172543562621576E307d, true);
//     double var13 = var1.nextUniform(0.0d, 6.651199047971083d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextF((-19.471609359304864d), 49.17275152005467d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "987d1022703cbf4da9778a37a450fc20f6503d61d6e947497ac5e6e3c0cb7f1681c9313d4c5c1a868f6aba2fe4bebf890b20"+ "'", var3.equals("987d1022703cbf4da9778a37a450fc20f6503d61d6e947497ac5e6e3c0cb7f1681c9313d4c5c1a868f6aba2fe4bebf890b20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.2153602378563937d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2.1641309433353637E305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.148963873973846d);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)8.881784197001252E-16d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var7 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var9 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var10 = var9.toString();
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var9);
    var7.addSuppressed((java.lang.Throwable)var9);
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var19 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException(var18, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var17, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var16, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.NullArgumentException var24 = new org.apache.commons.math3.exception.NullArgumentException(var14, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var13, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalArgumentException var26 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.NullArgumentException var27 = new org.apache.commons.math3.exception.NullArgumentException(var4, (java.lang.Object[])var19);
    org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var19);
    java.lang.Number var29 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var10.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0+ "'", var29.equals(0));

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.260531119726735d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 24.198465894038733d);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     boolean var3 = var0.isSupportLowerBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2501920651831036d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(3212953265256213504L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.6348809972623879E-4d, 0.45677172503860936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.08987179253137886d);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     int var18 = var1.nextInt(27, 100);
//     double var20 = var1.nextChiSquare(2.6028578312239015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "987b7216a9809fc8c4531565c5b014d24102ff97a846b00ee5bd5e3d0eb223c356d2623d0c36e1b19e6eeca8087813a903ff"+ "'", var3.equals("987b7216a9809fc8c4531565c5b014d24102ff97a846b00ee5bd5e3d0eb223c356d2623d0c36e1b19e6eeca8087813a903ff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.286438770244121d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 7.690210594562804d);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-5.693522866084209d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 148.47061010689274d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1379843843793974016L), (-7));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var7 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MaxCountExceededException var9 = new org.apache.commons.math3.exception.MaxCountExceededException(var4, (java.lang.Number)(byte)1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var3, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NullArgumentException var13 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.Number var4 = var3.getMin();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)(-2.0d), (java.lang.Number)4.165587190894948d, false);
    java.lang.Number var6 = var5.getArgument();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-2.0d)+ "'", var6.equals((-2.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var2);
    org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    org.apache.commons.math3.util.ResizableDoubleArray var5 = new org.apache.commons.math3.util.ResizableDoubleArray(var3);
    double[] var6 = var3.getElements();
    var3.setExpansionMode(1);
    double[] var9 = var3.getInternalValues();
    var1.addElements(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(3116, 3.4028235E38f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var13);
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var1.copy();
    int var16 = var15.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-11.579626535984998d));

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999998943584386d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-110L), 474370825216844736L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(149.37409939757816d, (-3.8183553599610858d), 0.0d, 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.9469118583888082d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1027.7597143959856d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-5293152609383083007L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5293152609383083007L);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextGamma((-1.0169623077095862d), (-10.868165610752694d));
//     double var9 = var1.nextCauchy(29.171528454339946d, 9.0d);
//     double var11 = var1.nextExponential(38.13608131498478d);
//     double var14 = var1.nextCauchy(1.5410312241221764d, 3.4948795302692948d);
//     int var17 = var1.nextSecureInt((-117325921), (-83903276));
//     double var20 = var1.nextWeibull(0.7395463592942557d, 23.21029720989869d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 148.60379696640206d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-18.139840477490452d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 32.341075375538274d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 54.62495358587747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5.254166121220852d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-102358633));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1.8406383496938339d);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var4 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var4);
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = var5.getTiesStrategy();
    java.lang.String var7 = var6.name();
    java.lang.String var8 = var6.name();
    java.lang.String var9 = var6.name();
    int var10 = var6.ordinal();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var11 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var3, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var12 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AVERAGE"+ "'", var7.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AVERAGE"+ "'", var9.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(4789936397411503936L, 2025644137419103232L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var3 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExpansionFactor(7.629395E-6f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var14 = var1.nextPoisson(44.007788545081404d);
//     double var16 = var1.nextExponential(161.62052203953047d);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var1.nextPascal((-105), 4.984737711268664d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "afec926cb025048c44613fd17cf460930b76f210f3019e4b1318726723e481ed028c0e0b4feb7eb25d6ed42176941a7a8f04"+ "'", var3.equals("afec926cb025048c44613fd17cf460930b76f210f3019e4b1318726723e481ed028c0e0b4feb7eb25d6ed42176941a7a8f04"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.3681166944951801d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 60L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 216.25081331230402d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(1);
    double[] var2 = var1.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.substituteMostRecentElement(4.75761123840619d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(7218835434699862529L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(5293152609383083007L, 4014251076750497793L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(81.93186623463397d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.099072422890936d);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(56.31232790250591d, (-0.9932484371644573d), (-0.5763282149202441d), (-116));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-105), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-105));

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(9.030385460342578E-7d, 0.0d, 2.4923224105534505d, (-127980029));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var3.getContractionCriteria();
    int var5 = var3.start();
    org.apache.commons.math3.util.ResizableDoubleArray var6 = var3.copy();
    double[] var7 = var6.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var8 = new org.apache.commons.math3.util.ResizableDoubleArray(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.7242441387499587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8846049353976515d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1819287553, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    int var13 = var1.start();
    var1.discardFrontElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-1.0212731418599934d), (-8.428574917575162d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(11.579430653027496d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.579430653027497d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     double var21 = var1.nextUniform(0.409278872838869d, 7.6644334196952775d, true);
//     double var24 = var1.nextF(1.3365301621724433E-74d, 1.4153292988002895d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "867fb44bd9c1557eb7275545aa102316b24f5f1b757f8ffbb2862faf02d9ddc7635a36aa86b49741c1fcaf2b63ccc23cd128"+ "'", var3.equals("867fb44bd9c1557eb7275545aa102316b24f5f1b757f8ffbb2862faf02d9ddc7635a36aa86b49741c1fcaf2b63ccc23cd128"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8363625025557515d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8195982740349386d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 6.922956211850264d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test247"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.3841858E-7f, 0.001953125f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.3841858E-7f);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var10 = var0.nextExponential(0.16227766016837952d);
//     double var13 = var0.nextF(0.15085749711366045d, 5.811390651303676d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-8.636143906568778d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.303709844217016d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.16811467938480054d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.541862173782476E-7d);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test249"); }


    double var1 = org.apache.commons.math3.special.Gamma.digamma((-1.4529973231235696d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1471428264102244d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(148.20567761983978d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.1708648413743195d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.833300085212844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0414421401285487d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test252"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(266.70649629911264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.747760046153423E115d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test253"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(115.88236082957272d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.445704108975163d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test254"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 43.84347793157677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test255"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.8432620506617192d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9447585959570287d));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test256"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-83.75291170889794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test257"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(0L, 170L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test258"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var2 = var0.cumulativeProbability(0.0d);
    double var3 = var0.getSupportUpperBound();
    var0.reseedRandomGenerator(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test259"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.6593239723930994d, (java.lang.Number)0.40270175174997785d, (java.lang.Number)4789936397411503936L);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test260"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(18.480334291561014d, (-512496555));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test261"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(5.2287814812793784E-6d, (-206885));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test262"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((-3103219178563426303L), 1995746824403479552L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1107472354159946751L));

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test263"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = var4.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var6 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var7 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var5, var6);
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test264"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-27.235566339247477d), 1.3458628770090784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-27.235566339247473d));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test265"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(20, (-96));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-76));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test266"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(4.75761123840619d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 58.237983315853576d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test267"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(5.331514379913182E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 32.94608517857843d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(45.27279620323017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.294539697328678E19d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test269"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(8.683964266775403d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2953.7094936419744d);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.7730075750417766d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3372564655227763d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test271"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var5 = null;
    java.math.BigInteger var7 = org.apache.commons.math3.util.ArithmeticUtils.pow(var5, 0L);
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0);
    java.math.BigInteger var10 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, var9);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 100L);
    java.math.BigInteger var14 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.366136040059517d, 10.478585954830956d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.366136040059517d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test273"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient(1455, 20925);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test274"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    java.lang.Class var29 = var1.getDeclaringClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Enum var31 = java.lang.Enum.<java.lang.Enum>valueOf(var29, "447c548dcde231e1ce9c95d7d4ac2b1baf34a1da26386ec92ba1278e7703474015a6625838779df6e214aa0ff75139417c96");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test275"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.5557864E22f, 0.3435381703512802d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.555786E22f);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test276"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.000001f, 3.544708112819307d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test277"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var8 = var6.sample(34);
    double[] var9 = var1.rank(var8);
    org.apache.commons.math3.stat.ranking.TiesStrategy var10 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var1.getNanStrategy();
    java.lang.String var12 = var11.name();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "MAXIMAL"+ "'", var12.equals("MAXIMAL"));

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var1.nextUniform(3.544708112819307d, 0.6936005370137376d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "2a6cb0340bc2d4b69590927746fc1721b097c6ec292bf59d91aa8567f4fc537c64375f50440b32b15efc36568ec8aae2ede0"+ "'", var3.equals("2a6cb0340bc2d4b69590927746fc1721b097c6ec292bf59d91aa8567f4fc537c64375f50440b32b15efc36568ec8aae2ede0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3737151466493607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test279"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(2325);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    var1.discardFrontElements(0);
    double var21 = var1.addElementRolling(30.66543173953429d);
    double var23 = var1.substituteMostRecentElement(0.031514511454554896d);
    float var24 = var1.getContractionCriteria();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 30.66543173953429d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.5f);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test280"); }


    boolean var1 = org.apache.commons.math3.util.ArithmeticUtils.isPowerOfTwo(4152318856435597312L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test281"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test282"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(6350, (-703556403));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-703550053));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test283"); }


    double var2 = org.apache.commons.math3.special.Gamma.regularizedGammaP(10.631760722610178d, 6.605358949815338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.09144282391696697d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test284"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos((-38.02083667789414d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     double var29 = var1.nextBeta(0.032094312270302745d, 0.428198591529539d);
//     var1.reSeedSecure((-1079717575831374079L));
//     long var34 = var1.nextSecureLong(274448725870672832L, 1147538942986031104L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "edefd2c4d6d826289b2d010673d44d3fbaf8b24495d0628377c3b02240af1e591dcc9e3b45d76acd80f9a801300580940189"+ "'", var3.equals("edefd2c4d6d826289b2d010673d44d3fbaf8b24495d0628377c3b02240af1e591dcc9e3b45d76acd80f9a801300580940189"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.1547654052063225d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 25.876002898525996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.16362220871355182d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0013977713688265528d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 286183440979776224L);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test286"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.4797106743533206d, (-4.582384203074734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4797106743533206d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1250178885), (java.lang.Number)(-48L), true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-48L)+ "'", var5.equals((-48L)));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     double var21 = var1.nextUniform(0.409278872838869d, 7.6644334196952775d, true);
//     double var23 = var1.nextExponential(73.13855026261534d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var1.nextPascal((-556289202), 6.088804183916286d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "da7ad26790c691f33237b9ed453f906e3e94e61a9fbd37c3ebd42e4e7596d20677b1888c361dbb90fe089adcafa5b21c2a21"+ "'", var3.equals("da7ad26790c691f33237b9ed453f906e3e94e61a9fbd37c3ebd42e4e7596d20677b1888c361dbb90fe089adcafa5b21c2a21"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.776766464309575d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7177142644082958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.5807704087273259d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 9.531393307604242d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test289"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(12.891967632422372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.6313108049354312d);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test290"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setExpansionMode(297623103);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test291"); }


    org.apache.commons.math3.stat.ranking.NaNStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    java.lang.String var3 = var2.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var7 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "AVERAGE"+ "'", var3.equals("AVERAGE"));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test292"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(86.74240888600346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test293"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     boolean var6 = var2.isSupportConnected();
//     double var8 = var2.cumulativeProbability((-1.0038370563294414d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.cumulativeProbability(146.44549731913872d, 0.5525683877554304d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.30768930390587457d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.49191425532136546d);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test294"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(213.1791673987999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 214.0d);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test295"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6689087058498806d, (java.lang.Number)(-4.269546866811581d), false);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(6, 100.0f);
    var3.addElement(1.2156545907991276d);
    double[] var6 = var3.getElements();
    java.lang.Object[] var7 = new java.lang.Object[] { var3};
    org.apache.commons.math3.exception.NullArgumentException var8 = new org.apache.commons.math3.exception.NullArgumentException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test297"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.9142161307821561d, 1.1844690163969658E-74d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test298"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    var1.setNumElements(21);
    int var10 = var1.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test299"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(7.629395E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7.629395E-6f);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-0.9110911459711815d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.7389091227614462d));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test301"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("f6689645cccd4263ae8c4babe45c073f3cd6a1bbcd2f7f5224f16e215ef6885dfc664ef157dcfe53f4cdbc2180f51ae61fef");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure(1L);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var6 = var5.sample();
//     double var7 = var5.getNumericalMean();
//     double var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     double var11 = var0.nextGaussian(0.0d, 4.288817095277554d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(0, 630502273, (-285567));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.4736717413947753d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10.368525851854619d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.0963339354418284d));
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test303"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(19.278190722344966d, 148.60379696640206d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 19.278190722344966d);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test304"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(111.60284877107065d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.5214061405773618d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.41963499970895235d);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     long var6 = var1.nextLong(0L, 2025644137419103233L);
//     double var9 = var1.nextGaussian(0.8019969832524574d, 66.6700062927355d);
//     var1.reSeedSecure();
//     double var13 = var1.nextCauchy(0.0d, 45.9548879662945d);
//     int var16 = var1.nextInt((-56), 12);
//     double var19 = var1.nextCauchy(59.171369307517345d, 0.5423156085106325d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 34.43273699220164d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 734551466112453504L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 64.52355024077445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 32.8103946285062d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-44));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 59.50188849840935d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(71.37380970762209d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.216637673260437d));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(4.796970182353903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 121.14282026907436d);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var15 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     java.lang.String var17 = var1.nextHexString(6316);
//     long var19 = var1.nextPoisson(13.221586840309266d);
//     double var21 = var1.nextChiSquare(0.18340211571916795d);
//     org.apache.commons.math3.distribution.NormalDistribution var24 = new org.apache.commons.math3.distribution.NormalDistribution(3.9034157645529923d, 0.039766406469604984d);
//     double var25 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var24);
//     long var27 = var1.nextPoisson(0.6168592909529225d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var30 = var1.nextWeibull(5.717858802944031d, (-0.15984079619916874d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "0278f4558b4791ad5596fb6e7fd2fae6ccf25c3751a61c00eb4a79a48a6791b84f5ccd0204d9ae1975e8b617ebfb5e500cb9"+ "'", var3.equals("0278f4558b4791ad5596fb6e7fd2fae6ccf25c3751a61c00eb4a79a48a6791b84f5ccd0204d9ae1975e8b617ebfb5e500cb9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.2663047465032979d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9693555296853006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.1240885377788121E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 3.919896575635024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0L);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test310"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm((-93), 285379740);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test311"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.9721523E-31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-102));

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test312"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.218601180602492d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(48.40854295060508d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.572716785686499d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure();
//     var1.reSeed(16L);
//     double var19 = var1.nextUniform(2.0d, 14.237606813581872d, true);
//     double var22 = var1.nextGamma((-20.577204430472907d), 0.5614043238043521d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var25 = var1.nextSecureInt(285460, (-42));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7c6c92bc48cd3a74ea806a1794dd52423bb5411371be9509770b0d7ec74640402256cba15792cc870b5f04ddc808a6ab2769"+ "'", var3.equals("7c6c92bc48cd3a74ea806a1794dd52423bb5411371be9509770b0d7ec74640402256cba15792cc870b5f04ddc808a6ab2769"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.4325385843954264d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12.152754637483802d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test315"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-42), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test316"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3116, (-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test317"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-9), 286183440979776224L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-819692799));

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficient((-3), (-78));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test319"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(543525818476686592L, 800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 543525818476686592L);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test320"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     int var20 = var1.nextSecureInt((-1450), 21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextBeta((-2.5939943385615924d), 6.947809528523891d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "25eb56a554c4974a96a93ca0f0a831fdc0efad92a398a645ffae06c632216b101aa920ad100057bd2fc400edab0be05d2dad"+ "'", var3.equals("25eb56a554c4974a96a93ca0f0a831fdc0efad92a398a645ffae06c632216b101aa920ad100057bd2fc400edab0be05d2dad"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26142379230421375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-670));
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test321"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(215720602, 7.6293945E-6f, 4.5E-44f, (-447873150));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(104.91357401080009d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test323"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(471897693666707008L, 355687428096000L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test324"); }


    double var2 = org.apache.commons.math3.util.FastMath.max((-48.283198828346514d), (-372.98597940182316d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-48.283198828346514d));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test325"); }


    double var1 = org.apache.commons.math3.special.Erf.erfc(6.063012596579243E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9993158623734482d);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test326"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 183.7831100704683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test327"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-651230979), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-651230979));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test328"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(7, 3.944305E-30f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test329"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.023604957517463766d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test330"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(9.771460689834196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test331"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements((-127980029));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test332"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.NaNStrategy var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.valueOf("ce7dd256c66fb00b751d4b33202710df1bcd14ae5c49a482315623b9dcb6e9302a632de93576e3394618881c69ff787f332f");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test333"); }


    org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
    double var3 = var2.getNumericalVariance();
    boolean var4 = var2.isSupportConnected();
    double var7 = var2.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
    double var8 = var2.getStandardDeviation();
    double var10 = var2.cumulativeProbability(0.49343374885006197d);
    double var13 = var2.cumulativeProbability(1.2168220259004512d, 67.32202106256064d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.06146076675140928d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5515022675452734d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.420037883850351d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test334"); }


    double var1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble(20925);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(7.826783848006244E11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28.07913488173628d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.7603951015204126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8639212517275301d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test337"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(50.94909583146956d, 37.32794332256712d, 1.4627348451982898d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test338"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var1 = org.apache.commons.math3.util.ArithmeticUtils.factorial(1918124033);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextWeibull(0.28583983826614007d, 4.072261697491794E-5d);
//     int var9 = var1.nextBinomial(692748758, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 79.12165433793714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.7838434081409E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test340"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(796684296743799824L, 68921);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test341"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow((-1018498667), 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1496992143));

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test342"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(31.441359245758186d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.516570815787564E13d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test343"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaturalRanking var5 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var6 = var5.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var7 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var8 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6);
    org.apache.commons.math3.stat.ranking.NaNStrategy var10 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var10);
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var11.getTiesStrategy();
    java.lang.String var13 = var12.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var14 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var6, var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var16 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.TiesStrategy var17 = var16.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var6, var17);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var19 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var17);
    java.lang.Class var20 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var22 = var21.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var22, var23);
    org.apache.commons.math3.stat.ranking.NaNStrategy var25 = var24.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var24.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var27 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var26);
    int var28 = var1.ordinal();
    org.apache.commons.math3.random.RandomGenerator var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var32 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "AVERAGE"+ "'", var13.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test344"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-1.9176854506617294d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.993312479114928d));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test345"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)52.217050732695114d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(105.97464604581293d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.29439877048742d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.8691264194920902d, (-4.445804110563701d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.8691264194920902d));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test348"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.3234891E-22f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3234891E-22f);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test349"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     double var5 = var2.density(18.409703235248998d);
//     double var7 = var2.probability(9.34227543668857d);
//     double var9 = var2.cumulativeProbability(0.4505451791095725d);
//     double var11 = var2.probability(3.0679934645157405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-21.129549688314782d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5498050729812682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test350"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(2325);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    var1.discardFrontElements(0);
    int var20 = var1.getExpansionMode();
    double var22 = var1.substituteMostRecentElement((-12.25808550676873d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setNumElements((-589261714));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test351"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.6237741930861675d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6237741930861678d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test352"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(4.056482E31f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.056482E31f);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test353"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(31.962252627588118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.157947409533439d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test354"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(8.4703295E-22f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test355"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = var1.copy();
    var10.addElement(2.3701879770272534E153d);
    int var13 = var10.getNumElements();
    var10.setNumElements(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test356"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(4665724868967888896L, 99);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test357"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(17, 1249363969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test358"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaturalRanking var15 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12);
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var16);
    org.apache.commons.math3.stat.ranking.TiesStrategy var18 = var17.getTiesStrategy();
    java.lang.String var19 = var18.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var20 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var12, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AVERAGE"+ "'", var19.equals("AVERAGE"));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test359"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(0.08516996514094463d, 0.9489318294220987d, 0.03974372976297623d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextUniform(4.87681109080397d, 66.6700062927355d);
//     double var13 = var1.nextGaussian(8.310101398016423d, 56.40999536847615d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var1.nextChiSquare((-1.3354863129736807d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-828147024));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 22.034499331603413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 92.41554840770233d);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test361"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setExpansionMode(1);
    double[] var7 = var1.getElements();
    int var8 = var1.start();
    var1.clear();
    var1.setElement(2, 2.633242452616744d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.19885430975358537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1988543097535854d);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test363"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    int var11 = var7.ordinal();
    java.lang.Class var12 = var7.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaturalRanking var13 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var16 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var17 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var15);
    org.apache.commons.math3.stat.ranking.NaturalRanking var19 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var20 = var19.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var21 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var21);
    org.apache.commons.math3.stat.ranking.NaturalRanking var23 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20);
    org.apache.commons.math3.stat.ranking.NaNStrategy var24 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var25 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var24);
    org.apache.commons.math3.stat.ranking.TiesStrategy var26 = var25.getTiesStrategy();
    java.lang.String var27 = var26.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var20, var26);
    org.apache.commons.math3.stat.ranking.NaNStrategy var29 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var30 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var29);
    org.apache.commons.math3.stat.ranking.TiesStrategy var31 = var30.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaturalRanking var32 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var20, var31);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var33 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var15, var31);
    int var34 = var31.ordinal();
    boolean var35 = var7.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AVERAGE"+ "'", var27.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test364"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0665895490501696d, (java.lang.Number)0.4505451791095725d, (java.lang.Number)(-0.32267104745890796d));
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint((-0.9574998286192915d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test366"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.substituteMostRecentElement((-3.1488299701481997d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalStateException");
    } catch (org.apache.commons.math3.exception.MathIllegalStateException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var9 = var1.nextF(0.9999998943584386d, 6.275922619569235d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextHexString((-580888836));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 191.2232812942683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.17124528552230928d);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test368"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-17.3187884261097d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3022698804919009d));

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test369"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(-1.575877718142896E-7d), false);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test370"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(2.274474349937051d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(11.491898101271795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 48959.60848907453d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test372"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)46.04777807390668d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test373"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(3067312546548822528L, 48L);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     long var15 = var1.nextLong(2025644137419103232L, 2025644137419103233L);
//     double var18 = var1.nextGamma(8.881784197001252E-16d, (-0.9469118583888082d));
//     double var21 = var1.nextGamma((-3.141592653589793d), 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var1.nextT((-2.3560693711166736d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "33eaf41ce19a2e4c5ac265e7c85650d1da9a559c9823e4082fdc721f05492e9ef4d594e2d841feb42551a7cc6765c68f9aa5"+ "'", var3.equals("33eaf41ce19a2e4c5ac265e7c85650d1da9a559c9823e4082fdc721f05492e9ef4d594e2d841feb42551a7cc6765c68f9aa5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.3425995877479548d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2025644137419103232L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     var1.reSeedSecure((-48L));
//     double var18 = var1.nextGamma(125.4107442965159d, 5100.5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var1.nextHypergeometric((-6350), (-11), (-276758528));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 158.83205250536088d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-10.620781964068106d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 657680.4611115047d);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test376"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-50.00832479015131d), (java.lang.Number)(-0.993312479114928d), false);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test377"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.9351598196739159d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test378"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(1.7960475903997133d, 1.4206623826625708d, 0.08631729905748209d, 6338);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.4765491617816185d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test379"); }


    org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
    double var1 = var0.getNumericalMean();
    double var2 = var0.getMean();
    double var3 = var0.getMean();
    double var4 = var0.getMean();
    double var5 = var0.getSupportLowerBound();
    double var6 = var0.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == Double.NEGATIVE_INFINITY);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test380"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(0, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test381"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var2 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var3 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var2);
    org.apache.commons.math3.stat.ranking.NaturalRanking var4 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var9 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1);
    org.apache.commons.math3.stat.ranking.NaNStrategy var11 = var10.getNanStrategy();
    int var12 = var11.ordinal();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test382"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1107472354159946751L), 3239152727494122237L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1107472354159946751L));

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-6.8602745996965435d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.11973437935564067d));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test384"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(52, (-711711710));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextSecureInt(9, 41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 120.23312680233103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 38);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test386"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test387"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    float var4 = var1.getExpansionFactor();
    var1.setContractionCriteria(10.000001f);
    var1.setNumElements(9);
    double[] var9 = var1.getInternalValues();
    int var10 = var1.getNumElements();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 9);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test388"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ(4.802880146377582d, (-1.9832721312526982d), (-0.9575217061535137d), 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test389"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(1558809787132314112L, 2822328434162903041L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4381138221295217153L);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test390"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var2 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var3 = var2.sample();
//     boolean var4 = var2.isSupportLowerBoundInclusive();
//     double var5 = var2.getStandardDeviation();
//     double var7 = var2.inverseCumulativeProbability(0.0d);
//     double var8 = var2.getSupportLowerBound();
//     boolean var9 = var2.isSupportUpperBoundInclusive();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.5995519938706146d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test391"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements((-1178076066));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     int var7 = var1.nextInt((-1250178885), 99);
//     double var10 = var1.nextGaussian(13.221586840309266d, Double.NaN);
//     double var13 = var1.nextUniform((-0.015775579295520044d), 342.4199650603462d);
//     int var16 = var1.nextZipf(90, 0.7201909394952613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-833879679));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 141.3335728128604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 10);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test393"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((-833879679), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-833879679));

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test394"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-8.428574917575162d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test395"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    org.apache.commons.math3.util.ResizableDoubleArray var15 = var14.copy();
    int var16 = var14.getNumElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setContractionCriteria(0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 101);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test396"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    var1.contract();
    float var15 = var1.getContractionCriteria();
    double var17 = var1.substituteMostRecentElement(0.0d);
    var1.contract();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test397"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.0f, 798385500);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test398"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.0d, 0.5566299156929325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5566299156929325d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test399"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(2.0542576475351547E24d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4332681701395432E12d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test401"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    float var2 = var1.getExpansionFactor();
    double[] var3 = var1.getInternalValues();
    var1.clear();
    float var5 = var1.getContractionCriteria();
    double[] var6 = var1.getInternalValues();
    org.apache.commons.math3.util.ResizableDoubleArray var7 = var1.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test402"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck(101, 6350);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6451);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test403"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    int var14 = var1.start();
    double[] var15 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var16 = new org.apache.commons.math3.util.ResizableDoubleArray(var15);
    org.apache.commons.math3.util.ResizableDoubleArray var17 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    org.apache.commons.math3.util.ResizableDoubleArray var18 = new org.apache.commons.math3.util.ResizableDoubleArray(var16);
    double[] var19 = var16.getElements();
    var16.setExpansionMode(1);
    double[] var22 = var16.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var16);
    double[] var24 = var1.getInternalValues();
    double[] var25 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var26 = new org.apache.commons.math3.util.ResizableDoubleArray(var25);
    float var27 = var26.getExpansionFactor();
    int var28 = var26.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var29 = var26.copy();
    var29.setElement(20925, (-7.249376137847348d));
    double[] var33 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var34 = new org.apache.commons.math3.util.ResizableDoubleArray(var33);
    org.apache.commons.math3.util.ResizableDoubleArray var35 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    var34.setNumElements(1);
    int var38 = var34.getExpansionMode();
    double var40 = var34.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var42 = var34.addElementRolling(100.0d);
    double[] var43 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var44 = new org.apache.commons.math3.util.ResizableDoubleArray(var43);
    org.apache.commons.math3.util.ResizableDoubleArray var45 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
    org.apache.commons.math3.util.ResizableDoubleArray var46 = new org.apache.commons.math3.util.ResizableDoubleArray(var44);
    double[] var47 = var44.getElements();
    var44.setElement(100, 1.0d);
    double[] var51 = var44.getElements();
    var34.addElements(var51);
    var34.setNumElements(68921);
    org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var34);
    var34.setContractionCriteria(2.0f);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var29, var34);
    org.apache.commons.math3.util.ResizableDoubleArray.copy(var1, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test404"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var8 = var6.sample(34);
    double[] var9 = var1.rank(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test405"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var1 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var1);
//     org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
//     java.lang.String var4 = var2.toString();
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     double var22 = var12.inverseCumulativeProbability(0.0d);
//     double var23 = var12.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31.334440965421432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12.042003251456551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 26.193218263811488d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 5.753228331479579d);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test407"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.3674212569981512d);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0.367) exceeded"+ "'", var2.equals("org.apache.commons.math3.exception.MaxCountExceededException: illegal state: maximal count (0.367) exceeded"));

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test408"); }


    double var1 = org.apache.commons.math3.special.Erf.erf((-0.3930649841662833d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.42170562608721146d));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(47, 0.0f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test410"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(86.76099095416971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86.0d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test411"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.3841858E-7f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0f));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test412"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test413"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.MaxCountExceededException var6 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var8 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var9 = var8.toString();
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var8);
    var6.addSuppressed((java.lang.Throwable)var8);
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    org.apache.commons.math3.exception.util.Localizable var17 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var18 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException(var17, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException(var15, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException(var14, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var13, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var12, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalArgumentException var25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.NullArgumentException var27 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var28 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var29 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var9.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test414"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos(0.024802061667175728d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.89016721807293d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test415"); }
// 
// 
//     double[] var0 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
//     org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
//     double[] var4 = var1.getElements();
//     var1.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
//     boolean var11 = var1.equals((java.lang.Object)var8);
//     boolean var13 = var1.equals((java.lang.Object)'#');
//     float var14 = var1.getContractionCriteria();
//     var1.contract();
//     var1.setNumElements(100);
//     double[] var18 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     org.apache.commons.math3.util.ResizableDoubleArray var20 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     org.apache.commons.math3.util.ResizableDoubleArray var21 = new org.apache.commons.math3.util.ResizableDoubleArray(var19);
//     double[] var22 = var19.getElements();
//     var19.setElement(100, 1.0d);
//     org.apache.commons.math3.exception.util.Localizable var26 = null;
//     org.apache.commons.math3.stat.ranking.NaNStrategy[] var27 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
//     org.apache.commons.math3.exception.MathIllegalStateException var28 = new org.apache.commons.math3.exception.MathIllegalStateException(var26, (java.lang.Object[])var27);
//     boolean var29 = var19.equals((java.lang.Object)var26);
//     boolean var31 = var19.equals((java.lang.Object)'#');
//     float var32 = var19.getContractionCriteria();
//     var19.contract();
//     var19.setNumElements(100);
//     double[] var36 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var37 = new org.apache.commons.math3.util.ResizableDoubleArray(var36);
//     org.apache.commons.math3.util.ResizableDoubleArray var38 = new org.apache.commons.math3.util.ResizableDoubleArray(var37);
//     var37.setNumElements(1);
//     int var41 = var37.getExpansionMode();
//     double var43 = var37.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
//     double[] var44 = var37.getElements();
//     var19.addElements(var44);
//     int var46 = var19.start();
//     double[] var47 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var48 = new org.apache.commons.math3.util.ResizableDoubleArray(var47);
//     float var49 = var48.getExpansionFactor();
//     double[] var50 = var48.getInternalValues();
//     var48.clear();
//     float var52 = var48.getContractionCriteria();
//     double[] var53 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var54 = new org.apache.commons.math3.util.ResizableDoubleArray(var53);
//     org.apache.commons.math3.util.ResizableDoubleArray var55 = new org.apache.commons.math3.util.ResizableDoubleArray(var54);
//     var54.discardFrontElements(0);
//     boolean var59 = var54.equals((java.lang.Object)(short)1);
//     double[] var61 = new double[] { 10.0d};
//     var54.addElements(var61);
//     var48.addElements(var61);
//     org.apache.commons.math3.util.ResizableDoubleArray.copy(var19, var48);
//     org.apache.commons.math3.random.RandomGenerator var65 = null;
//     org.apache.commons.math3.random.RandomDataImpl var66 = new org.apache.commons.math3.random.RandomDataImpl(var65);
//     double var68 = var66.nextExponential(100.0d);
//     int var71 = var66.nextZipf(10, 100.0d);
//     int var74 = var66.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var77 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var78 = var66.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var77);
//     double var79 = var77.getStandardDeviation();
//     double var81 = var77.cumulativeProbability((-2.0439843355597187d));
//     double[] var83 = var77.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var84 = new org.apache.commons.math3.util.ResizableDoubleArray(var83);
//     double[] var85 = new double[] { };
//     org.apache.commons.math3.util.ResizableDoubleArray var86 = new org.apache.commons.math3.util.ResizableDoubleArray(var85);
//     float var87 = var86.getExpansionFactor();
//     double[] var88 = var86.getInternalValues();
//     var84.addElements(var88);
//     var48.addElements(var88);
//     var1.addElements(var88);
//     double[] var92 = var1.getElements();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 2.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 104.59606098392227d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 0.7723748773849395d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 2.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test416"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.TiesStrategy var11 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var12 = var10.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var13);
    org.apache.commons.math3.stat.ranking.TiesStrategy var15 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var16 = var14.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var19 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var21 = var19.sample(34);
    double[] var22 = var14.rank(var21);
    double[] var23 = var10.rank(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test417"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setElement(100, 1.0d);
    double[] var18 = var11.getElements();
    var1.addElements(var18);
    var1.setNumElements(68921);
    org.apache.commons.math3.util.ResizableDoubleArray var22 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setExpansionFactor(2.4999998f);
    double var26 = var1.addElementRolling((-17.89215974098645d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardFrontElements(27985566);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 100.0d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test418"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(73.13855026261534d, 19.79060019102854d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 75.76882861994271d);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test419"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientLog(0, 1508);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test420"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var9 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var9);
    boolean var11 = var1.equals((java.lang.Object)var8);
    boolean var13 = var1.equals((java.lang.Object)'#');
    org.apache.commons.math3.util.ResizableDoubleArray var14 = var1.copy();
    int var15 = var14.getExpansionMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test421"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var11 = var10.isSupportUpperBoundInclusive();
    boolean var12 = var1.equals((java.lang.Object)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addElement(0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test422"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(1243621435034931200L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1243621435034931200L);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test423"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    int var3 = var1.getExpansionMode();
    org.apache.commons.math3.util.ResizableDoubleArray var4 = var1.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addElement(6.275922619569235d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test424"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(266.70649629911264d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.436916340478475d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test425"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-56), (-60));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3360);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test426"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var3.setExpansionMode(0);
    double[] var6 = var3.getElements();
    double[] var7 = var3.getElements();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var3.addElementRolling(1.0836469666713937d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.9451837163806285d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.568938887225696d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test428"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(3239152727494122237L, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((-475858716), 1508);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test430"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-5.642305350660976d), (-7.5884915066300875d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.456257875940908d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test431"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0066969781551766E-4d, (java.lang.Number)(-1.0d), false);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.nextF(0.28263707322912984d, (-2.410194294496317d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "27eb16d3a17cedf6ca466b12469c51ba3f1622e4d3e0db6ccf5d16839542adf0d761a197da87ed32a754ebddbde0e04be000"+ "'", var3.equals("27eb16d3a17cedf6ca466b12469c51ba3f1622e4d3e0db6ccf5d16839542adf0d761a197da87ed32a754ebddbde0e04be000"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.4150078766330145d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 22);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test433"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(6451, 99.99999f, 4.5918E-41f);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test434"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(4.5916E-41f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var4 = new org.apache.commons.math3.util.ResizableDoubleArray(1018498664, 3.944305E-30f, 2.0f, (-1250178885));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeedSecure(0L);
//     var1.reSeedSecure(1558790486165778433L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b26f96f0932105e93234358ad57798f89ca797d245857fb3b2e65b9c1e9249e8aee0a4e6a6989566ce3f53fe7521d8ae2493"+ "'", var3.equals("b26f96f0932105e93234358ad57798f89ca797d245857fb3b2e65b9c1e9249e8aee0a4e6a6989566ce3f53fe7521d8ae2493"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.7834879445067402d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test437"); }


    org.apache.commons.math3.stat.ranking.TiesStrategy var0 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var1 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var0);
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = var1.getTiesStrategy();
    org.apache.commons.math3.stat.ranking.NaNStrategy var3 = var1.getNanStrategy();
    org.apache.commons.math3.distribution.NormalDistribution var6 = new org.apache.commons.math3.distribution.NormalDistribution(0.4920673008707643d, 1.876817614886854d);
    double[] var8 = var6.sample(34);
    double[] var9 = var1.rank(var8);
    org.apache.commons.math3.util.ResizableDoubleArray var10 = new org.apache.commons.math3.util.ResizableDoubleArray(var9);
    var10.addElement(45.9548879662945d);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var10.copy();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test438"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.8974256635155496d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6236244533177808d);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-10.817465674450201d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.999979953694278d));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test440"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling((-0.6123797044686811d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test441"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     double var8 = var1.nextChiSquare(3.616242248904851d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextWeibull(111.10643218159737d, (-13.17690971916771d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "5a785282058193c07b991262ca555cf5b68fb7e9dbbe9e89094d68d5a6fe5c7da3153be71cad5707ee58587e52b19d964cc9"+ "'", var3.equals("5a785282058193c07b991262ca555cf5b68fb7e9dbbe9e89094d68d5a6fe5c7da3153be71cad5707ee58587e52b19d964cc9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5352829751698043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.5377356505436175d);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test442"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck(70, (-1250175769));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1250175839);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test443"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(41, (-1231361484));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1231361484));

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test444"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(62.556381183280465d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.4E-45f);
    java.lang.Number var3 = var2.getMin();
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var5);
    var2.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-20.269663961976036d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 20.269663961976036d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test447"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    org.apache.commons.math3.util.ResizableDoubleArray var8 = var1.copy();
    var1.clear();
    org.apache.commons.math3.distribution.NormalDistribution var10 = new org.apache.commons.math3.distribution.NormalDistribution();
    boolean var11 = var10.isSupportUpperBoundInclusive();
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = var1.copy();
    double[] var14 = var1.getInternalValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test448"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(11.224799109881092d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.503466602496354d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test449"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(2.842171E-14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.842171E-14f);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test450"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.getElement((-96));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test451"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.09144282391696697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0957541239726638d);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var14 = var12.getStandardDeviation();
//     double var16 = var12.cumulativeProbability((-2.0439843355597187d));
//     double[] var18 = var12.sample(25);
//     org.apache.commons.math3.util.ResizableDoubleArray var19 = new org.apache.commons.math3.util.ResizableDoubleArray(var18);
//     double[] var20 = var19.getInternalValues();
//     double[] var21 = var19.getElements();
//     double[] var22 = var19.getInternalValues();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 298.5965118176636d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.504049273836974d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.4505451791095725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test453"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.09144282391696697d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.09169855452891158d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test454"); }


    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(2325);
    int var2 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.discardMostRecentElements((-1091499589));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var5 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var1, (java.lang.Number)(-2.0439843355597187d), (java.lang.Number)52.001078291710975d, false);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test456"); }


    org.apache.commons.math3.exception.MaxCountExceededException var1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)(-6.349539183359093d));
    org.apache.commons.math3.exception.MaxCountExceededException var3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number)0.9999996848245061d);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0);
    java.lang.String var6 = var5.toString();
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    var3.addSuppressed((java.lang.Throwable)var5);
    var1.addSuppressed((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var3.getContext();
    java.lang.Number var11 = var3.getMax();
    java.lang.Number var12 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"+ "'", var6.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0.9999996848245061d+ "'", var11.equals(0.9999996848245061d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 0.9999996848245061d+ "'", var12.equals(0.9999996848245061d));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test457"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    var1.clear();
    int var11 = var1.getExpansionMode();
    int var12 = var1.getExpansionMode();
    int var13 = var1.start();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setElement((-92158364), (-18.804897963419908d));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.2100466270217347d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.2100466270217347d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test459"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(5.960466E-8f, (-0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960466E-8f);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test460"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(51, 172565);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test461"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     double var8 = var1.nextT(6.066191094237188E76d);
//     double var11 = var1.nextGaussian(6.0502044810397875d, 1.9142161307821561d);
//     org.apache.commons.math3.random.RandomGenerator var12 = null;
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl(var12);
//     java.lang.String var15 = var13.nextHexString(100);
//     double var18 = var13.nextGaussian(0.0d, 2.251752586176186d);
//     int var21 = var13.nextInt((-1), 1);
//     int var24 = var13.nextSecureInt(0, 34);
//     var13.reSeedSecure();
//     org.apache.commons.math3.distribution.NormalDistribution var28 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var29 = var28.getNumericalVariance();
//     boolean var30 = var28.isSupportConnected();
//     double var33 = var28.cumulativeProbability((-0.48609186402077603d), 1.0652279546366723d);
//     double var35 = var28.density(0.0d);
//     boolean var36 = var28.isSupportUpperBoundInclusive();
//     double var38 = var28.density(5.964535219365547d);
//     double var39 = var13.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var28);
//     org.apache.commons.math3.distribution.NormalDistribution var42 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var43 = var42.getNumericalVariance();
//     double var44 = var42.getNumericalMean();
//     double var45 = var42.getSupportLowerBound();
//     double var46 = var13.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var42);
//     double var47 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var42);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var50 = var1.nextWeibull(21954.99676616325d, (-8.520991649862598d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11.20773363014805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1.0831254036108435E-10d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8.274305858234783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "45fe94ba2c48a770f7ca84869de7b1a8fa205762f3a7075d889b3822636cd9b68a089a350757a95b6fe9aebe95d0a0792255"+ "'", var15.equals("45fe94ba2c48a770f7ca84869de7b1a8fa205762f3a7075d889b3822636cd9b68a089a350757a95b6fe9aebe95d0a0792255"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-2.1226294689961507d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.06146076675140928d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.039766406469604984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.031733077854635645d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-11.464234987531297d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 6.0042374946587955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 6.393912320209072d);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test462"); }


    double var1 = org.apache.commons.math3.special.Gamma.lanczos((-0.3215992052665822d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 54.88674248780567d);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test463"); }
// 
// 
//     double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaQ((-2.410194294496317d), 3.9716384933144453d, 20.100377448632262d, 27985567);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test464"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.08631729905748209d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test465"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(350134950387303632L, (-110L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test466"); }


    org.apache.commons.math3.distribution.NormalDistribution var3 = new org.apache.commons.math3.distribution.NormalDistribution(33.684359025435676d, 2.44430201837607d, 9.717962678996846d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test467"); }


    java.math.BigInteger var0 = null;
    java.math.BigInteger var2 = org.apache.commons.math3.util.ArithmeticUtils.pow(var0, 0L);
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0);
    java.math.BigInteger var8 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, 4665724868967888896L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test468"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(52.001078291710975d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test469"); }
// 
// 
//     org.apache.commons.math3.distribution.NormalDistribution var0 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var1 = var0.getNumericalMean();
//     double var2 = var0.sample();
//     var0.reseedRandomGenerator(1765921446827724705L);
//     double[] var6 = var0.sample(14);
//     var0.reseedRandomGenerator((-2025644137419103210L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.18730418355959236d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     int var9 = var1.nextInt((-1), 1);
//     int var12 = var1.nextSecureInt(0, 34);
//     var1.reSeed();
//     int var17 = var1.nextHypergeometric(68921, 3, 6350);
//     org.apache.commons.math3.distribution.NormalDistribution var20 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var21 = var20.sample();
//     double var23 = var20.density(18.409703235248998d);
//     double var25 = var20.probability(9.34227543668857d);
//     double var26 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var29 = var1.nextSecureInt(23, (-589261714));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "2feeb2cb7adad777a2e0a033516f10d022b9206630e221b47609d5f35fc1fa0c4df7c08fee217f50e4bb05a57ed5b5a31d13"+ "'", var3.equals("2feeb2cb7adad777a2e0a033516f10d022b9206630e221b47609d5f35fc1fa0c4df7c08fee217f50e4bb05a57ed5b5a31d13"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.6476708088491745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 19.338561017286388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006302513166439201d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 4.434601921513211d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test471"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray((-12573));
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test472"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.8260180801643263d, 0.34176273066585183d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14249261883262265d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test473"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(6.034079778370001d, (-4.710933495145894d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.034079778370001d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test474"); }


    long var2 = org.apache.commons.math3.util.ArithmeticUtils.gcd(5L, 541811409497799232L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextGaussian(0.0d, 2.251752586176186d);
//     double var8 = var1.nextT(1.0d);
//     int var11 = var1.nextSecureInt((-1371062271), 190);
//     long var14 = var1.nextSecureLong(0L, 18L);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var1.nextInversionDeviate(var15);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test476"); }


    double var4 = org.apache.commons.math3.special.Gamma.regularizedGammaP(110.43579544915016d, 0.14389500536894387d, 29.554682320900305d, 68921);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 7.308656079578379E-273d);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test477"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextHexString(100);
//     double var6 = var1.nextUniform(0.04499920941044011d, 0.918918213896427d);
//     int var9 = var1.nextZipf(1024, 6.605358949815338d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var1.nextHexString((-997090893));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "63ebf4933a8418308df018af00546e0b4788f49eaa79820af03d0011dfc574df51f3cf5f992e76f18bc5bf0cbba6a0832c0f"+ "'", var3.equals("63ebf4933a8418308df018af00546e0b4788f49eaa79820af03d0011dfc574df51f3cf5f992e76f18bc5bf0cbba6a0832c0f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7824015698300356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test478"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.28583983826614007d, (java.lang.Number)0.06812197096180644d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test479"); }


    int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(235, 32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7520);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test480"); }


    org.apache.commons.math3.stat.ranking.NaturalRanking var0 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var1 = var0.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var2 = null;
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var3 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var2);
    java.lang.Class var4 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var5 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var6 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var5);
    org.apache.commons.math3.stat.ranking.TiesStrategy var7 = var6.getTiesStrategy();
    java.lang.String var8 = var7.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var9 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var10 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var1, var7);
    org.apache.commons.math3.stat.ranking.NaturalRanking var11 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var12 = var11.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var13 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var14 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var12, var13);
    org.apache.commons.math3.stat.ranking.NaNStrategy var15 = var14.getNanStrategy();
    org.apache.commons.math3.stat.ranking.TiesStrategy var16 = var14.getTiesStrategy();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var17 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var16);
    org.apache.commons.math3.stat.ranking.NaturalRanking var18 = new org.apache.commons.math3.stat.ranking.NaturalRanking();
    org.apache.commons.math3.stat.ranking.NaNStrategy var19 = var18.getNanStrategy();
    org.apache.commons.math3.random.RandomGenerator var20 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var21 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19, var20);
    org.apache.commons.math3.stat.ranking.NaturalRanking var22 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var19);
    org.apache.commons.math3.stat.ranking.NaNStrategy var23 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var24 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var23);
    org.apache.commons.math3.stat.ranking.TiesStrategy var25 = var24.getTiesStrategy();
    java.lang.String var26 = var25.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var27 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var19, var25);
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var28 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var25);
    java.lang.Class var29 = var1.getDeclaringClass();
    org.apache.commons.math3.stat.ranking.NaNStrategy var30 = null;
    org.apache.commons.math3.stat.ranking.NaturalRanking var31 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var30);
    org.apache.commons.math3.stat.ranking.TiesStrategy var32 = var31.getTiesStrategy();
    java.lang.String var33 = var32.name();
    org.apache.commons.math3.stat.ranking.NaturalRanking var34 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.NaturalRanking var35 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    org.apache.commons.math3.stat.ranking.NaturalRanking var36 = new org.apache.commons.math3.stat.ranking.NaturalRanking(var32);
    java.lang.String var37 = var32.name();
    org.apache.commons.math3.stat.inference.MannWhitneyUTest var38 = new org.apache.commons.math3.stat.inference.MannWhitneyUTest(var1, var32);
    java.lang.Class var39 = var32.getDeclaringClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "AVERAGE"+ "'", var8.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "AVERAGE"+ "'", var26.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "AVERAGE"+ "'", var33.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "AVERAGE"+ "'", var37.equals("AVERAGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test481"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.stat.ranking.TiesStrategy var1 = org.apache.commons.math3.stat.ranking.TiesStrategy.valueOf("c9f912b5e0632db4675751f24415a1ace096564c14e87c480e5147f4b61e8ec55d25bf20bd4e5cb2bf9adf0e1ff38e2c6640");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test482"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.stat.ranking.NaNStrategy[] var3 = org.apache.commons.math3.stat.ranking.NaNStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var4 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     double var11 = var1.nextT(1.3877787807814457E-17d);
//     org.apache.commons.math3.distribution.NormalDistribution var14 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var15 = var14.sample();
//     boolean var16 = var14.isSupportLowerBoundInclusive();
//     double var17 = var14.getStandardDeviation();
//     double var19 = var14.inverseCumulativeProbability(0.0d);
//     double var20 = var14.getSupportLowerBound();
//     double var21 = var14.getSupportUpperBound();
//     double var22 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var25 = var1.nextSecureLong(1298433376908083868L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 147.03901036099828d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.3701879770273167E153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.115403383125189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-10.648227008309197d));
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test484"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck(34, (-475858716));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test485"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(6.22183085353382d, 0.4650525586097103d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4961897680208476d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test486"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)145.07341190090915d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test487"); }


    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(27, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.discardFrontElements(285460);
      fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException");
    } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test488"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.math.BigInteger var2 = null;
    java.math.BigInteger var4 = org.apache.commons.math3.util.ArithmeticUtils.pow(var2, 0L);
    java.math.BigInteger var6 = org.apache.commons.math3.util.ArithmeticUtils.pow(var4, 0);
    java.math.BigInteger var7 = null;
    java.math.BigInteger var9 = org.apache.commons.math3.util.ArithmeticUtils.pow(var7, 0L);
    java.math.BigInteger var11 = org.apache.commons.math3.util.ArithmeticUtils.pow(var9, 0);
    java.math.BigInteger var12 = org.apache.commons.math3.util.ArithmeticUtils.pow(var6, var11);
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var1, (java.lang.Number)var11, (java.lang.Number)(short)1, (java.lang.Number)(-0.7656658570186433d));
    org.apache.commons.math3.exception.NotPositiveException var16 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)var11);
    java.math.BigInteger var18 = org.apache.commons.math3.util.ArithmeticUtils.pow(var11, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.math.BigInteger var20 = org.apache.commons.math3.util.ArithmeticUtils.pow(var18, (-1175508555));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test489"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.7772054281156179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7772054281156179d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test491"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    var1.setNumElements(1);
    int var5 = var1.getExpansionMode();
    double var7 = var1.substituteMostRecentElement(Double.NEGATIVE_INFINITY);
    double var9 = var1.addElementRolling(100.0d);
    double[] var10 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var11 = new org.apache.commons.math3.util.ResizableDoubleArray(var10);
    org.apache.commons.math3.util.ResizableDoubleArray var12 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    org.apache.commons.math3.util.ResizableDoubleArray var13 = new org.apache.commons.math3.util.ResizableDoubleArray(var11);
    double[] var14 = var11.getElements();
    var11.setElement(100, 1.0d);
    double[] var18 = var11.getElements();
    var1.addElements(var18);
    float var20 = var1.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == Double.NEGATIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1268.568243354647d, (java.lang.Number)0.7250514821907734d, true);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test493"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.569453864216163d), 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.5286160771182778E8d));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test494"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.3847728247431226d, (-117325921));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test495"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.stat.ranking.TiesStrategy[] var2 = org.apache.commons.math3.stat.ranking.TiesStrategy.values();
    org.apache.commons.math3.exception.MathIllegalStateException var3 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     double var6 = var1.nextCauchy((-0.9575217061535136d), 3.941334262707623E-6d);
//     double var9 = var1.nextCauchy(82.16419961411961d, 0.056750019064709015d);
//     double var12 = var1.nextCauchy((-0.9575511737800637d), 0.9836610997948011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 151.79363279792122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9575279383622874d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 82.12164525754102d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.7606854562036675d));
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test497"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     int var4 = var1.nextInt((-2), 1);
//     org.apache.commons.math3.distribution.NormalDistribution var5 = new org.apache.commons.math3.distribution.NormalDistribution();
//     double var6 = var5.getNumericalMean();
//     double var7 = var5.sample();
//     var5.reseedRandomGenerator(1765921446827724705L);
//     double var10 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var5);
//     long var12 = var1.nextPoisson(1.1088745506274904E8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3629757414633832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.035559525180011625d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 110902986L);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test498"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextExponential(100.0d);
//     int var6 = var1.nextZipf(10, 100.0d);
//     int var9 = var1.nextZipf(10, 3.1622776601683795d);
//     org.apache.commons.math3.distribution.NormalDistribution var12 = new org.apache.commons.math3.distribution.NormalDistribution((-0.8011436155469337d), 10.0d);
//     double var13 = var1.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution)var12);
//     double var15 = var12.cumulativeProbability((-1.0d));
//     double var16 = var12.getNumericalVariance();
//     double var17 = var12.getMean();
//     double var18 = var12.sample();
//     double var20 = var12.density(0.06446622075849562d);
//     double var22 = var12.density(0.06828906586604412d);
//     double var23 = var12.getNumericalMean();
//     var12.reseedRandomGenerator(1131479055207487616L);
//     double var26 = var12.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 351.3089700409443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 13.086361713947607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4920673008707643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 8.38800405021927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.039745047845647995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.03974372976297623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-0.8011436155469337d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test499"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var2 = org.apache.commons.math3.util.ArithmeticUtils.lcm(42L, (-2025644137419103232L));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test500"); }


    double[] var0 = new double[] { };
    org.apache.commons.math3.util.ResizableDoubleArray var1 = new org.apache.commons.math3.util.ResizableDoubleArray(var0);
    org.apache.commons.math3.util.ResizableDoubleArray var2 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    org.apache.commons.math3.util.ResizableDoubleArray var3 = new org.apache.commons.math3.util.ResizableDoubleArray(var1);
    double[] var4 = var1.getElements();
    var1.setElement(100, 1.0d);
    double[] var8 = var1.getElements();
    org.apache.commons.math3.util.ResizableDoubleArray var9 = new org.apache.commons.math3.util.ResizableDoubleArray(var8);
    double var11 = var9.addElementRolling(0.0d);
    var9.addElement((-0.7014095186799629d));
    float var14 = var9.getExpansionFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);

  }

}
