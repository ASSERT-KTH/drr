
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.FieldElement var18 = var7.getTrace();
    org.apache.commons.math.linear.FieldLUDecompositionImpl var19 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var7);
    org.apache.commons.math.linear.FieldMatrix var20 = var19.getL();
    org.apache.commons.math.linear.FieldMatrix var21 = var19.getP();
    org.apache.commons.math.linear.Array2DRowRealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    org.apache.commons.math.linear.NonSquareMatrixException var3 = new org.apache.commons.math.linear.NonSquareMatrixException(2147483647, 2);
    java.lang.String var4 = var3.getPattern();
    java.lang.Object[] var5 = var3.getArguments();
    org.apache.commons.math.ode.DerivativeException var6 = new org.apache.commons.math.ode.DerivativeException("", var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "a {0}x{1} matrix was provided instead of a square matrix"+ "'", var4.equals("a {0}x{1} matrix was provided instead of a square matrix"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldMatrix var31 = var25.copy();
    org.apache.commons.math.linear.FieldMatrix var32 = var25.transpose();
    org.apache.commons.math.linear.FieldLUDecompositionImpl var33 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var25);
    org.apache.commons.math.FieldElement var34 = var33.getDeterminant();
    org.apache.commons.math.linear.FieldDecompositionSolver var35 = var33.getSolver();
    int[] var36 = var33.getPivot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldVector var32 = var7.getRowVector(0);
    org.apache.commons.math.linear.FieldMatrix var35 = var7.createMatrix(1, 1);
    int var36 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var38 = new org.apache.commons.math.fraction.BigFraction(1L);
    java.math.BigInteger var39 = var38.getDenominator();
    org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var42 = var41.abs();
    org.apache.commons.math.fraction.BigFraction var43 = var42.reciprocal();
    org.apache.commons.math.fraction.BigFraction var45 = var43.pow(1);
    byte var46 = var45.byteValue();
    float var47 = var45.floatValue();
    boolean var48 = var38.equals((java.lang.Object)var45);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var38);
    org.apache.commons.math.FieldElement var50 = var7.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var49);
    org.apache.commons.math.fraction.BigFraction var54 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var55 = var54.abs();
    org.apache.commons.math.fraction.BigFraction var57 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var58 = var57.abs();
    org.apache.commons.math.fraction.BigFraction var59 = var58.reciprocal();
    org.apache.commons.math.fraction.BigFraction var61 = var59.pow(1);
    byte var62 = var61.byteValue();
    float var63 = var61.floatValue();
    org.apache.commons.math.fraction.BigFraction var65 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var66 = var65.abs();
    org.apache.commons.math.fraction.BigFraction var68 = var65.subtract(100L);
    java.lang.String var69 = var68.toString();
    org.apache.commons.math.fraction.BigFraction var70 = var61.divide(var68);
    org.apache.commons.math.fraction.BigFraction var72 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var73 = var72.abs();
    org.apache.commons.math.fraction.BigFraction var74 = var73.reciprocal();
    org.apache.commons.math.fraction.BigFraction var76 = var74.pow(1);
    byte var77 = var76.byteValue();
    java.math.BigInteger var78 = var76.getDenominator();
    org.apache.commons.math.fraction.BigFraction var79 = var70.divide(var78);
    org.apache.commons.math.fraction.BigFraction var80 = var54.subtract(var78);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.multiplyEntry(0, 10, (org.apache.commons.math.FieldElement)var80);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "-90"+ "'", var69.equals("-90"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldMatrix var32 = var25.getRowMatrix(0);
    int var33 = var25.getRowDimension();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var36 = var25.createMatrix((-1), 2);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
//     org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
//     org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
//     org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
//     org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
//     org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
//     int var8 = var7.getRowDimension();
//     org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
//     org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
//     org.apache.commons.math.FieldElement[] var13 = new org.apache.commons.math.FieldElement[] { var12};
//     org.apache.commons.math.linear.FieldVector var14 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var13);
//     org.apache.commons.math.FieldElement[][] var15 = new org.apache.commons.math.FieldElement[][] { var13};
//     org.apache.commons.math.linear.BlockFieldMatrix var16 = new org.apache.commons.math.linear.BlockFieldMatrix(var15);
//     org.apache.commons.math.linear.FieldMatrix var18 = var16.getColumnMatrix(0);
//     org.apache.commons.math.linear.BlockFieldMatrix var19 = var7.subtract(var16);
//     int var20 = var19.getColumnDimension();
//     org.apache.commons.math.fraction.BigFraction var22 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var23 = var22.abs();
//     org.apache.commons.math.fraction.BigFraction var24 = var23.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var26 = var24.pow(1);
//     byte var27 = var26.byteValue();
//     float var28 = var26.floatValue();
//     org.apache.commons.math.fraction.BigFraction var30 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var31 = var30.abs();
//     org.apache.commons.math.fraction.BigFraction var33 = var30.subtract(100L);
//     java.lang.String var34 = var33.toString();
//     org.apache.commons.math.fraction.BigFraction var35 = var26.divide(var33);
//     org.apache.commons.math.fraction.BigFraction var37 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var38 = var37.abs();
//     org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var41 = var39.pow(1);
//     byte var42 = var41.byteValue();
//     java.math.BigInteger var43 = var41.getDenominator();
//     org.apache.commons.math.fraction.BigFraction var44 = var35.divide(var43);
//     org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction(var43);
//     org.apache.commons.math.linear.FieldMatrix var46 = var19.scalarAdd((org.apache.commons.math.FieldElement)var45);
//     java.io.ObjectInputStream var48 = null;
//     org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object)var45, "org.apache.commons.math.ode.DerivativeException: ", var48);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    java.lang.Object[] var3 = null;
    org.apache.commons.math.ode.events.EventException var4 = new org.apache.commons.math.ode.events.EventException("hi!", var3);
    java.io.IOException var5 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var4);
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math.ConvergenceException var7 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[])var6);
    org.apache.commons.math.linear.MatrixIndexException var8 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[])var6);
    java.lang.String var9 = var8.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: "+ "'", var9.equals("org.apache.commons.math.MaxEvaluationsExceededException: "));

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }
// 
// 
//     double[] var6 = new double[] { 100.0d, (-1.0d)};
//     double[] var9 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var10 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var6, var9);
//     double[][] var11 = new double[][] { var9};
//     org.apache.commons.math.linear.RealMatrix var12 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var11);
//     org.apache.commons.math.MathRuntimeException var13 = new org.apache.commons.math.MathRuntimeException("hi!", (java.lang.Object[])var11);
//     org.apache.commons.math.ode.IntegratorException var14 = new org.apache.commons.math.ode.IntegratorException("Dormand-Prince 8 (5, 3)", (java.lang.Object[])var11);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var11);
//     java.io.ObjectOutputStream var16 = null;
//     org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix)var15, var16);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.fraction.BigFraction var32 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var33 = var32.abs();
    org.apache.commons.math.fraction.BigFraction var34 = var33.reduce();
    org.apache.commons.math.FieldElement[] var35 = new org.apache.commons.math.FieldElement[] { var34};
    org.apache.commons.math.linear.FieldVector var36 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var35);
    org.apache.commons.math.FieldElement[][] var37 = new org.apache.commons.math.FieldElement[][] { var35};
    org.apache.commons.math.linear.BlockFieldMatrix var38 = new org.apache.commons.math.linear.BlockFieldMatrix(var37);
    int var39 = var38.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var42 = var41.abs();
    org.apache.commons.math.fraction.BigFraction var43 = var42.reduce();
    org.apache.commons.math.FieldElement[] var44 = new org.apache.commons.math.FieldElement[] { var43};
    org.apache.commons.math.linear.FieldVector var45 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var44);
    org.apache.commons.math.FieldElement[][] var46 = new org.apache.commons.math.FieldElement[][] { var44};
    org.apache.commons.math.linear.BlockFieldMatrix var47 = new org.apache.commons.math.linear.BlockFieldMatrix(var46);
    org.apache.commons.math.linear.FieldMatrix var49 = var47.getColumnMatrix(0);
    org.apache.commons.math.linear.BlockFieldMatrix var50 = var38.subtract(var47);
    org.apache.commons.math.linear.BlockFieldMatrix var51 = var25.multiply(var50);
    java.lang.String[] var53 = new java.lang.String[] { "-90"};
    org.apache.commons.math.linear.BigMatrix var54 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var53);
    java.lang.String[][] var55 = new java.lang.String[][] { var53};
    org.apache.commons.math.linear.BigMatrix var56 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var55);
    org.apache.commons.math.fraction.BigFraction var58 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var59 = var58.abs();
    org.apache.commons.math.fraction.BigFraction var60 = var59.reduce();
    org.apache.commons.math.FieldElement[] var61 = new org.apache.commons.math.FieldElement[] { var60};
    org.apache.commons.math.linear.FieldVector var62 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var61);
    org.apache.commons.math.FieldElement[][] var63 = new org.apache.commons.math.FieldElement[][] { var61};
    org.apache.commons.math.linear.BlockFieldMatrix var64 = new org.apache.commons.math.linear.BlockFieldMatrix(var63);
    org.apache.commons.math.linear.BlockFieldMatrix var65 = new org.apache.commons.math.linear.BlockFieldMatrix(var63);
    org.apache.commons.math.fraction.BigFraction var67 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var68 = var67.abs();
    org.apache.commons.math.fraction.BigFraction var69 = var68.reduce();
    org.apache.commons.math.FieldElement[] var70 = new org.apache.commons.math.FieldElement[] { var69};
    org.apache.commons.math.linear.FieldVector var71 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var70);
    org.apache.commons.math.FieldElement[][] var72 = new org.apache.commons.math.FieldElement[][] { var70};
    org.apache.commons.math.linear.BlockFieldMatrix var73 = new org.apache.commons.math.linear.BlockFieldMatrix(var72);
    int var74 = var73.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var77 = var73.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var79 = var73.getRowVector(0);
    org.apache.commons.math.linear.BlockFieldMatrix var80 = var65.subtract(var73);
    org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix)var56, (org.apache.commons.math.linear.AnyMatrix)var80);
    org.apache.commons.math.linear.BlockFieldMatrix var82 = var50.subtract(var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowRealMatrix var83 = org.apache.commons.math.linear.MatrixUtils.fractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var80);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetFunctionValueAccuracy();
    var0.resetFunctionValueAccuracy();
    int var3 = var0.getIterationCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.apache.commons.math.linear.NonSquareMatrixException var2 = new org.apache.commons.math.linear.NonSquareMatrixException(0, 10);
    org.apache.commons.math.ode.DerivativeException var3 = new org.apache.commons.math.ode.DerivativeException((java.lang.Throwable)var2);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     var8.clearStepHandlers();
//     java.util.Collection var10 = var8.getEventHandlers();
//     var8.setInitialStepSize(1.0E-15d);
//     java.io.ObjectInputStream var14 = null;
//     org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object)1.0E-15d, "org.apache.commons.math.linear.InvalidMatrixException: ", var14);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    java.lang.Object[] var2 = null;
    org.apache.commons.math.MaxIterationsExceededException var3 = new org.apache.commons.math.MaxIterationsExceededException(9000, "", var2);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    java.lang.Throwable var13 = null;
    org.apache.commons.math.fraction.BigFraction var18 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var19 = var18.abs();
    org.apache.commons.math.fraction.BigFraction var20 = var19.reduce();
    org.apache.commons.math.FieldElement[] var21 = new org.apache.commons.math.FieldElement[] { var20};
    org.apache.commons.math.linear.FieldVector var22 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var21);
    org.apache.commons.math.FieldElement[][] var23 = new org.apache.commons.math.FieldElement[][] { var21};
    org.apache.commons.math.linear.BlockFieldMatrix var24 = new org.apache.commons.math.linear.BlockFieldMatrix(var23);
    int var25 = var24.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var28 = var24.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var30 = var24.getRowVector(0);
    org.apache.commons.math.fraction.BigFraction var33 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var34 = var33.abs();
    org.apache.commons.math.fraction.BigFraction var35 = var34.reduce();
    org.apache.commons.math.FieldElement[] var36 = new org.apache.commons.math.FieldElement[] { var35};
    org.apache.commons.math.linear.FieldVector var37 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var36);
    org.apache.commons.math.FieldElement[][] var38 = new org.apache.commons.math.FieldElement[][] { var36};
    org.apache.commons.math.linear.BlockFieldMatrix var39 = new org.apache.commons.math.linear.BlockFieldMatrix(var38);
    int var40 = var39.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var42 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var43 = var42.abs();
    org.apache.commons.math.fraction.BigFraction var44 = var43.reduce();
    double var46 = var43.pow((-1.0d));
    double var47 = var43.percentageValue();
    org.apache.commons.math.FieldElement[] var48 = new org.apache.commons.math.FieldElement[] { var43};
    org.apache.commons.math.FieldElement[] var49 = var39.operate(var48);
    var24.setRow(0, var48);
    org.apache.commons.math.FieldElement[][] var51 = var24.getData();
    org.apache.commons.math.linear.InvalidMatrixException var52 = new org.apache.commons.math.linear.InvalidMatrixException("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[])var51);
    org.apache.commons.math.FunctionEvaluationException var53 = new org.apache.commons.math.FunctionEvaluationException(var13, 1.0d, "", (java.lang.Object[])var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.copySubMatrix((-10), 2, 0, 9000, var51);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    long var4 = var2.getDenominatorAsLong();
    java.math.BigInteger var5 = var2.getDenominator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.apache.commons.math.linear.BigMatrix var1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFractionField var3 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var4 = var3.getZero();
    org.apache.commons.math.fraction.BigFraction var5 = var3.getOne();
    org.apache.commons.math.fraction.BigFraction var6 = var2.add(var5);
    org.apache.commons.math.fraction.BigFraction var8 = var2.pow((-90L));
    org.apache.commons.math.fraction.BigFraction var10 = var8.pow(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0E-15d, (-90000.0d), 0.0d, 25.954553519470085d);
    org.apache.commons.math.ode.sampling.StepHandler var5 = null;
    var4.addStepHandler(var5);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    org.apache.commons.math.linear.RealVector var10 = org.apache.commons.math.linear.MatrixUtils.createRealVector(var7);
    java.lang.Object[] var12 = null;
    org.apache.commons.math.FunctionEvaluationException var13 = new org.apache.commons.math.FunctionEvaluationException(var7, "", var12);
    java.lang.String var14 = var13.getPattern();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var9 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var5, var8);
    double[][] var10 = new double[][] { var8};
    org.apache.commons.math.linear.Array2DRowRealMatrix var11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var10);
    org.apache.commons.math.ode.IntegratorException var12 = new org.apache.commons.math.ode.IntegratorException("", (java.lang.Object[])var10);
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var23 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var19, var22);
    double[][] var24 = new double[][] { var22};
    org.apache.commons.math.linear.Array2DRowRealMatrix var25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var24);
    java.lang.ArithmeticException var26 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[])var24);
    org.apache.commons.math.MathException var27 = new org.apache.commons.math.MathException((java.lang.Throwable)var12, "0", (java.lang.Object[])var24);
    org.apache.commons.math.linear.Array2DRowRealMatrix var28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var24);
    double[] var33 = new double[] { 100.0d, (-1.0d)};
    double[] var36 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var37 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var33, var36);
    org.apache.commons.math.linear.Array2DRowRealMatrix var38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var36);
    double[][] var39 = var38.getDataRef();
    double[][] var40 = var38.getDataRef();
    double[][] var41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var40);
    double[][] var42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var41);
    org.apache.commons.math.linear.BlockRealMatrix var43 = new org.apache.commons.math.linear.BlockRealMatrix(var41);
    java.lang.Object var44 = null;
    boolean var45 = var43.equals(var44);
    org.apache.commons.math.linear.BlockRealMatrix var47 = var43.getColumnMatrix(1);
    double[] var52 = new double[] { 100.0d, (-1.0d)};
    double[] var55 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var56 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var52, var55);
    double[][] var57 = new double[][] { var55};
    org.apache.commons.math.linear.RealMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var57);
    org.apache.commons.math.linear.BlockRealMatrix var59 = new org.apache.commons.math.linear.BlockRealMatrix(var57);
    org.apache.commons.math.linear.RealVector var61 = var59.getColumnVector(0);
    org.apache.commons.math.linear.RealVector var62 = var47.preMultiply(var61);
    org.apache.commons.math.linear.RealVector var63 = var28.preMultiply(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var11 = var7.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var13 = var7.getRowVector(0);
    org.apache.commons.math.fraction.BigFraction var15 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var16 = var15.abs();
    org.apache.commons.math.fraction.BigFraction var17 = var16.reduce();
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var17};
    org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
    org.apache.commons.math.FieldElement[][] var20 = new org.apache.commons.math.FieldElement[][] { var18};
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    int var22 = var21.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var24 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var25 = var24.abs();
    org.apache.commons.math.fraction.BigFraction var26 = var25.reduce();
    double var28 = var25.pow((-1.0d));
    double var29 = var25.percentageValue();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.FieldElement[] var31 = var21.operate(var30);
    org.apache.commons.math.FieldElement[] var32 = var7.operate(var31);
    org.apache.commons.math.fraction.BigFraction var36 = new org.apache.commons.math.fraction.BigFraction(10.0d, 1000.0d, 100);
    org.apache.commons.math.FieldElement[] var37 = new org.apache.commons.math.FieldElement[] { var36};
    org.apache.commons.math.linear.FieldMatrix var38 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var37);
    org.apache.commons.math.linear.FieldMatrix var39 = var7.preMultiply(var38);
    org.apache.commons.math.FunctionEvaluationException var41 = new org.apache.commons.math.FunctionEvaluationException((-1.0d));
    org.apache.commons.math.MathRuntimeException var42 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var41);
    org.apache.commons.math.MathRuntimeException var43 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var41);
    boolean var44 = var7.equals((java.lang.Object)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var1 = new double[] { };
//     var0.reinitialize(var1, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var4 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     var0.shift();
//     double var6 = var0.getPreviousTime();
//     org.apache.commons.math.ode.events.CombinedEventsManager var9 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     boolean var10 = var9.isEmpty();
//     java.util.Collection var11 = var9.getEventsStates();
//     var9.clearEventsHandlers();
//     java.util.Collection var13 = var9.getEventsStates();
//     double[] var19 = new double[] { 100.0d, (-1.0d)};
//     double[] var22 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var23 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var19, var22);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var22);
//     double[][] var25 = var24.getDataRef();
//     double[][] var26 = var24.getDataRef();
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var35 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var31, var34);
//     double[][] var36 = new double[][] { var34};
//     org.apache.commons.math.linear.RealMatrix var37 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var36);
//     org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
//     org.apache.commons.math.linear.RealVector var40 = var38.getColumnVector(0);
//     double var41 = var38.getFrobeniusNorm();
//     org.apache.commons.math.linear.RealMatrix var42 = var24.multiply((org.apache.commons.math.linear.RealMatrix)var38);
//     org.apache.commons.math.linear.RealVector var44 = var38.getColumnVector(0);
//     org.apache.commons.math.linear.RealMatrix var46 = var38.getRowMatrix(0);
//     org.apache.commons.math.linear.BlockRealMatrix var47 = var38.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var50 = var38.createMatrix(100, 10);
//     int var51 = var50.getRowDimension();
//     org.apache.commons.math.linear.BlockRealMatrix var53 = var50.getRowMatrix(0);
//     double[] var55 = var50.getRow(0);
//     boolean var56 = var9.reset(Double.NaN, var55);
//     double[] var61 = new double[] { 100.0d, (-1.0d)};
//     double[] var64 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var65 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var61, var64);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var64);
//     double[][] var67 = var66.getDataRef();
//     double[][] var68 = var66.getDataRef();
//     org.apache.commons.math.linear.RealMatrix var71 = var66.createMatrix(2, 100);
//     double[] var76 = new double[] { 100.0d, (-1.0d)};
//     double[] var79 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var80 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var76, var79);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var79);
//     double[][] var82 = var81.getDataRef();
//     double[][] var83 = var81.getDataRef();
//     org.apache.commons.math.linear.Array2DRowRealMatrix var84 = var66.subtract(var81);
//     var0.reinitialize((-1.0d), (-90000.0d), var55, var66);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var86 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     var86.finalizeStep();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.FieldElement var18 = var7.getTrace();
    int var19 = var7.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var22 = var21.abs();
    org.apache.commons.math.fraction.BigFraction var23 = var22.reduce();
    double var24 = var23.doubleValue();
    java.math.BigDecimal var25 = var23.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var27 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var28 = var27.abs();
    java.math.BigDecimal var30 = var27.bigDecimalValue(0);
    org.apache.commons.math.fraction.BigFraction var31 = var23.multiply(var27);
    org.apache.commons.math.linear.FieldMatrix var32 = var7.scalarMultiply((org.apache.commons.math.FieldElement)var23);
    org.apache.commons.math.fraction.BigFraction var34 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var35 = var34.abs();
    org.apache.commons.math.fraction.BigFraction var36 = var35.reduce();
    org.apache.commons.math.FieldElement[] var37 = new org.apache.commons.math.FieldElement[] { var36};
    org.apache.commons.math.linear.FieldVector var38 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var37);
    org.apache.commons.math.FieldElement[][] var39 = new org.apache.commons.math.FieldElement[][] { var37};
    org.apache.commons.math.linear.BlockFieldMatrix var40 = new org.apache.commons.math.linear.BlockFieldMatrix(var39);
    int var41 = var40.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var43 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var44 = var43.abs();
    org.apache.commons.math.fraction.BigFraction var45 = var44.reduce();
    double var47 = var44.pow((-1.0d));
    double var48 = var44.percentageValue();
    org.apache.commons.math.FieldElement[] var49 = new org.apache.commons.math.FieldElement[] { var44};
    org.apache.commons.math.FieldElement[] var50 = var40.operate(var49);
    org.apache.commons.math.FieldElement var51 = var40.getTrace();
    int var52 = var40.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var54 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var55 = var54.abs();
    org.apache.commons.math.fraction.BigFraction var56 = var55.reduce();
    double var57 = var56.doubleValue();
    java.math.BigDecimal var58 = var56.bigDecimalValue();
    org.apache.commons.math.fraction.BigFraction var60 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var61 = var60.abs();
    java.math.BigDecimal var63 = var60.bigDecimalValue(0);
    org.apache.commons.math.fraction.BigFraction var64 = var56.multiply(var60);
    org.apache.commons.math.linear.FieldMatrix var65 = var40.scalarMultiply((org.apache.commons.math.FieldElement)var56);
    org.apache.commons.math.linear.FieldMatrix var66 = var7.multiply((org.apache.commons.math.linear.FieldMatrix)var40);
    org.apache.commons.math.linear.FieldMatrix var67 = var7.copy();
    org.apache.commons.math.fraction.BigFraction var71 = new org.apache.commons.math.fraction.BigFraction(10.0d, 1000.0d, 100);
    double var72 = var71.percentageValue();
    org.apache.commons.math.fraction.BigFraction var73 = var71.reciprocal();
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var74 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var73);
    org.apache.commons.math.fraction.BigFraction var79 = org.apache.commons.math.fraction.BigFraction.getReducedFraction(8, 100);
    java.lang.String var80 = var79.toString();
    org.apache.commons.math.FieldElement var81 = var74.visit(8, 100, (org.apache.commons.math.FieldElement)var79);
    org.apache.commons.math.FieldElement var82 = var7.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var74);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var87 = var7.getSubMatrix((-1), (-1), 100, 100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + "2 / 25"+ "'", var80.equals("2 / 25"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.pow(1);
    byte var6 = var5.byteValue();
    java.math.BigInteger var7 = var5.getDenominator();
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var10 = var9.abs();
    long var11 = var9.longValue();
    org.apache.commons.math.fraction.BigFraction var13 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var14 = var13.abs();
    org.apache.commons.math.fraction.BigFraction var15 = var14.reduce();
    org.apache.commons.math.fraction.BigFraction var17 = var15.divide((-1));
    long var18 = var17.getDenominatorAsLong();
    int var19 = var9.compareTo(var17);
    java.math.BigInteger var20 = var17.getNumerator();
    org.apache.commons.math.fraction.BigFraction var22 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var23 = var22.abs();
    org.apache.commons.math.fraction.BigFraction var24 = var23.reciprocal();
    org.apache.commons.math.fraction.BigFraction var26 = var24.pow(1);
    byte var27 = var26.byteValue();
    float var28 = var26.floatValue();
    org.apache.commons.math.fraction.BigFraction var30 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var31 = var30.abs();
    org.apache.commons.math.fraction.BigFraction var33 = var30.subtract(100L);
    java.lang.String var34 = var33.toString();
    org.apache.commons.math.fraction.BigFraction var35 = var26.divide(var33);
    org.apache.commons.math.fraction.BigFraction var37 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var38 = var37.abs();
    org.apache.commons.math.fraction.BigFraction var39 = var38.reciprocal();
    org.apache.commons.math.fraction.BigFraction var41 = var39.pow(1);
    byte var42 = var41.byteValue();
    java.math.BigInteger var43 = var41.getDenominator();
    org.apache.commons.math.fraction.BigFraction var44 = var35.divide(var43);
    org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction(var43);
    org.apache.commons.math.fraction.BigFraction var46 = new org.apache.commons.math.fraction.BigFraction(var20, var43);
    org.apache.commons.math.fraction.BigFraction var47 = new org.apache.commons.math.fraction.BigFraction(var7, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "-90"+ "'", var34.equals("-90"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     boolean var1 = var0.isEmpty();
//     java.util.Collection var2 = var0.getEventsStates();
//     org.apache.commons.math.ode.events.CombinedEventsManager var3 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var4 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator();
//     var4.storeTime((-1.0d));
//     boolean var7 = var3.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var4);
//     java.util.Collection var8 = var3.getEventsStates();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var9 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     var9.shift();
//     boolean var11 = var9.isForward();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var12 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var9);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var15 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var16 = new double[] { };
//     var15.reinitialize(var16, false);
//     java.lang.Object[] var24 = new java.lang.Object[] { 1L};
//     java.lang.ArithmeticException var25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var24);
//     java.lang.ArithmeticException var26 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var24);
//     double[] var31 = new double[] { 100.0d, (-1.0d)};
//     double[] var34 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var35 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var31, var34);
//     java.lang.Object[] var42 = new java.lang.Object[] { 0L};
//     org.apache.commons.math.MaxEvaluationsExceededException var43 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var42);
//     java.io.EOFException var44 = org.apache.commons.math.MathRuntimeException.createEOFException("", var42);
//     java.io.EOFException var45 = org.apache.commons.math.MathRuntimeException.createEOFException("", var42);
//     org.apache.commons.math.FunctionEvaluationException var46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var26, var31, "hi!", var42);
//     double[] var51 = new double[] { 100.0d, (-1.0d)};
//     double[] var54 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var55 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var51, var54);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var54);
//     double[][] var57 = var56.getDataRef();
//     var15.reinitialize(Double.NaN, 100.0d, var31, var56);
//     double[] var63 = new double[] { 100.0d, (-1.0d)};
//     double[] var66 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var67 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var63, var66);
//     double[][] var68 = new double[][] { var66};
//     org.apache.commons.math.linear.Array2DRowRealMatrix var69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var68);
//     boolean var71 = var69.equals((java.lang.Object)(-1));
//     var12.reinitialize(0.9d, 100.0d, var31, var69);
//     boolean var73 = var3.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var12);
//     double var74 = var12.getPreviousTime();
//     var12.setInterpolatedTime(1.4142135623730951d);
//     var12.shift();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var78 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var12);
//     boolean var79 = var0.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var12);
//     double[] var80 = var12.getInterpolatedDerivatives();
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    double[] var5 = new double[] { (-1.0d), 10.0d, (-1.0d)};
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var14 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var10, var13);
    org.apache.commons.math.linear.BigMatrix var15 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var13);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var17 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, true);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var19 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var13, false);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var20 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(0.2d, 0.0d, var5, var13);
    int var21 = var20.getMaxEvaluations();
    java.util.Collection var22 = var20.getStepHandlers();
    int var23 = var20.getOrder();
    int var24 = var20.getOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 8);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0d, (-1.0d), 1.0d, 0.0d);
    double var5 = var4.getSafety();
    org.apache.commons.math.ode.sampling.StepHandler var6 = null;
    var4.addStepHandler(var6);
    int var8 = var4.getEvaluations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    org.apache.commons.math.fraction.FractionConversionException var2 = new org.apache.commons.math.fraction.FractionConversionException(2.0d, (-1));
    org.apache.commons.math.fraction.FractionConversionException var6 = new org.apache.commons.math.fraction.FractionConversionException(10.0d, 10L, 1L);
    var2.addSuppressed((java.lang.Throwable)var6);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    long var2 = var1.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var4 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var5 = var4.abs();
    org.apache.commons.math.fraction.BigFraction var6 = var5.reciprocal();
    org.apache.commons.math.fraction.BigFraction var8 = var6.pow(1);
    org.apache.commons.math.fraction.BigFraction var9 = var1.subtract(var6);
    org.apache.commons.math.FieldElement[] var10 = new org.apache.commons.math.FieldElement[] { var6};
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var10);
    org.apache.commons.math.linear.FieldMatrix var12 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createRowFieldMatrix(var10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var13 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var16 = var13.createMatrix((-10), 0);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    org.apache.commons.math.linear.Array2DRowRealMatrix var2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(10, 100);
    int var3 = var2.getColumnDimension();
    int var4 = var2.getColumnDimension();
    java.lang.String var5 = var2.toString();
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var14 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var10, var13);
    double[][] var15 = new double[][] { var13};
    org.apache.commons.math.linear.RealMatrix var16 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var15);
    org.apache.commons.math.linear.BlockRealMatrix var17 = new org.apache.commons.math.linear.BlockRealMatrix(var15);
    org.apache.commons.math.linear.RealVector var19 = var17.getColumnVector(0);
    int var20 = var17.getColumnDimension();
    org.apache.commons.math.linear.RealMatrix var22 = var17.getColumnMatrix(0);
    org.apache.commons.math.linear.RealMatrix var24 = var17.scalarMultiply(2.0d);
    double[] var29 = new double[] { 100.0d, (-1.0d)};
    double[] var32 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var33 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var29, var32);
    double[][] var34 = new double[][] { var32};
    org.apache.commons.math.linear.Array2DRowRealMatrix var35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var34);
    double[] var40 = new double[] { 100.0d, (-1.0d)};
    double[] var43 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var44 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var40, var43);
    org.apache.commons.math.linear.Array2DRowRealMatrix var45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var43);
    double[][] var46 = var45.getDataRef();
    double[][] var47 = var45.getDataRef();
    double[] var52 = new double[] { 100.0d, (-1.0d)};
    double[] var55 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var56 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var52, var55);
    double[][] var57 = new double[][] { var55};
    org.apache.commons.math.linear.RealMatrix var58 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var57);
    org.apache.commons.math.linear.BlockRealMatrix var59 = new org.apache.commons.math.linear.BlockRealMatrix(var57);
    org.apache.commons.math.linear.RealVector var61 = var59.getColumnVector(0);
    double var62 = var59.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var63 = var45.multiply((org.apache.commons.math.linear.RealMatrix)var59);
    org.apache.commons.math.linear.Array2DRowRealMatrix var64 = var35.multiply(var45);
    org.apache.commons.math.linear.BlockRealMatrix var65 = var17.subtract((org.apache.commons.math.linear.RealMatrix)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.Array2DRowRealMatrix var66 = var2.multiply(var35);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"+ "'", var5.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.linear.RealVector var13 = var11.getColumnVector(0);
    int var14 = var11.getColumnDimension();
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var23 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var19, var22);
    org.apache.commons.math.linear.Array2DRowRealMatrix var24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var22);
    double[][] var25 = var24.getDataRef();
    double[][] var26 = var24.getDataRef();
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var35 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var31, var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math.linear.RealMatrix var37 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var36);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    org.apache.commons.math.linear.RealVector var40 = var38.getColumnVector(0);
    double var41 = var38.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var42 = var24.multiply((org.apache.commons.math.linear.RealMatrix)var38);
    double[] var47 = new double[] { 100.0d, (-1.0d)};
    double[] var50 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var51 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var47, var50);
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var50);
    double[][] var53 = var52.getDataRef();
    double[][] var54 = var52.getDataRef();
    double[] var59 = new double[] { 100.0d, (-1.0d)};
    double[] var62 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var63 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var59, var62);
    double[][] var64 = new double[][] { var62};
    org.apache.commons.math.linear.RealMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var64);
    org.apache.commons.math.linear.BlockRealMatrix var66 = new org.apache.commons.math.linear.BlockRealMatrix(var64);
    org.apache.commons.math.linear.RealVector var68 = var66.getColumnVector(0);
    double var69 = var66.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var70 = var52.multiply((org.apache.commons.math.linear.RealMatrix)var66);
    org.apache.commons.math.linear.RealVector var72 = var66.getColumnVector(0);
    org.apache.commons.math.linear.RealVector var73 = var38.preMultiply(var72);
    org.apache.commons.math.linear.BlockRealMatrix var74 = var11.add(var38);
    org.apache.commons.math.linear.BlockRealMatrix var75 = var38.copy();
    org.apache.commons.math.linear.BlockRealMatrix var77 = var75.getColumnMatrix(1);
    org.apache.commons.math.ode.events.CombinedEventsManager var78 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var79 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator();
    var79.storeTime((-1.0d));
    boolean var82 = var78.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var79);
    java.util.Collection var83 = var78.getEventsStates();
    org.apache.commons.math.ode.events.CombinedEventsManager var84 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var85 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator();
    var85.storeTime((-1.0d));
    boolean var88 = var84.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var85);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var89 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var85);
    boolean var90 = var78.evaluateStep((org.apache.commons.math.ode.sampling.StepInterpolator)var89);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var91 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var89);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var92 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var89);
    boolean var93 = var75.equals((java.lang.Object)var89);
    org.apache.commons.math.linear.RealMatrixPreservingVisitor var94 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var75.walkInOptimizedOrder(var94, 10, 1, 0, (-10));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    org.apache.commons.math.linear.RealMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    org.apache.commons.math.linear.RealMatrix var11 = var10.copy();
    org.apache.commons.math.linear.RealMatrixChangingVisitor var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var10.walkInOptimizedOrder(var12, 0, 2, 2, 100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    double[][] var10 = var9.getDataRef();
    int var11 = var9.getColumnDimension();
    org.apache.commons.math.linear.RealMatrix var12 = var9.copy();
    org.apache.commons.math.linear.RealMatrix var14 = var9.scalarMultiply(1.0d);
    double[][] var15 = var9.getData();
    org.apache.commons.math.linear.RealMatrix var17 = var9.scalarAdd(1.0E-15d);
    org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix)var17, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, (-1.0d), 1.0E-15d, 0.1d);
    var5.setMinReduction(0.0d);
    int var8 = var5.getMaxEvaluations();
    org.apache.commons.math.ode.events.EventHandler var9 = null;
    var5.addEventHandler(var9, 1.0650410894399627d, 1.0650410894399627d, 100);
    var5.clearStepHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2147483647);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var5 = var3.divide((-1));
    long var6 = var5.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var7 = var5.getField();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var7, 10);
    org.apache.commons.math.linear.BlockFieldMatrix var13 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var7, 2, 8);
    org.apache.commons.math.FieldElement var14 = null;
    org.apache.commons.math.linear.FieldMatrix var15 = var13.scalarMultiply(var14);
    org.apache.commons.math.linear.FieldMatrix var16 = var13.transpose();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var5 = var3.divide((-1));
    long var6 = var5.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var7 = var5.getField();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.fraction.BigFraction var10 = var8.multiply((-1L));
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(1L);
    org.apache.commons.math.fraction.BigFraction var16 = new org.apache.commons.math.fraction.BigFraction(10.0d, 1000.0d, 100);
    double var17 = var16.percentageValue();
    org.apache.commons.math.fraction.BigFraction var18 = var16.reciprocal();
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var19 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var18);
    org.apache.commons.math.fraction.BigFraction var20 = var18.reduce();
    org.apache.commons.math.fraction.BigFraction var22 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var23 = var22.abs();
    org.apache.commons.math.fraction.BigFraction var24 = var23.reduce();
    double var25 = var24.doubleValue();
    org.apache.commons.math.fraction.BigFraction var26 = var24.negate();
    java.math.BigInteger var27 = var24.getDenominator();
    org.apache.commons.math.fraction.BigFraction var28 = var18.add(var27);
    org.apache.commons.math.fraction.BigFraction var29 = var12.divide(var27);
    org.apache.commons.math.fraction.BigFraction var30 = var10.multiply(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var4 = var3.negate();
    org.apache.commons.math.fraction.BigFraction var6 = var4.divide(100);
    org.apache.commons.math.fraction.BigFraction var8 = var4.multiply(1);
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(0.0d);
    java.math.BigInteger var11 = var10.getDenominator();
    org.apache.commons.math.fraction.BigFraction var14 = new org.apache.commons.math.fraction.BigFraction(10L, 100L);
    org.apache.commons.math.fraction.BigFractionField var15 = var14.getField();
    org.apache.commons.math.fraction.BigFraction var17 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var18 = var17.abs();
    long var19 = var17.longValue();
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var22 = var21.abs();
    org.apache.commons.math.fraction.BigFraction var23 = var22.reduce();
    org.apache.commons.math.fraction.BigFraction var25 = var23.divide((-1));
    long var26 = var25.getDenominatorAsLong();
    int var27 = var17.compareTo(var25);
    java.math.BigInteger var28 = var25.getNumerator();
    org.apache.commons.math.fraction.BigFraction var29 = var14.multiply(var28);
    org.apache.commons.math.fraction.BigFraction var30 = new org.apache.commons.math.fraction.BigFraction(var11, var28);
    org.apache.commons.math.fraction.BigFraction var31 = var8.multiply(var28);
    org.apache.commons.math.fraction.BigFraction var33 = var8.divide(9000);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    java.lang.String[] var1 = new java.lang.String[] { "Maximal number of iterations ({0}) exceeded"};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.BigMatrix var2 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var1);
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    java.lang.Object[] var1 = null;
    java.lang.IllegalArgumentException var2 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.ConvergenceException var3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     var8.clearStepHandlers();
//     double var10 = var8.getCurrentSignedStepsize();
//     java.lang.String var11 = var8.getName();
//     double var12 = var8.getCurrentStepStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Dormand-Prince 8 (5, 3)"+ "'", var11.equals("Dormand-Prince 8 (5, 3)"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.FieldElement[] var32 = var7.getRow(0);
    org.apache.commons.math.linear.FieldVector var34 = var7.getRowVector(0);
    org.apache.commons.math.fraction.BigFraction var36 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var37 = var36.abs();
    org.apache.commons.math.fraction.BigFraction var38 = var37.reduce();
    org.apache.commons.math.FieldElement[] var39 = new org.apache.commons.math.FieldElement[] { var38};
    org.apache.commons.math.linear.FieldVector var40 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var39);
    org.apache.commons.math.FieldElement[][] var41 = new org.apache.commons.math.FieldElement[][] { var39};
    org.apache.commons.math.linear.BlockFieldMatrix var42 = new org.apache.commons.math.linear.BlockFieldMatrix(var41);
    int var43 = var42.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var46 = var45.abs();
    org.apache.commons.math.fraction.BigFraction var47 = var46.reduce();
    double var49 = var46.pow((-1.0d));
    double var50 = var46.percentageValue();
    org.apache.commons.math.FieldElement[] var51 = new org.apache.commons.math.FieldElement[] { var46};
    org.apache.commons.math.FieldElement[] var52 = var42.operate(var51);
    org.apache.commons.math.fraction.BigFraction var54 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var55 = var54.abs();
    org.apache.commons.math.fraction.BigFraction var56 = var55.reduce();
    org.apache.commons.math.FieldElement[] var57 = new org.apache.commons.math.FieldElement[] { var56};
    org.apache.commons.math.linear.FieldVector var58 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var57);
    org.apache.commons.math.FieldElement[][] var59 = new org.apache.commons.math.FieldElement[][] { var57};
    org.apache.commons.math.linear.BlockFieldMatrix var60 = new org.apache.commons.math.linear.BlockFieldMatrix(var59);
    int var61 = var60.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var64 = var60.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var65 = var42.add(var60);
    org.apache.commons.math.fraction.BigFraction var67 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var68 = var67.abs();
    java.math.BigDecimal var70 = var67.bigDecimalValue(0);
    org.apache.commons.math.linear.FieldMatrix var71 = var65.scalarAdd((org.apache.commons.math.FieldElement)var67);
    org.apache.commons.math.linear.FieldMatrix var72 = var7.preMultiply(var71);
    org.apache.commons.math.linear.Array2DRowRealMatrix var73 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix((org.apache.commons.math.linear.FieldMatrix)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var73.addToEntry(0, 100, (-1.0d));
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     var8.clearStepHandlers();
//     java.util.Collection var10 = var8.getEventHandlers();
//     double var11 = var8.getCurrentStepStart();
//     int var12 = var8.getOrder();
//     java.util.Collection var13 = var8.getEventHandlers();
//     double var14 = var8.getSafety();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.9d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var9 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var5, var8);
    org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var8);
    double[][] var11 = var10.getDataRef();
    double[][] var12 = var10.getDataRef();
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var21 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var17, var20);
    double[][] var22 = new double[][] { var20};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var22);
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var22);
    org.apache.commons.math.linear.RealVector var26 = var24.getColumnVector(0);
    double var27 = var24.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var28 = var10.multiply((org.apache.commons.math.linear.RealMatrix)var24);
    int var29 = var10.getRowDimension();
    double[][] var30 = var10.getData();
    java.lang.ArithmeticException var31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("-1 / 9000", (java.lang.Object[])var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math.linear.MatrixIndexException var2 = new org.apache.commons.math.linear.MatrixIndexException("", var1);
    org.apache.commons.math.fraction.BigFraction var5 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var6 = var5.abs();
    org.apache.commons.math.fraction.BigFraction var7 = var6.reduce();
    org.apache.commons.math.FieldElement[] var8 = new org.apache.commons.math.FieldElement[] { var7};
    org.apache.commons.math.linear.FieldVector var9 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var8);
    org.apache.commons.math.FieldElement[][] var10 = new org.apache.commons.math.FieldElement[][] { var8};
    org.apache.commons.math.linear.BlockFieldMatrix var11 = new org.apache.commons.math.linear.BlockFieldMatrix(var10);
    int var12 = var11.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var14 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var15 = var14.abs();
    org.apache.commons.math.fraction.BigFraction var16 = var15.reduce();
    double var18 = var15.pow((-1.0d));
    double var19 = var15.percentageValue();
    org.apache.commons.math.FieldElement[] var20 = new org.apache.commons.math.FieldElement[] { var15};
    org.apache.commons.math.FieldElement[] var21 = var11.operate(var20);
    org.apache.commons.math.ConvergenceException var22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var2, "hi!", (java.lang.Object[])var21);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var23 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var21);
    org.apache.commons.math.fraction.BigFraction var27 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var28 = var27.abs();
    org.apache.commons.math.fraction.BigFraction var29 = var28.reduce();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var29};
    org.apache.commons.math.linear.FieldVector var31 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var30);
    org.apache.commons.math.FieldElement[][] var32 = new org.apache.commons.math.FieldElement[][] { var30};
    org.apache.commons.math.linear.BlockFieldMatrix var33 = new org.apache.commons.math.linear.BlockFieldMatrix(var32);
    int var34 = var33.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var37 = var33.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var39 = var33.getRowVector(0);
    org.apache.commons.math.FieldElement[][] var40 = var33.getData();
    java.io.EOFException var41 = org.apache.commons.math.MathRuntimeException.createEOFException("Dormand-Prince 8 (5, 3)", (java.lang.Object[])var40);
    java.lang.ArrayIndexOutOfBoundsException var42 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("evaluation failed for argument = {0}", (java.lang.Object[])var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setSubMatrix(var40, (-1), 9000);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetFunctionValueAccuracy();
    var0.setRelativeAccuracy(0.0d);
    var0.setAbsoluteAccuracy(1000.0d);
    var0.resetRelativeAccuracy();
    var0.setAbsoluteAccuracy((-910.0d));

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     double var9 = var8.getCurrentStepStart();
//     var8.setMaxEvaluations(0);
//     double var12 = var8.getMaxGrowth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 10.0d);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var5 = var3.divide((-1));
    long var6 = var5.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var7 = var5.getField();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var7, 10);
    org.apache.commons.math.linear.BlockFieldMatrix var13 = new org.apache.commons.math.linear.BlockFieldMatrix((org.apache.commons.math.Field)var7, 2, 8);
    org.apache.commons.math.Field var14 = var13.getField();
    org.apache.commons.math.linear.FieldVector var16 = var13.getColumnVector(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }
// 
// 
//     double[] var7 = new double[] { 100.0d, (-1.0d)};
//     double[] var10 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var11 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var7, var10);
//     org.apache.commons.math.linear.BigMatrix var12 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var10);
//     java.lang.Object[] var18 = new java.lang.Object[] { 0L};
//     org.apache.commons.math.MaxEvaluationsExceededException var19 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var18);
//     java.io.EOFException var20 = org.apache.commons.math.MathRuntimeException.createEOFException("", var18);
//     java.io.EOFException var21 = org.apache.commons.math.MathRuntimeException.createEOFException("", var18);
//     java.lang.Object[] var24 = new java.lang.Object[] { 1L};
//     java.lang.ArithmeticException var25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var24);
//     org.apache.commons.math.ode.events.EventException var26 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var25);
//     java.lang.IllegalArgumentException var27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var25);
//     var21.addSuppressed((java.lang.Throwable)var25);
//     double[] var35 = new double[] { 100.0d, (-1.0d)};
//     double[] var38 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var39 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var35, var38);
//     double[][] var40 = new double[][] { var38};
//     org.apache.commons.math.linear.RealMatrix var41 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var40);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var40);
//     java.lang.ArrayIndexOutOfBoundsException var43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", (java.lang.Object[])var40);
//     org.apache.commons.math.MathRuntimeException var44 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var25, "org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[])var40);
//     java.lang.Object[] var48 = new java.lang.Object[] { 0L};
//     org.apache.commons.math.MaxEvaluationsExceededException var49 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var48);
//     org.apache.commons.math.ConvergenceException var50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var49);
//     double[] var55 = new double[] { 100.0d, (-1.0d)};
//     double[] var58 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var59 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var55, var58);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var58);
//     java.lang.Object[] var65 = new java.lang.Object[] { 1L};
//     java.lang.ArithmeticException var66 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var65);
//     java.lang.ArithmeticException var67 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var65);
//     org.apache.commons.math.FunctionEvaluationException var68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var50, var58, "hi!", var65);
//     org.apache.commons.math.fraction.BigFraction var71 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var72 = var71.abs();
//     org.apache.commons.math.fraction.BigFraction var73 = var72.reduce();
//     org.apache.commons.math.FieldElement[] var74 = new org.apache.commons.math.FieldElement[] { var73};
//     org.apache.commons.math.linear.FieldVector var75 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var74);
//     org.apache.commons.math.FieldElement[][] var76 = new org.apache.commons.math.FieldElement[][] { var74};
//     org.apache.commons.math.linear.BlockFieldMatrix var77 = new org.apache.commons.math.linear.BlockFieldMatrix(var76);
//     int var78 = var77.getRowDimension();
//     org.apache.commons.math.fraction.BigFraction var80 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var81 = var80.abs();
//     org.apache.commons.math.fraction.BigFraction var82 = var81.reduce();
//     double var84 = var81.pow((-1.0d));
//     double var85 = var81.percentageValue();
//     org.apache.commons.math.FieldElement[] var86 = new org.apache.commons.math.FieldElement[] { var81};
//     org.apache.commons.math.FieldElement[] var87 = var77.operate(var86);
//     org.apache.commons.math.FunctionEvaluationException var88 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var44, var58, "-90", (java.lang.Object[])var87);
//     org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var89 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(10, (-1.0d), 2.0d, var10, var58);
//     double var90 = var89.getSafety();
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var95 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1000.0d, 1.0E-15d, 0.0d, 1.0E-15d);
//     var89.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var95);
//     double var97 = var95.getCurrentStepStart();
//     int var98 = var95.getOrder();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 0.1d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1000.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 0.9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var97 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == 8);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, 0.9d, (-1.0d), 1.0E-14d, 1.0E100d);
    var5.setMinReduction(1.0E-15d);
    double[] var12 = new double[] { 100.0d, (-1.0d)};
    double[] var15 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var16 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var12, var15);
    var16.clearStepHandlers();
    var16.clearStepHandlers();
    org.apache.commons.math.ode.sampling.StepHandler var19 = null;
    var16.addStepHandler(var19);
    var5.setStarterIntegrator((org.apache.commons.math.ode.FirstOrderIntegrator)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
//     org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
//     org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
//     org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
//     org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
//     org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
//     org.apache.commons.math.linear.FieldMatrix var9 = var7.getColumnMatrix(0);
//     org.apache.commons.math.fraction.BigFraction var11 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var12 = var11.abs();
//     org.apache.commons.math.fraction.BigFraction var13 = var12.reduce();
//     org.apache.commons.math.FieldElement[] var14 = new org.apache.commons.math.FieldElement[] { var13};
//     org.apache.commons.math.linear.FieldVector var15 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var14);
//     org.apache.commons.math.FieldElement[][] var16 = new org.apache.commons.math.FieldElement[][] { var14};
//     org.apache.commons.math.linear.BlockFieldMatrix var17 = new org.apache.commons.math.linear.BlockFieldMatrix(var16);
//     int var18 = var17.getRowDimension();
//     org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var21 = var20.abs();
//     org.apache.commons.math.fraction.BigFraction var22 = var21.reduce();
//     double var24 = var21.pow((-1.0d));
//     double var25 = var21.percentageValue();
//     org.apache.commons.math.FieldElement[] var26 = new org.apache.commons.math.FieldElement[] { var21};
//     org.apache.commons.math.FieldElement[] var27 = var17.operate(var26);
//     org.apache.commons.math.fraction.BigFraction var29 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var30 = var29.abs();
//     org.apache.commons.math.fraction.BigFraction var31 = var30.reduce();
//     org.apache.commons.math.FieldElement[] var32 = new org.apache.commons.math.FieldElement[] { var31};
//     org.apache.commons.math.linear.FieldVector var33 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var32);
//     org.apache.commons.math.FieldElement[][] var34 = new org.apache.commons.math.FieldElement[][] { var32};
//     org.apache.commons.math.linear.BlockFieldMatrix var35 = new org.apache.commons.math.linear.BlockFieldMatrix(var34);
//     int var36 = var35.getRowDimension();
//     org.apache.commons.math.fraction.BigFraction var38 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var39 = var38.abs();
//     org.apache.commons.math.fraction.BigFraction var40 = var39.reduce();
//     double var42 = var39.pow((-1.0d));
//     double var43 = var39.percentageValue();
//     org.apache.commons.math.FieldElement[] var44 = new org.apache.commons.math.FieldElement[] { var39};
//     org.apache.commons.math.FieldElement[] var45 = var35.operate(var44);
//     org.apache.commons.math.fraction.BigFraction var47 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var48 = var47.abs();
//     org.apache.commons.math.fraction.BigFraction var49 = var48.reduce();
//     org.apache.commons.math.FieldElement[] var50 = new org.apache.commons.math.FieldElement[] { var49};
//     org.apache.commons.math.linear.FieldVector var51 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var50);
//     org.apache.commons.math.FieldElement[][] var52 = new org.apache.commons.math.FieldElement[][] { var50};
//     org.apache.commons.math.linear.BlockFieldMatrix var53 = new org.apache.commons.math.linear.BlockFieldMatrix(var52);
//     int var54 = var53.getRowDimension();
//     org.apache.commons.math.linear.FieldMatrix var57 = var53.createMatrix(1, 1);
//     org.apache.commons.math.linear.BlockFieldMatrix var58 = var35.add(var53);
//     org.apache.commons.math.linear.FieldVector var60 = var35.getRowVector(0);
//     org.apache.commons.math.linear.FieldVector var61 = var17.preMultiply(var60);
//     org.apache.commons.math.linear.FieldMatrix var62 = var7.multiply((org.apache.commons.math.linear.FieldMatrix)var17);
//     org.apache.commons.math.linear.FieldMatrixChangingVisitor var63 = null;
//     org.apache.commons.math.FieldElement var64 = var17.walkInColumnOrder(var63);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var5 = var3.divide((-1));
    long var6 = var5.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var7 = var5.getField();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var7, 10);
    org.apache.commons.math.fraction.BigFraction var11 = var7.getOne();
    org.apache.commons.math.fraction.BigFraction var12 = var7.getOne();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var3 = var2.abs();
    org.apache.commons.math.fraction.BigFraction var4 = var3.reduce();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldVector var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var7);
    int var9 = var8.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var12 = var8.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var14 = var8.getRowVector(0);
    org.apache.commons.math.FieldElement[] var16 = var8.getRow(0);
    org.apache.commons.math.linear.FieldMatrix var17 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createColumnFieldMatrix(var16);
    org.apache.commons.math.ode.IntegratorException var18 = new org.apache.commons.math.ode.IntegratorException("org.apache.commons.math.linear.InvalidMatrixException: ", (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }


    org.apache.commons.math.Field var0 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var1 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var0);
    int var2 = var1.getColumnDimension();
    org.apache.commons.math.Field var3 = var1.getField();
    org.apache.commons.math.FieldElement[][] var4 = var1.getDataRef();
    org.apache.commons.math.Field var5 = null;
    org.apache.commons.math.linear.Array2DRowFieldMatrix var6 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var5);
    org.apache.commons.math.FieldElement[][] var7 = var6.getDataRef();
    int var8 = var6.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reciprocal();
    org.apache.commons.math.fraction.BigFraction var14 = var11.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var16 = var11.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var17 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var16);
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var22 = var21.abs();
    org.apache.commons.math.fraction.BigFraction var24 = var21.subtract(100L);
    org.apache.commons.math.fraction.BigFraction var26 = var24.multiply(10);
    var17.visit((-1), 2, (org.apache.commons.math.FieldElement)var26);
    org.apache.commons.math.FieldElement var28 = var6.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var17);
    org.apache.commons.math.FieldElement var29 = var1.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var17);
    org.apache.commons.math.fraction.BigFraction var31 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var32 = var31.abs();
    org.apache.commons.math.fraction.BigFraction var33 = var32.reciprocal();
    org.apache.commons.math.fraction.BigFraction var35 = var32.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var37 = var32.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var38 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var37);
    var38.start(1, 100, 0, 0, 10, 8);
    org.apache.commons.math.FieldElement var46 = var1.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var38);
    org.apache.commons.math.fraction.BigFraction var48 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var49 = var48.abs();
    org.apache.commons.math.fraction.BigFraction var50 = var49.reciprocal();
    org.apache.commons.math.fraction.BigFraction var52 = var49.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var54 = var49.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var55 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var54);
    org.apache.commons.math.FieldElement var56 = var1.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var55);
    org.apache.commons.math.fraction.BigFraction var58 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var59 = var58.abs();
    org.apache.commons.math.fraction.BigFraction var60 = var59.reduce();
    org.apache.commons.math.FieldElement[] var61 = new org.apache.commons.math.FieldElement[] { var60};
    org.apache.commons.math.linear.FieldVector var62 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var61);
    org.apache.commons.math.FieldElement[][] var63 = new org.apache.commons.math.FieldElement[][] { var61};
    org.apache.commons.math.linear.BlockFieldMatrix var64 = new org.apache.commons.math.linear.BlockFieldMatrix(var63);
    org.apache.commons.math.linear.BlockFieldMatrix var65 = new org.apache.commons.math.linear.BlockFieldMatrix(var63);
    org.apache.commons.math.fraction.BigFraction var67 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var68 = var67.abs();
    org.apache.commons.math.fraction.BigFraction var69 = var68.reduce();
    org.apache.commons.math.FieldElement[] var70 = new org.apache.commons.math.FieldElement[] { var69};
    org.apache.commons.math.linear.FieldVector var71 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var70);
    org.apache.commons.math.FieldElement[][] var72 = new org.apache.commons.math.FieldElement[][] { var70};
    org.apache.commons.math.linear.BlockFieldMatrix var73 = new org.apache.commons.math.linear.BlockFieldMatrix(var72);
    int var74 = var73.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var77 = var73.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var79 = var73.getRowVector(0);
    org.apache.commons.math.linear.BlockFieldMatrix var80 = var65.subtract(var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldMatrix var81 = var1.multiply((org.apache.commons.math.linear.FieldMatrix)var65);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var21 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var17, var20);
    double[][] var22 = new double[][] { var20};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var22);
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var22);
    double[] var29 = new double[] { 100.0d, (-1.0d)};
    double[] var32 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var33 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var29, var32);
    double[][] var34 = new double[][] { var32};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var24.subtract(var36);
    var11.setRowMatrix(0, var37);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    var39.addToEntry(0, 0, 0.0d);
    org.apache.commons.math.linear.BlockRealMatrix var46 = var39.createMatrix(2, 8);
    double[] var52 = new double[] { 100.0d, (-1.0d)};
    double[] var55 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var56 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var52, var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55);
    double[][] var58 = var57.getDataRef();
    double[][] var59 = var57.getDataRef();
    double[][] var60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var59);
    double[][] var61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var60);
    org.apache.commons.math.linear.BlockRealMatrix var62 = new org.apache.commons.math.linear.BlockRealMatrix(var60);
    java.lang.Object var63 = null;
    boolean var64 = var62.equals(var63);
    org.apache.commons.math.linear.BlockRealMatrix var66 = var62.getColumnMatrix(1);
    double[] var71 = new double[] { 100.0d, (-1.0d)};
    double[] var74 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var75 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var71, var74);
    double[][] var76 = new double[][] { var74};
    org.apache.commons.math.linear.RealMatrix var77 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var76);
    org.apache.commons.math.linear.BlockRealMatrix var78 = new org.apache.commons.math.linear.BlockRealMatrix(var76);
    org.apache.commons.math.linear.RealVector var80 = var78.getColumnVector(0);
    org.apache.commons.math.linear.RealVector var81 = var66.preMultiply(var80);
    org.apache.commons.math.linear.BlockRealMatrix var82 = var66.copy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var39.setRowMatrix(100, (org.apache.commons.math.linear.RealMatrix)var82);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.BlockRealMatrix var2 = new org.apache.commons.math.linear.BlockRealMatrix(8, 0);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }
// 
// 
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var0 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
//     double[] var1 = new double[] { };
//     var0.reinitialize(var1, false);
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var4 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     var0.shift();
//     org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var6 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var0);
//     double var7 = var0.getCurrentTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    double[] var6 = new double[] { 100.0d, (-1.0d)};
    double[] var9 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var10 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var6, var9);
    org.apache.commons.math.linear.BigMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var9);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var12 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    var12.shift();
    boolean var14 = var12.isForward();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var15 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var12);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var18 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    double[] var19 = new double[] { };
    var18.reinitialize(var19, false);
    java.lang.Object[] var27 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var28 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var27);
    java.lang.ArithmeticException var29 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var27);
    double[] var34 = new double[] { 100.0d, (-1.0d)};
    double[] var37 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var38 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var34, var37);
    java.lang.Object[] var45 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var46 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var45);
    java.io.EOFException var47 = org.apache.commons.math.MathRuntimeException.createEOFException("", var45);
    java.io.EOFException var48 = org.apache.commons.math.MathRuntimeException.createEOFException("", var45);
    org.apache.commons.math.FunctionEvaluationException var49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var29, var34, "hi!", var45);
    double[] var54 = new double[] { 100.0d, (-1.0d)};
    double[] var57 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var58 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var54, var57);
    org.apache.commons.math.linear.Array2DRowRealMatrix var59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var57);
    double[][] var60 = var59.getDataRef();
    var18.reinitialize(Double.NaN, 100.0d, var34, var59);
    double[] var66 = new double[] { 100.0d, (-1.0d)};
    double[] var69 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var70 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var66, var69);
    double[][] var71 = new double[][] { var69};
    org.apache.commons.math.linear.Array2DRowRealMatrix var72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var71);
    boolean var74 = var72.equals((java.lang.Object)(-1));
    var15.reinitialize(0.9d, 100.0d, var34, var72);
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var76 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator((-1.0d), 10.0d, var9, var34);
    org.apache.commons.math.linear.BigMatrix var77 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var34);
    org.apache.commons.math.ode.sampling.DummyStepInterpolator var79 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var34, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldMatrix var31 = var25.copy();
    org.apache.commons.math.linear.FieldMatrix var32 = var25.transpose();
    org.apache.commons.math.fraction.BigFraction var35 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var36 = var35.abs();
    org.apache.commons.math.fraction.BigFraction var37 = var36.reduce();
    org.apache.commons.math.FieldElement[] var38 = new org.apache.commons.math.FieldElement[] { var37};
    org.apache.commons.math.linear.FieldVector var39 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var38);
    org.apache.commons.math.FieldElement[][] var40 = new org.apache.commons.math.FieldElement[][] { var38};
    org.apache.commons.math.linear.BlockFieldMatrix var41 = new org.apache.commons.math.linear.BlockFieldMatrix(var40);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var42 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var43 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var45 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var40, false);
    org.apache.commons.math.FieldElement[][] var46 = var45.getDataRef();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var48 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var46, false);
    int var49 = var48.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var53 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var54 = var53.abs();
    org.apache.commons.math.fraction.BigFraction var55 = var54.reduce();
    org.apache.commons.math.FieldElement[] var56 = new org.apache.commons.math.FieldElement[] { var55};
    org.apache.commons.math.linear.FieldVector var57 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var56);
    org.apache.commons.math.FieldElement[][] var58 = new org.apache.commons.math.FieldElement[][] { var56};
    org.apache.commons.math.linear.BlockFieldMatrix var59 = new org.apache.commons.math.linear.BlockFieldMatrix(var58);
    int var60 = var59.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var62 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var63 = var62.abs();
    org.apache.commons.math.fraction.BigFraction var64 = var63.reduce();
    double var66 = var63.pow((-1.0d));
    double var67 = var63.percentageValue();
    org.apache.commons.math.FieldElement[] var68 = new org.apache.commons.math.FieldElement[] { var63};
    org.apache.commons.math.FieldElement[] var69 = var59.operate(var68);
    org.apache.commons.math.FunctionEvaluationException var70 = new org.apache.commons.math.FunctionEvaluationException((-1.0d), "", (java.lang.Object[])var69);
    org.apache.commons.math.FieldElement[] var71 = var48.preMultiply(var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.setRow(9000, var71);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    double var5 = var2.pow((-1.0d));
    double var6 = var2.percentageValue();
    int var7 = var2.getDenominatorAsInt();
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var10 = var9.abs();
    long var11 = var9.longValue();
    org.apache.commons.math.fraction.BigFraction var13 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var14 = var13.abs();
    org.apache.commons.math.fraction.BigFraction var15 = var14.reduce();
    org.apache.commons.math.fraction.BigFraction var17 = var15.divide((-1));
    long var18 = var17.getDenominatorAsLong();
    int var19 = var9.compareTo(var17);
    java.math.BigInteger var20 = var17.getNumerator();
    org.apache.commons.math.fraction.BigFraction var21 = var2.multiply(var20);
    org.apache.commons.math.fraction.BigFraction var23 = var21.subtract(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldVector var32 = var7.getRowVector(0);
    org.apache.commons.math.linear.FieldMatrix var35 = var7.createMatrix(1, 1);
    int var36 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var38 = new org.apache.commons.math.fraction.BigFraction(1L);
    java.math.BigInteger var39 = var38.getDenominator();
    org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var42 = var41.abs();
    org.apache.commons.math.fraction.BigFraction var43 = var42.reciprocal();
    org.apache.commons.math.fraction.BigFraction var45 = var43.pow(1);
    byte var46 = var45.byteValue();
    float var47 = var45.floatValue();
    boolean var48 = var38.equals((java.lang.Object)var45);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var49 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var38);
    org.apache.commons.math.FieldElement var50 = var7.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var49);
    org.apache.commons.math.fraction.BigFraction var52 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var53 = var52.abs();
    org.apache.commons.math.fraction.BigFraction var54 = var53.reduce();
    org.apache.commons.math.FieldElement[] var55 = new org.apache.commons.math.FieldElement[] { var54};
    org.apache.commons.math.linear.FieldVector var56 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var55);
    org.apache.commons.math.FieldElement[][] var57 = new org.apache.commons.math.FieldElement[][] { var55};
    org.apache.commons.math.linear.BlockFieldMatrix var58 = new org.apache.commons.math.linear.BlockFieldMatrix(var57);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var59 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var57);
    org.apache.commons.math.fraction.BigFraction var61 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var62 = var61.abs();
    org.apache.commons.math.fraction.BigFraction var64 = var61.subtract(100L);
    java.lang.String var65 = var64.toString();
    org.apache.commons.math.linear.FieldMatrix var66 = var59.scalarAdd((org.apache.commons.math.FieldElement)var64);
    org.apache.commons.math.FieldElement[][] var67 = var59.getDataRef();
    org.apache.commons.math.FieldElement[][] var68 = org.apache.commons.math.linear.BlockFieldMatrix.<org.apache.commons.math.FieldElement>toBlocksLayout(var67);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var70 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var68, false);
    org.apache.commons.math.fraction.BigFraction var72 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var73 = var72.abs();
    org.apache.commons.math.fraction.BigFraction var74 = var73.reduce();
    org.apache.commons.math.FieldElement[] var75 = new org.apache.commons.math.FieldElement[] { var74};
    org.apache.commons.math.linear.FieldVector var76 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var75);
    org.apache.commons.math.FieldElement[][] var77 = new org.apache.commons.math.FieldElement[][] { var75};
    org.apache.commons.math.linear.BlockFieldMatrix var78 = new org.apache.commons.math.linear.BlockFieldMatrix(var77);
    org.apache.commons.math.Field var79 = var78.getField();
    org.apache.commons.math.fraction.BigFraction var81 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var82 = var81.abs();
    org.apache.commons.math.fraction.BigFraction var83 = var82.reciprocal();
    org.apache.commons.math.fraction.BigFraction var85 = var82.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var87 = var82.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var88 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var87);
    org.apache.commons.math.FieldElement var89 = var78.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var88);
    org.apache.commons.math.FieldElement var90 = var70.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var88);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var95 = var7.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var88, 0, 0, 1, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "-90"+ "'", var65.equals("-90"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    org.apache.commons.math.ode.events.EventHandler var0 = null;
    org.apache.commons.math.ode.events.EventState var4 = new org.apache.commons.math.ode.events.EventState(var0, 0.1d, 0.0d, 0);
    org.apache.commons.math.ode.events.EventHandler var5 = var4.getEventHandler();
    double[] var7 = null;
    boolean var8 = var4.reset(0.9d, var7);
    int var9 = var4.getMaxIterationCount();
    boolean var10 = var4.stop();
    double var11 = var4.getConvergence();
    boolean var12 = var4.stop();
    double var13 = var4.getConvergence();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    double[] var5 = new double[] { 100.0d, (-1.0d)};
    double[] var8 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var9 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var5, var8);
    double[][] var10 = new double[][] { var8};
    org.apache.commons.math.linear.RealMatrix var11 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var10);
    org.apache.commons.math.MathRuntimeException var12 = new org.apache.commons.math.MathRuntimeException("hi!", (java.lang.Object[])var10);
    org.apache.commons.math.linear.BlockRealMatrix var13 = new org.apache.commons.math.linear.BlockRealMatrix(var10);
    int var14 = var13.getColumnDimension();
    org.apache.commons.math.linear.RealMatrix var15 = var13.transpose();
    double var16 = var13.getFrobeniusNorm();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.4142135623730951d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.FieldElement var18 = var7.getTrace();
    org.apache.commons.math.linear.FieldLUDecompositionImpl var19 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var7);
    org.apache.commons.math.FieldElement var20 = var19.getDeterminant();
    org.apache.commons.math.linear.FieldMatrix var21 = var19.getP();
    org.apache.commons.math.linear.FieldDecompositionSolver var22 = var19.getSolver();
    org.apache.commons.math.linear.FieldDecompositionSolver var23 = var19.getSolver();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    org.apache.commons.math.FieldElement[] var13 = new org.apache.commons.math.FieldElement[] { var12};
    org.apache.commons.math.linear.FieldVector var14 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var13);
    org.apache.commons.math.FieldElement[][] var15 = new org.apache.commons.math.FieldElement[][] { var13};
    org.apache.commons.math.linear.BlockFieldMatrix var16 = new org.apache.commons.math.linear.BlockFieldMatrix(var15);
    int var17 = var16.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var20 = var16.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var22 = var16.getRowVector(0);
    org.apache.commons.math.linear.BlockFieldMatrix var23 = var8.subtract(var16);
    org.apache.commons.math.fraction.BigFraction var25 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var26 = var25.abs();
    org.apache.commons.math.fraction.BigFraction var27 = var26.reduce();
    org.apache.commons.math.FieldElement[] var28 = new org.apache.commons.math.FieldElement[] { var27};
    org.apache.commons.math.linear.FieldVector var29 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var28);
    org.apache.commons.math.FieldElement[][] var30 = new org.apache.commons.math.FieldElement[][] { var28};
    org.apache.commons.math.linear.BlockFieldMatrix var31 = new org.apache.commons.math.linear.BlockFieldMatrix(var30);
    int var32 = var31.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var34 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var35 = var34.abs();
    org.apache.commons.math.fraction.BigFraction var36 = var35.reduce();
    double var38 = var35.pow((-1.0d));
    double var39 = var35.percentageValue();
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var35};
    org.apache.commons.math.FieldElement[] var41 = var31.operate(var40);
    org.apache.commons.math.linear.FieldMatrix var42 = var16.add((org.apache.commons.math.linear.FieldMatrix)var31);
    org.apache.commons.math.fraction.BigFraction var44 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var45 = var44.abs();
    org.apache.commons.math.fraction.BigFraction var46 = var45.reduce();
    org.apache.commons.math.FieldElement[] var47 = new org.apache.commons.math.FieldElement[] { var46};
    org.apache.commons.math.linear.FieldVector var48 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var47);
    org.apache.commons.math.FieldElement[][] var49 = new org.apache.commons.math.FieldElement[][] { var47};
    org.apache.commons.math.linear.BlockFieldMatrix var50 = new org.apache.commons.math.linear.BlockFieldMatrix(var49);
    int var51 = var50.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var53 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var54 = var53.abs();
    org.apache.commons.math.fraction.BigFraction var55 = var54.reduce();
    double var57 = var54.pow((-1.0d));
    double var58 = var54.percentageValue();
    org.apache.commons.math.FieldElement[] var59 = new org.apache.commons.math.FieldElement[] { var54};
    org.apache.commons.math.FieldElement[] var60 = var50.operate(var59);
    org.apache.commons.math.FieldElement var61 = var50.getTrace();
    int var62 = var50.getColumnDimension();
    org.apache.commons.math.fraction.BigFraction var64 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var65 = var64.abs();
    org.apache.commons.math.fraction.BigFraction var66 = var65.reduce();
    org.apache.commons.math.FieldElement[] var67 = new org.apache.commons.math.FieldElement[] { var66};
    org.apache.commons.math.linear.FieldVector var68 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var67);
    org.apache.commons.math.FieldElement[][] var69 = new org.apache.commons.math.FieldElement[][] { var67};
    org.apache.commons.math.linear.BlockFieldMatrix var70 = new org.apache.commons.math.linear.BlockFieldMatrix(var69);
    org.apache.commons.math.linear.BlockFieldMatrix var71 = new org.apache.commons.math.linear.BlockFieldMatrix(var69);
    org.apache.commons.math.fraction.BigFraction var73 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var74 = var73.abs();
    org.apache.commons.math.fraction.BigFraction var75 = var74.reduce();
    org.apache.commons.math.FieldElement[] var76 = new org.apache.commons.math.FieldElement[] { var75};
    org.apache.commons.math.linear.FieldVector var77 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var76);
    org.apache.commons.math.FieldElement[][] var78 = new org.apache.commons.math.FieldElement[][] { var76};
    org.apache.commons.math.linear.BlockFieldMatrix var79 = new org.apache.commons.math.linear.BlockFieldMatrix(var78);
    int var80 = var79.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var83 = var79.createMatrix(1, 1);
    org.apache.commons.math.linear.FieldVector var85 = var79.getRowVector(0);
    org.apache.commons.math.linear.BlockFieldMatrix var86 = var71.subtract(var79);
    org.apache.commons.math.linear.BlockFieldMatrix var87 = var50.subtract(var86);
    org.apache.commons.math.linear.FieldVector var89 = var86.getColumnVector(0);
    org.apache.commons.math.linear.FieldVector var90 = var31.operate(var89);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.linear.FieldVector var92 = var31.getRowVector(100);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var9 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6, false);
    org.apache.commons.math.FieldElement[][] var12 = var11.getDataRef();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var14 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var12, false);
    org.apache.commons.math.fraction.BigFraction var16 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var17 = var16.abs();
    org.apache.commons.math.fraction.BigFraction var18 = var17.reduce();
    org.apache.commons.math.FieldElement[] var19 = new org.apache.commons.math.FieldElement[] { var18};
    org.apache.commons.math.linear.FieldVector var20 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var19);
    org.apache.commons.math.FieldElement[][] var21 = new org.apache.commons.math.FieldElement[][] { var19};
    org.apache.commons.math.linear.BlockFieldMatrix var22 = new org.apache.commons.math.linear.BlockFieldMatrix(var21);
    org.apache.commons.math.Field var23 = var22.getField();
    org.apache.commons.math.fraction.BigFraction var25 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var26 = var25.abs();
    org.apache.commons.math.fraction.BigFraction var27 = var26.reciprocal();
    org.apache.commons.math.fraction.BigFraction var29 = var26.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var31 = var26.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var32 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var31);
    var32.start(1, 100, 0, 0, 10, 8);
    org.apache.commons.math.FieldElement var40 = var22.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var32);
    org.apache.commons.math.linear.FieldMatrix var41 = var14.add((org.apache.commons.math.linear.FieldMatrix)var22);
    org.apache.commons.math.fraction.BigFraction var43 = new org.apache.commons.math.fraction.BigFraction(0.0d);
    float var44 = var43.floatValue();
    java.lang.String var45 = var43.toString();
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var46 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var43);
    org.apache.commons.math.FieldElement var47 = var46.end();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var52 = var14.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var46, (-1), 2147483647, (-1), 8);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "0"+ "'", var45.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction((-90L), 10L);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var3 = var2.abs();
    org.apache.commons.math.fraction.BigFraction var4 = var3.reduce();
    org.apache.commons.math.FieldElement[] var5 = new org.apache.commons.math.FieldElement[] { var4};
    org.apache.commons.math.linear.FieldVector var6 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var5);
    org.apache.commons.math.FieldElement[][] var7 = new org.apache.commons.math.FieldElement[][] { var5};
    org.apache.commons.math.linear.BlockFieldMatrix var8 = new org.apache.commons.math.linear.BlockFieldMatrix(var7);
    org.apache.commons.math.Field var9 = var8.getField();
    java.lang.Object[] var11 = null;
    org.apache.commons.math.linear.MatrixIndexException var12 = new org.apache.commons.math.linear.MatrixIndexException("", var11);
    org.apache.commons.math.fraction.BigFraction var15 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var16 = var15.abs();
    org.apache.commons.math.fraction.BigFraction var17 = var16.reduce();
    org.apache.commons.math.FieldElement[] var18 = new org.apache.commons.math.FieldElement[] { var17};
    org.apache.commons.math.linear.FieldVector var19 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var18);
    org.apache.commons.math.FieldElement[][] var20 = new org.apache.commons.math.FieldElement[][] { var18};
    org.apache.commons.math.linear.BlockFieldMatrix var21 = new org.apache.commons.math.linear.BlockFieldMatrix(var20);
    int var22 = var21.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var24 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var25 = var24.abs();
    org.apache.commons.math.fraction.BigFraction var26 = var25.reduce();
    double var28 = var25.pow((-1.0d));
    double var29 = var25.percentageValue();
    org.apache.commons.math.FieldElement[] var30 = new org.apache.commons.math.FieldElement[] { var25};
    org.apache.commons.math.FieldElement[] var31 = var21.operate(var30);
    org.apache.commons.math.ConvergenceException var32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var12, "hi!", (java.lang.Object[])var31);
    org.apache.commons.math.FieldElement[] var33 = var8.preMultiply(var31);
    org.apache.commons.math.linear.MatrixIndexException var34 = new org.apache.commons.math.linear.MatrixIndexException("-90", (java.lang.Object[])var33);
    java.lang.Object[] var35 = var34.getArguments();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    double[] var7 = new double[] { 100.0d, (-1.0d)};
    double[] var10 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var11 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var7, var10);
    org.apache.commons.math.linear.BigMatrix var12 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var10);
    java.lang.Object[] var18 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var19 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var18);
    java.io.EOFException var20 = org.apache.commons.math.MathRuntimeException.createEOFException("", var18);
    java.io.EOFException var21 = org.apache.commons.math.MathRuntimeException.createEOFException("", var18);
    java.lang.Object[] var24 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var24);
    org.apache.commons.math.ode.events.EventException var26 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var25);
    java.lang.IllegalArgumentException var27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var25);
    var21.addSuppressed((java.lang.Throwable)var25);
    double[] var35 = new double[] { 100.0d, (-1.0d)};
    double[] var38 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var39 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var35, var38);
    double[][] var40 = new double[][] { var38};
    org.apache.commons.math.linear.RealMatrix var41 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var40);
    org.apache.commons.math.linear.Array2DRowRealMatrix var42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var40);
    java.lang.ArrayIndexOutOfBoundsException var43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", (java.lang.Object[])var40);
    org.apache.commons.math.MathRuntimeException var44 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var25, "org.apache.commons.math.MaxEvaluationsExceededException: ", (java.lang.Object[])var40);
    java.lang.Object[] var48 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var49 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var48);
    org.apache.commons.math.ConvergenceException var50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var49);
    double[] var55 = new double[] { 100.0d, (-1.0d)};
    double[] var58 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var59 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var55, var58);
    org.apache.commons.math.linear.Array2DRowRealMatrix var60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var58);
    java.lang.Object[] var65 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var66 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var65);
    java.lang.ArithmeticException var67 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var65);
    org.apache.commons.math.FunctionEvaluationException var68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var50, var58, "hi!", var65);
    org.apache.commons.math.fraction.BigFraction var71 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var72 = var71.abs();
    org.apache.commons.math.fraction.BigFraction var73 = var72.reduce();
    org.apache.commons.math.FieldElement[] var74 = new org.apache.commons.math.FieldElement[] { var73};
    org.apache.commons.math.linear.FieldVector var75 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var74);
    org.apache.commons.math.FieldElement[][] var76 = new org.apache.commons.math.FieldElement[][] { var74};
    org.apache.commons.math.linear.BlockFieldMatrix var77 = new org.apache.commons.math.linear.BlockFieldMatrix(var76);
    int var78 = var77.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var80 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var81 = var80.abs();
    org.apache.commons.math.fraction.BigFraction var82 = var81.reduce();
    double var84 = var81.pow((-1.0d));
    double var85 = var81.percentageValue();
    org.apache.commons.math.FieldElement[] var86 = new org.apache.commons.math.FieldElement[] { var81};
    org.apache.commons.math.FieldElement[] var87 = var77.operate(var86);
    org.apache.commons.math.FunctionEvaluationException var88 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var44, var58, "-90", (java.lang.Object[])var87);
    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var89 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(10, (-1.0d), 2.0d, var10, var58);
    double var90 = var89.getMaxGrowth();
    double var91 = var89.getSafety();
    int var92 = var89.getMaxEvaluations();
    double var93 = var89.getSafety();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0650410894399627d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0.9d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetFunctionValueAccuracy();
    var0.setRelativeAccuracy(0.0d);
    var0.resetFunctionValueAccuracy();
    var0.resetAbsoluteAccuracy();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.solve(Double.POSITIVE_INFINITY, 1.0d, 2.8284271247461903d);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }


    org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator var5 = new org.apache.commons.math.ode.nonstiff.AdamsMoultonIntegrator(1, Double.NaN, (-1.0d), 1.0E-15d, 0.1d);
    var5.setMinReduction(0.0d);
    double var8 = var5.getSafety();
    java.lang.String var9 = var5.getName();
    var5.setMaxGrowth((-90000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Adams-Moulton"+ "'", var9.equals("Adams-Moulton"));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var21 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var17, var20);
    double[][] var22 = new double[][] { var20};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var22);
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var22);
    double[] var29 = new double[] { 100.0d, (-1.0d)};
    double[] var32 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var33 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var29, var32);
    double[][] var34 = new double[][] { var32};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var24.subtract(var36);
    var11.setRowMatrix(0, var37);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    var39.addToEntry(0, 0, 0.0d);
    org.apache.commons.math.linear.BlockRealMatrix var46 = var39.createMatrix(2, 8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var46.multiplyEntry(9000, 2147483647, 1.080059738892306d);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.linear.RealVector var13 = var11.getColumnVector(0);
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var14 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator();
    var14.shift();
    boolean var16 = var14.isForward();
    org.apache.commons.math.ode.sampling.NordsieckStepInterpolator var17 = new org.apache.commons.math.ode.sampling.NordsieckStepInterpolator(var14);
    java.lang.Object[] var19 = null;
    java.lang.ArithmeticException var20 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var19);
    java.lang.Object[] var24 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var25 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var24);
    org.apache.commons.math.ConvergenceException var26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var25);
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var35 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var31, var34);
    org.apache.commons.math.linear.Array2DRowRealMatrix var36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var34);
    java.lang.Object[] var41 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var42 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var41);
    java.lang.ArithmeticException var43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var41);
    org.apache.commons.math.FunctionEvaluationException var44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var26, var34, "hi!", var41);
    double[] var50 = new double[] { 100.0d, (-1.0d)};
    double[] var53 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var54 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var50, var53);
    double[][] var55 = new double[][] { var53};
    org.apache.commons.math.linear.RealMatrix var56 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var55);
    org.apache.commons.math.linear.Array2DRowRealMatrix var57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var55);
    org.apache.commons.math.linear.BlockRealMatrix var58 = new org.apache.commons.math.linear.BlockRealMatrix(var55);
    org.apache.commons.math.FunctionEvaluationException var59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var20, var34, "Dormand-Prince 8 (5, 3)", (java.lang.Object[])var55);
    var14.reinitialize(var34, false);
    double[] var62 = var11.operate(var34);
    org.apache.commons.math.linear.RealMatrix var63 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    double[] var7 = new double[] { 100.0d, (-1.0d)};
    double[] var10 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var11 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var7, var10);
    double[][] var12 = new double[][] { var10};
    org.apache.commons.math.linear.Array2DRowRealMatrix var13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var12);
    double[][] var14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var12);
    java.text.ParseException var15 = org.apache.commons.math.MathRuntimeException.createParseException(1, "", (java.lang.Object[])var14);
    java.util.ConcurrentModificationException var16 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("Array2DRowRealMatrix{{1.0},{-1.0}}", (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var28 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var29 = var28.abs();
    org.apache.commons.math.fraction.BigFraction var30 = var29.reduce();
    double var32 = var29.pow((-1.0d));
    double var33 = var29.percentageValue();
    org.apache.commons.math.FieldElement[] var34 = new org.apache.commons.math.FieldElement[] { var29};
    org.apache.commons.math.FieldElement[] var35 = var25.operate(var34);
    org.apache.commons.math.fraction.BigFraction var37 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var38 = var37.abs();
    org.apache.commons.math.fraction.BigFraction var39 = var38.reduce();
    org.apache.commons.math.FieldElement[] var40 = new org.apache.commons.math.FieldElement[] { var39};
    org.apache.commons.math.linear.FieldVector var41 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var40);
    org.apache.commons.math.FieldElement[][] var42 = new org.apache.commons.math.FieldElement[][] { var40};
    org.apache.commons.math.linear.BlockFieldMatrix var43 = new org.apache.commons.math.linear.BlockFieldMatrix(var42);
    int var44 = var43.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var47 = var43.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var48 = var25.add(var43);
    org.apache.commons.math.linear.FieldVector var50 = var25.getRowVector(0);
    org.apache.commons.math.linear.FieldVector var51 = var7.preMultiply(var50);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement[] var53 = var7.getRow(2);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     org.apache.commons.math.linear.BigMatrix var9 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var7);
//     org.apache.commons.math.ode.sampling.DummyStepInterpolator var11 = new org.apache.commons.math.ode.sampling.DummyStepInterpolator(var7, true);
//     double var12 = var11.getPreviousTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    int var8 = var7.getRowDimension();
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    double var14 = var11.pow((-1.0d));
    double var15 = var11.percentageValue();
    org.apache.commons.math.FieldElement[] var16 = new org.apache.commons.math.FieldElement[] { var11};
    org.apache.commons.math.FieldElement[] var17 = var7.operate(var16);
    org.apache.commons.math.fraction.BigFraction var19 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var20 = var19.abs();
    org.apache.commons.math.fraction.BigFraction var21 = var20.reduce();
    org.apache.commons.math.FieldElement[] var22 = new org.apache.commons.math.FieldElement[] { var21};
    org.apache.commons.math.linear.FieldVector var23 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var22);
    org.apache.commons.math.FieldElement[][] var24 = new org.apache.commons.math.FieldElement[][] { var22};
    org.apache.commons.math.linear.BlockFieldMatrix var25 = new org.apache.commons.math.linear.BlockFieldMatrix(var24);
    int var26 = var25.getRowDimension();
    org.apache.commons.math.linear.FieldMatrix var29 = var25.createMatrix(1, 1);
    org.apache.commons.math.linear.BlockFieldMatrix var30 = var7.add(var25);
    org.apache.commons.math.linear.FieldMatrix var31 = var25.copy();
    org.apache.commons.math.linear.FieldMatrix var32 = var25.transpose();
    org.apache.commons.math.linear.FieldLUDecompositionImpl var33 = new org.apache.commons.math.linear.FieldLUDecompositionImpl((org.apache.commons.math.linear.FieldMatrix)var25);
    org.apache.commons.math.linear.FieldMatrix var34 = var33.getU();
    int[] var35 = var33.getPivot();
    org.apache.commons.math.linear.FieldMatrix var36 = var33.getL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var4 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(1.0d, (-1.0d), 1.0d, 0.0d);
    double var5 = var4.getSafety();
    org.apache.commons.math.ode.sampling.StepHandler var6 = null;
    var4.addStepHandler(var6);
    var4.clearStepHandlers();
    var4.clearEventHandlers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    java.lang.Object[] var3 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var4 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var3);
    org.apache.commons.math.ode.events.EventException var5 = new org.apache.commons.math.ode.events.EventException((java.lang.Throwable)var4);
    java.lang.IllegalArgumentException var6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable)var4);
    org.apache.commons.math.FunctionEvaluationException var8 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var4, 100.0d);
    java.lang.Object[] var11 = null;
    org.apache.commons.math.ode.events.EventException var12 = new org.apache.commons.math.ode.events.EventException("hi!", var11);
    java.io.IOException var13 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable)var12);
    java.lang.Throwable[] var14 = var12.getSuppressed();
    org.apache.commons.math.FunctionEvaluationException var16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var12, 100.0d);
    double[] var25 = new double[] { 100.0d, (-1.0d)};
    double[] var28 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var29 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var25, var28);
    double[][] var30 = new double[][] { var28};
    org.apache.commons.math.linear.RealMatrix var31 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var30);
    org.apache.commons.math.MathRuntimeException var32 = new org.apache.commons.math.MathRuntimeException("hi!", (java.lang.Object[])var30);
    org.apache.commons.math.ode.IntegratorException var33 = new org.apache.commons.math.ode.IntegratorException("Dormand-Prince 8 (5, 3)", (java.lang.Object[])var30);
    org.apache.commons.math.FunctionEvaluationException var34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var12, (-1.0d), "Dormand-Prince 8 (5, 3)", (java.lang.Object[])var30);
    org.apache.commons.math.MathException var35 = new org.apache.commons.math.MathException((java.lang.Throwable)var4, "", (java.lang.Object[])var30);
    org.apache.commons.math.linear.InvalidMatrixException var36 = new org.apache.commons.math.linear.InvalidMatrixException("BlockRealMatrix{{3.0,-3.0}}", (java.lang.Object[])var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var3.pow(1);
    byte var6 = var5.byteValue();
    float var7 = var5.floatValue();
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var10 = var9.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var9.subtract(100L);
    java.lang.String var13 = var12.toString();
    org.apache.commons.math.fraction.BigFraction var14 = var5.divide(var12);
    org.apache.commons.math.fraction.BigFraction var16 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var17 = var16.abs();
    org.apache.commons.math.fraction.BigFraction var18 = var17.reciprocal();
    org.apache.commons.math.fraction.BigFraction var20 = var18.pow(1);
    byte var21 = var20.byteValue();
    java.math.BigInteger var22 = var20.getDenominator();
    org.apache.commons.math.fraction.BigFraction var23 = var14.divide(var22);
    java.lang.String var24 = var23.toString();
    org.apache.commons.math.fraction.BigFractionField var25 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var26 = var25.getZero();
    long var27 = var26.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var29 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var30 = var29.abs();
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var33 = var31.pow(1);
    org.apache.commons.math.fraction.BigFraction var34 = var26.subtract(var31);
    org.apache.commons.math.fraction.BigFraction var38 = new org.apache.commons.math.fraction.BigFraction(10.0d, 1000.0d, 100);
    double var39 = var38.percentageValue();
    org.apache.commons.math.fraction.BigFraction var40 = var38.reciprocal();
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var41 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var40);
    org.apache.commons.math.fraction.BigFraction var42 = var40.reduce();
    int var43 = var31.compareTo(var40);
    org.apache.commons.math.fraction.BigFraction var45 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var46 = var45.abs();
    org.apache.commons.math.fraction.BigFraction var47 = var46.reciprocal();
    org.apache.commons.math.fraction.BigFraction var49 = var47.pow(1);
    byte var50 = var49.byteValue();
    java.math.BigInteger var51 = var49.getDenominator();
    org.apache.commons.math.fraction.BigFraction var52 = var40.divide(var51);
    org.apache.commons.math.fraction.BigFraction var53 = var23.pow(var51);
    java.lang.Throwable var54 = null;
    java.lang.Object[] var56 = null;
    org.apache.commons.math.ConvergenceException var57 = new org.apache.commons.math.ConvergenceException(var54, "hi!", var56);
    org.apache.commons.math.fraction.BigFraction var60 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var61 = var60.abs();
    java.math.BigDecimal var63 = var60.bigDecimalValue(0);
    java.math.BigDecimal[] var64 = new java.math.BigDecimal[] { var63};
    org.apache.commons.math.linear.BigMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var64);
    org.apache.commons.math.MathException var66 = new org.apache.commons.math.MathException((java.lang.Throwable)var57, "Dormand-Prince 8 (5, 3)", (java.lang.Object[])var64);
    org.apache.commons.math.linear.BigMatrix var67 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var64);
    org.apache.commons.math.linear.BigMatrix var68 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var64);
    boolean var69 = var23.equals((java.lang.Object)var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "-90"+ "'", var13.equals("-90"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "-1 / 9000"+ "'", var24.equals("-1 / 9000"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
    boolean var1 = var0.stop();
    boolean var2 = var0.stop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.fraction.BigFraction var5 = var3.divide((-1));
    long var6 = var5.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var7 = var5.getField();
    org.apache.commons.math.fraction.BigFraction var8 = var7.getZero();
    org.apache.commons.math.linear.FieldMatrix var10 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var7, 10);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var11 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var7);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var12 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var7);
    org.apache.commons.math.linear.FieldMatrix var14 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldIdentityMatrix((org.apache.commons.math.Field)var7, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     double[][] var9 = new double[][] { var7};
//     org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
//     org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
//     org.apache.commons.math.linear.RealVector var13 = var11.getColumnVector(0);
//     double var14 = var11.getFrobeniusNorm();
//     org.apache.commons.math.linear.BlockRealMatrix var15 = var11.copy();
//     org.apache.commons.math.linear.BlockRealMatrix var17 = var15.scalarAdd(0.9d);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var18 = null;
//     double var19 = var15.walkInRowOrder(var18);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetFunctionValueAccuracy();
    var0.resetFunctionValueAccuracy();
    var0.setRelativeAccuracy(0.0d);
    double var5 = var0.getRelativeAccuracy();
    int var6 = var0.getIterationCount();
    var0.setRelativeAccuracy(1.0E100d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
    double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var9);
    org.apache.commons.math.linear.Array2DRowRealMatrix var12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
    org.apache.commons.math.linear.RealMatrix var14 = var12.scalarAdd(1.0E100d);
    org.apache.commons.math.linear.RealMatrix var16 = var12.scalarMultiply(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     double[][] var9 = new double[][] { var7};
//     org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
//     double[][] var11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var9);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
//     org.apache.commons.math.linear.RealMatrix var14 = var12.scalarAdd(1.0E100d);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var15 = null;
//     double var16 = var12.walkInColumnOrder(var15);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }
// 
// 
//     org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
//     org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
//     org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
//     org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
//     org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
//     org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
//     org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
//     org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
//     org.apache.commons.math.fraction.BigFraction var13 = var10.subtract(100L);
//     java.lang.String var14 = var13.toString();
//     org.apache.commons.math.linear.FieldMatrix var15 = var8.scalarAdd((org.apache.commons.math.FieldElement)var13);
//     org.apache.commons.math.fraction.BigFraction var17 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var18 = var17.abs();
//     org.apache.commons.math.fraction.BigFraction var19 = var18.reciprocal();
//     org.apache.commons.math.fraction.BigFraction var21 = var19.pow(1);
//     byte var22 = var21.byteValue();
//     java.math.BigInteger var23 = var21.getDenominator();
//     org.apache.commons.math.fraction.BigFraction var24 = var13.divide(var23);
//     org.apache.commons.math.fraction.BigFraction var26 = new org.apache.commons.math.fraction.BigFraction(1L);
//     java.math.BigInteger var27 = var26.getDenominator();
//     org.apache.commons.math.fraction.BigFraction var28 = var24.divide(var26);
//     org.apache.commons.math.fraction.BigFraction var30 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var31 = var30.abs();
//     org.apache.commons.math.fraction.BigFraction var32 = var31.reduce();
//     org.apache.commons.math.fraction.BigFraction var34 = var32.divide((-1));
//     long var35 = var34.getDenominatorAsLong();
//     org.apache.commons.math.fraction.BigFractionField var36 = var34.getField();
//     org.apache.commons.math.fraction.BigFraction var37 = var36.getZero();
//     org.apache.commons.math.fraction.BigFraction var39 = var37.multiply((-1L));
//     org.apache.commons.math.fraction.BigFraction var41 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var42 = var41.abs();
//     org.apache.commons.math.fraction.BigFraction var43 = var42.reduce();
//     double var44 = var43.doubleValue();
//     org.apache.commons.math.fraction.BigFraction var45 = var43.negate();
//     java.math.BigInteger var46 = var43.getNumerator();
//     org.apache.commons.math.fraction.BigFraction var47 = var39.subtract(var46);
//     org.apache.commons.math.fraction.BigFraction var49 = new org.apache.commons.math.fraction.BigFraction(10);
//     org.apache.commons.math.fraction.BigFraction var50 = var49.abs();
//     org.apache.commons.math.fraction.BigFraction var51 = var50.reduce();
//     double var52 = var51.doubleValue();
//     org.apache.commons.math.fraction.BigFraction var53 = var51.negate();
//     java.math.BigInteger var54 = var51.getDenominator();
//     org.apache.commons.math.fraction.BigFraction var55 = new org.apache.commons.math.fraction.BigFraction(var46, var54);
//     org.apache.commons.math.fraction.BigFraction var56 = var28.subtract(var46);
//     java.io.ObjectInputStream var58 = null;
//     org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object)var46, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", var58);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    double var5 = var2.pow((-1.0d));
    double var6 = var2.percentageValue();
    double var7 = var2.doubleValue();
    org.apache.commons.math.fraction.BigFraction var9 = var2.multiply(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
//     double[][] var10 = var9.getDataRef();
//     double[][] var11 = var9.getDataRef();
//     double[] var16 = new double[] { 100.0d, (-1.0d)};
//     double[] var19 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var20 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var16, var19);
//     double[][] var21 = new double[][] { var19};
//     org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var21);
//     org.apache.commons.math.linear.BlockRealMatrix var23 = new org.apache.commons.math.linear.BlockRealMatrix(var21);
//     org.apache.commons.math.linear.RealVector var25 = var23.getColumnVector(0);
//     double var26 = var23.getFrobeniusNorm();
//     org.apache.commons.math.linear.RealMatrix var27 = var9.multiply((org.apache.commons.math.linear.RealMatrix)var23);
//     org.apache.commons.math.linear.RealVector var29 = var23.getColumnVector(0);
//     org.apache.commons.math.linear.RealMatrix var31 = var23.getRowMatrix(0);
//     org.apache.commons.math.linear.BlockRealMatrix var32 = var23.transpose();
//     org.apache.commons.math.linear.BlockRealMatrix var33 = var23.transpose();
//     double[] var38 = new double[] { 100.0d, (-1.0d)};
//     double[] var41 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var42 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var38, var41);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var41);
//     int var44 = var43.getColumnDimension();
//     java.lang.String var45 = var43.toString();
//     org.apache.commons.math.linear.BlockRealMatrix var46 = var33.subtract((org.apache.commons.math.linear.RealMatrix)var43);
//     org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix)var33, 0);
//     org.apache.commons.math.linear.RealMatrixChangingVisitor var49 = null;
//     double var50 = var33.walkInOptimizedOrder(var49);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     double[][] var9 = new double[][] { var7};
//     org.apache.commons.math.linear.Array2DRowRealMatrix var10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var9);
//     double[] var15 = new double[] { 100.0d, (-1.0d)};
//     double[] var18 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var19 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var15, var18);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var18);
//     double[][] var21 = var20.getDataRef();
//     double[][] var22 = var20.getDataRef();
//     double[] var27 = new double[] { 100.0d, (-1.0d)};
//     double[] var30 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var31 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var27, var30);
//     double[][] var32 = new double[][] { var30};
//     org.apache.commons.math.linear.RealMatrix var33 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var32);
//     org.apache.commons.math.linear.BlockRealMatrix var34 = new org.apache.commons.math.linear.BlockRealMatrix(var32);
//     org.apache.commons.math.linear.RealVector var36 = var34.getColumnVector(0);
//     double var37 = var34.getFrobeniusNorm();
//     org.apache.commons.math.linear.RealMatrix var38 = var20.multiply((org.apache.commons.math.linear.RealMatrix)var34);
//     org.apache.commons.math.linear.Array2DRowRealMatrix var39 = var10.multiply(var20);
//     org.apache.commons.math.linear.RealMatrixPreservingVisitor var40 = null;
//     double var41 = var10.walkInRowOrder(var40);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.apache.commons.math.fraction.BigFractionField var0 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var1 = var0.getZero();
    org.apache.commons.math.linear.Array2DRowFieldMatrix var4 = new org.apache.commons.math.linear.Array2DRowFieldMatrix((org.apache.commons.math.Field)var0, 10, 100);
    int var5 = var4.getColumnDimension();
    org.apache.commons.math.linear.FieldMatrix var8 = var4.createMatrix(100, 10);
    org.apache.commons.math.fraction.BigFraction var10 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var11 = var10.abs();
    org.apache.commons.math.fraction.BigFraction var12 = var11.reduce();
    org.apache.commons.math.FieldElement[] var13 = new org.apache.commons.math.FieldElement[] { var12};
    org.apache.commons.math.linear.FieldVector var14 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var13);
    org.apache.commons.math.FieldElement[][] var15 = new org.apache.commons.math.FieldElement[][] { var13};
    org.apache.commons.math.linear.BlockFieldMatrix var16 = new org.apache.commons.math.linear.BlockFieldMatrix(var15);
    org.apache.commons.math.Field var17 = var16.getField();
    org.apache.commons.math.fraction.BigFraction var21 = new org.apache.commons.math.fraction.BigFraction(10.0d, 1000.0d, 100);
    double var22 = var21.percentageValue();
    org.apache.commons.math.fraction.BigFraction var23 = var21.reciprocal();
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var24 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var23);
    org.apache.commons.math.fraction.BigFractionField var27 = org.apache.commons.math.fraction.BigFractionField.getInstance();
    org.apache.commons.math.fraction.BigFraction var28 = var27.getZero();
    long var29 = var28.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFraction var31 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var32 = var31.abs();
    org.apache.commons.math.fraction.BigFraction var33 = var32.reciprocal();
    org.apache.commons.math.fraction.BigFraction var35 = var33.pow(1);
    org.apache.commons.math.fraction.BigFraction var36 = var28.subtract(var33);
    org.apache.commons.math.FieldElement var37 = var24.visit(10, 2, (org.apache.commons.math.FieldElement)var36);
    var24.start(8, 100, 100, 8, 2, 2147483647);
    org.apache.commons.math.FieldElement var45 = var16.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var24);
    org.apache.commons.math.fraction.BigFraction var49 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var50 = var49.abs();
    org.apache.commons.math.fraction.BigFraction var51 = var50.reciprocal();
    float var52 = var50.floatValue();
    long var53 = var50.longValue();
    org.apache.commons.math.fraction.BigFraction var55 = var50.divide(100);
    long var56 = var50.getDenominatorAsLong();
    org.apache.commons.math.FieldElement var57 = var24.visit(0, 2, (org.apache.commons.math.FieldElement)var50);
    org.apache.commons.math.FieldElement var58 = var4.walkInColumnOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var24);
    org.apache.commons.math.fraction.BigFraction var64 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var65 = var64.abs();
    org.apache.commons.math.fraction.BigFraction var66 = var65.reduce();
    org.apache.commons.math.FieldElement[] var67 = new org.apache.commons.math.FieldElement[] { var66};
    org.apache.commons.math.linear.FieldVector var68 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var67);
    org.apache.commons.math.FieldElement[][] var69 = new org.apache.commons.math.FieldElement[][] { var67};
    org.apache.commons.math.linear.BlockFieldMatrix var70 = new org.apache.commons.math.linear.BlockFieldMatrix(var69);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var71 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var69);
    org.apache.commons.math.FieldElement[][] var72 = var71.getData();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.copySubMatrix(100, 2147483647, 0, 8, var72);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1000.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    java.lang.Object[] var3 = new java.lang.Object[] { 0L};
    org.apache.commons.math.MaxEvaluationsExceededException var4 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", var3);
    org.apache.commons.math.ConvergenceException var5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable)var4);
    double[] var10 = new double[] { 100.0d, (-1.0d)};
    double[] var13 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var14 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var10, var13);
    org.apache.commons.math.linear.Array2DRowRealMatrix var15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var13);
    java.lang.Object[] var20 = new java.lang.Object[] { 1L};
    java.lang.ArithmeticException var21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var20);
    java.lang.ArithmeticException var22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", var20);
    org.apache.commons.math.FunctionEvaluationException var23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable)var5, var13, "hi!", var20);
    org.apache.commons.math.ode.DerivativeException var24 = new org.apache.commons.math.ode.DerivativeException((java.lang.Throwable)var23);
    org.apache.commons.math.linear.InvalidMatrixException var25 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable)var23);
    org.apache.commons.math.MathRuntimeException var26 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var25);
    java.lang.Object[] var27 = var25.getArguments();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    double[][] var10 = var9.getDataRef();
    double[][] var11 = var9.getDataRef();
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var20 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var16, var19);
    double[][] var21 = new double[][] { var19};
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var21);
    org.apache.commons.math.linear.BlockRealMatrix var23 = new org.apache.commons.math.linear.BlockRealMatrix(var21);
    org.apache.commons.math.linear.RealVector var25 = var23.getColumnVector(0);
    double var26 = var23.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var27 = var9.multiply((org.apache.commons.math.linear.RealMatrix)var23);
    org.apache.commons.math.linear.RealVector var29 = var23.getColumnVector(0);
    org.apache.commons.math.linear.RealMatrix var31 = var23.scalarMultiply(2.0d);
    org.apache.commons.math.linear.RealMatrix var32 = var23.transpose();
    double var33 = var23.getNorm();
    int var34 = var23.getRowDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }


    org.apache.commons.math.FunctionEvaluationException var1 = new org.apache.commons.math.FunctionEvaluationException((-1.0d));
    org.apache.commons.math.MathRuntimeException var2 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var1);
    java.lang.String[] var5 = new java.lang.String[] { "-90"};
    org.apache.commons.math.linear.BigMatrix var6 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var5);
    org.apache.commons.math.linear.BigMatrix var7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var5);
    org.apache.commons.math.linear.BigMatrix var8 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var5);
    java.lang.String[][] var9 = new java.lang.String[][] { var5};
    org.apache.commons.math.linear.BigMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(var9);
    org.apache.commons.math.MathRuntimeException var11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable)var2, "org.apache.commons.math.MathRuntimeException$3: ", (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    org.apache.commons.math.linear.Array2DRowRealMatrix var9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var7);
    double[][] var10 = var9.getDataRef();
    double[][] var11 = var9.getDataRef();
    double[] var16 = new double[] { 100.0d, (-1.0d)};
    double[] var19 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var20 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var16, var19);
    double[][] var21 = new double[][] { var19};
    org.apache.commons.math.linear.RealMatrix var22 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var21);
    org.apache.commons.math.linear.BlockRealMatrix var23 = new org.apache.commons.math.linear.BlockRealMatrix(var21);
    org.apache.commons.math.linear.RealVector var25 = var23.getColumnVector(0);
    double var26 = var23.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var27 = var9.multiply((org.apache.commons.math.linear.RealMatrix)var23);
    org.apache.commons.math.linear.RealVector var29 = var23.getColumnVector(0);
    org.apache.commons.math.linear.RealMatrix var31 = var23.getRowMatrix(0);
    org.apache.commons.math.linear.BlockRealMatrix var32 = var23.transpose();
    org.apache.commons.math.linear.BlockRealMatrix var35 = var23.createMatrix(100, 10);
    org.apache.commons.math.linear.BlockRealMatrix var36 = var23.copy();
    org.apache.commons.math.linear.BlockRealMatrix var37 = var23.copy();
    double[] var43 = new double[] { 100.0d, (-1.0d)};
    double[] var46 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var47 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var43, var46);
    org.apache.commons.math.linear.BigMatrix var48 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(var46);
    org.apache.commons.math.linear.BigMatrix var49 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(var46);
    double[] var57 = new double[] { 100.0d, (-1.0d)};
    double[] var60 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var61 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var57, var60);
    org.apache.commons.math.linear.Array2DRowRealMatrix var62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var60);
    double[][] var63 = var62.getDataRef();
    double[][] var64 = var62.getDataRef();
    double[][] var65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var64);
    double[][] var66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var65);
    double[][] var67 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(var65);
    org.apache.commons.math.FunctionEvaluationException var68 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "", (java.lang.Object[])var65);
    org.apache.commons.math.FunctionEvaluationException var69 = new org.apache.commons.math.FunctionEvaluationException(var46, "Dormand-Prince 8 (5, 3)", (java.lang.Object[])var65);
    org.apache.commons.math.linear.RealMatrix var70 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setColumn(100, var46);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var4 = var1.subtract(100L);
    org.apache.commons.math.fraction.BigFraction var6 = var4.multiply(10);
    org.apache.commons.math.fraction.BigFraction var8 = var6.add((-1L));
    org.apache.commons.math.fraction.BigFraction var10 = var6.add((-1));
    java.math.BigDecimal var11 = var6.bigDecimalValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    double[] var17 = new double[] { 100.0d, (-1.0d)};
    double[] var20 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var21 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var17, var20);
    double[][] var22 = new double[][] { var20};
    org.apache.commons.math.linear.RealMatrix var23 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var22);
    org.apache.commons.math.linear.BlockRealMatrix var24 = new org.apache.commons.math.linear.BlockRealMatrix(var22);
    double[] var29 = new double[] { 100.0d, (-1.0d)};
    double[] var32 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var33 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var29, var32);
    double[][] var34 = new double[][] { var32};
    org.apache.commons.math.linear.RealMatrix var35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var36 = new org.apache.commons.math.linear.BlockRealMatrix(var34);
    org.apache.commons.math.linear.BlockRealMatrix var37 = var24.subtract(var36);
    var11.setRowMatrix(0, var37);
    org.apache.commons.math.linear.BlockRealMatrix var39 = var37.transpose();
    var39.addToEntry(0, 0, 0.0d);
    int var44 = var39.getColumnDimension();
    org.apache.commons.math.linear.BlockRealMatrix var45 = var39.transpose();
    double var46 = var45.getFrobeniusNorm();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    double[] var4 = new double[] { 100.0d, (-1.0d)};
    double[] var7 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
    double[][] var9 = new double[][] { var7};
    org.apache.commons.math.linear.RealMatrix var10 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var9);
    org.apache.commons.math.linear.BlockRealMatrix var11 = new org.apache.commons.math.linear.BlockRealMatrix(var9);
    org.apache.commons.math.linear.RealVector var13 = var11.getColumnVector(0);
    int var14 = var11.getColumnDimension();
    double[] var19 = new double[] { 100.0d, (-1.0d)};
    double[] var22 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var23 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var19, var22);
    org.apache.commons.math.linear.Array2DRowRealMatrix var24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var22);
    double[][] var25 = var24.getDataRef();
    double[][] var26 = var24.getDataRef();
    double[] var31 = new double[] { 100.0d, (-1.0d)};
    double[] var34 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var35 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var31, var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math.linear.RealMatrix var37 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var36);
    org.apache.commons.math.linear.BlockRealMatrix var38 = new org.apache.commons.math.linear.BlockRealMatrix(var36);
    org.apache.commons.math.linear.RealVector var40 = var38.getColumnVector(0);
    double var41 = var38.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var42 = var24.multiply((org.apache.commons.math.linear.RealMatrix)var38);
    double[] var47 = new double[] { 100.0d, (-1.0d)};
    double[] var50 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var51 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var47, var50);
    org.apache.commons.math.linear.Array2DRowRealMatrix var52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(var50);
    double[][] var53 = var52.getDataRef();
    double[][] var54 = var52.getDataRef();
    double[] var59 = new double[] { 100.0d, (-1.0d)};
    double[] var62 = new double[] { 1.0d, (-1.0d)};
    org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var63 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var59, var62);
    double[][] var64 = new double[][] { var62};
    org.apache.commons.math.linear.RealMatrix var65 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(var64);
    org.apache.commons.math.linear.BlockRealMatrix var66 = new org.apache.commons.math.linear.BlockRealMatrix(var64);
    org.apache.commons.math.linear.RealVector var68 = var66.getColumnVector(0);
    double var69 = var66.getFrobeniusNorm();
    org.apache.commons.math.linear.RealMatrix var70 = var52.multiply((org.apache.commons.math.linear.RealMatrix)var66);
    org.apache.commons.math.linear.RealVector var72 = var66.getColumnVector(0);
    org.apache.commons.math.linear.RealVector var73 = var38.preMultiply(var72);
    org.apache.commons.math.linear.BlockRealMatrix var74 = var11.add(var38);
    org.apache.commons.math.linear.BlockRealMatrix var75 = var38.copy();
    org.apache.commons.math.linear.BlockRealMatrix var77 = var75.getColumnMatrix(1);
    org.apache.commons.math.linear.RealVector var79 = var77.getRowVector(0);
    org.apache.commons.math.linear.RealMatrixChangingVisitor var80 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var85 = var77.walkInColumnOrder(var80, 2147483647, 0, (-1), 10);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.4142135623730951d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }
// 
// 
//     org.apache.commons.math.ode.events.CombinedEventsManager var0 = new org.apache.commons.math.ode.events.CombinedEventsManager();
//     double var1 = var0.getEventTime();
//     boolean var2 = var0.stop();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.apache.commons.math.analysis.solvers.BrentSolver var0 = new org.apache.commons.math.analysis.solvers.BrentSolver();
    var0.resetFunctionValueAccuracy();
    var0.setRelativeAccuracy(0.0d);
    var0.setAbsoluteAccuracy(1000.0d);
    var0.setAbsoluteAccuracy(0.9d);
    var0.setMaximalIterationCount(0);
    org.apache.commons.math.analysis.UnivariateRealFunction var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var0.solve(var10, 1000.0d, 0.9d);
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }
// 
// 
//     double[] var4 = new double[] { 100.0d, (-1.0d)};
//     double[] var7 = new double[] { 1.0d, (-1.0d)};
//     org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator var8 = new org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator(10.0d, 0.0d, var4, var7);
//     var8.clearStepHandlers();
//     var8.clearStepHandlers();
//     java.lang.String var11 = var8.getName();
//     double var12 = var8.getCurrentStepStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Dormand-Prince 8 (5, 3)"+ "'", var11.equals("Dormand-Prince 8 (5, 3)"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }


    org.apache.commons.math.fraction.BigFraction var2 = new org.apache.commons.math.fraction.BigFraction(10L, 100L);
    org.apache.commons.math.fraction.BigFractionField var3 = var2.getField();
    org.apache.commons.math.fraction.BigFraction var5 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var6 = var5.abs();
    long var7 = var5.longValue();
    org.apache.commons.math.fraction.BigFraction var9 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var10 = var9.abs();
    org.apache.commons.math.fraction.BigFraction var11 = var10.reduce();
    org.apache.commons.math.fraction.BigFraction var13 = var11.divide((-1));
    long var14 = var13.getDenominatorAsLong();
    int var15 = var5.compareTo(var13);
    java.math.BigInteger var16 = var13.getNumerator();
    org.apache.commons.math.fraction.BigFraction var17 = var2.multiply(var16);
    org.apache.commons.math.fraction.BigFraction var19 = var17.subtract((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.fraction.BigFraction var20 = var19.reciprocal();
      fail("Expected exception of type Exception");
    } catch (Exception e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reduce();
    org.apache.commons.math.FieldElement[] var4 = new org.apache.commons.math.FieldElement[] { var3};
    org.apache.commons.math.linear.FieldVector var5 = org.apache.commons.math.linear.MatrixUtils.<org.apache.commons.math.FieldElement>createFieldVector(var4);
    org.apache.commons.math.FieldElement[][] var6 = new org.apache.commons.math.FieldElement[][] { var4};
    org.apache.commons.math.linear.BlockFieldMatrix var7 = new org.apache.commons.math.linear.BlockFieldMatrix(var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var8 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.linear.Array2DRowFieldMatrix var9 = new org.apache.commons.math.linear.Array2DRowFieldMatrix(var6);
    org.apache.commons.math.linear.FieldMatrix var10 = var9.copy();
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var13 = var12.abs();
    org.apache.commons.math.fraction.BigFraction var14 = var13.reciprocal();
    org.apache.commons.math.fraction.BigFraction var16 = var14.pow(1);
    byte var17 = var16.byteValue();
    float var18 = var16.floatValue();
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var21 = var20.abs();
    org.apache.commons.math.fraction.BigFraction var23 = var20.subtract(100L);
    java.lang.String var24 = var23.toString();
    org.apache.commons.math.fraction.BigFraction var25 = var16.divide(var23);
    org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor var26 = new org.apache.commons.math.linear.DefaultFieldMatrixChangingVisitor((org.apache.commons.math.FieldElement)var16);
    org.apache.commons.math.FieldElement var27 = var9.walkInOptimizedOrder((org.apache.commons.math.linear.FieldMatrixChangingVisitor)var26);
    org.apache.commons.math.fraction.BigFraction var29 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var30 = var29.abs();
    org.apache.commons.math.fraction.BigFraction var31 = var30.reciprocal();
    org.apache.commons.math.fraction.BigFraction var33 = var30.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var35 = var30.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var36 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var35);
    org.apache.commons.math.FieldElement var37 = var36.end();
    var36.start(2, 2147483647, 0, 2147483647, 10, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math.FieldElement var49 = var9.walkInRowOrder((org.apache.commons.math.linear.FieldMatrixPreservingVisitor)var36, 1, 0, 1, 2147483647);
      fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException");
    } catch (org.apache.commons.math.linear.MatrixIndexException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (byte)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.1f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "-90"+ "'", var24.equals("-90"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }


    org.apache.commons.math.fraction.BigFraction var1 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var2 = var1.abs();
    org.apache.commons.math.fraction.BigFraction var3 = var2.reciprocal();
    org.apache.commons.math.fraction.BigFraction var5 = var2.subtract(0L);
    org.apache.commons.math.fraction.BigFraction var7 = var2.subtract(0L);
    org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor var8 = new org.apache.commons.math.linear.DefaultFieldMatrixPreservingVisitor((org.apache.commons.math.FieldElement)var7);
    org.apache.commons.math.fraction.BigFraction var12 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var13 = var12.abs();
    org.apache.commons.math.fraction.BigFraction var15 = var12.subtract(100L);
    org.apache.commons.math.fraction.BigFraction var17 = var15.multiply(10);
    var8.visit((-1), 2, (org.apache.commons.math.FieldElement)var17);
    org.apache.commons.math.fraction.BigFraction var20 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var21 = var20.abs();
    org.apache.commons.math.fraction.BigFraction var22 = var21.reduce();
    org.apache.commons.math.fraction.BigFraction var24 = var22.divide((-1));
    long var25 = var24.getDenominatorAsLong();
    org.apache.commons.math.fraction.BigFractionField var26 = var24.getField();
    org.apache.commons.math.fraction.BigFraction var27 = var26.getZero();
    org.apache.commons.math.fraction.BigFraction var29 = var27.subtract((-1L));
    org.apache.commons.math.fraction.BigFraction var30 = var17.divide(var29);
    double var31 = var17.percentageValue();
    org.apache.commons.math.fraction.BigFraction var33 = new org.apache.commons.math.fraction.BigFraction(10);
    org.apache.commons.math.fraction.BigFraction var34 = var33.abs();
    org.apache.commons.math.fraction.BigFraction var35 = var34.reduce();
    org.apache.commons.math.fraction.BigFraction var37 = var35.divide((-1));
    long var38 = var37.getDenominatorAsLong();
    int var39 = var17.compareTo(var37);
    org.apache.commons.math.fraction.BigFraction var41 = var17.subtract((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-90000.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

}
