
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double[] var1 = new double[] { 0.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var3 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    double[] var1 = new double[] { 1.0d};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkPositive(var0);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var13 = new double[] { };
    double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = org.apache.commons.math3.util.MathArrays.distance1(var10, var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)100L);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial(0, 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "57fdd2ad3b"+ "'", var4.equals("57fdd2ad3b"));
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.0d), 0.0d, 0.0d, 10.0d, 1.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var9 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    double[] var16 = new double[] { };
    double[] var20 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var16, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var14, var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var24 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var20);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(100.0d, 100.0d, 1.0d, 0.0d, 1.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10010.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(10010.0d, 100.0d, 1.0d, 10.0d, 1.0d, 100.0d, 10010.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1011120.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.apache.commons.math3.exception.NullArgumentException var0 = new org.apache.commons.math3.exception.NullArgumentException();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"+ "'", var1.equals("org.apache.commons.math3.exception.NullArgumentException: null is not allowed"));

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var17, (-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 1011120.0d);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var28 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var27);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("", "83c393468c");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.NullArgumentException: null is not allowed", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextZipf((-1), 1.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)100, (java.lang.Number)1, false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.0d, 10010.0d, 10.0d, 0.0d, 1011120.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 100100.0d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(1.0d, 1011120.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var1.nextUniform(10.0d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 93172.20368305333d);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10.0d, (java.lang.Number)1L, true);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var23 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var24 = new double[] { };
    double[] var28 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
    double[] var30 = new double[] { };
    double[] var34 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var23, var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var34, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var40 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var16, var34);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextF((-152295.14271861385d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "610333d7b4"+ "'", var4.equals("610333d7b4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-152295.14271861385d));
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    java.lang.Number var20 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var23 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var20, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = var23.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var27 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var24, true, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextChiSquare((-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
//     double[] var18 = null;
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var3, var18);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 1);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextPascal(0, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0L, (java.lang.Number)(short)1, true);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(-1L), false);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)(short)10, (java.lang.Number)1.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)10+ "'", var5.equals((short)10));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var7 = new double[] { };
//     double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var5, var11);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var11);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(1.0d, 1011120.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var1.nextLong(7540580061456263210L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1002988.1590993088d);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    float var6 = var4.nextFloat();
    double[] var10 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var11 = new double[] { };
    double[] var15 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
    double[] var17 = new double[] { };
    double[] var21 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var17, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var15, var21);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeAdd(var10, var21);
    double[] var26 = org.apache.commons.math3.util.MathArrays.normalizeArray(var21, (-1.0d));
    double[] var30 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double[] var37 = new double[] { };
    double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var41);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var41, (-1.0d));
    double[] var47 = new double[] { };
    double[] var51 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
    double[] var53 = new double[] { };
    double[] var57 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var53, var57);
    double[] var59 = new double[] { };
    double[] var63 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var59, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var57, var63);
    double var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var51, var63);
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var46, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var68 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var21, var46);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.27873123f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 22.10526315789474d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextHypergeometric(10, 100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)14603.081554194827d, var2);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1755678109);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var2.nextSample(var5, 5);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0d);
    java.lang.Number var2 = var1.getMin();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextPascal(10, (-152295.14271861385d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 100);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextHypergeometric(1, (-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var10);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (-1.0d)};
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var5, var7);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)(byte)0, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100L, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1755678109);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextWeibull(22.10526315789474d, (-0.9387123485327005d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     var4.clear();
//     double var6 = var4.nextDouble();
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var7);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial((-1), 10010.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d6c617f73f"+ "'", var4.equals("d6c617f73f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double[] var1 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var3 = new double[] { };
    double[] var7 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var8 = org.apache.commons.math3.util.MathArrays.distance1(var3, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    var1.setSeed((-4237628123369238917L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal(1755678109, 185.2718719624735d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "05f19a7201"+ "'", var2.equals("05f19a7201"));
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("d3e0117a10", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "872d21a36b"+ "'", var4.equals("872d21a36b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0f, (java.lang.Number)19.375753716098963d, true);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    double var11 = var2.nextGamma(185.2718719624735d, 37.124987752215674d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextCauchy((-0.3183389366223311d), (-0.3183389366223311d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5606.347746720141d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    var2.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var2.nextPoisson(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    var4.setSeed(7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    double var11 = var2.nextGamma(185.2718719624735d, 37.124987752215674d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextCauchy(0.9153238394393426d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5606.347746720141d);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGamma(0.5263157894736842d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f6f0c5f54d"+ "'", var4.equals("f6f0c5f54d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(100, 1.0d);
//     int var8 = var2.nextInt(0, 10);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var2.nextSample(var9, 119583573);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextGamma(5606.347746720141d, (-152295.14271861385d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(1, 1755678109, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)22.10526315789474d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100.0f};
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var5);
    java.lang.Number var8 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0+ "'", var8.equals(0));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
    double[] var43 = new double[] { (-1.0d)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var41, var43);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var2.nextSecureLong(0L, (-4237628123369238917L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 10);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var18 = new double[] { };
    double[] var22 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var25);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)10.0f);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     boolean var3 = var1.nextBoolean();
//     double var4 = var1.nextGaussian();
//     byte[] var5 = null;
//     var1.nextBytes(var5);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextCauchy(49.73518257362382d, 0.2787313252014696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1183934ab3"+ "'", var4.equals("1183934ab3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 49.437501015567314d);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    long var10 = var2.nextPoisson(1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextPoisson((-0.3183389366223311d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(5, 37.124987752215674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.util.Pair var0 = null;
//     org.apache.commons.math3.util.Pair var1 = new org.apache.commons.math3.util.Pair(var0);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     long var18 = var0.nextLong(1L, 10L);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 43);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 5, 43);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var41);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextHypergeometric(5, 119583573, 89);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)(byte)(-1), (java.lang.Number)0);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(37.124987752215674d, 0.0d, 49.73518257362382d, 100.0d, 10010.0d, 49.73518257362382d, 100.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 502822.6958193368d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var25);
    double[] var42 = new double[] { };
    double[] var46 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var42, var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    double[] var18 = new double[] { };
    double[] var22 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var22);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var10);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var0.nextSample(var3, 119583573);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    boolean var6 = var5.getStrict();
    java.lang.String var7 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly decreasing (10 <= 10)"+ "'", var7.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 0 and 1 are not strictly decreasing (10 <= 10)"));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(byte)10, (java.lang.Number)185.2718719624735d, false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextSecureInt(1, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1755678109, 0);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "a7ae9eaa587b71faa29926ab716bb826bf3ccf3697f94e3d1f2cdff90668ea76b00eb85f69165ee3547"+ "'", var3.equals("a7ae9eaa587b71faa29926ab716bb826bf3ccf3697f94e3d1f2cdff90668ea76b00eb85f69165ee3547"));
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.nextHypergeometric(1, 44, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     var6.reSeed((-1L));
//     java.lang.String var10 = var6.nextSecureHexString(10);
//     var6.reSeedSecure();
//     int var15 = var6.nextHypergeometric(100, 1, 1);
//     int[] var18 = var6.nextPermutation(10, 5);
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var18);
//     int[] var21 = new int[] { 1};
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 0);
//     int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 0);
//     int[] var27 = new int[] { 1};
//     int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
//     int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
//     int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var33 = org.apache.commons.math3.util.MathArrays.distance(var18, var21);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "9d36118b77"+ "'", var10.equals("9d36118b77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(short)(-1), (java.lang.Number)(short)0, true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    long var10 = var2.nextPoisson(1.0d);
    double var12 = var2.nextT(5606.347746720141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.926725986813839d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.nextHypergeometric(83, 1755678109, 119583573);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)0);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var2.nextPermutation(0, 334518628);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5609.481394292047d);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)49.437501015567314d, var2, (java.lang.Number)89);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, (-0.3183389366223311d));
//     java.lang.Comparable[] var21 = new java.lang.Comparable[] { (-1.0f)};
//     java.lang.Number var22 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var22, (java.lang.Number)(byte)100, 100);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var25.getDirection();
//     boolean var28 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var21, var26, false);
//     double[][] var29 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var26, var29);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0L);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)(short)1, (java.lang.Number)10.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.23449722509094836d, (java.lang.Number)1.1672233456208478d, true);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    int var8 = var2.nextZipf(5, 5606.347746720141d);
    int var11 = var2.nextBinomial(0, 0.41292608781564977d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextGamma(0.0d, 0.5263157894736842d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9153238394393426d, 0.926725986813839d, 3.6008534624247894E11d, 5606.347746720141d, 4481.058440388458d, 0.0d, 10010.0d, 5606.347746720141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0187637256530055E15d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var24, var30);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var10, var30);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 14.177446878757825d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    boolean var6 = var5.getStrict();
    boolean var7 = var5.getStrict();
    java.lang.Number var8 = var5.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(1685.0291123281943d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e4efd1b474"+ "'", var4.equals("e4efd1b474"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(10010.0d, 1.1672233456208478d, 4411.553384062907d, 3.6008534624247894E11d, 37.124987752215674d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.5885357277791555E15d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    long[] var2 = new long[] { 1L, (-1L)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     long var14 = var2.nextLong(7L, 10L);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var2.nextInversionDeviate(var15);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     int var15 = var0.nextPascal(5, 0.40877566087838346d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextChiSquare((-0.9387123485327005d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "98515b678d"+ "'", var4.equals("98515b678d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1054671320);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextLong(5141685311728891869L, 8L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)119583573);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10, (java.lang.Number)0.41292608781564977d, var2);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    java.lang.Number var6 = var5.getPrevious();
    java.lang.Number var7 = var5.getPrevious();
    int var8 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)10+ "'", var6.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)10+ "'", var7.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)35, var1, false);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)22.10526315789474d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100.0f};
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var5);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10, (java.lang.Number)100.0d, 0);
    var1.addSuppressed((java.lang.Throwable)var11);
    java.lang.Number var13 = var11.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 100.0d+ "'", var13.equals(100.0d));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(5, 37.124987752215674d);
//     double var14 = var2.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextWeibull(19.375753716098963d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.01731035720893923d);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    int var6 = var4.nextInt(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var2.nextUniform(9998.458978288749d, 4481.058440388458d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 502926.81918299187d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    double var8 = var2.nextWeibull(1.5885357277791555E15d, 0.926725986813839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.9267259868138397d);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation(0, 5);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "17af40d9f0"+ "'", var4.equals("17af40d9f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3578cb40f4", "729c45c4bc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a2805e892c"+ "'", var4.equals("a2805e892c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "04aa06d854373b3bbd8a4f71f9fb09ef002c46aeb1fd"+ "'", var9.equals("04aa06d854373b3bbd8a4f71f9fb09ef002c46aeb1fd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-445839021452577984L));
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.23449722509094836d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     int var4 = var1.nextInt(89);
//     java.util.List var5 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var6 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var5);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var2.nextUniform(276733.161992937d, 0.23449722509094836d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1494.959397091152d);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    java.lang.Comparable[] var7 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var8, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = var11.getDirection();
    boolean var14 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var7, var12, false);
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    double var6 = var4.nextDouble();
    var4.clear();
    double[] var11 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    double[] var18 = new double[] { };
    double[] var22 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var22);
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeAdd(var11, var22);
    double[] var27 = org.apache.commons.math3.util.MathArrays.normalizeArray(var22, (-1.0d));
    double[] var28 = new double[] { };
    double[] var32 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
    double[] var34 = new double[] { };
    double[] var38 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var34, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var32, var38);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var55, (-1.0d));
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var38, var55);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var27, var55);
    double[] var63 = new double[] { };
    double[] var67 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var63, var67);
    double[] var69 = new double[] { };
    double[] var73 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var69, var73);
    double[] var75 = new double[] { };
    double[] var79 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var75, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var73, var79);
    double var82 = org.apache.commons.math3.util.MathArrays.distanceInf(var67, var79);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var79);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var84 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var55, var79);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)9998.458978288749d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextUniform(1685.0291123281943d, (-0.3183389366223311d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextHypergeometric(100, 3, 1755678109);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "cf2498d3a5"+ "'", var4.equals("cf2498d3a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1203042934);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)502926.81918299187d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = new double[] { };
    double[] var21 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var17, var21);
    double[] var23 = new double[] { };
    double[] var27 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var23, var27);
    double[] var29 = new double[] { };
    double[] var33 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var29, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var27, var33);
    double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var37 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8, var33);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.9387123485327005d), 0.926725986813839d, (-1.0d), 1.5885357277791555E15d, 22.10526315789474d, 6182.891512476099d, 7.343684965302029E9d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.5878013591459518E15d));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(7263549.284553437d, 4481.058440388458d, 276733.161944128d, 0.5263157894736842d, 0.23449722509094836d, 0.40877566087838346d, 10010.0d, 0.926725986813839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.2548543754381306E10d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var9 = new int[] { 1};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    var7.setSeed(var11);
    int[] var14 = new int[] { 1};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var14);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var14);
    int[] var20 = new int[] { 1};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    int[] var26 = new int[] { 1};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 0);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 0);
    int var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var26);
    int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var20);
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextWeibull(4481.058440388458d, 0.2787313252014696d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.2787313252014696d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d23049fa0c"+ "'", var4.equals("d23049fa0c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.27868821153744294d);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)1.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    java.lang.Number var7 = var3.getMax();
    java.lang.Number var8 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1.0d+ "'", var8.equals(1.0d));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextUniform(3.2548543754381306E10d, 11.0d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5263157894736842d, (java.lang.Number)9998.458978288749d, 1755678109);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var24, var30);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var10, var30);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var59 = new double[] { };
    double[] var63 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var59, var63);
    double[] var65 = new double[] { };
    double[] var69 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var65, var69);
    double[] var71 = new double[] { };
    double[] var75 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var71, var75);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var69, var75);
    double var78 = org.apache.commons.math3.util.MathArrays.distanceInf(var63, var75);
    double var79 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var63);
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var10, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 21.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var2.nextSample(var13, 44);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    var5.setSeed(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var17);
    var19.setSeed(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextSecureLong(100L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    java.lang.Number var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (-1.0d)};
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var2);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NotFiniteNumberException: null is not a finite number"+ "'", var4.equals("org.apache.commons.math3.exception.NotFiniteNumberException: null is not a finite number"));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var1.nextExponential((-152295.14271861385d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.5885357277791555E15d, var2, false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 5, 10);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var12 = var2.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextPascal(119583573, 502926.81918299187d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "9c98781732"+ "'", var2.equals("9c98781732"));
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextZipf(0, 276733.161944128d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextHypergeometric(83, 119583573, 74);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9c4ee57381"+ "'", var4.equals("9c4ee57381"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextChiSquare(1.5885357277791555E15d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("87e9f92473", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var7 = new double[] { };
//     double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
//     double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
//     double[] var22 = new double[] { };
//     double[] var26 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var22, var26);
//     double[] var28 = new double[] { };
//     double[] var32 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
//     double[] var34 = new double[] { };
//     double[] var38 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var34, var38);
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var32, var38);
//     double var41 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var38);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var17, var26);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var42);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     int var4 = var1.nextInt(89);
//     var1.setSeed(5);
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)(short)0, (java.lang.Number)10L);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)5141685311728891869L, (java.lang.Number)4052L, 89);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)100.0d, (java.lang.Number)(-1L), (java.lang.Number)(-316249655302969216L));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    java.lang.Comparable[] var42 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var43 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var43, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var46.getDirection();
    boolean var49 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var42, var47, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var36, var47, true, false);
    double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 2.0187637256530055E15d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var36);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextSecureLong(8L, 8L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextChiSquare(1.5885357277791555E15d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "73161e9f6c"+ "'", var4.equals("73161e9f6c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var13 = var0.nextUniform((-0.3183389366223311d), 49.73518257362382d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextZipf(5, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e47000fecb"+ "'", var4.equals("e47000fecb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 19.375753716098963d);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
//     var2.reSeedSecure();
//     double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
//     int var21 = var2.nextSecureInt(0, 83);
//     java.util.Collection var22 = null;
//     java.lang.Object[] var24 = var2.nextSample(var22, 795460800);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextBinomial(55, 1011120.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     double[] var0 = null;
//     double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     double var10 = var2.nextF(6.133447800101376d, 0.27868821153744294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2349.693493309191d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 44986.47454917167d);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     var2.reSeedSecure(7540580061456263210L);
//     var2.reSeedSecure(10L);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 5);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     long var1 = var0.nextLong();
//     boolean var2 = var0.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-867244594845292898L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == true);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10, (java.lang.Number)100.0d, 0);
    java.lang.Number var4 = var3.getPrevious();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.0d+ "'", var4.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    double var6 = var4.nextDouble();
    double var7 = var4.nextGaussian();
    double var8 = var4.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var9.nextUniform(0.23449722509094836d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.9387123485327005d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.41292608781564977d);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     long var14 = var2.nextLong(7L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var2.nextHypergeometric(44, 55, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4304.286951677743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "10941bda41e9f638229acc154a1ad8cf757c054949d2ec33ac48c62050d08219314026a15804c76232c9f6847a0e21e60b9b"+ "'", var11.equals("10941bda41e9f638229acc154a1ad8cf757c054949d2ec33ac48c62050d08219314026a15804c76232c9f6847a0e21e60b9b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9L);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.41292608781564977d, 44986.47454917167d, 1685.0291123281943d, 4480.197711865118d, 0.0d, 3.2548543754381306E10d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 7567839.662419096d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var4 = null;
//     int var5 = org.apache.commons.math3.util.MathArrays.distance1(var1, var4);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var9 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    double[] var16 = new double[] { };
    double[] var20 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var16, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var14, var20);
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeAdd(var9, var20);
    double[] var25 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, (-1.0d));
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double[] var42 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var43 = new double[] { };
    double[] var47 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var43, var47);
    double[] var49 = new double[] { };
    double[] var53 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var49, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var47, var53);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeAdd(var42, var53);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var53, (-1.0d));
    double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var36, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var25, var53);
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var4, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextPascal(10, 3.6008534624247894E11d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var3 = new int[] { 1};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
//     var1.setSeed(var5);
//     int[] var8 = new int[] { 1};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
//     int[] var13 = new int[] { 1};
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl();
//     var16.reSeed((-1L));
//     java.lang.String var20 = var16.nextSecureHexString(10);
//     var16.reSeedSecure();
//     int var25 = var16.nextHypergeometric(100, 1, 1);
//     int[] var28 = var16.nextPermutation(10, 5);
//     int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var15);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "d702dc5e98"+ "'", var20.equals("d702dc5e98"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(100100.0d, 22.10526315789474d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
//     double[] var6 = new double[] { };
//     double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
//     double[] var12 = new double[] { };
//     double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
//     double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var21 = new double[] { };
//     double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
//     double[] var27 = new double[] { };
//     double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
//     double[] var33 = new double[] { };
//     double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
//     double[] var42 = null;
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var42);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(273.14655120642885d, 276733.161944128d, 0.926725986813839d, 0.9153238394393426d, 10010.0d, 37.124987752215674d, 14.177446878757825d, 0.41292608781564977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 7.596033661938047E7d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 83);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 83);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextInt(43, 43);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5ee7a0c344"+ "'", var4.equals("5ee7a0c344"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1410366988);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2691423794949081088L));
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(8L);
    int var7 = var2.nextZipf(83, 4411.553384062907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextInt(5, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var2.nextUniform(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var3.nextChiSquare((-0.9387123485327005d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-152295.14271861385d), (-1.5878013591459518E15d), 14.279906171571504d, (-1.5878013591459518E15d), 37.124987752215674d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.4179176094551405E20d);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     int var15 = var0.nextPascal(5, 0.40877566087838346d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(7.343684965302029E9d, (-28312.721511760275d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "358e3a995f"+ "'", var4.equals("358e3a995f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1150007917);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)2.0187637256530055E15d, (java.lang.Number)(-2307991337150814208L), 0);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(4411.553384062907d, 4481.058440388458d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var2.nextPermutation(3, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4440.01349320976d);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextGamma(4411.553384062907d, 1685.0291123281943d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.01731035720893923d, (-422264.7974214142d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "00c6feaa54"+ "'", var4.equals("00c6feaa54"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7263549.284553437d);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)(-1), var1);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(-867244594845292898L), true);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    double var4 = var1.nextGaussian();
    int[] var8 = new int[] { 10, 1, 0};
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    var1.setSeed(var8);
    int var12 = var1.nextInt(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.23449722509094836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeedSecure(4052L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(7.596033661938047E7d, 502926.81918299187d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10, (java.lang.Number)(byte)0, 0);
    boolean var4 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(short)0, (java.lang.Number)(byte)100, 16);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var3 = new int[] { 1};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
//     var1.setSeed(var5);
//     long var7 = var1.nextLong();
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     var0.reSeed(7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a463a7a18d"+ "'", var4.equals("a463a7a18d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 326172715);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-199254194018620640L));
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var10);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    java.lang.Object var23 = var22.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextF(0.0d, 0.926725986813839d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7cbdce8218"+ "'", var4.equals("7cbdce8218"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    var2.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextUniform(100.0d, 49.437501015567314d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5141685311728891869L);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    long var11 = var2.nextLong((-199254194018620640L), (-98107090172506864L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-150956856425768896L));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-3983742070236694016L), var2);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)1.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    java.lang.Number var7 = var3.getMax();
    boolean var8 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    double var5 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.4774960009367326d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    long var11 = var2.nextPoisson(0.27868821153744294d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(100, 273.14655120642885d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var2.nextHypergeometric(0, 0, 83);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt(0, 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 53);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(3.6008534624247894E11d, 7263549.284553437d, 0.0d, 276733.161944128d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.6154976590777344E18d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextUniform(49.437501015567314d, (-0.7309748381028882d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)(short)0, (java.lang.Number)10L);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 100 out of [0, 10] range"+ "'", var4.equals("org.apache.commons.math3.exception.OutOfRangeException: 100 out of [0, 10] range"));

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)(byte)(-1));
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var5 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var4);
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     java.lang.Comparable[] var8 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var9, false);
//     double[] var13 = new double[] { 1.0d};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var13);
//     java.lang.Number var15 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var15, (java.lang.Number)(byte)100, 100);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var18.getDirection();
//     boolean var22 = org.apache.commons.math3.util.MathArrays.checkOrder(var13, var19, false, false);
//     boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var8, var19, true);
//     org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var8);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     var1.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3607515929832048803L);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var2.nextHypergeometric(326172715, 89, 1755678109);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 2, 0);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    double[] var16 = new double[] { };
    double[] var20 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var16, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var14, var20);
    double var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    double[] var25 = new double[] { };
    double[] var29 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var25, var29);
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double[] var37 = new double[] { };
    double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var29, var35);
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var35);
    double[] var46 = new double[] { };
    double[] var50 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var46, var50);
    double[] var52 = new double[] { };
    double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    double[] var58 = new double[] { };
    double[] var62 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var58, var62);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var56, var62);
    double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var50, var62);
    double[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var67 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var20, var62);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var5.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var5.getDirection();
    int var8 = var5.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)4554967237661810166L, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     double var8 = var0.nextWeibull(7.343684965302029E9d, 276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7b61148d6d"+ "'", var4.equals("7b61148d6d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 276733.161944128d);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextF(0.40877566087838346d, 273.14655120642885d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var18 = new double[] { };
    double[] var22 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var23 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
    double[] var24 = new double[] { };
    double[] var28 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
    double[] var30 = new double[] { };
    double[] var34 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
    double[] var39 = new double[] { };
    double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var55);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var60 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var17, var59);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    double[] var0 = null;
    double[] var4 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var5 = new double[] { };
    double[] var9 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var5, var9);
    double[] var11 = new double[] { };
    double[] var15 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var15);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.0d));
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var20, var37);
    double[] var45 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var46 = new double[] { };
    double[] var50 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var46, var50);
    double[] var52 = new double[] { };
    double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var50, var56);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeAdd(var45, var56);
    double[] var61 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, (-0.3183389366223311d));
    double var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var61);
    double[] var63 = new double[] { };
    double[] var67 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var63, var67);
    double[] var69 = new double[] { };
    double[] var73 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var69, var73);
    double[] var75 = new double[] { };
    double[] var79 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var80 = org.apache.commons.math3.util.MathArrays.distance1(var75, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var73, var79);
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var67, var73);
    double var83 = org.apache.commons.math3.util.MathArrays.distance(var61, var73);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.5263157894736842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 14.279906171571504d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 1.0d};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var7 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var8 = new double[] { };
//     double[] var12 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     double[] var14 = new double[] { };
//     double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var12, var18);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var7, var18);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, (-1.0d));
//     boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var18);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance(var0, var2);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var14 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var19 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var24, var30);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeAdd(var19, var30);
    double[] var35 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, (-1.0d));
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var37 = org.apache.commons.math3.util.MathArrays.linearCombination(var4, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair(var23);
    java.lang.Object var25 = var24.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 100L+ "'", var25.equals(100L));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.23449722509094836d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    long var5 = var4.nextLong();
    var4.setSeed(59);
    double var8 = var4.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.8255599450450224d));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextBeta((-0.3183389366223311d), 0.9267259868138397d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), 1146362687);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextZipf(2, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.5885357277791555E15d, (java.lang.Number)0.07797476827309713d, false);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     double var14 = var2.nextGaussian(6655.664073045887d, 10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6670.1469035478d);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextUniform(1685.0291123281943d, (-1.5878013591459518E15d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 277605L);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
    double[] var42 = new double[] { };
    double[] var46 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var42, var46);
    double[] var48 = new double[] { };
    double[] var52 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    double[] var54 = new double[] { };
    double[] var58 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var54, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var52, var58);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var46, var52);
    double[] var62 = new double[] { };
    double[] var66 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var67 = org.apache.commons.math3.util.MathArrays.distance1(var62, var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var66);
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var41, var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var41);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-422264.7974214142d), (java.lang.Number)4052L, true);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 4052L+ "'", var5.equals(4052L));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)4480.197711865118d, (java.lang.Number)0.27868821153744294d, var2);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var24 = var22.getSecond();
    java.lang.Object var25 = var22.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + 100L+ "'", var24.equals(100L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 100L+ "'", var25.equals(100L));

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     java.util.List var5 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var6 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var5);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)10010.0d, (java.lang.Number)(short)(-1), true);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(short)10);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    var3.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    var2.reSeedSecure((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextInt(89, 83);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextSecureLong(10L, (-867244594845292898L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d3876f85f1"+ "'", var4.equals("d3876f85f1"));
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var2.nextPermutation(10, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextHypergeometric(16, 6, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ebde4b5f82"+ "'", var4.equals("ebde4b5f82"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "98e619bdfdab044bbb772caccf99dae5a21df025e69e"+ "'", var9.equals("98e619bdfdab044bbb772caccf99dae5a21df025e69e"));
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NotPositiveException var4 = new org.apache.commons.math3.exception.NotPositiveException(var2, (java.lang.Number)(byte)(-1));
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var35 = org.apache.commons.math3.util.MathArrays.distance1(var24, var27);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(0.40877566087838346d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1c30f9101f"+ "'", var4.equals("1c30f9101f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.2787313252014696d, 2349.693493309191d, 0.017178374061959746d, 8273.979899088612d, (-1.8255599450450224d), 7567839.662419096d, 0.017178374061959746d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 114938.89818584558d);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     double var7 = var1.nextUniform((-1.0d), 7263549.284553437d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 277089L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 223115.0311913556d);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     double var10 = var0.nextGamma(0.40877566087838346d, 22.10526315789474d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextInt(83, 15);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ebe8e1a615"+ "'", var4.equals("ebe8e1a615"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4.820306568371384d);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var13 = var2.nextGamma(49.437501015567314d, 7.343684965302029E9d);
    double var16 = var2.nextGaussian(6655.664073045887d, 1685.0291123281943d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.6008534624247894E11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 6780.649531159886d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.5885357277791555E15d, (java.lang.Number)(-867244594845292898L), (java.lang.Number)277089L);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 1);
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    int var5 = var2.getDimension();
    int var6 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var1.getContext();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(3.2548543754381306E10d, 2.0187637256530055E15d, (-0.3183389366223311d), 0.41292608781564977d, 3965.0367954613544d, 502926.81918299187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6.570781945417467E25d);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(1, 1011120.0d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var2.nextSample(var7, 100);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100.0d, var1);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 35, 89);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    double var11 = var2.nextGaussian(14418.670979848415d, 276733.161992937d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextCauchy(37.124987752215674d, (-28312.721511760275d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-723068.631252455d));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     var6.reSeed((-1L));
//     java.lang.String var10 = var6.nextSecureHexString(10);
//     var6.reSeedSecure();
//     int var15 = var6.nextHypergeometric(100, 1, 1);
//     int[] var18 = var6.nextPermutation(10, 5);
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var18);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var18);
//     boolean var21 = var20.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f1b84323d7"+ "'", var10.equals("f1b84323d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     double var17 = var0.nextWeibull(185.2718719624735d, 0.01731035720893923d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("282198b4f1186da7f0a6688ebc06dbeeff26eeda6cef", "6b2079aeb4");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8c59da530e"+ "'", var4.equals("8c59da530e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "6a6f66d786157f390d3ece6211dc05be5292098ecda2"+ "'", var9.equals("6a6f66d786157f390d3ece6211dc05be5292098ecda2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3433341470664749056L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.017165361893826763d);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    int var8 = var2.nextZipf(5, 5606.347746720141d);
    int var11 = var2.nextBinomial(0, 0.41292608781564977d);
    double var13 = var2.nextExponential(14603.081554194827d);
    double var15 = var2.nextT(49.437501015567314d);
    var2.reSeedSecure((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 53743.07090776245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5162940945248184d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     byte[] var8 = new byte[] { (byte)100, (byte)0, (byte)10};
//     var4.nextBytes(var8);
//     int[] var10 = null;
//     var4.setSeed(var10);
//     double var12 = var4.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.667275766788113d);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     double var17 = var0.nextWeibull(185.2718719624735d, 0.01731035720893923d);
//     double var19 = var0.nextExponential(0.954816313157598d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b824d071f4"+ "'", var4.equals("b824d071f4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "4bd42be530dd263a6fc9622029d02a310321f124f1f4"+ "'", var9.equals("4bd42be530dd263a6fc9622029d02a310321f124f1f4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2100806147823023616L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.017341366001328715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5.290248133988897d);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 100);
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(8L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextUniform(1.0d, 0.2787313252014696d, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)19.375753716098963d, (java.lang.Number)5141685311728891869L, (java.lang.Number)223115.0311913556d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var55);
    double[] var60 = new double[] { };
    double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    double[] var66 = new double[] { };
    double[] var70 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var71 = org.apache.commons.math3.util.MathArrays.distance1(var66, var70);
    double[] var72 = new double[] { };
    double[] var76 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var77 = org.apache.commons.math3.util.MathArrays.distance1(var72, var76);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var70, var76);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var64, var70);
    double[] var80 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var2.nextUniform(3.6008534624247894E11d, 0.5263157894736842d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8072.573601789959d);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     int var14 = var2.nextInt(0, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("2ab998d625", "b4ee55f0a6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)44, var2, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 44+ "'", var5.equals(44));

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var25);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var7 = new double[] { };
//     double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var5, var11);
//     double[] var21 = new double[] { };
//     double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
//     double[] var27 = new double[] { };
//     double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
//     double[] var33 = new double[] { };
//     double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var11, var31);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var31);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 2349.693493309191d);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextBinomial(0, 6670.1469035478d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     double var15 = var2.nextF(185.2718719624735d, 276733.161992937d);
//     var2.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8718199161117666d);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 37.124987752215674d, 7.596033661938047E7d, (-422264.7974214142d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-3.2075376154645125E13d));

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     long var5 = var2.nextPoisson(11.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    double var6 = var4.nextDouble();
    double var7 = var4.nextGaussian();
    double var8 = var4.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    double[] var16 = new double[] { };
    double[] var20 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var21 = org.apache.commons.math3.util.MathArrays.distance1(var16, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var14, var20);
    double[] var26 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var37);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var55, (-1.0d));
    double[] var61 = new double[] { };
    double[] var65 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var66 = org.apache.commons.math3.util.MathArrays.distance1(var61, var65);
    double[] var67 = new double[] { };
    double[] var71 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var67, var71);
    double[] var73 = new double[] { };
    double[] var77 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var78 = org.apache.commons.math3.util.MathArrays.distance1(var73, var77);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var71, var77);
    double var80 = org.apache.commons.math3.util.MathArrays.distanceInf(var65, var77);
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var60, var77);
    java.lang.Comparable[] var83 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var84 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var87 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var84, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var88 = var87.getDirection();
    boolean var90 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var83, var88, false);
    boolean var93 = org.apache.commons.math3.util.MathArrays.checkOrder(var77, var88, true, false);
    double[] var95 = org.apache.commons.math3.util.MathArrays.normalizeArray(var77, 2.0187637256530055E15d);
    double[] var96 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var97 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var14, var95);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.9387123485327005d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.41292608781564977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-8587680114487392385L));
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    boolean var6 = var5.getStrict();
    boolean var7 = var5.getStrict();
    java.lang.Number var8 = var5.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)10+ "'", var8.equals((byte)10));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     var2.reSeed(0L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var2.nextSample(var15, 3);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)1.0f, (java.lang.Number)100.0d);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var44, (-0.3183389366223311d));
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var19);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.5263157894736842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     long var14 = var2.nextLong(7L, 10L);
//     var2.reSeed(5141685311728891869L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var2.nextHypergeometric(35, 100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3077.8924971075485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "4e06d97feb14021e195bd342b679f852861300abc4aeccdd2251fbc6255c5072b1af9cbb3d4cdc907781e44dea1d0b93c9b8"+ "'", var11.equals("4e06d97feb14021e195bd342b679f852861300abc4aeccdd2251fbc6255c5072b1af9cbb3d4cdc907781e44dea1d0b93c9b8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 10L);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)(short)10, (java.lang.Number)1.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)0+ "'", var6.equals((short)0));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextF(0.40877566087838346d, 273.14655120642885d);
//     long var14 = var0.nextPoisson(3965.0367954613544d);
//     int var17 = var0.nextBinomial(100, 0.4020775187866738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a7d884c760"+ "'", var4.equals("a7d884c760"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "f82447eba99e1270fc2003b1cd0290ab6379d4dce731"+ "'", var9.equals("f82447eba99e1270fc2003b1cd0290ab6379d4dce731"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07797476827309713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4052L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 42);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextSecureLong(0L, 100L);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "615a64370e"+ "'", var4.equals("615a64370e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 49.73518257362382d);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)(byte)(-1));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextHypergeometric(59, 1755678109, 1755678109);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)74, (java.lang.Number)(byte)100, false);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     int var12 = var0.nextSecureInt(10, 16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(6535425231125204517L, (-3983742070236694016L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2777e66589"+ "'", var4.equals("2777e66589"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "d92637a7c2e9691c22bd4f05bd6dab838b050ff0039f"+ "'", var9.equals("d92637a7c2e9691c22bd4f05bd6dab838b050ff0039f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 13);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     long var14 = var2.nextLong(7L, 10L);
//     double var17 = var2.nextF(11.0d, 1.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var18 = null;
//     int var19 = var2.nextInversionDeviate(var18);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    double var8 = var2.nextWeibull(3965.0367954613544d, 859310.3200241375d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 859555.3460788252d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)"6b2079aeb4");

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    var1.setSeed(0);
    double var7 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.908642352606886d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var24 = var23.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1685.0291123281943d, (java.lang.Number)(byte)10, 35);
    boolean var4 = var3.getStrict();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var7 = new int[] { 1};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var7);
//     int[] var14 = new int[] { 1};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl();
//     var19.reSeed((-1L));
//     java.lang.String var23 = var19.nextSecureHexString(10);
//     var19.reSeedSecure();
//     int var28 = var19.nextHypergeometric(100, 1, 1);
//     int[] var31 = var19.nextPermutation(10, 5);
//     int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var18);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "d640850e85"+ "'", var23.equals("d640850e85"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     int[] var3 = new int[] { 10, 1, 0};
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     int[] var6 = new int[] { 1};
//     int[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 0);
//     org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var12 = new int[] { 1};
//     int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 0);
//     var10.setSeed(var14);
//     int var16 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
//     var4.setSeed(var14);
//     int[] var19 = new int[] { 1};
//     int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
//     org.apache.commons.math3.random.RandomDataImpl var22 = new org.apache.commons.math3.random.RandomDataImpl();
//     var22.reSeed((-1L));
//     java.lang.String var26 = var22.nextSecureHexString(10);
//     var22.reSeedSecure();
//     int var31 = var22.nextHypergeometric(100, 1, 1);
//     int[] var34 = var22.nextPermutation(10, 5);
//     int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var21, var34);
//     double var36 = org.apache.commons.math3.util.MathArrays.distance(var14, var21);
//     int[] var38 = new int[] { 1};
//     int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 0);
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var44 = new int[] { 1};
//     int[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 0);
//     var42.setSeed(var46);
//     int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var46);
//     org.apache.commons.math3.random.Well19937c var49 = new org.apache.commons.math3.random.Well19937c(var40);
//     double var50 = org.apache.commons.math3.util.MathArrays.distance(var14, var40);
//     int[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "444d925617"+ "'", var26.equals("444d925617"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed(59);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    double[] var8 = new double[] { };
    double[] var12 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var14 = new double[] { };
    double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var24);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var12, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var28 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var18);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.5263157894736842d, 0.23449722509094836d, (-28312.721511760275d), 223115.0311913556d, 8273.979899088612d, 7.596033661938047E7d, 1011120.0d, 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6.36942772394751E11d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextHypergeometric(55, 3, 59);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    java.lang.Comparable[] var42 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var43 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var43, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var46.getDirection();
    boolean var49 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var42, var47, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var36, var47, true, false);
    double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 2.0187637256530055E15d);
    java.lang.Number var55 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var58 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var55, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var59 = var58.getDirection();
    boolean var62 = org.apache.commons.math3.util.MathArrays.checkOrder(var54, var59, false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2987715053862827087L, (java.lang.Number)0.667275766788113d, false);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 16);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     boolean var3 = var1.nextBoolean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 8274495299620453503L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("eaa1515822", "8437b93008ff8108cae3874f34a0e2253638be9538e2");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     java.lang.String var7 = var2.nextHexString(55);
//     double var10 = var2.nextBeta(3965.0367954613544d, 4481.058440388458d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, 1);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextF(0.40877566087838346d, 273.14655120642885d);
//     long var14 = var0.nextPoisson(3965.0367954613544d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "396a86d029"+ "'", var4.equals("396a86d029"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "3416b33aa7d4ad292d7a07d684bdaddd87a965809781"+ "'", var9.equals("3416b33aa7d4ad292d7a07d684bdaddd87a965809781"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07797476827309713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4052L);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)22.10526315789474d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { 100.0f};
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var3, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 9);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     double var8 = var0.nextWeibull(7.343684965302029E9d, 276733.161992937d);
//     java.lang.String var10 = var0.nextHexString(1);
//     var0.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "88c8746481"+ "'", var4.equals("88c8746481"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 276733.161944128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "6"+ "'", var10.equals("6"));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(5, 37.124987752215674d);
//     double var14 = var2.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var2.nextUniform(4480.197711865118d, 5.290248133988897d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.01731035720893923d);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     int var4 = var1.nextInt(89);
//     double var5 = var1.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6725114712513113606L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.6697249068063902d);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    java.lang.Comparable[] var42 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var43 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var43, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var46.getDirection();
    boolean var49 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var42, var47, false);
    boolean var52 = org.apache.commons.math3.util.MathArrays.checkOrder(var36, var47, true, false);
    double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var36, 2.0187637256530055E15d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var54);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric((-1), 0, 59);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     double var7 = var0.nextExponential(1.1672233456208478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "61a7622cc9"+ "'", var4.equals("61a7622cc9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.574650977475056d);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.lang.String var2 = var0.nextHexString(100);
//     double var5 = var0.nextCauchy(0.9153238394393426d, 7263549.284553437d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 42);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("9aa5f0db84", "2a6e95102585876d207a9bae5455e5cb7577ba0da47f");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    double[] var7 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var7);
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var9, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    boolean var16 = org.apache.commons.math3.util.MathArrays.checkOrder(var7, var13, false, false);
    boolean var18 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var13, true);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var19.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var44, (-0.3183389366223311d));
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double[] var65 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var67 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var63, var65);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.5263157894736842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (-1.0d)};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, var3);
    org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "1183934ab3"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, false);
    double[] var15 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var17, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var20.getDirection();
    boolean var24 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var21, false, false);
    boolean var26 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var21, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.7309748381028882d), (java.lang.Number)3.600850744922761E11d, 5, var21, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var21, true);
    org.apache.commons.math3.exception.MathInternalError var31 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1146362687);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    java.lang.String var7 = var2.nextHexString(55);
    double var10 = var2.nextBeta(3965.0367954613544d, 4481.058440388458d);
    double var12 = var2.nextT(0.0024793994397472184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c5"+ "'", var7.equals("0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c5"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.466749620721066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.6942430090005716E85d);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     var6.reSeed((-1L));
//     java.lang.String var10 = var6.nextSecureHexString(10);
//     var6.reSeedSecure();
//     int var15 = var6.nextHypergeometric(100, 1, 1);
//     int[] var18 = var6.nextPermutation(10, 5);
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var18);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var18);
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 100);
//     int[] var24 = new int[] { 1};
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 0);
//     org.apache.commons.math3.random.Well19937c var28 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var30 = new int[] { 1};
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 0);
//     var28.setSeed(var32);
//     int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var32);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var32);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "73a7f93127"+ "'", var10.equals("73a7f93127"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     long var18 = var0.nextLong(1L, 10L);
//     long var21 = var0.nextSecureLong((-1693446730382879232L), (-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextPascal(1755678109, (-0.9387123485327005d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1fe8dd9f46"+ "'", var4.equals("1fe8dd9f46"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 49.73518257362382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1518511053664316160L));
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 30.578470663054077d);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    int var7 = var4.nextInt(89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 26);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed"+ "'", var1.equals("org.apache.commons.math3.exception.NotANumberException: NaN is not allowed"));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var21 = var2.nextLong((-98107090172506864L), (-3326135190239569920L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 502926.81918299187d);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0L);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0L+ "'", var3.equals(0L));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    long[] var1 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    long[][] var3 = new long[][] { var1};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var14 = new int[] { 1};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    int[] var20 = new int[] { 1};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var20);
    int var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    int[] var28 = new int[] { 1};
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 0);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var34 = new int[] { 1};
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 0);
    var32.setSeed(var36);
    int var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)273.14655120642885d, (java.lang.Number)(short)(-1), (java.lang.Number)(byte)1);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var21 = var2.nextPermutation(33, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 502926.81918299187d);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 1.0d};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2);
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     java.lang.Comparable[] var19 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
//     boolean var22 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var19, var20, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
//     boolean var25 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var19, var23, false);
//     org.apache.commons.math3.exception.MathArithmeticException var26 = new org.apache.commons.math3.exception.MathArithmeticException(var17, (java.lang.Object[])var19);
//     java.lang.Comparable[] var28 = new java.lang.Comparable[] { (-1.0f)};
//     java.lang.Number var29 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var32 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var29, (java.lang.Number)(byte)100, 100);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var33 = var32.getDirection();
//     boolean var35 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var33, false);
//     boolean var37 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var19, var33, false);
//     double[] var38 = new double[] { };
//     double[] var42 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var43 = org.apache.commons.math3.util.MathArrays.distance1(var38, var42);
//     double[] var44 = new double[] { };
//     double[] var48 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var49 = org.apache.commons.math3.util.MathArrays.distance1(var44, var48);
//     double[] var50 = new double[] { };
//     double[] var54 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var55 = org.apache.commons.math3.util.MathArrays.distance1(var50, var54);
//     boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var48, var54);
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var42, var48);
//     double[] var58 = new double[] { };
//     double[] var62 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var63 = org.apache.commons.math3.util.MathArrays.distance1(var58, var62);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var62);
//     double[][] var65 = new double[][] { var64};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var33, var65);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var2, var33, false);
//     boolean var70 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var33, false);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    double[] var39 = new double[] { };
    double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var37, var43);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double[] var47 = new double[] { };
    double[] var51 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var51);
    double[] var57 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var58 = new double[] { };
    double[] var62 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var58, var62);
    double[] var64 = new double[] { };
    double[] var68 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var64, var68);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var62, var68);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeAdd(var57, var68);
    double[] var73 = org.apache.commons.math3.util.MathArrays.normalizeArray(var57, (-0.3183389366223311d));
    double var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var31, var57);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var3 = new int[] { 1};
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
//     var1.setSeed(var5);
//     int[] var8 = new int[] { 1};
//     int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
//     int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
//     int[] var14 = new int[] { 1};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     org.apache.commons.math3.random.RandomDataImpl var19 = new org.apache.commons.math3.random.RandomDataImpl();
//     var19.reSeed((-1L));
//     java.lang.String var23 = var19.nextSecureHexString(10);
//     var19.reSeedSecure();
//     int var28 = var19.nextHypergeometric(100, 1, 1);
//     int[] var31 = var19.nextPermutation(10, 5);
//     int var32 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var31);
//     double var33 = org.apache.commons.math3.util.MathArrays.distance(var5, var31);
//     int[] var34 = null;
//     double var35 = org.apache.commons.math3.util.MathArrays.distance(var31, var34);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    int var8 = var2.nextZipf(5, 5606.347746720141d);
    int var11 = var2.nextBinomial(0, 0.41292608781564977d);
    double var14 = var2.nextGaussian(502822.6958193368d, 1011120.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1125185.2252459729d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10, (java.lang.Number)100.0d, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     double var18 = var0.nextGamma(37.124987752215674d, 9998.458978288749d);
//     double var21 = var0.nextUniform((-0.7309748381028882d), 0.9153238394393426d);
//     org.apache.commons.math3.distribution.IntegerDistribution var22 = null;
//     int var23 = var0.nextInversionDeviate(var22);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     long var17 = var0.nextPoisson(0.954816313157598d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f486dc5cc3"+ "'", var4.equals("f486dc5cc3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-152295.14271861385d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextSecureLong(8L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f9d40c5944"+ "'", var4.equals("f9d40c5944"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1137381724);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-4229268977162906112L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.0d);
    boolean var2 = var1.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Comparable[] var6 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var6, var7, false);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var3, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)6780.649531159886d, (java.lang.Number)1.0f, true);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 334518628, 0);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)9998.458978288749d, var1, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(1.0d, 1011120.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var1.nextInt(68, 9);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 261952.56581048336d);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var2.nextSecureLong(0L, (-3326135190239569920L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    double[] var7 = new double[] { };
    double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
    double[] var13 = new double[] { };
    double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    double[] var19 = new double[] { };
    double[] var23 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var19, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var17, var23);
    double var26 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    double[] var28 = new double[] { };
    double[] var32 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
    double[] var34 = new double[] { };
    double[] var38 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var34, var38);
    double[] var40 = new double[] { };
    double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var38, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var32);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 0);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    double[] var57 = new double[] { };
    double[] var61 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var57, var61);
    double[] var63 = new double[] { };
    double[] var67 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var68 = org.apache.commons.math3.util.MathArrays.distance1(var63, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var61, var67);
    double var70 = org.apache.commons.math3.util.MathArrays.distanceInf(var55, var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var71 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var50, var67);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    float[] var1 = new float[] { 1.0f};
    float[] var5 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var1, var5);
    float[] var7 = null;
    float[] var9 = new float[] { 1.0f};
    float[] var13 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var9, var13);
    float[] var16 = new float[] { 1.0f};
    float[] var20 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var16, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var9, var20);
    float[] var23 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var9, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var7, var9);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var5, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var55);
    java.lang.Comparable[] var64 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var65 = null;
    boolean var67 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var64, var65, false);
    double[] var69 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var69);
    java.lang.Number var71 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var71, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = var74.getDirection();
    boolean var78 = org.apache.commons.math3.util.MathArrays.checkOrder(var69, var75, false, false);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var64, var75, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.7309748381028882d), (java.lang.Number)3.600850744922761E11d, 5, var75, false);
    boolean var85 = org.apache.commons.math3.util.MathArrays.checkOrder(var19, var75, false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var5 = new double[] { };
//     double[] var9 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var10 = org.apache.commons.math3.util.MathArrays.distance1(var5, var9);
//     double[] var11 = new double[] { };
//     double[] var15 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var16 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
//     boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var15);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var15);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-1.0d));
//     double[] var21 = new double[] { };
//     double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
//     double[] var27 = new double[] { };
//     double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
//     double[] var33 = new double[] { };
//     double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
//     double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
//     double var41 = org.apache.commons.math3.util.MathArrays.distance1(var20, var37);
//     double var42 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var37);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     double var15 = var2.nextF(185.2718719624735d, 276733.161992937d);
//     double var18 = var2.nextGaussian(0.0d, 37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8718199161117666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 22.034666388288965d);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair(var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair(var24);
    org.apache.commons.math3.exception.MathArithmeticException var26 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var27 = var26.getContext();
    boolean var28 = var25.equals((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    var1.setSeed(0L);
    double var5 = var1.nextGaussian();
    int var6 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.043481143175376734d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1536916561);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     long var11 = var0.nextPoisson(0.9267259868138397d);
//     var0.reSeed(0L);
//     java.lang.String var15 = var0.nextHexString(33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5b59117726"+ "'", var4.equals("5b59117726"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "5d9849968398c45290eaf723582da568183a49f3b9ef"+ "'", var9.equals("5d9849968398c45290eaf723582da568183a49f3b9ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d"+ "'", var15.equals("7c95c53e6ebf6e7867c80117938712b6d"));
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, false);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var4 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9548162f);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    var5.setSeed(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var3);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    float var5 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.4774959f);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", "f486dc5cc3");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(1.0d, 1011120.0d, false);
//     double var7 = var1.nextChiSquare(10010.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 216531.41332395418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9872.424459741485d);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     double[] var1 = new double[] { 1.0d};
//     org.apache.commons.math3.util.MathArrays.checkOrder(var1);
//     double[] var6 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var7 = new double[] { };
//     double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var17);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var17, (-1.0d));
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var17);
//     double[] var24 = null;
//     double var25 = org.apache.commons.math3.util.MathArrays.linearCombination(var1, var24);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     var0.reSeedSecure(4052L);
//     java.lang.String var22 = var0.nextSecureHexString(83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextPoisson((-0.6252178382957178d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "48e18a2380"+ "'", var4.equals("48e18a2380"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1553975658);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-3446940464272131584L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "92e4acc8f81d0db76baf26fc7dab3c12b2d5a04cb8835a4283fcc82123fb606d227aea0257a401f3074"+ "'", var22.equals("92e4acc8f81d0db76baf26fc7dab3c12b2d5a04cb8835a4283fcc82123fb606d227aea0257a401f3074"));
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.017341366001328715d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    int var18 = var2.nextZipf(59, 6670.1469035478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var24 = var23.getSecond();
    java.lang.Object var25 = var23.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + 100L+ "'", var24.equals(100L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var25);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 0);
    double[] var44 = new double[] { };
    double[] var48 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var44, var48);
    double[] var50 = new double[] { };
    double[] var54 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var55 = org.apache.commons.math3.util.MathArrays.distance1(var50, var54);
    double[] var56 = new double[] { };
    double[] var60 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var61 = org.apache.commons.math3.util.MathArrays.distance1(var56, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var54, var60);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var48, var54);
    double[] var64 = new double[] { };
    double[] var68 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var69 = org.apache.commons.math3.util.MathArrays.distance1(var64, var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var48, var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var71 = org.apache.commons.math3.util.MathArrays.ebeAdd(var43, var48);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     var2.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var2.nextUniform(53743.07090776245d, 0.4774960009367326d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c6abfb927c"+ "'", var4.equals("c6abfb927c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "6cc06906b0ddfc7d779df1e84c8eb541feef4ea75f08"+ "'", var9.equals("6cc06906b0ddfc7d779df1e84c8eb541feef4ea75f08"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3789592247346349568L));
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var7 = new int[] { 1};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     var5.setSeed(var9);
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
//     int[] var13 = new int[] { 1};
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var17);
//     long var20 = var19.nextLong();
//     byte[] var21 = null;
//     var19.nextBytes(var21);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1438954750);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     var4.clear();
//     double var6 = var4.nextDouble();
//     double var7 = var4.nextGaussian();
//     double var8 = var4.nextDouble();
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     var9.reSeed();
//     double var14 = var9.nextUniform((-723068.631252455d), 0.0d, true);
//     double var17 = var9.nextF(4411.553384062907d, 0.4774960009367326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2787313252014696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-0.9387123485327005d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.41292608781564977d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-96866.37670153315d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 12.183861247133061d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var21 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var23 = org.apache.commons.math3.util.MathArrays.ebeDivide(var10, var21);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     double var12 = var2.nextUniform((-152295.14271861385d), 22.10526315789474d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var2.nextSecureLong(0L, (-98107090172506864L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6454.676950455714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-99743.9126323211d));
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, (-0.3183389366223311d));
//     double[] var20 = null;
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeAdd(var19, var20);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     long var2 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var3.reSeed(100L);
//     long var8 = var3.nextSecureLong((-4237628123369238917L), 7L);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var3.nextSample(var9, 90);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    var1.clear();
    boolean var5 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)89, (java.lang.Number)(short)0, true);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    var5.setSeed(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
    int[] var20 = new int[] { 1};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 0);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var26 = new int[] { 1};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 0);
    var24.setSeed(var28);
    int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var28);
    int[] var32 = new int[] { 1};
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 0);
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 0);
    int var37 = org.apache.commons.math3.util.MathArrays.distance1(var22, var36);
    org.apache.commons.math3.random.Well19937c var38 = new org.apache.commons.math3.random.Well19937c(var36);
    int var39 = org.apache.commons.math3.util.MathArrays.distance1(var3, var36);
    int[] var41 = new int[] { 1};
    int[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var41, 0);
    org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var47 = new int[] { 1};
    int[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 0);
    var45.setSeed(var49);
    int var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var49);
    double var52 = org.apache.commons.math3.util.MathArrays.distance(var3, var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    int var9 = var2.nextInt(0, 326172715);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 98304788);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var6 = new org.apache.commons.math3.exception.DimensionMismatchException(var3, 0, 100);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)795460800, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)(short)0, (java.lang.Number)10L);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(8273.979899088612d, 14.177446878757825d, (-28312.721511760275d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 117303.91049523883d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     int var8 = var2.nextZipf(5, 5606.347746720141d);
//     int var11 = var2.nextBinomial(0, 0.41292608781564977d);
//     double var13 = var2.nextExponential(14603.081554194827d);
//     long var16 = var2.nextSecureLong(0L, 59523L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9153238394393426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 53743.07090776245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 42140L);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var9, false);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var5);
    java.lang.Comparable[] var14 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var15 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var15, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var19 = var18.getDirection();
    boolean var21 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var19, false);
    boolean var23 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var19, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)185.2718719624735d, (java.lang.Number)(byte)10, 90, var19, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5141685311728891869L, (java.lang.Number)43, true);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 100);
    int var4 = var3.getDimension();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)19.375753716098963d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var16 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var17 = new double[] { };
    double[] var21 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var22 = org.apache.commons.math3.util.MathArrays.distance1(var17, var21);
    double[] var23 = new double[] { };
    double[] var27 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var21, var27);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var27);
    double var31 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 10.0d);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    double var2 = var1.nextDouble();
    double var3 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.40877566087838346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.954816313157598d);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var5 = var4.nextLong();
//     var4.setSeed(8L);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     java.lang.String var10 = var8.nextHexString(100);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var8.nextSample(var11, 53);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)10);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)10+ "'", var3.equals((short)10));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    double[] var1 = new double[] { 0.0d};
    double[] var2 = new double[] { };
    double[] var6 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var7 = org.apache.commons.math3.util.MathArrays.distance1(var2, var6);
    double[] var8 = new double[] { };
    double[] var12 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var14 = new double[] { };
    double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var12, var18);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var6, var12);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var12);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(8L);
    int var7 = var2.nextZipf(83, 4411.553384062907d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextChiSquare((-422264.7974214142d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     int var12 = var0.nextBinomial(0, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextBeta(6.570781945417467E25d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2e38b98a09"+ "'", var4.equals("2e38b98a09"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "9f4a1f22d2cbafdb1c738124989eaa822331dc31197f"+ "'", var9.equals("9f4a1f22d2cbafdb1c738124989eaa822331dc31197f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    double var7 = var2.nextExponential(10010.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("bdd8f3d2348aa4f98703769a130538572d5737da429e", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 185.2718719624735d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var1 = new double[] { };
    double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
    double[] var7 = new double[] { };
    double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var5, var11);
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Comparable[] var16 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = null;
    boolean var19 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var17, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var20, false);
    org.apache.commons.math3.exception.MathArithmeticException var23 = new org.apache.commons.math3.exception.MathArithmeticException(var14, (java.lang.Object[])var16);
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var26 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var29 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var26, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = var29.getDirection();
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var25, var30, false);
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var16, var30, false);
    double[] var35 = new double[] { };
    double[] var39 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var35, var39);
    double[] var41 = new double[] { };
    double[] var45 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
    double[] var47 = new double[] { };
    double[] var51 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var45, var51);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var39, var45);
    double[] var55 = new double[] { };
    double[] var59 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var60 = org.apache.commons.math3.util.MathArrays.distance1(var55, var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var59);
    double[][] var62 = new double[][] { var61};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var30, var62);
    org.apache.commons.math3.exception.NullArgumentException var64 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)31.26438416598488d, (java.lang.Number)(-0.10429427302091279d), false);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     int var4 = var1.nextInt(89);
//     int var6 = var1.nextInt(33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5752918913054996782L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 25);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)0, (java.lang.Number)(short)10, (java.lang.Number)1.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getArgument();
    java.lang.Number var6 = var3.getHi();
    java.lang.Number var7 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0f+ "'", var6.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)0+ "'", var7.equals((short)0));

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)9998.458978288749d, (java.lang.Number)(-815912261906828288L), false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(25);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(100, 1.0d);
//     int var8 = var2.nextInt(0, 10);
//     double var11 = var2.nextGamma(185.2718719624735d, 37.124987752215674d);
//     double var14 = var2.nextGaussian(4481.058440388458d, 9998.458978288749d);
//     long var17 = var2.nextSecureLong(4247151651261818872L, 5141685311728891869L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5606.347746720141d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8273.979899088612d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4690075531747316736L);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(117303.91049523883d, 0.41292608781564977d, 2.0187637256530055E15d, 0.40877566087838346d, 0.4020775187866738d, 30.578470663054077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.252214761595651E14d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var7, false);
    double[] var11 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var11);
    double[] var13 = new double[] { };
    double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    double[] var19 = new double[] { };
    double[] var23 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var19, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var17, var23);
    org.apache.commons.math3.exception.util.Localizable var26 = null;
    java.lang.Comparable[] var28 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var29 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var29, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var32 = null;
    boolean var34 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var32, false);
    org.apache.commons.math3.exception.MathArithmeticException var35 = new org.apache.commons.math3.exception.MathArithmeticException(var26, (java.lang.Object[])var28);
    java.lang.Comparable[] var37 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var38 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var38, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = var41.getDirection();
    boolean var44 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var37, var42, false);
    boolean var46 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var28, var42, false);
    double[] var47 = new double[] { };
    double[] var51 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var52 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
    double[] var53 = new double[] { };
    double[] var57 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var58 = org.apache.commons.math3.util.MathArrays.distance1(var53, var57);
    double[] var59 = new double[] { };
    double[] var63 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var59, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var57, var63);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var51, var57);
    double[] var67 = new double[] { };
    double[] var71 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var67, var71);
    double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var71);
    double[][] var74 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var42, var74);
    org.apache.commons.math3.util.MathArrays.checkOrder(var11, var42, false);
    boolean var79 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var42, true);
    org.apache.commons.math3.exception.NotFiniteNumberException var80 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(byte)10, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var7);
    int[] var16 = new int[] { 10, 1, 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 9);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var7, true);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9ac5893860"+ "'", var4.equals("9ac5893860"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1046972955);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2427542156791145472L));
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 100);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var1);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    int var7 = var2.nextZipf(100, 2135.1904046211293d);
    double var10 = var2.nextWeibull(2349.693493309191d, 14.279906171571504d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextInt(42, 5);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 14.266529369004015d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     var2.reSeed();
//     var2.reSeed();
//     double var11 = var2.nextGaussian(0.0d, 0.27868821153744294d);
//     double var13 = var2.nextChiSquare(3.6008534624247894E11d);
//     double var16 = var2.nextGaussian(1685.0291123281943d, 0.017341366001328715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14603.081554194827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.05871564367493758d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.600866825489309E11d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1685.0347442526615d);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)10L, (java.lang.Number)(byte)(-1), (java.lang.Number)0);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)(-1)+ "'", var4.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0+ "'", var5.equals(0));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     long var5 = var1.nextPoisson(324109.9885521297d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 276418L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 323958L);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     long var18 = var0.nextLong(1L, 10L);
//     double var21 = var0.nextWeibull(49.437501015567314d, 14603.081554194827d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var0.nextZipf(89, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "43202c53a2"+ "'", var4.equals("43202c53a2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 49.73518257362382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 14418.670979848415d);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    java.lang.Comparable[] var4 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var8, false);
    double[] var12 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var14 = new double[] { };
    double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var24);
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    java.lang.Comparable[] var29 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var30, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    boolean var35 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var33, false);
    org.apache.commons.math3.exception.MathArithmeticException var36 = new org.apache.commons.math3.exception.MathArithmeticException(var27, (java.lang.Object[])var29);
    java.lang.Comparable[] var38 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var39 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var39, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var42.getDirection();
    boolean var45 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var38, var43, false);
    boolean var47 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var43, false);
    double[] var48 = new double[] { };
    double[] var52 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    double[] var54 = new double[] { };
    double[] var58 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var54, var58);
    double[] var60 = new double[] { };
    double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var58, var64);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var52, var58);
    double[] var68 = new double[] { };
    double[] var72 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var68, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var72);
    double[][] var75 = new double[][] { var74};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var43, var75);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12, var43, false);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var43, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)323958L, (java.lang.Number)53743.07090776245d, 0, var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var6 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var7 = new org.apache.commons.math3.exception.DimensionMismatchException(var4, 0, 100);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, var1, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    float var3 = var1.nextFloat();
    double var4 = var1.nextGaussian();
    long var5 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9548162f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.4482830501914015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5559641039979712746L);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    double[] var0 = null;
    double[] var1 = new double[] { };
    double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
    double[] var7 = new double[] { };
    double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
    double[] var13 = new double[] { };
    double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var5, var11);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 74);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var27);
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance(var27, var35);
    double[] var41 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var42 = new double[] { };
    double[] var46 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var47 = org.apache.commons.math3.util.MathArrays.distance1(var42, var46);
    double[] var48 = new double[] { };
    double[] var52 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var46, var52);
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeAdd(var41, var52);
    double[] var57 = org.apache.commons.math3.util.MathArrays.normalizeArray(var52, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var58 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var35, var52);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 14.177446878757825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(1.0d, 1011120.0d, false);
//     double var7 = var1.nextChiSquare(1.1672233456208478d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var1.nextPermutation(0, 1046972955);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 637149.3741472539d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.026188413387635945d);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.setSeed(6);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var5 = var1.nextUniform(31.26438416598488d, 4411.553384062907d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 272.0751302700693d);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextUniform((-1.5878013591459518E15d), (-0.11351498500106294d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var3.nextBinomial(10, 2135.1904046211293d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-7.174271937959112E13d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    double var7 = var2.nextExponential(10010.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextWeibull(1.1672233456208478d, (-1.5878013591459518E15d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 185.2718719624735d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.4774960009367326d, 0.017178374061959746d, 0.27868821153744294d, 0.4020775187866738d, 0.0d, 2349.693493309191d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.12025686952725181d);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)1.0f, (java.lang.Number)100.0d);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0f+ "'", var6.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0f+ "'", var7.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1.0d+ "'", var8.equals(1.0d));

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(100, 1.0d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var2.nextSample(var6, 89);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var7 = new int[] { 1};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     var5.setSeed(var9);
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
//     int[] var13 = new int[] { 1};
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//     int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var17);
//     java.util.List var20 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var21 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var19, var20);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     java.lang.String var7 = var2.nextHexString(55);
//     double var10 = var2.nextBeta(3965.0367954613544d, 4481.058440388458d);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, 0);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(44, 30);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
//     double[] var6 = new double[] { };
//     double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
//     double[] var12 = new double[] { };
//     double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
//     double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var21 = new double[] { };
//     double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
//     double[] var27 = new double[] { };
//     double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
//     double[] var33 = new double[] { };
//     double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
//     boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
//     boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
//     double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
//     boolean var45 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var42, false, true);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    int var7 = var2.nextZipf(100, 2135.1904046211293d);
    double var10 = var2.nextWeibull(2349.693493309191d, 14.279906171571504d);
    int var13 = var2.nextInt((-1), 5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var2.nextPoisson((-0.05871564367493758d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 14.266529369004015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     double var6 = var0.nextF(0.5263157894736842d, 0.2787313252014696d);
//     var0.reSeedSecure((-8587680114487392385L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextLong(5141685311728891869L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "95fedf7375"+ "'", var2.equals("95fedf7375"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.28513127930203946d);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextLong(0L, (-2885667895715912192L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5200533d4c"+ "'", var4.equals("5200533d4c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-152295.14271861385d));
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0, (java.lang.Number)21.0d, (java.lang.Number)0.27873123f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 21.0d+ "'", var4.equals(21.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.27873123f+ "'", var5.equals(0.27873123f));

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     double var6 = var0.nextF(0.5263157894736842d, 0.2787313252014696d);
//     var0.reSeedSecure((-8587680114487392385L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(98304788, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "b1473c81e3"+ "'", var2.equals("b1473c81e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 29195.570367208442d);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     double var17 = var0.nextWeibull(185.2718719624735d, 0.01731035720893923d);
//     java.lang.String var19 = var0.nextSecureHexString(43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextPascal(0, 0.19778446032203834d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b2fcbcaa1d"+ "'", var4.equals("b2fcbcaa1d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "18a8fd11ca7435cacf577a47db6630bea7ffca679439"+ "'", var9.equals("18a8fd11ca7435cacf577a47db6630bea7ffca679439"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-362947522370382592L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.017394570468361733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "8379b89425c49c8121d3a8f35efa8103be3112e59ad"+ "'", var19.equals("8379b89425c49c8121d3a8f35efa8103be3112e59ad"));
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.017341366001328715d, (java.lang.Number)0.12025686952725181d, true);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    double var11 = var2.nextGamma(185.2718719624735d, 37.124987752215674d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextWeibull(0.0d, 324109.9885521297d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5606.347746720141d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextSecureInt(74, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextSecureLong(0L, 100L);
//     double var15 = var0.nextExponential(9872.424459741485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7c36b3b6da"+ "'", var4.equals("7c36b3b6da"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "f9315841db69c96d5597680d50c88eb51a953fe95b03"+ "'", var9.equals("f9315841db69c96d5597680d50c88eb51a953fe95b03"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 76L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1808.576187995902d);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    boolean var24 = var22.equals((java.lang.Object)(-3326135190239569920L));
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var26 = var22.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var2.nextSecureLong(7540580061456263210L, (-150956856425768896L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    double var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var25);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 0);
    double[] var45 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, (-1.5878013591459518E15d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var13 = var0.nextUniform(0.9153238394393426d, 14.177446878757825d, true);
//     org.apache.commons.math3.distribution.RealDistribution var14 = null;
//     double var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGamma(0.27868821153744294d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e0e70f93fb"+ "'", var4.equals("e0e70f93fb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1332609094);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 83);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1693446730382879232L));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1146362687, 5);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     int var15 = var0.nextPascal(5, 0.40877566087838346d);
//     int var18 = var0.nextZipf(85, 4481.058440388458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "65e6fa2ef1"+ "'", var4.equals("65e6fa2ef1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 393820222);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     var0.reSeedSecure(4052L);
//     java.lang.String var22 = var0.nextSecureHexString(6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "34a14462bc"+ "'", var4.equals("34a14462bc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1735228169);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-4072472875657933824L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "36bdfb"+ "'", var22.equals("36bdfb"));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    var2.reSeedSecure((-3326135190239569920L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1438954750, (java.lang.Number)22.10526315789474d, (java.lang.Number)7567839.662419096d);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     long var2 = var1.nextLong();
//     double var3 = var1.nextGaussian();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4185087196069645046L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-1.334741001015885d));
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    var2.reSeedSecure((-1L));
    var2.reSeedSecure(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    float[] var1 = new float[] { 1.0f};
    float[] var5 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var1, var5);
    float[] var8 = new float[] { 1.0f};
    float[] var12 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var8, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var1, var12);
    float[] var16 = new float[] { 1.0f};
    float[] var20 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var16, var20);
    float[] var23 = new float[] { 1.0f};
    float[] var27 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var16, var27);
    float[] var30 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var16, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var16);
    float[] var33 = null;
    float[] var35 = new float[] { 1.0f};
    float[] var39 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var35, var39);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var33, var39);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var12, var33);
    float[] var44 = new float[] { 1.0f};
    float[] var48 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var44, var48);
    float[] var51 = new float[] { 1.0f};
    float[] var55 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var44, var55);
    float[] var58 = null;
    float[] var60 = new float[] { 1.0f};
    float[] var64 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var60, var64);
    float[] var67 = new float[] { 1.0f};
    float[] var71 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var67, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var60, var71);
    float[] var74 = null;
    boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var60, var74);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var58, var60);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var60);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var33, var60);
    float[] var79 = null;
    float[] var81 = new float[] { 1.0f};
    float[] var85 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var81, var85);
    float[] var88 = new float[] { 1.0f};
    float[] var92 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var88, var92);
    boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var81, var92);
    float[] var95 = null;
    boolean var96 = org.apache.commons.math3.util.MathArrays.equals(var81, var95);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var79, var81);
    boolean var98 = org.apache.commons.math3.util.MathArrays.equals(var33, var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == true);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     int var7 = var0.nextBinomial(35, 0.07797476827309713d);
//     java.lang.String var9 = var0.nextHexString(9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3c959edcef"+ "'", var4.equals("3c959edcef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "685639e4a"+ "'", var9.equals("685639e4a"));
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var1.nextBinomial(100, (-0.05871564367493758d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 276152L);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var0.nextInversionDeviate(var5);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextF(0.40877566087838346d, 273.14655120642885d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextGaussian(100100.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "de08224d4a"+ "'", var4.equals("de08224d4a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "c3daeaca3a17c91cad528d55c9b237932cd7ac59a037"+ "'", var9.equals("c3daeaca3a17c91cad528d55c9b237932cd7ac59a037"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07797476827309713d);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(byte)100, 100);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)100+ "'", var5.equals((byte)100));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)(short)0, (java.lang.Number)10L);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     var2.reSeed();
//     double var15 = var2.nextUniform(276733.161992937d, 8.252214761595651E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7891.527654497291d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "6c96a756e0e6069a30db934c7483f76b0895b1e1ac387d0c9090f7cfbec460340809ab1e5c258dde1ad0b25eb1b7857c2c9c"+ "'", var11.equals("6c96a756e0e6069a30db934c7483f76b0895b1e1ac387d0c9090f7cfbec460340809ab1e5c258dde1ad0b25eb1b7857c2c9c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 6.505592635661839E14d);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var5 = new org.apache.commons.math3.exception.DimensionMismatchException(var2, 0, 100);
//     java.lang.Throwable[] var6 = var5.getSuppressed();
//     org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     java.lang.Object[] var10 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var9, var10);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(5, 37.124987752215674d);
//     java.lang.String var14 = var2.nextSecureHexString(100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "812085ab64366dd3381092e69aedc664caf408bb2c29f3b2b6a877195f53b3fe814d5ab5d9645fb44596976c7a04d66b62c3"+ "'", var14.equals("812085ab64366dd3381092e69aedc664caf408bb2c29f3b2b6a877195f53b3fe814d5ab5d9645fb44596976c7a04d66b62c3"));
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     double var11 = var0.nextUniform(4411.553384062907d, 2.0187637256530055E15d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextSecureLong(4690075531747316736L, 8L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6dd841d4df"+ "'", var4.equals("6dd841d4df"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.416104948113002E14d);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair(var23);
    org.apache.commons.math3.util.Pair var25 = new org.apache.commons.math3.util.Pair(var24);
    java.lang.Object var26 = var24.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(5, 37.124987752215674d);
//     double var15 = var2.nextF(7.596033661938047E7d, 1125185.2252459729d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9983164408899687d);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)(byte)10, 1, var3, true);
    java.lang.Number var6 = var5.getPrevious();
    boolean var7 = var5.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)10+ "'", var6.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

}
