
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var5 = new double[] { };
    double[] var9 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var5, var9);
    double[] var11 = new double[] { };
    double[] var15 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var15);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var15);
    double[] var22 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var23 = new double[] { };
    double[] var27 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var28 = org.apache.commons.math3.util.MathArrays.distance1(var23, var27);
    double[] var29 = new double[] { };
    double[] var33 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var29, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var27, var33);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeAdd(var22, var33);
    double[] var38 = org.apache.commons.math3.util.MathArrays.normalizeArray(var33, (-1.0d));
    double[] var39 = new double[] { };
    double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var55);
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var38, var55);
    java.lang.Comparable[] var61 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var62 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var65 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var62, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var66 = var65.getDirection();
    boolean var68 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var61, var66, false);
    boolean var71 = org.apache.commons.math3.util.MathArrays.checkOrder(var55, var66, true, false);
    double[] var73 = org.apache.commons.math3.util.MathArrays.normalizeArray(var55, 2.0187637256530055E15d);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeAdd(var4, var73);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var73);
    double[] var79 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var80 = new double[] { };
    double[] var84 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var85 = org.apache.commons.math3.util.MathArrays.distance1(var80, var84);
    double[] var86 = new double[] { };
    double[] var90 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var91 = org.apache.commons.math3.util.MathArrays.distance1(var86, var90);
    boolean var92 = org.apache.commons.math3.util.MathArrays.equals(var84, var90);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeAdd(var79, var90);
    double[] var95 = org.apache.commons.math3.util.MathArrays.copyOf(var93, 6);
    double var96 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.0d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     long var11 = var0.nextPoisson(0.9267259868138397d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextInt(1536916561, 795460800);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "baf474a31d"+ "'", var4.equals("baf474a31d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "b670668677ad9291cbf80d6bb8343c7e7b7510ce0c07"+ "'", var9.equals("b670668677ad9291cbf80d6bb8343c7e7b7510ce0c07"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    int var12 = var2.nextBinomial(10, 0.6990788547755153d);
    double var16 = var2.nextUniform(19.375753716098963d, 6655.664073045887d, true);
    long var19 = var2.nextLong(42140L, 1076958526617624704L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 3188.176887259223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 28757354433757140L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    var5.setSeed(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var17);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(0);
    byte[] var24 = new byte[] { (byte)0, (byte)0};
    var21.nextBytes(var24);
    var19.nextBytes(var24);
    var19.setSeed(52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var7 = new int[] { 1};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    var5.setSeed(var9);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    int var18 = org.apache.commons.math3.util.MathArrays.distance1(var3, var17);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var17);
    int var20 = var19.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 752916846);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)3.600866825489309E11d, (java.lang.Number)49.73518257362382d, 326172715);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.600866825489309E11d+ "'", var4.equals(3.600866825489309E11d));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)8274495299620453503L, (java.lang.Number)55, false);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var7 = new int[] { 1};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//     var5.setSeed(var9);
//     int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var9);
//     int[] var15 = new int[] { 10, 1, 0};
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int[] var18 = new int[] { 1};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 0);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var24 = new int[] { 1};
//     int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 0);
//     var22.setSeed(var26);
//     int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var20, var26);
//     var16.setSeed(var26);
//     int[] var31 = new int[] { 1};
//     int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 0);
//     org.apache.commons.math3.random.RandomDataImpl var34 = new org.apache.commons.math3.random.RandomDataImpl();
//     var34.reSeed((-1L));
//     java.lang.String var38 = var34.nextSecureHexString(10);
//     var34.reSeedSecure();
//     int var43 = var34.nextHypergeometric(100, 1, 1);
//     int[] var46 = var34.nextPermutation(10, 5);
//     int var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var46);
//     double var48 = org.apache.commons.math3.util.MathArrays.distance(var26, var33);
//     int[] var50 = new int[] { 1};
//     int[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 0);
//     org.apache.commons.math3.random.Well19937c var54 = new org.apache.commons.math3.random.Well19937c(10L);
//     int[] var56 = new int[] { 1};
//     int[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 0);
//     var54.setSeed(var58);
//     int var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var52, var58);
//     org.apache.commons.math3.random.Well19937c var61 = new org.apache.commons.math3.random.Well19937c(var52);
//     double var62 = org.apache.commons.math3.util.MathArrays.distance(var26, var52);
//     int var63 = org.apache.commons.math3.util.MathArrays.distance1(var3, var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "4e03ce68ce"+ "'", var38.equals("4e03ce68ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    long var5 = var4.nextLong();
    var4.setSeed(8L);
    int[] var9 = new int[] { 1};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var9);
    var4.setSeed(var9);
    var4.setSeed(16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    long var11 = var2.nextLong((-150956856425768896L), 276682L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextInt(119583573, 83);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-78875561168351632L));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.017302287618914003d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    boolean var7 = var1.nextBoolean();
    int[] var9 = new int[] { 1};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var15 = new int[] { 1};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 0);
    var13.setSeed(var17);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var17);
    var1.setSeed(var17);
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    double var17 = var2.nextExponential(0.0024793994397472184d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.629038612649283E-4d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { (-1.0d)};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var5.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "1183934ab3"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    java.lang.Comparable[] var10 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var11, false);
    double[] var15 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    java.lang.Number var17 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var17, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var20.getDirection();
    boolean var24 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var21, false, false);
    boolean var26 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var10, var21, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.7309748381028882d), (java.lang.Number)3.600850744922761E11d, 5, var21, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var21, true);
    org.apache.commons.math3.exception.NullArgumentException var31 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl();
//     var6.reSeed((-1L));
//     java.lang.String var10 = var6.nextSecureHexString(10);
//     var6.reSeedSecure();
//     int var15 = var6.nextHypergeometric(100, 1, 1);
//     int[] var18 = var6.nextPermutation(10, 5);
//     int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var18);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var18);
//     double[] var21 = null;
//     double[] var22 = new double[] { };
//     double[] var26 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var27 = org.apache.commons.math3.util.MathArrays.distance1(var22, var26);
//     double[] var28 = new double[] { };
//     double[] var32 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var33 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
//     boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var26, var32);
//     double[] var38 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var39 = new double[] { };
//     double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
//     double[] var45 = new double[] { };
//     double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
//     boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var43, var49);
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeAdd(var38, var49);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.normalizeArray(var49, (-1.0d));
//     double var55 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var49);
//     double[] var59 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var60 = new double[] { };
//     double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
//     double[] var66 = new double[] { };
//     double[] var70 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var71 = org.apache.commons.math3.util.MathArrays.distance1(var66, var70);
//     boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var64, var70);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeAdd(var59, var70);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.normalizeArray(var70, (-1.0d));
//     double[] var76 = new double[] { };
//     double[] var80 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var81 = org.apache.commons.math3.util.MathArrays.distance1(var76, var80);
//     double[] var82 = new double[] { };
//     double[] var86 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var87 = org.apache.commons.math3.util.MathArrays.distance1(var82, var86);
//     double[] var88 = new double[] { };
//     double[] var92 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var93 = org.apache.commons.math3.util.MathArrays.distance1(var88, var92);
//     boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var86, var92);
//     double var95 = org.apache.commons.math3.util.MathArrays.distanceInf(var80, var92);
//     double var96 = org.apache.commons.math3.util.MathArrays.distance1(var75, var92);
//     boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var49, var92);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var98 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var20, var21, var92);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    byte[] var4 = new byte[] { (byte)0, (byte)0};
    var1.nextBytes(var4);
    var1.setSeed(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextF(0.40877566087838346d, 273.14655120642885d);
//     long var14 = var0.nextPoisson(3965.0367954613544d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var17 = var0.nextSecureLong((-4072472875657933824L), (-4237628123369238917L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0642c6b80b"+ "'", var4.equals("0642c6b80b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "6cb6cc97ce58999e7dc3579770755a077b007a3a6e20"+ "'", var9.equals("6cb6cc97ce58999e7dc3579770755a077b007a3a6e20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07797476827309713d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4052L);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    float[] var0 = null;
    float[] var2 = new float[] { 1.0f};
    float[] var6 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var2, var6);
    float[] var9 = new float[] { 1.0f};
    float[] var13 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var9, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var2, var13);
    float[] var17 = new float[] { 1.0f};
    float[] var21 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var17, var21);
    float[] var24 = new float[] { 1.0f};
    float[] var28 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var24, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var17, var28);
    float[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var17, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var17);
    float[] var34 = null;
    float[] var36 = new float[] { 1.0f};
    float[] var40 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var36, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var40);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var13, var34);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    long[] var3 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    long[][] var5 = new long[][] { var3};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var5);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var5);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var5);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     int var7 = var2.nextZipf(100, 2135.1904046211293d);
//     double var10 = var2.nextWeibull(2349.693493309191d, 14.279906171571504d);
//     var2.reSeed();
//     java.lang.String var13 = var2.nextHexString(30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14.266529369004015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "dff9f0bae3ddc60332d44d17561429"+ "'", var13.equals("dff9f0bae3ddc60332d44d17561429"));
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)(byte)(-1));
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathArithmeticException var8 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-2100806147823023616L), var1);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    double var10 = var2.nextUniform(10.0d, 100.0d, false);
    double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
    var2.reSeedSecure();
    double var17 = var2.nextExponential(2.4179176094551405E20d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 37.124987752215674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3965.0367954613544d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 6.46465790801216E19d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1685.0291123281943d, (java.lang.Number)(byte)10, 35);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1685.0291123281943d+ "'", var4.equals(1685.0291123281943d));

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextWeibull(4481.058440388458d, 0.2787313252014696d);
//     var0.reSeed((-199254194018620640L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextGaussian(4.574650977475056d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6e2a0c20c9"+ "'", var4.equals("6e2a0c20c9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.27868821153744294d);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(16, 16);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    double var6 = var4.nextDouble();
    double var7 = var4.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var8.nextPoisson((-0.05871564367493758d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.9387123485327005d));

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     double var18 = var0.nextGamma(37.124987752215674d, 9998.458978288749d);
//     org.apache.commons.math3.distribution.RealDistribution var19 = null;
//     double var20 = var0.nextInversionDeviate(var19);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
//     var2.reSeedSecure();
//     double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
//     long var21 = var2.nextSecureLong(0L, 6535425231125204517L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14603.081554194827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3965.0367954613544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 502926.81918299187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 4665674839569508352L);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     double var12 = var0.nextGamma(3.6942430090005716E85d, 6.505592635661839E14d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "65e7d5e54b"+ "'", var4.equals("65e7d5e54b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "f7d410ec2eda2a7fa4efbdf2dd20bc15531bf7ea52cc"+ "'", var9.equals("f7d410ec2eda2a7fa4efbdf2dd20bc15531bf7ea52cc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2.403324011369935E100d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure(7540580061456263210L);
    var2.reSeedSecure(10L);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextUniform((-1.5878013591459518E15d), (-0.11351498500106294d));
    long var8 = var3.nextPoisson(6.133447800101376d);
    long var10 = var3.nextPoisson(324109.9885521297d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-7.174271937959112E13d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 324764L);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
//     var2.reSeed();
//     long var18 = var2.nextSecureLong((-468211539698969088L), 6535425231125204517L);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var2.nextSample(var19, 0);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextExponential(0.5263157894736842d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextF((-0.3183389366223311d), 0.667275766788113d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6990788547755153d);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     java.lang.String var7 = var0.nextSecureHexString(9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "71fed6bec4"+ "'", var4.equals("71fed6bec4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "da84ba850"+ "'", var7.equals("da84ba850"));
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    java.lang.Comparable[] var14 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var15, false);
    double[] var19 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    java.lang.Number var21 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var21, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = var24.getDirection();
    boolean var28 = org.apache.commons.math3.util.MathArrays.checkOrder(var19, var25, false, false);
    boolean var30 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var14, var25, true);
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double[] var37 = new double[] { };
    double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    org.apache.commons.math3.exception.util.Localizable var44 = null;
    java.lang.Comparable[] var46 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = null;
    boolean var49 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var46, var47, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var50 = null;
    boolean var52 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var46, var50, false);
    org.apache.commons.math3.exception.MathArithmeticException var53 = new org.apache.commons.math3.exception.MathArithmeticException(var44, (java.lang.Object[])var46);
    java.lang.Comparable[] var55 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var56 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var59 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var56, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var60 = var59.getDirection();
    boolean var62 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var55, var60, false);
    boolean var64 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var46, var60, false);
    double[] var65 = new double[] { };
    double[] var69 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var70 = org.apache.commons.math3.util.MathArrays.distance1(var65, var69);
    double[] var71 = new double[] { };
    double[] var75 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var76 = org.apache.commons.math3.util.MathArrays.distance1(var71, var75);
    double[] var77 = new double[] { };
    double[] var81 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var82 = org.apache.commons.math3.util.MathArrays.distance1(var77, var81);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var75, var81);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var69, var75);
    double[] var85 = new double[] { };
    double[] var89 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var90 = org.apache.commons.math3.util.MathArrays.distance1(var85, var89);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var69, var89);
    double[][] var92 = new double[][] { var91};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var60, var92);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var25, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4554967237661810166L, (java.lang.Number)11.0d, (java.lang.Number)(short)(-1));

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     int var8 = var2.nextZipf(5, 5606.347746720141d);
//     int var11 = var2.nextBinomial(0, 0.41292608781564977d);
//     int var14 = var2.nextSecureInt(83, 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9153238394393426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 90);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
    double[] var30 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double[] var37 = new double[] { };
    double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var41);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, (-0.3183389366223311d));
    double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var30);
    double[] var51 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var52 = new double[] { };
    double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    double[] var58 = new double[] { };
    double[] var62 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var63 = org.apache.commons.math3.util.MathArrays.distance1(var58, var62);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var56, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeAdd(var51, var62);
    double[] var67 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, (-0.3183389366223311d));
    double[] var68 = new double[] { };
    double[] var72 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var68, var72);
    double[] var74 = new double[] { };
    double[] var78 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var74, var78);
    double[] var80 = new double[] { };
    double[] var84 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var85 = org.apache.commons.math3.util.MathArrays.distance1(var80, var84);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var78, var84);
    double var87 = org.apache.commons.math3.util.MathArrays.distanceInf(var72, var84);
    double[] var88 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var72);
    double[] var90 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 3.6942430090005716E85d);
    double[] var91 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextSecureInt(33, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bc392913c2"+ "'", var4.equals("bc392913c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1340752960);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-4380808758316945408L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     double var21 = var0.nextCauchy(8879.287806416309d, 3965.0367954613544d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a05670ab36"+ "'", var4.equals("a05670ab36"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 908338718);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-4456246965382990336L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 8459.555629912116d);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     var0.reSeed((-1693446730382879232L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a8247c9091"+ "'", var4.equals("a8247c9091"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "a0210411058cd9908703c766184bbaeef68b25146daf"+ "'", var9.equals("a0210411058cd9908703c766184bbaeef68b25146daf"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-3673591022036090880L));
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 100);
    double[] var8 = new double[] { };
    double[] var12 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var14 = new double[] { };
    double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var24);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var12, var18);
    double[] var28 = new double[] { };
    double[] var32 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var33 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
    double[] var34 = new double[] { };
    double[] var38 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var34, var38);
    double[] var40 = new double[] { };
    double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var38, var44);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var32, var38);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var18, var38);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 100.0f};
    org.apache.commons.math3.exception.MathArithmeticException var4 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var3);
    org.apache.commons.math3.exception.MathArithmeticException var5 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     var4.clear();
//     double var6 = var4.nextDouble();
//     double var7 = var4.nextGaussian();
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var8.nextSample(var9, 0);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     byte[] var8 = new byte[] { (byte)100, (byte)0, (byte)10};
//     var4.nextBytes(var8);
//     int[] var10 = null;
//     var4.setSeed(var10);
//     long var12 = var4.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1671677545155387191L);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var8);
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var14 = new int[] { 1};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    long[] var1 = new long[] { 10L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(byte)(-1));
    java.lang.Throwable[] var3 = var2.getSuppressed();
    boolean var4 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(49, 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "73a4614c99"+ "'", var4.equals("73a4614c99"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "ac0bb41dad11928c460f008100bdc963cb553dc0cc9b"+ "'", var9.equals("ac0bb41dad11928c460f008100bdc963cb553dc0cc9b"));
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var24 = var22.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextZipf((-1), 223115.0311913556d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    int var7 = var2.nextZipf(100, 2135.1904046211293d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextGamma(1.908642352606886d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1, (java.lang.Number)100.0d, true);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextUniform(22.10526315789474d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     double var18 = var0.nextGaussian(49.73518257362382d, 276733.161992937d);
//     double var21 = var0.nextCauchy(8879.287806416309d, 3965.0367954613544d);
//     double var24 = var0.nextF(0.2787313252014696d, 22.10526315789474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6c7a077002"+ "'", var4.equals("6c7a077002"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 972185778);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2055295967030466560L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-422264.7974214142d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 8459.555629912116d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 9.517178777190678E-5d);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     var2.reSeedSecure(4052L);
//     var2.reSeedSecure();
//     int var9 = var2.nextSecureInt(43, 334518628);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 132475888);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)4480.197711865118d);
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(33);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-4237628123369238917L), (java.lang.Number)2987715053862827087L, (java.lang.Number)(-1L));

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(272.0751302700693d, 1.1672233456208478d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "cc9f5ad676"+ "'", var4.equals("cc9f5ad676"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "0c46d6456789520c557465809714074224677a0d25b6"+ "'", var9.equals("0c46d6456789520c557465809714074224677a0d25b6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-381307186664029184L));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    int var8 = var2.nextZipf(5, 5606.347746720141d);
    int var11 = var2.nextBinomial(0, 0.41292608781564977d);
    double var13 = var2.nextExponential(14603.081554194827d);
    var2.reSeed((-199254194018620640L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 53743.07090776245d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    byte[] var4 = new byte[] { (byte)0, (byte)0};
    var1.nextBytes(var4);
    int var7 = var1.nextInt(3);
    var1.clear();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
//     double[] var20 = new double[] { };
//     double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
//     double[] var26 = new double[] { };
//     double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var24, var30);
//     double[] var36 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var37 = new double[] { };
//     double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
//     double[] var43 = new double[] { };
//     double[] var47 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var48 = org.apache.commons.math3.util.MathArrays.distance1(var43, var47);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var41, var47);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.ebeAdd(var36, var47);
//     double[] var52 = org.apache.commons.math3.util.MathArrays.normalizeArray(var47, (-1.0d));
//     double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var47);
//     boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var19, var47);
//     double[] var55 = new double[] { };
//     double[] var59 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var60 = org.apache.commons.math3.util.MathArrays.distance1(var55, var59);
//     double[] var61 = new double[] { };
//     double[] var65 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var66 = org.apache.commons.math3.util.MathArrays.distance1(var61, var65);
//     double[] var67 = new double[] { };
//     double[] var71 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var72 = org.apache.commons.math3.util.MathArrays.distance1(var67, var71);
//     boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var65, var71);
//     double var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var59, var71);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.copyOf(var71);
//     double var76 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var71);
//     double[] var77 = null;
//     double var78 = org.apache.commons.math3.util.MathArrays.linearCombination(var71, var77);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
//     double[] var6 = new double[] { };
//     double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
//     double[] var12 = new double[] { };
//     double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
//     double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
//     double[] var23 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var24 = new double[] { };
//     double[] var28 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
//     double[] var30 = new double[] { };
//     double[] var34 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var35 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var34);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var23, var34);
//     double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var34, (-1.0d));
//     double[] var40 = new double[] { };
//     double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
//     double[] var46 = new double[] { };
//     double[] var50 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var51 = org.apache.commons.math3.util.MathArrays.distance1(var46, var50);
//     double[] var52 = new double[] { };
//     double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var50, var56);
//     double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var56);
//     double var60 = org.apache.commons.math3.util.MathArrays.distance1(var39, var56);
//     java.lang.Comparable[] var62 = new java.lang.Comparable[] { (-1.0f)};
//     java.lang.Number var63 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var66 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var63, (java.lang.Number)(byte)100, 100);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var67 = var66.getDirection();
//     boolean var69 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var62, var67, false);
//     boolean var72 = org.apache.commons.math3.util.MathArrays.checkOrder(var56, var67, true, false);
//     double[] var73 = new double[] { };
//     double[] var77 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var73, var77);
//     double[] var79 = new double[] { };
//     double[] var83 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var84 = org.apache.commons.math3.util.MathArrays.distance1(var79, var83);
//     double[] var85 = new double[] { };
//     double[] var89 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var90 = org.apache.commons.math3.util.MathArrays.distance1(var85, var89);
//     boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var83, var89);
//     boolean var92 = org.apache.commons.math3.util.MathArrays.equals(var77, var83);
//     boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var56, var77);
//     boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var16, var56);
//     double[] var95 = null;
//     double var96 = org.apache.commons.math3.util.MathArrays.linearCombination(var56, var95);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-3.2075376154645125E13d));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var7 = new org.apache.commons.math3.exception.DimensionMismatchException(var4, 0, 100);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var6, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var9, false);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)119583573, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.OutOfRangeException var18 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-468211539698969088L), (java.lang.Number)44986.47454917167d, (java.lang.Number)1685.0291123281943d);
    java.lang.Number var19 = var18.getHi();
    var14.addSuppressed((java.lang.Throwable)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 1685.0291123281943d+ "'", var19.equals(1685.0291123281943d));

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     int var8 = var2.nextZipf(5, 5606.347746720141d);
//     int var11 = var2.nextBinomial(0, 0.41292608781564977d);
//     double var13 = var2.nextExponential(14603.081554194827d);
//     var2.reSeed();
//     double var17 = var2.nextGamma(31.26438416598488d, 22.034666388288965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9153238394393426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 53743.07090776245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 509.4239827436647d);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     double var15 = var2.nextF(185.2718719624735d, 276733.161992937d);
//     double var17 = var2.nextT(3.600850744922761E11d);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var2.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8718199161117666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8874841839060438d));
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(4411.553384062907d, 4481.058440388458d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextInt(752916846, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4452.436473029689d);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     double var10 = var0.nextF(4481.058440388458d, 22.034666388288965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2f15821d20"+ "'", var4.equals("2f15821d20"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0047533118749334d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     long var2 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var3.reSeed(100L);
//     long var8 = var3.nextSecureLong((-4237628123369238917L), 7L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var3.nextInt(52, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7540580061456263210L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1787623165795761408L));
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    byte[] var8 = new byte[] { (byte)100, (byte)0, (byte)10};
    var4.nextBytes(var8);
    byte[] var11 = new byte[] { (byte)10};
    var4.nextBytes(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 908338718, 55);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var3 = new int[] { 1};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 0);
    var1.setSeed(var5);
    int[] var8 = new int[] { 1};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 0);
    int var11 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var8);
    int[] var13 = new int[] { 1};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var13);
    var16.clear();
    double var18 = var16.nextDouble();
    var16.clear();
    var16.setSeed(100L);
    org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var5, (java.lang.Object)100L);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair(var22);
    java.lang.Object var24 = var23.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    java.lang.Comparable[] var13 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var14 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var14, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = var17.getDirection();
    boolean var20 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var13, var18, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.27873123f, (java.lang.Number)(-4237628123369238917L), 5, var18, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-0.10429427302091279d), (java.lang.Number)0.0024793994397472184d, 74, var18, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var26 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)3.2548543754381306E10d, (java.lang.Number)0.5263157894736842d, 15, var18, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)3.600850744922761E11d, (java.lang.Number)2.403324011369935E100d, 0, var18, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, (-0.3183389366223311d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var24, var30);
    double[] var40 = new double[] { };
    double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var44);
    double[] var50 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    double[] var57 = new double[] { };
    double[] var61 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var62 = org.apache.commons.math3.util.MathArrays.distance1(var57, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var55, var61);
    double[] var64 = org.apache.commons.math3.util.MathArrays.ebeAdd(var50, var61);
    double[] var66 = org.apache.commons.math3.util.MathArrays.normalizeArray(var50, (-0.3183389366223311d));
    double var67 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var50);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var50, 68);
    java.lang.Comparable[] var74 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var75 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var78 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var75, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var79 = var78.getDirection();
    boolean var81 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var74, var79, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var83 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.27873123f, (java.lang.Number)(-4237628123369238917L), 5, var79, true);
    boolean var86 = org.apache.commons.math3.util.MathArrays.checkOrder(var69, var79, false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var89 = org.apache.commons.math3.util.MathArrays.checkOrder(var19, var79, false, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.0495113940566383d, (java.lang.Number)2.0d, false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var5 = new org.apache.commons.math3.exception.DimensionMismatchException(var2, 0, 100);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     java.lang.String var8 = var2.nextSecureHexString(100);
//     long var11 = var2.nextSecureLong((-3326135190239569920L), 59523L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextGaussian(0.4020775187866738d, (-447428.39537913015d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2213193b10a20bba43d4b3fc9ac25105382a67d51d029c14f6097560a271492ecf224ec8cd73fe2f2a6fa3f29f35cb2f7104"+ "'", var8.equals("2213193b10a20bba43d4b3fc9ac25105382a67d51d029c14f6097560a271492ecf224ec8cd73fe2f2a6fa3f29f35cb2f7104"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1793783030610121216L));
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var21 = new double[] { };
    double[] var25 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var26 = org.apache.commons.math3.util.MathArrays.distance1(var21, var25);
    double[] var27 = new double[] { };
    double[] var31 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var33 = new double[] { };
    double[] var37 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var37);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var25, var31);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var31);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 14.177446878757825d);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     double var17 = var0.nextWeibull(185.2718719624735d, 0.01731035720893923d);
//     java.lang.String var19 = var0.nextSecureHexString(43);
//     long var22 = var0.nextLong((-150956856425768896L), 5752918913054996782L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextCauchy(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e3d05c49a2"+ "'", var4.equals("e3d05c49a2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "15c9d451dc99a8629c54034d1b5e3d39c39cbc4ba2f0"+ "'", var9.equals("15c9d451dc99a8629c54034d1b5e3d39c39cbc4ba2f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-466433237557145472L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.01711078638661543d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "d79bb7cacfdd182be582560872d6863ddda6feeae85"+ "'", var19.equals("d79bb7cacfdd182be582560872d6863ddda6feeae85"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2963398972940577792L);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var4 = new org.apache.commons.math3.exception.DimensionMismatchException(var1, 0, 100);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     org.apache.commons.math3.distribution.RealDistribution var16 = null;
//     double var17 = var0.nextInversionDeviate(var16);
// 
//   }

//  public void test93() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
//
//
//    int[] var1 = new int[] { 1};
//    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//    int[] var7 = new int[] { 1};
//    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
//    int[] var13 = new int[] { 1};
//    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 0);
//    int var18 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var13);
//    int var19 = org.apache.commons.math3.util.MathArrays.distance1(var5, var7);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 1046972955);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var5);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var11);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var13);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var15);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var17);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var18 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var19 == 0);
//
//  }
//
  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)1.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { 100.0f};
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var6, var8);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    org.apache.commons.math3.util.Pair var11 = new org.apache.commons.math3.util.Pair((java.lang.Object)var3, (java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var14 = var0.nextT(223115.0311913556d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "130c8546fb"+ "'", var4.equals("130c8546fb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.3838371302289217d);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 100);
//     double[] var12 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     double[] var19 = new double[] { };
//     double[] var23 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var19, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var17, var23);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeAdd(var12, var23);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, (-1.0d));
//     double[] var29 = new double[] { };
//     double[] var33 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var34 = org.apache.commons.math3.util.MathArrays.distance1(var29, var33);
//     double[] var35 = new double[] { };
//     double[] var39 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var40 = org.apache.commons.math3.util.MathArrays.distance1(var35, var39);
//     double[] var41 = new double[] { };
//     double[] var45 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
//     boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var39, var45);
//     double var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var45);
//     double var49 = org.apache.commons.math3.util.MathArrays.distance1(var28, var45);
//     boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var28);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var8);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-4237628123369238917L), (java.lang.Number)10, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)7L);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(5976.3000502945915d, 0.017052173536624703d, 859310.3200241375d, 9.517178777190678E-5d, 6182.891512476099d, 2135.1904046211293d, 8879.287806416309d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.320183432125736E7d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.27873123f);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextExponential(0.5263157894736842d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextZipf(15, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6990788547755153d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
    double[] var30 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var31 = new double[] { };
    double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
    double[] var37 = new double[] { };
    double[] var41 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var42 = org.apache.commons.math3.util.MathArrays.distance1(var37, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var35, var41);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var41);
    double[] var46 = org.apache.commons.math3.util.MathArrays.normalizeArray(var30, (-0.3183389366223311d));
    double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var30);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 68);
    double[] var53 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var54 = new double[] { };
    double[] var58 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var54, var58);
    double[] var60 = new double[] { };
    double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var58, var64);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeAdd(var53, var64);
    double[] var69 = org.apache.commons.math3.util.MathArrays.normalizeArray(var53, (-0.3183389366223311d));
    double[] var70 = new double[] { };
    double[] var74 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var75 = org.apache.commons.math3.util.MathArrays.distance1(var70, var74);
    double[] var76 = new double[] { };
    double[] var80 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var81 = org.apache.commons.math3.util.MathArrays.distance1(var76, var80);
    double[] var82 = new double[] { };
    double[] var86 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var87 = org.apache.commons.math3.util.MathArrays.distance1(var82, var86);
    boolean var88 = org.apache.commons.math3.util.MathArrays.equals(var80, var86);
    double var89 = org.apache.commons.math3.util.MathArrays.distanceInf(var74, var86);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeDivide(var53, var74);
    double var91 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    double var92 = org.apache.commons.math3.util.MathArrays.distance(var30, var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 14.177446878757825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 14.866068747318506d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)5606.347746720141d, (java.lang.Number)(-4656872040217468132L), false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(972185778);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    int var7 = var2.nextZipf(100, 2135.1904046211293d);
    double var10 = var2.nextWeibull(2349.693493309191d, 14.279906171571504d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextSecureInt(496545966, 326172715);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 14.266529369004015d);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1183934ab3", "55667e0c4d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "db454865cf"+ "'", var4.equals("db454865cf"));
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextT(276733.161992937d);
    double var9 = var2.nextCauchy(276733.161944128d, 1.0047533118749334d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextF(6182.891512476099d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.7309748381028882d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 276730.21748287673d);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     java.lang.String var8 = var2.nextSecureHexString(100);
//     long var11 = var2.nextSecureLong((-3326135190239569920L), 59523L);
//     double var14 = var2.nextGamma(1132.4636644703082d, 7891.527654497291d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "8b12e5813312e480006c04618c9daf256a7b7d0295a2f5dffaf8d4b334c7fdf6d1f2a7bf02dd5c2d0cdb46364c760e197e94"+ "'", var8.equals("8b12e5813312e480006c04618c9daf256a7b7d0295a2f5dffaf8d4b334c7fdf6d1f2a7bf02dd5c2d0cdb46364c760e197e94"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1625355324943433984L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8996648.00931824d);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var7 = var2.nextUniform(0.9153238394393426d, 10010.0d, false);
//     var2.reSeedSecure((-4237628123369238917L));
//     java.lang.String var11 = var2.nextHexString(100);
//     long var14 = var2.nextLong(7L, 10L);
//     double var17 = var2.nextCauchy((-1.0d), 100.0d);
//     org.apache.commons.math3.distribution.RealDistribution var18 = null;
//     double var19 = var2.nextInversionDeviate(var18);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     int var9 = var0.nextBinomial(33, 0.2787313252014696d);
//     int var12 = var0.nextSecureInt(74, 496545966);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "683e2db025"+ "'", var4.equals("683e2db025"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 367643481);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     java.lang.String var8 = var2.nextSecureHexString(100);
//     var2.reSeed(2987715053862827087L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "199eda676f43f5dc502295aedad364710381958ebe09f3703db4bffd0250475a1ca10b81dd0a49e12e797b295f20b6dbbf78"+ "'", var8.equals("199eda676f43f5dc502295aedad364710381958ebe09f3703db4bffd0250475a1ca10b81dd0a49e12e797b295f20b6dbbf78"));
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    double var11 = var2.nextGamma(185.2718719624735d, 37.124987752215674d);
    double var14 = var2.nextGaussian(4481.058440388458d, 9998.458978288749d);
    int var17 = var2.nextZipf(15, 5606.347746720141d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var2.nextF((-3.2075376154645125E13d), (-1.334741001015885d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5606.347746720141d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8273.979899088612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)149075031, (java.lang.Number)1, (java.lang.Number)76L);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextZipf(83, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var1.nextF((-0.9387123485327005d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 275528L);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(100, 1.0d);
    int var8 = var2.nextInt(0, 10);
    long var11 = var2.nextLong((-150956856425768896L), 276682L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextUniform(7263549.284553437d, 0.017052173536624703d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-78875561168351632L));

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 6);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.9387123485327005d), (java.lang.Number)7.596033661938047E7d, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.setSeed((-815912261906828288L));
    int var5 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 424225255);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextGaussian(10.0d, 276733.161992937d);
//     double var18 = var0.nextGamma(37.124987752215674d, 9998.458978288749d);
//     double var21 = var0.nextGamma(5606.347746720141d, 2990922.8198766294d);
//     org.apache.commons.math3.distribution.RealDistribution var22 = null;
//     double var23 = var0.nextInversionDeviate(var22);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, true);
    org.apache.commons.math3.exception.MathArithmeticException var9 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var1.nextDouble();
    var1.setSeed(0);
    var1.setSeed(324764L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7540580061456263210L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.954816313157598d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(3.6942430090005716E85d, 14.279906171571504d, 0.0d, (-1.8255599450450224d), 1125185.2252459729d, 12.183861247133061d, 1.0047533118749334d, 0.005035219192084889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 5.275344354351215E86d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var4 = new double[] { };
//     double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
//     double[] var10 = new double[] { };
//     double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
//     double[] var18 = new double[] { };
//     double[] var22 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var23 = org.apache.commons.math3.util.MathArrays.distance1(var18, var22);
//     double[] var24 = new double[] { };
//     double[] var28 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var29 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
//     double[] var30 = new double[] { };
//     double[] var34 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var35 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
//     boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var34);
//     double var37 = org.apache.commons.math3.util.MathArrays.distanceInf(var22, var34);
//     double var38 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var22);
//     double[] var39 = new double[] { };
//     double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
//     double[] var45 = new double[] { };
//     double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
//     double[] var51 = new double[] { };
//     double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
//     double var58 = org.apache.commons.math3.util.MathArrays.distanceInf(var43, var55);
//     double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var55);
//     double[] var60 = new double[] { };
//     double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
//     double[] var66 = new double[] { };
//     double[] var70 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var71 = org.apache.commons.math3.util.MathArrays.distance1(var66, var70);
//     double[] var72 = new double[] { };
//     double[] var76 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var77 = org.apache.commons.math3.util.MathArrays.distance1(var72, var76);
//     boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var70, var76);
//     double var79 = org.apache.commons.math3.util.MathArrays.distanceInf(var64, var76);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var64);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var55);
//     double[] var82 = null;
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var81, var82);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    long var5 = var4.nextLong();
    var4.setSeed(8L);
    boolean var8 = var4.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5141685311728891869L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
//     var2.reSeed();
//     long var18 = var2.nextSecureLong((-468211539698969088L), 6535425231125204517L);
//     int var21 = var2.nextPascal(367643481, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14603.081554194827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3965.0367954613544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 4726242229657284608L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2147483647);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    double var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var4, var16);
    double[] var23 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var24 = new double[] { };
    double[] var28 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var24, var28);
    double[] var30 = new double[] { };
    double[] var34 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var35 = org.apache.commons.math3.util.MathArrays.distance1(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var34);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeAdd(var23, var34);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, (-0.3183389366223311d));
    double[] var40 = new double[] { };
    double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
    double[] var46 = new double[] { };
    double[] var50 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var46, var50);
    double[] var52 = new double[] { };
    double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var50, var56);
    double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var44, var56);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeDivide(var23, var44);
    double[] var62 = org.apache.commons.math3.util.MathArrays.normalizeArray(var23, 3.6942430090005716E85d);
    double var63 = org.apache.commons.math3.util.MathArrays.distance(var16, var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 2.6122242830153E85d);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     double var7 = var0.nextGamma(502822.6958193368d, 14603.081554194827d);
//     java.lang.String var9 = var0.nextSecureHexString(44);
//     var0.reSeed();
//     long var13 = var0.nextLong((-4237628123369238917L), 0L);
//     var0.reSeed();
//     double var17 = var0.nextWeibull(185.2718719624735d, 0.01731035720893923d);
//     double var19 = var0.nextExponential(0.954816313157598d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextPascal(424225255, 1125185.2252459729d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1ebc57592b"+ "'", var4.equals("1ebc57592b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.343684965302029E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "fd037836c2c52a20ed4460f83781ec4346938fb28882"+ "'", var9.equals("fd037836c2c52a20ed4460f83781ec4346938fb28882"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1120419740331432192L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.01733704374767777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0501418511301512d);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-96866.37670153315d), 10.0d, 0.5162940945248184d, 273.14655120642885d, 2.0187637256530055E15d, 1.0047533118749334d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.028359538274314E15d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)100, (java.lang.Number)(short)0, (java.lang.Number)10L);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var6 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { "1183934ab3"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.320183432125736E7d);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)1.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    java.lang.Number var6 = var3.getMax();
    boolean var7 = var3.getBoundIsAllowed();
    boolean var8 = var3.getBoundIsAllowed();
    boolean var9 = var3.getBoundIsAllowed();
    boolean var10 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1.0d+ "'", var6.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)496545966, (java.lang.Number)4554967237661810166L, true);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(2.6122242830153E85d, 6.36942772394751E11d, 2.0187637256530055E15d, (-0.7309748381028882d), 22.034666388288965d, 0.3838371302289217d, 0.0d, 502926.81918299187d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.663837376940656E97d);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeed();
//     int var8 = var2.nextSecureInt(52, 98304788);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 23040815);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     double var11 = var2.nextChiSquare(4481.058440388458d);
//     var2.reSeedSecure();
//     double var15 = var2.nextF(185.2718719624735d, 276733.161992937d);
//     double var17 = var2.nextT(3.600850744922761E11d);
//     var2.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var2.nextSecureInt(393820222, 98304788);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4411.553384062907d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.8718199161117666d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-0.8874841839060438d));
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.0d, (java.lang.Number)1.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 16);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var5 = var4.nextLong();
//     var4.setSeed(8L);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     java.util.List var9 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var10 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var4, var9);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     var2.reSeedSecure((-2375917353946954240L));
//     java.lang.String var9 = var2.nextSecureHexString(49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.9153238394393426d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "950eeaaa39b2e451dfc0d128733acba508a118331ab44c2f5"+ "'", var9.equals("950eeaaa39b2e451dfc0d128733acba508a118331ab44c2f5"));
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     int[] var5 = new int[] { 1};
//     int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 0);
//     org.apache.commons.math3.random.RandomDataImpl var8 = new org.apache.commons.math3.random.RandomDataImpl();
//     var8.reSeed((-1L));
//     java.lang.String var12 = var8.nextSecureHexString(10);
//     var8.reSeedSecure();
//     int var17 = var8.nextHypergeometric(100, 1, 1);
//     int[] var20 = var8.nextPermutation(10, 5);
//     int var21 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var1, var20);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 23040815);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "119a66c3e0"+ "'", var12.equals("119a66c3e0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    java.lang.String var7 = var2.nextHexString(55);
    double var10 = var2.nextBeta(3965.0367954613544d, 4481.058440388458d);
    var2.reSeed();
    int var14 = var2.nextBinomial(3, 1.0d);
    var2.reSeed((-2427542156791145472L));
    double var19 = var2.nextWeibull(49.73518257362382d, 0.23449722509094836d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c5"+ "'", var7.equals("0157ee74f3754b9a34adbdfa4a6879af047755869150a7cd6a102c5"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.466749620721066d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.23061058607778495d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    java.lang.Number var0 = null;
    double[] var4 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var4);
    double[] var6 = new double[] { };
    double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
    double[] var12 = new double[] { };
    double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
    org.apache.commons.math3.exception.util.Localizable var19 = null;
    java.lang.Comparable[] var21 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = null;
    boolean var24 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var21, var22, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    boolean var27 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var21, var25, false);
    org.apache.commons.math3.exception.MathArithmeticException var28 = new org.apache.commons.math3.exception.MathArithmeticException(var19, (java.lang.Object[])var21);
    java.lang.Comparable[] var30 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var31 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var34 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var31, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = var34.getDirection();
    boolean var37 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var30, var35, false);
    boolean var39 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var21, var35, false);
    double[] var40 = new double[] { };
    double[] var44 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var40, var44);
    double[] var46 = new double[] { };
    double[] var50 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var46, var50);
    double[] var52 = new double[] { };
    double[] var56 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var57 = org.apache.commons.math3.util.MathArrays.distance1(var52, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var50, var56);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var44, var50);
    double[] var60 = new double[] { };
    double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var44, var64);
    double[][] var67 = new double[][] { var66};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var35, var67);
    org.apache.commons.math3.util.MathArrays.checkOrder(var4, var35, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var72 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)85, 1, var35, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    double var6 = var2.nextExponential(10010.0d);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.nextBinomial(10, 1.908642352606886d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14603.081554194827d);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = new double[] { };
//     double[] var5 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var1, var5);
//     double[] var7 = new double[] { };
//     double[] var11 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var7, var11);
//     double[] var13 = new double[] { };
//     double[] var17 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var13, var17);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var11, var17);
//     double var20 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var17);
//     double[] var24 = new double[] { 10.0d, 0.0d, 10.0d};
//     double[] var25 = new double[] { };
//     double[] var29 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var30 = org.apache.commons.math3.util.MathArrays.distance1(var25, var29);
//     double[] var31 = new double[] { };
//     double[] var35 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var36 = org.apache.commons.math3.util.MathArrays.distance1(var31, var35);
//     boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var29, var35);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var35);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.normalizeArray(var35, (-1.0d));
//     double[] var41 = new double[] { };
//     double[] var45 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var46 = org.apache.commons.math3.util.MathArrays.distance1(var41, var45);
//     double[] var47 = new double[] { };
//     double[] var51 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var52 = org.apache.commons.math3.util.MathArrays.distance1(var47, var51);
//     double[] var53 = new double[] { };
//     double[] var57 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var58 = org.apache.commons.math3.util.MathArrays.distance1(var53, var57);
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var51, var57);
//     double var60 = org.apache.commons.math3.util.MathArrays.distanceInf(var45, var57);
//     double var61 = org.apache.commons.math3.util.MathArrays.distance1(var40, var57);
//     java.lang.Comparable[] var63 = new java.lang.Comparable[] { (-1.0f)};
//     java.lang.Number var64 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var67 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var64, (java.lang.Number)(byte)100, 100);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var68 = var67.getDirection();
//     boolean var70 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var63, var68, false);
//     boolean var73 = org.apache.commons.math3.util.MathArrays.checkOrder(var57, var68, true, false);
//     double[] var74 = new double[] { };
//     double[] var78 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var79 = org.apache.commons.math3.util.MathArrays.distance1(var74, var78);
//     double[] var80 = new double[] { };
//     double[] var84 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var85 = org.apache.commons.math3.util.MathArrays.distance1(var80, var84);
//     double[] var86 = new double[] { };
//     double[] var90 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var91 = org.apache.commons.math3.util.MathArrays.distance1(var86, var90);
//     boolean var92 = org.apache.commons.math3.util.MathArrays.equals(var84, var90);
//     boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var78, var84);
//     boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var57, var78);
//     boolean var95 = org.apache.commons.math3.util.MathArrays.equals(var17, var57);
//     double var96 = org.apache.commons.math3.util.MathArrays.distance1(var0, var17);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    float[] var1 = new float[] { 1.0f};
    float[] var5 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equals(var1, var5);
    float[] var8 = new float[] { 1.0f};
    float[] var12 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var8, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var1, var12);
    float[] var16 = new float[] { 1.0f};
    float[] var20 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var16, var20);
    float[] var23 = new float[] { 1.0f};
    float[] var27 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var16, var27);
    float[] var30 = null;
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var16, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var16);
    float[] var34 = new float[] { 1.0f};
    float[] var38 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var34, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var16, var38);
    float[] var42 = new float[] { 1.0f};
    float[] var46 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var42, var46);
    float[] var49 = new float[] { 1.0f};
    float[] var53 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var49, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var42, var53);
    float[] var57 = new float[] { 1.0f};
    float[] var61 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var57, var61);
    float[] var64 = new float[] { 1.0f};
    float[] var68 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var64, var68);
    boolean var70 = org.apache.commons.math3.util.MathArrays.equals(var57, var68);
    float[] var71 = null;
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var57, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var57);
    float[] var74 = null;
    float[] var76 = new float[] { 1.0f};
    float[] var80 = new float[] { 100.0f, 0.0f, 10.0f};
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var76, var80);
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var74, var80);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var53, var74);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equals(var38, var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    byte[] var8 = new byte[] { (byte)100, (byte)0, (byte)10};
    var4.nextBytes(var8);
    org.apache.commons.math3.random.RandomDataGenerator var10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var8, false);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var2, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double[] var3 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var4 = new double[] { };
    double[] var8 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var9 = org.apache.commons.math3.util.MathArrays.distance1(var4, var8);
    double[] var10 = new double[] { };
    double[] var14 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var15 = org.apache.commons.math3.util.MathArrays.distance1(var10, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var8, var14);
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
    double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-1.0d));
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    double[] var26 = new double[] { };
    double[] var30 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var31 = org.apache.commons.math3.util.MathArrays.distance1(var26, var30);
    double[] var32 = new double[] { };
    double[] var36 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var32, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var30, var36);
    double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var36);
    double var40 = org.apache.commons.math3.util.MathArrays.distance1(var19, var36);
    double[] var44 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeAdd(var44, var55);
    double[] var60 = org.apache.commons.math3.util.MathArrays.normalizeArray(var44, (-0.3183389366223311d));
    double var61 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var60);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    double[] var67 = new double[] { 10.0d, 0.0d, 10.0d};
    double[] var68 = new double[] { };
    double[] var72 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var68, var72);
    double[] var74 = new double[] { };
    double[] var78 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var79 = org.apache.commons.math3.util.MathArrays.distance1(var74, var78);
    boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var72, var78);
    double[] var81 = org.apache.commons.math3.util.MathArrays.ebeAdd(var67, var78);
    double[] var83 = org.apache.commons.math3.util.MathArrays.normalizeArray(var78, (-1.0d));
    double var84 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var78);
    double[] var85 = org.apache.commons.math3.util.MathArrays.copyOf(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 22.10526315789474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.5263157894736842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == (-10.578947368421051d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int[] var12 = var0.nextPermutation(10, 5);
//     double var15 = var0.nextCauchy((-1.0d), 100.0d);
//     long var18 = var0.nextLong(1L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2a38623cf8"+ "'", var4.equals("2a38623cf8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 49.73518257362382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 7L);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { "b4ee55f0a6"};
    double[] var3 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    double[] var5 = new double[] { };
    double[] var9 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var10 = org.apache.commons.math3.util.MathArrays.distance1(var5, var9);
    double[] var11 = new double[] { };
    double[] var15 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var16 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var9, var15);
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    java.lang.Comparable[] var20 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var20, var21, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    boolean var26 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var20, var24, false);
    org.apache.commons.math3.exception.MathArithmeticException var27 = new org.apache.commons.math3.exception.MathArithmeticException(var18, (java.lang.Object[])var20);
    java.lang.Comparable[] var29 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var30 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var30, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var34 = var33.getDirection();
    boolean var36 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var34, false);
    boolean var38 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var20, var34, false);
    double[] var39 = new double[] { };
    double[] var43 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var44 = org.apache.commons.math3.util.MathArrays.distance1(var39, var43);
    double[] var45 = new double[] { };
    double[] var49 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var50 = org.apache.commons.math3.util.MathArrays.distance1(var45, var49);
    double[] var51 = new double[] { };
    double[] var55 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var56 = org.apache.commons.math3.util.MathArrays.distance1(var51, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var49, var55);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var43, var49);
    double[] var59 = new double[] { };
    double[] var63 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var64 = org.apache.commons.math3.util.MathArrays.distance1(var59, var63);
    double[] var65 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var63);
    double[][] var66 = new double[][] { var65};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var34, var66);
    org.apache.commons.math3.util.MathArrays.checkOrder(var3, var34, false);
    boolean var71 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var34, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var4 = var1.nextGamma(0.926725986813839d, 2349.693493309191d);
//     var1.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 565.0577683697343d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(5);
    var2.reSeed();
    var2.reSeed((-2100806147823023616L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextF(22.10526315789474d, 10.0d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextPascal(74, 6655.664073045887d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.9153238394393426d);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(496545966);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    int[] var1 = new int[] { 1};
    int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
    var4.clear();
    double var6 = var4.nextDouble();
    double var7 = var4.nextGaussian();
    double var8 = var4.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    var9.reSeedSecure();
    long var12 = var9.nextPoisson(0.954816313157598d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.9387123485327005d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.41292608781564977d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var4 = var2.nextExponential(0.5263157894736842d);
    var2.reSeedSecure(0L);
    double var9 = var2.nextGaussian(0.2787313252014696d, 0.23449722509094836d);
    double var11 = var2.nextExponential(14.866068747318506d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.6990788547755153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5524419608109314d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 54.71093096630052d);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }
// 
// 
//     double[] var0 = new double[] { };
//     double[] var4 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var5 = org.apache.commons.math3.util.MathArrays.distance1(var0, var4);
//     double[] var6 = new double[] { };
//     double[] var10 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var11 = org.apache.commons.math3.util.MathArrays.distance1(var6, var10);
//     double[] var12 = new double[] { };
//     double[] var16 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var17 = org.apache.commons.math3.util.MathArrays.distance1(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var10, var16);
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var4, var10);
//     double[] var20 = new double[] { };
//     double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var24);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 74);
//     double[] var29 = null;
//     double var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var28, var29);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     double var8 = var0.nextWeibull(7.343684965302029E9d, 276733.161992937d);
//     java.lang.String var10 = var0.nextHexString(1);
//     long var13 = var0.nextSecureLong((-3421154187157187072L), (-78875561168351632L));
//     int[] var16 = var0.nextPermutation(1, 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bad821ca1a"+ "'", var4.equals("bad821ca1a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 276733.161944128d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "6"+ "'", var10.equals("6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-2633674873767055872L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(8L);
    int var7 = var2.nextZipf(83, 4411.553384062907d);
    var2.reSeed(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     var2.reSeedSecure((-3983742070236694016L));
//     java.lang.String var14 = var2.nextSecureHexString(42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14603.081554194827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "1c6bd6809386a9cd37f75127e425543e1ab0138638"+ "'", var14.equals("1c6bd6809386a9cd37f75127e425543e1ab0138638"));
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     int var9 = var2.nextSecureInt((-1), 100);
//     int var12 = var2.nextZipf(100, 273.14655120642885d);
//     double var15 = var2.nextUniform(6655.664073045887d, 117303.91049523883d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 18237.731573200443d);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     long var6 = var0.nextLong(0L, 276682L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextHypergeometric(0, 1735228169, 1051261391);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "5d452c236b"+ "'", var2.equals("5d452c236b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 258657L);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextF(22.10526315789474d, 10.0d);
//     var2.reSeedSecure(7540580061456263210L);
//     var2.reSeedSecure(10L);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, 2);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 334518628, 326172715);
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 326172715);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     double var6 = var2.nextExponential(10010.0d);
//     double var10 = var2.nextUniform(10.0d, 100.0d, false);
//     double var14 = var2.nextUniform((-0.9387123485327005d), 14603.081554194827d, false);
//     var2.reSeedSecure();
//     double var18 = var2.nextCauchy(502822.6958193368d, 0.9153238394393426d);
//     int var21 = var2.nextSecureInt(0, 83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var2.nextExponential((-0.9387123485327005d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14603.081554194827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 37.124987752215674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3965.0367954613544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 502926.81918299187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 68);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)4665674839569508352L, (java.lang.Number)0.5263157894736842d, 1051261391);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     double var12 = var0.nextCauchy(0.0d, 0.9153238394393426d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextBinomial(85, 3.6008534624247894E11d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "14fc9df46e"+ "'", var4.equals("14fc9df46e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.3183389366223311d));
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.12025686952725181d, (java.lang.Number)(-4237628123369238917L), false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var7, false);
    org.apache.commons.math3.exception.MathArithmeticException var10 = new org.apache.commons.math3.exception.MathArithmeticException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextHexString(5);
//     var2.reSeedSecure((-1L));
//     java.lang.String var8 = var2.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var2.nextPermutation(33, 367643481);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "1d052"+ "'", var4.equals("1d052"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "494962f301e354cf05dbac8a45a05d1208d5ac3293cb9ba1625563fb74da919eb0118d850f504b054f3c1a2e6cbeb90fb45c"+ "'", var8.equals("494962f301e354cf05dbac8a45a05d1208d5ac3293cb9ba1625563fb74da919eb0118d850f504b054f3c1a2e6cbeb90fb45c"));
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }
// 
// 
//     int[] var1 = new int[] { 1};
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 0);
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var1);
//     long var5 = var4.nextLong();
//     var4.setSeed(8L);
//     org.apache.commons.math3.random.RandomDataGenerator var8 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     java.lang.String var10 = var8.nextHexString(100);
//     java.lang.String var12 = var8.nextSecureHexString(30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5141685311728891869L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "8501c1bdeaa3a7f78e54dc0cf6530a08f72373f131cd6cddf1109daff575f23216cba253f61c0ea8382de39f3edaa3f20644"+ "'", var10.equals("8501c1bdeaa3a7f78e54dc0cf6530a08f72373f131cd6cddf1109daff575f23216cba253f61c0ea8382de39f3edaa3f20644"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c4f5307f2133dfd1aa43087870f677"+ "'", var12.equals("c4f5307f2133dfd1aa43087870f677"));
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Comparable[] var3 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var3, var4, false);
    org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var3);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)5.290248133988897d, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.3183389366223311d), (java.lang.Number)54.71093096630052d, (java.lang.Number)100);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     long var6 = var0.nextLong(0L, 276682L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(83, 9);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "a0c26ce52b"+ "'", var2.equals("a0c26ce52b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 273256L);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeed();
//     double var8 = var0.nextF(0.017178374061959746d, 6655.664073045887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c8b2498002"+ "'", var4.equals("c8b2498002"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.4686606541870811E-9d);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-867244594845292898L), (java.lang.Number)276730.21748287673d, (java.lang.Number)49.73518257362382d);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed((-1L));
//     java.lang.String var4 = var0.nextSecureHexString(10);
//     var0.reSeedSecure();
//     int var9 = var0.nextHypergeometric(100, 1, 1);
//     int var12 = var0.nextSecureInt(5, 1755678109);
//     long var15 = var0.nextSecureLong((-4656872040217468132L), 0L);
//     long var17 = var0.nextPoisson(6655.664073045887d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "64ff458d08"+ "'", var4.equals("64ff458d08"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 668269025);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2569434898440446976L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 6514L);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)100100.0d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     long var3 = var1.nextPoisson(276733.161992937d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var1.nextUniform(6182.891512476099d, 49.73518257362382d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 277217L);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)323958L, (java.lang.Number)(short)1, false);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(7L, 3233753233997579692L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2270251626897072384L);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    java.lang.Comparable[] var4 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var5, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var8, false);
    double[] var12 = new double[] { 1.0d};
    org.apache.commons.math3.util.MathArrays.checkOrder(var12);
    double[] var14 = new double[] { };
    double[] var18 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var14, var18);
    double[] var20 = new double[] { };
    double[] var24 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var25 = org.apache.commons.math3.util.MathArrays.distance1(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var18, var24);
    org.apache.commons.math3.exception.util.Localizable var27 = null;
    java.lang.Comparable[] var29 = new java.lang.Comparable[] { "org.apache.commons.math3.exception.NullArgumentException: null is not allowed"};
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var30, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var33 = null;
    boolean var35 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var33, false);
    org.apache.commons.math3.exception.MathArithmeticException var36 = new org.apache.commons.math3.exception.MathArithmeticException(var27, (java.lang.Object[])var29);
    java.lang.Comparable[] var38 = new java.lang.Comparable[] { (-1.0f)};
    java.lang.Number var39 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var39, (java.lang.Number)(byte)100, 100);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var42.getDirection();
    boolean var45 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var38, var43, false);
    boolean var47 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var29, var43, false);
    double[] var48 = new double[] { };
    double[] var52 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var53 = org.apache.commons.math3.util.MathArrays.distance1(var48, var52);
    double[] var54 = new double[] { };
    double[] var58 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var59 = org.apache.commons.math3.util.MathArrays.distance1(var54, var58);
    double[] var60 = new double[] { };
    double[] var64 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var65 = org.apache.commons.math3.util.MathArrays.distance1(var60, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var58, var64);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var52, var58);
    double[] var68 = new double[] { };
    double[] var72 = new double[] { (-1.0d), 10.0d, 10.0d};
    double var73 = org.apache.commons.math3.util.MathArrays.distance1(var68, var72);
    double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var72);
    double[][] var75 = new double[][] { var74};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var43, var75);
    org.apache.commons.math3.util.MathArrays.checkOrder(var12, var43, false);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var43, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-316249655302969216L), (java.lang.Number)4554967237661810166L, 55, var43, false);
    java.lang.Number var83 = var82.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + 4554967237661810166L+ "'", var83.equals(4554967237661810166L));

  }

}
