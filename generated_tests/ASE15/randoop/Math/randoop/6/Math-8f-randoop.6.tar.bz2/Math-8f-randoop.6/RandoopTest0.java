
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double[] var3 = new double[] { 100.0d, 10.0d, 1.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    double[] var5 = null;
    double[][] var6 = new double[][] { var5};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var4, var6);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    int[] var2 = new int[] { 10, 10};
    int[] var4 = new int[] { 100};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = org.apache.commons.math3.util.MathArrays.distance1(var2, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(10.0d, 100.0d, 0.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1000.0d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var27);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var16 = org.apache.commons.math3.util.MathArrays.ebeAdd(var3, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     double[] var17 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var21 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var24 = new double[] { (-1.0d), (-1.0d)};
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var17, var24);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 1);
//     double[][] var29 = new double[][] { var24};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var13, var29);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
//     java.lang.Number var5 = var4.getHi();
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     double[] var12 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var15 = new double[] { (-1.0d), (-1.0d)};
//     boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var15);
//     java.lang.Object[] var17 = new java.lang.Object[] { var15};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var17);
//     org.apache.commons.math3.exception.MathArithmeticException var19 = new org.apache.commons.math3.exception.MathArithmeticException(var7, var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, var17);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextHypergeometric(0, 0, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double[] var15 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var10, var15);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var18 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var21 = new double[] { (-1.0d), (-1.0d)};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var23 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var10, var18);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     org.apache.commons.math3.distribution.IntegerDistribution var1 = null;
//     int var2 = var0.nextInversionDeviate(var1);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    double[] var0 = new double[] { };
    double[] var4 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d)};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var9 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var7);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1, 10);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextInt(10, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     org.apache.commons.math3.distribution.IntegerDistribution var3 = null;
//     int var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.distance1(var0, var2);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, (-1));
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    double[] var0 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var3, var13, false);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    double[] var3 = new double[] { 0.0d, 100.0d, 0.0d};
    double[] var7 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var7, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var14);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var13 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var8);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextPoisson((-0.27096157230053536d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1));
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation((-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     byte[] var3 = null;
//     var1.nextBytes(var3);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextBeta(1000.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 474.80944486981116d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var16 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var17 = var16.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3, var17, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
//     java.lang.Number var5 = var4.getHi();
//     java.lang.Number var6 = var4.getHi();
//     java.lang.String var7 = var4.toString();
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    int var8 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextHexString((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 100);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var10);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric(100, (-1), 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 729.7307017868861d);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextPascal((-1), 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 51.840119754296985d);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var3 = null;
//     int var4 = var0.nextInversionDeviate(var3);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)0, (java.lang.Number)(short)10, 100, var7, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     long[] var0 = null;
//     long[][] var1 = new long[][] { var0};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var1);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     double[] var17 = null;
//     double var18 = org.apache.commons.math3.util.MathArrays.linearCombination(var16, var17);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var31, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var50);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double[] var21 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var25 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var28 = new double[] { (-1.0d), (-1.0d)};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var21, var28);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 1);
    double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
    double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var15, var32);
    double[] var38 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var42 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var45 = new double[] { (-1.0d), (-1.0d)};
    boolean var46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var42, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var38, var45);
    double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var45, 1);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var49);
    org.apache.commons.math3.util.MathArrays.checkOrder(var49);
    double[] var55 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var59 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var62 = new double[] { (-1.0d), (-1.0d)};
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var62);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var55, var62);
    double[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 1);
    double var67 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var49, var66);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var75 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var76 = var75.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var78 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var76, true);
    boolean var80 = org.apache.commons.math3.util.MathArrays.isMonotonic(var68, var76, false);
    boolean var83 = org.apache.commons.math3.util.MathArrays.checkOrder(var15, var76, false, false);
    double[][] var84 = new double[][] { var15};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var84);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.2793342356121425d, (java.lang.Number)10, true);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextGamma(0.2793342356121425d, (-0.27096157230053536d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1, (java.lang.Number)0.0d, 0);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric(100, (-1), 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextCauchy(0.0d, 1000.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(100.0d, (-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 314.09158730255683d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 956.1791934882469d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var51 = org.apache.commons.math3.util.MathArrays.ebeAdd(var33, var50);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var31);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    double[] var9 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var13 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var16 = new double[] { (-1.0d), (-1.0d)};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var9, var16);
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.isMonotonic(var20, var21, false);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var26 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var16, var25);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextInt(10, 1);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     int var11 = var1.nextInt();
//     double[] var13 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
//     boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var13, var14, false);
//     double[] var17 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var13, var17);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    long[][] var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkRectangular(var0);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
//     java.lang.Number var4 = var3.getMin();
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
//     java.lang.Number var10 = var9.getMax();
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     long[] var12 = null;
//     long[][] var13 = new long[][] { var12};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var11, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var13);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal((-1), 375.6315311789929d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (null)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (null)"));

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10, 275296862);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextF((-0.27096157230053536d), 0.33904363745058674d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 16.737615156127085d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var0.nextSecureLong(1399632177780768928L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(2099284361, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 13.524794341082229d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "275296329248a8e480375b93e1364611e6adb201d1ea354ea21648b8bb5138e22b20c4b7ba7b204b63bf4df3bcd87fe508d4"+ "'", var6.equals("275296329248a8e480375b93e1364611e6adb201d1ea354ea21648b8bb5138e22b20c4b7ba7b204b63bf4df3bcd87fe508d4"));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)10.0f, (java.lang.Number)(byte)(-1), true);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 0);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.28355429246443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9"+ "'", var6.equals("9"));
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    double var6 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.5996555078851037d));

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var4 = var3.getMax();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    long[] var6 = null;
    long[][] var7 = new long[][] { var6};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var9.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var6);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var2 = null;
//     int var3 = var0.nextInversionDeviate(var2);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-75.50392116110793d));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var30 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var10, var27);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextUniform(1000.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)120.65610151834143d, var2, false);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var4 = var3.getIndex();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)"+ "'", var5.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)"));

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 10);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1.0d), (java.lang.Number)375.6315311789929d, 110);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextT((-11.293482242235479d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2147483647, (-1));
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 2147483647);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var0.nextPermutation(2125371022, 2024169968);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.33904363745058674d, (java.lang.Number)110, (java.lang.Number)1000.0d);
    double[] var8 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var12 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var15 = new double[] { (-1.0d), (-1.0d)};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var8, var15);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    double[] var23 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var27 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var30 = new double[] { (-1.0d), (-1.0d)};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var23, var30);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[][] var36 = new double[][] { var34};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var36);
    org.apache.commons.math3.util.Pair var38 = new org.apache.commons.math3.util.Pair((java.lang.Object)110, (java.lang.Object)var36);
    double[] var42 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var46 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var49 = new double[] { (-1.0d), (-1.0d)};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var42, var49);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 1);
    double var54 = org.apache.commons.math3.util.MathArrays.safeNorm(var53);
    org.apache.commons.math3.util.MathArrays.checkOrder(var53);
    double[] var59 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var63 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d)};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var63, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var59, var66);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 1);
    double var71 = org.apache.commons.math3.util.MathArrays.safeNorm(var70);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var53, var70);
    boolean var73 = var38.equals((java.lang.Object)var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextF(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.920920910874275d);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextLong(1399632177780768928L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 667.2214553745608d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.47070632848645555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.16650865099494558d);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var3, false);
    java.lang.Number var6 = var5.getMin();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var11, false);
    java.lang.Object[] var14 = new java.lang.Object[] { var13};
    org.apache.commons.math3.exception.MathArithmeticException var15 = new org.apache.commons.math3.exception.MathArithmeticException(var8, var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var14);
    org.apache.commons.math3.exception.MathInternalError var18 = new org.apache.commons.math3.exception.MathInternalError(var0, var14);
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var18.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var3 = var0.nextPermutation(0, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal(110, 2.7497630628293734d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    boolean var5 = var3.getStrict();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)"+ "'", var6.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)"));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var5 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)100, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextExponential((-0.27096157230053536d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)10.0f, 100);
    org.apache.commons.math3.exception.DimensionMismatchException var6 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    var3.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.clear();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 1);
    double[] var15 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var19 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var22 = new double[] { (-1.0d), (-1.0d)};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var15, var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 1);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var28 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var11, var26);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
//     java.lang.Number var4 = var3.getMax();
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     long[] var6 = null;
//     long[][] var7 = new long[][] { var6};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var7);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var7);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal(100, 308.199125549581d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = org.apache.commons.math3.util.MathArrays.distance1(var7, var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (null)", "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-630.0848204215227d));

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(110, 0, 2099284361);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.20826293466070808d);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(short)1);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(10L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 7.479734555117679d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "89f118639922aa5db78fa20cc04c013717c207c413442ec5d363df968b3d370dff43905c33e68fa38b9de256cf4a14371ef9"+ "'", var6.equals("89f118639922aa5db78fa20cc04c013717c207c413442ec5d363df968b3d370dff43905c33e68fa38b9de256cf4a14371ef9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9L);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
    int var3 = var1.nextInt(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var7 = var0.nextHexString(2099284361);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 653.9959066611634d);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var0.nextSample(var2, 0);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var0.nextPermutation(2099284361, 110);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var1);
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var8, false);
    double[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    double[] var17 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var21 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var24 = new double[] { (-1.0d), (-1.0d)};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var17, var24);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 1);
    double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    org.apache.commons.math3.util.MathArrays.checkOrder(var28);
    double[] var34 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var38 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var41 = new double[] { (-1.0d), (-1.0d)};
    boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var41);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var34, var41);
    double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var41, 1);
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var28, var45);
    double[] var51 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var55 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var58 = new double[] { (-1.0d), (-1.0d)};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var55, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var51, var58);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 1);
    double var63 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    org.apache.commons.math3.util.MathArrays.checkOrder(var62);
    double[] var68 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var75 = new double[] { (-1.0d), (-1.0d)};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var68, var75);
    double[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var75, 1);
    double var80 = org.apache.commons.math3.util.MathArrays.safeNorm(var79);
    double[] var81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var62, var79);
    double[] var82 = org.apache.commons.math3.util.MathArrays.ebeDivide(var47, var79);
    double[][] var83 = new double[][] { var79};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var7, var13, var83);
    double[] var88 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var92 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var95 = new double[] { (-1.0d), (-1.0d)};
    boolean var96 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var92, var95);
    boolean var97 = org.apache.commons.math3.util.MathArrays.equals(var88, var95);
    double var98 = org.apache.commons.math3.util.MathArrays.distance1(var7, var95);
    double var99 = org.apache.commons.math3.util.MathArrays.distance1(var1, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//     double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var44 = new double[] { (-1.0d), (-1.0d)};
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var61 = new double[] { (-1.0d), (-1.0d)};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
//     double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var75 = var74.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var77 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var75, true);
//     boolean var79 = org.apache.commons.math3.util.MathArrays.isMonotonic(var67, var75, false);
//     boolean var82 = org.apache.commons.math3.util.MathArrays.checkOrder(var14, var75, false, false);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var83 = null;
//     boolean var85 = org.apache.commons.math3.util.MathArrays.isMonotonic(var14, var83, false);
//     double[] var86 = null;
//     double[] var87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var86);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var6 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1653827364);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var31, var37);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextSecureInt(1, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1389096311);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    double var8 = var7.nextGaussian();
    double var9 = var7.nextGaussian();
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    var7.setSeed(var13);
    int[] var20 = new int[] { 1, 0, (-1)};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var5, var20);
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 2147483647);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, 275296862);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextWeibull(0.0d, 48.550599067346205d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    double var8 = var7.nextGaussian();
    double var9 = var7.nextGaussian();
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    var7.setSeed(var13);
    int[] var20 = new int[] { 1, 0, (-1)};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var5, var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 2099284361);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.1697362923985073d, (-10061.775830036235d), 884.5884346216443d, 0.2793342356121425d, 1.908642352606886d, 219.80508910257697d, 0.16021426377524167d, 1.6281116695939835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1040.9625410266885d));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var8 = null;
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var11, false);
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    double[] var17 = org.apache.commons.math3.util.MathArrays.normalizeArray(var10, 375.6315311789929d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var17);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    double[] var3 = new double[] { 10.0d, (-1.0d), 0.0d};
    double[] var7 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var7, var14);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var45 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var48 = new double[] { (-1.0d), (-1.0d)};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var48);
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var41, var48);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    org.apache.commons.math3.util.MathArrays.checkOrder(var52);
    double[] var58 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var62 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var65 = new double[] { (-1.0d), (-1.0d)};
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var65);
    boolean var67 = org.apache.commons.math3.util.MathArrays.equals(var58, var65);
    double[] var69 = org.apache.commons.math3.util.MathArrays.copyOf(var65, 1);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var69);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var52, var69);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var69);
    double[] var76 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var79 = new double[] { (-1.0d), (-1.0d)};
    boolean var80 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var76, var79);
    double var81 = org.apache.commons.math3.util.MathArrays.distanceInf(var72, var76);
    double[] var85 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var89 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var92 = new double[] { (-1.0d), (-1.0d)};
    boolean var93 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var89, var92);
    boolean var94 = org.apache.commons.math3.util.MathArrays.equals(var85, var92);
    double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var92, 1);
    double var97 = org.apache.commons.math3.util.MathArrays.safeNorm(var96);
    double[] var98 = org.apache.commons.math3.util.MathArrays.ebeDivide(var72, var96);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var99 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var72);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.0d, (java.lang.Number)0.1697362923985073d, false);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    double[] var12 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var16 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var19 = new double[] { (-1.0d), (-1.0d)};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var16, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var12, var19);
    double[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    double[] var27 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var31 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var34 = new double[] { (-1.0d), (-1.0d)};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var27, var34);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var34, 1);
    double var39 = org.apache.commons.math3.util.MathArrays.safeNorm(var38);
    double[][] var40 = new double[][] { var38};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var23, var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var6, var40);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    byte[] var6 = new byte[] { };
    var1.nextBytes(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.IntegerDistribution var2 = null;
//     int var3 = var0.nextInversionDeviate(var2);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    double[] var3 = new double[] { 10.0d, 10.0d, 0.0d};
    double[] var7 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var7, var14);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var18);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextF((-98.85902789850113d), (-3.956734617801294d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(12L, 12L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2024169968, (-184300078));
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var1.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    var1.setSeed(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    float var11 = var1.nextFloat();
    float var12 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.1177659f);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextGamma((-11.293482242235479d), (-66.08463703834872d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2794141797069598d);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var15 = var14.getMax();
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    long[] var17 = null;
    long[][] var18 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
    java.lang.Number var23 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + 1399632177780768928L+ "'", var23.equals(1399632177780768928L));

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextCauchy(0.0d, 1000.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(2125371022, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 511.37918087922617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-393.26173788354464d));
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var5 = var0.nextChiSquare(1.6281116695939835d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation(0, 631747952);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.203218368892643d);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getKey();
    float[] var6 = new float[] { 0.0f};
    float[] var9 = new float[] { 100.0f, (-1.0f)};
    float[] var11 = new float[] { 10.0f};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var9, var11);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var15);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var6, var11);
    float[] var23 = new float[] { 100.0f, (-1.0f)};
    float[] var25 = new float[] { 10.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var23, var25);
    float[] var29 = new float[] { 100.0f, (-1.0f)};
    float[] var31 = new float[] { 10.0f};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var29, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var29);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var11, var25);
    boolean var35 = var2.equals((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-11.703609724860312d));

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var6 = var0.nextSecureHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1865776280);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextBinomial((-1), 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//     double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var44 = new double[] { (-1.0d), (-1.0d)};
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var61 = new double[] { (-1.0d), (-1.0d)};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
//     double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
//     double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var75 = new double[] { (-1.0d), (-1.0d)};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
//     double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
//     double[] var81 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var85 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var88 = new double[] { (-1.0d), (-1.0d)};
//     boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var85, var88);
//     boolean var90 = org.apache.commons.math3.util.MathArrays.equals(var81, var88);
//     double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var88, 1);
//     double var93 = org.apache.commons.math3.util.MathArrays.safeNorm(var92);
//     double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var68, var92);
//     double var95 = org.apache.commons.math3.util.MathArrays.safeNorm(var94);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var94);
//     double[] var97 = null;
//     double[] var98 = org.apache.commons.math3.util.MathArrays.ebeDivide(var94, var97);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextGamma(1.0d, (-98.85902789850113d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.12788651403039478d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(9.874886093050462d, (-630.0848204215227d), 4.874293883290859d, 1.4062427447877337d, 3.452827866077632d, 13.603169545881526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-6168.191987338353d));

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    double[] var6 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var9 = new double[] { (-1.0d), (-1.0d)};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var9);
    java.lang.Object[] var11 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var11);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, 275296862);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("143b0403afcda0880d73281db0deb0074bcb920e831abe6991789f9ec45758562b34e2c899adb3340fa035793a9c5178fd4a", "c9c1e206440d2f0b869a56ba29e877cf4d26a95f179b237eb2fa547b20003c0a0da1668b6bd8540a9b5f42c46771044185bf");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 6.715825704804095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "34f85a28c40327ee4551fa451aa9bcd72c85ea18776cdaa0efcc61014a817561d28a8d5c76fa4008ab156d32ee931841edf9"+ "'", var6.equals("34f85a28c40327ee4551fa451aa9bcd72c85ea18776cdaa0efcc61014a817561d28a8d5c76fa4008ab156d32ee931841edf9"));
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var75 = new double[] { (-1.0d), (-1.0d)};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
    double[] var81 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var85 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var88 = new double[] { (-1.0d), (-1.0d)};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var85, var88);
    boolean var90 = org.apache.commons.math3.util.MathArrays.equals(var81, var88);
    double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var88, 1);
    double var93 = org.apache.commons.math3.util.MathArrays.safeNorm(var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var68, var92);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 631747952);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(110, (-10061.775830036235d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 240.77635671896624d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.022305919091161315d);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextBeta(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.nextSecureHexString((-528848821));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.nextCauchy(0.0d, (-6168.191987338353d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(1179441559, 1179441559);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 601.3085707685499d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.11562156810421995d);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     int[] var14 = new int[] { 1, 0, (-1)};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
//     int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var21 = var18.nextPermutation(100, 100);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var7, var21);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(0);
//     double var25 = var24.nextGaussian();
//     double var26 = var24.nextGaussian();
//     int[] var30 = new int[] { 1, 0, (-1)};
//     int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
//     var24.setSeed(var30);
//     int[] var37 = new int[] { 1, 0, (-1)};
//     int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
//     int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var37);
//     org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(0);
//     double var43 = var42.nextGaussian();
//     double var44 = var42.nextGaussian();
//     int[] var48 = new int[] { 1, 0, (-1)};
//     int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
//     var42.setSeed(var48);
//     org.apache.commons.math3.random.Well19937c var53 = new org.apache.commons.math3.random.Well19937c(0);
//     double var54 = var53.nextGaussian();
//     double var55 = var53.nextGaussian();
//     int[] var59 = new int[] { 1, 0, (-1)};
//     int[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var59, 1);
//     var53.setSeed(var59);
//     int var63 = org.apache.commons.math3.util.MathArrays.distanceInf(var48, var59);
//     double var64 = org.apache.commons.math3.util.MathArrays.distance(var30, var59);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var65 = org.apache.commons.math3.util.MathArrays.distance(var21, var59);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 162);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.0d);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextHypergeometric(275296862, 631747952, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.isMonotonic(var14, var15, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var14);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(1);
    double var10 = var1.nextDouble();
    int[] var11 = null;
    var1.setSeed(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2787313252014696d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextBinomial((-528848821), 0.1697362923985073d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)120.65610151834143d, (java.lang.Number)10.0f, true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(0);
    double var19 = var18.nextGaussian();
    double var20 = var18.nextGaussian();
    int[] var24 = new int[] { 1, 0, (-1)};
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 1);
    var18.setSeed(var24);
    int[] var31 = new int[] { 1, 0, (-1)};
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    int var34 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var31);
    double var35 = org.apache.commons.math3.util.MathArrays.distance(var16, var31);
    int[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    int var37 = org.apache.commons.math3.util.MathArrays.distance1(var7, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)275296862, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)33.67095195679566d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    var0.reSeedSecure();
    var0.reSeed(848835256306514304L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var0.nextPascal(0, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.05185587726462d));

  }

//  public void test179() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
//
//
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//    double var2 = var1.nextGaussian();
//    double var3 = var1.nextGaussian();
//    int[] var7 = new int[] { 1, 0, (-1)};
//    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//    var1.setSeed(var7);
//    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
//    double var13 = var12.nextGaussian();
//    double var14 = var12.nextGaussian();
//    int[] var18 = new int[] { 1, 0, (-1)};
//    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
//    var12.setSeed(var18);
//    int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var18);
//    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 631747952);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var2 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var3 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var18);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var20);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var22 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var23);
//
//  }
//
  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var5 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var9 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)10L);
    var2.addSuppressed((java.lang.Throwable)var9);
    java.lang.Object var11 = null;
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair((java.lang.Object)var9, var11);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.0d), (-11.293482242235479d), 0.39543159219858365d, 3.452827866077632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12.658839462906196d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-10.492720870205883d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 71.27252655213718d);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextBeta((-2.940839070076483d), 4.874293883290859d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1322118006);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var7, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 2099284361, (-1));
    int var4 = var3.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
    int[] var21 = new int[] { 1, 0, (-1)};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var21);
    int var25 = org.apache.commons.math3.util.MathArrays.distance1(var7, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextPascal(1179441559, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 0.13996529155952087d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextF(0.16021426377524167d, 2.7497630628293734d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var4.nextHexString(2024169968);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.020945796376795382d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    java.lang.Number var4 = var3.getMin();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextPascal(2147483647, 48.550599067346205d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    boolean var7 = var6.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-184300078));

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextT((-98.85902789850113d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 474L);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextCauchy(0.0d, 1000.0d);
//     org.apache.commons.math3.distribution.IntegerDistribution var9 = null;
//     int var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.0386695297463309d));

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextLong(3976504751842537792L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 909.4055543638262d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.12588627525268536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8.042292549971673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-59.21291486486284d));
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.2793342356121425d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)(-1.0f), (java.lang.Number)(byte)1);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0f)+ "'", var5.equals((-1.0f)));

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(2125371022);
    float var2 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.468529f);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextLong(1399632177780768928L, 10L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(10, 2147483647);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6, 2099284361);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     var0.reSeed(1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 575.3928572028764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.18528098186661676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException(var0, var1);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    double var2 = var1.nextDouble();
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2395389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 275296862);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.020945796376795382d, 990.5444466590764d, 0.33904363745058674d, 122.12396088898325d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 62.15309420156054d);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt((-1), 2125371022);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform((-98.85902789850113d), (-266.3994807003071d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 890480056);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var75 = new double[] { (-1.0d), (-1.0d)};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 631747952);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2.0d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)100);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.nextBinomial((-528848821), 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var0.nextPermutation(1, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(308.199125549581d, (-266.3994807003071d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.04237406002282797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var4.nextBinomial(1819577945, 48.550599067346205d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    int var3 = var1.nextInt(2125371022);
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2099284361);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 259766232686583471L);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getStrict();
    java.lang.Number var7 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1+ "'", var7.equals(1));

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     double var11 = var0.nextUniform((-11.293482242235479d), 0.33272672175073054d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 0);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    int var4 = var1.nextPascal(275296862, 0.05063040741363588d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    double[] var5 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var8 = new double[] { (-1.0d), (-1.0d)};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    java.lang.Object[] var10 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var10);
    org.apache.commons.math3.exception.MathArithmeticException var12 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var10);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var12.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getSecond();
    java.lang.Object var12 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10.0d+ "'", var11.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     double[] var6 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var9 = new double[] { (-1.0d), (-1.0d)};
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var9);
//     java.lang.Object[] var11 = new java.lang.Object[] { var9};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)375.6315311789929d, var11);
//     org.apache.commons.math3.exception.util.Localizable var14 = null;
//     long[] var15 = new long[] { };
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var15);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var15);
//     long[][] var18 = new long[][] { var15};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var13, var14, (java.lang.Object[])var18);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var14 = var0.nextExponential(219.80508910257697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform((-1.8066441508022335d), (-75.50392116110793d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 855.7491464373812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7221559560380385d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.534587917019962d);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var15 = var14.getMax();
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    long[] var17 = null;
    long[][] var18 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
    java.lang.Number var23 = var3.getHi();
    java.lang.Number var24 = var3.getHi();
    java.lang.Number var25 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 1399632177780768928L+ "'", var25.equals(1399632177780768928L));

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT((-8.05185587726462d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-344.2497233344407d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4.874293883290859d, (java.lang.Number)(-1L), true);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var34 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var18, var29);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull((-66.08463703834872d), (-0.27096157230053536d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 17.48415129527817d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e"+ "'", var6.equals("e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var11.nextUniform(0.1697362923985073d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var8);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var8, var17);
    float[] var20 = null;
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var8, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextGamma((-11.293482242235479d), 0.05063040741363588d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2024169968, 10);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(10.0d, (-1.246395958433071d), 0.0d, 122.12396088898325d, 0.2395389662180223d, 0.5131366286482398d, 0.33732388204490654d, 939.2076725668584d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 304.47613478983845d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    java.lang.Object[] var10 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathArithmeticException var11 = new org.apache.commons.math3.exception.MathArithmeticException(var4, var10);
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)375.6315311789929d, var10);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var11.nextSecureHexString((-528848821));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    long var4 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-791562805055479252L));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1), (java.lang.Number)9128399031861897490L, (java.lang.Number)1.0d);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure();
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 782409001);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double[] var5 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var8 = new double[] { (-1.0d), (-1.0d)};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d)};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var26);
    double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var5, var28);
    double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var36 = new double[] { (-1.0d), (-1.0d)};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var39 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var28, var38);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.39543159219858365d, 1.8301900518845509d, 375.6315311789929d, (-0.27096157230053536d), 0.08679600259959512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 687.4535731566205d);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0f);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var2.nextT(0.33272672175073054d);
//     org.apache.commons.math3.util.Pair var5 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.0f, (java.lang.Object)var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12.57359046654414d);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(40.53524660505049d, (-3.956734617801294d), 12.658839462906196d, 0.0d, 0.9802138153623559d, 0.9802138153623559d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-159.42639435948843d));

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//     double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var44 = new double[] { (-1.0d), (-1.0d)};
//     boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
//     double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//     double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var61 = new double[] { (-1.0d), (-1.0d)};
//     boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
//     boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
//     double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
//     double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var75 = new double[] { (-1.0d), (-1.0d)};
//     boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
//     double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
//     double[] var81 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var85 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var88 = new double[] { (-1.0d), (-1.0d)};
//     boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var85, var88);
//     boolean var90 = org.apache.commons.math3.util.MathArrays.equals(var81, var88);
//     double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var88, 1);
//     double var93 = org.apache.commons.math3.util.MathArrays.safeNorm(var92);
//     double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var68, var92);
//     double var95 = org.apache.commons.math3.util.MathArrays.safeNorm(var94);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var94);
//     double[] var97 = null;
//     double[] var98 = org.apache.commons.math3.util.MathArrays.ebeAdd(var94, var97);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextHypergeometric(2125371022, (-1), 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var14 = var0.nextExponential(219.80508910257697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextF(0.0d, 1.7084569304728279d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 665.7256308162749d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.14442313687124933d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 123.25370262449428d);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var26 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var3, var23);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextHypergeometric(1, 2024169968, 2024169968);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6508018156619827d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextBeta(739.9960916531347d, (-6.27174892868895d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)259766232686583471L, (java.lang.Number)2125371022, false);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(1819577945, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1483922953);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0d), (java.lang.Number)100, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    float var8 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.51857734f);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0.40877557f};
    double[] var5 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var5, var12);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 1);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var33);
    double[] var39 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var43 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d)};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var39, var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 1);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var56 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var60 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var63 = new double[] { (-1.0d), (-1.0d)};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var56, var63);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var63, 1);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var50, var67);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var76 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var77 = var76.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var79 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var77, true);
    boolean var81 = org.apache.commons.math3.util.MathArrays.isMonotonic(var69, var77, false);
    boolean var84 = org.apache.commons.math3.util.MathArrays.checkOrder(var16, var77, false, false);
    boolean var86 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var77, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure();
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 110);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//     double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d)};
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var21 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var11);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)10};
//     var1.nextBytes(var7);
//     double var9 = var1.nextGaussian();
//     java.util.List var10 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var11 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy((-10019.332251989288d), 0.16021426377524167d);
    double var13 = var4.nextGamma(0.33732388204490654d, 1.908642352606886d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var4.nextHypergeometric(0, 0, 1009135716);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-10019.276570315034d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.06400839652217086d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.nextHypergeometric(110, 100, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy((-10019.332251989288d), 0.16021426377524167d);
    long var12 = var4.nextPoisson(0.2793342356121425d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-10019.276570315034d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0L);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 1+ "'", var6.equals(1));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextF(0.16021426377524167d, 2.7497630628293734d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var4.nextHypergeometric(0, 2125371022, 1179441559);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.020945796376795382d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var9 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    boolean var12 = org.apache.commons.math3.util.MathArrays.isMonotonic(var9, var10, false);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = null;
    double[] var19 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var23 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d)};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var19, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var36 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var40 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var43 = new double[] { (-1.0d), (-1.0d)};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var36, var43);
    double[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 1);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var30, var47);
    double[] var53 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var57 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var60 = new double[] { (-1.0d), (-1.0d)};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var57, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var53, var60);
    double[] var64 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 1);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var64);
    org.apache.commons.math3.util.MathArrays.checkOrder(var64);
    double[] var70 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var74 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var77 = new double[] { (-1.0d), (-1.0d)};
    boolean var78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var74, var77);
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var70, var77);
    double[] var81 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 1);
    double var82 = org.apache.commons.math3.util.MathArrays.safeNorm(var81);
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var64, var81);
    double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var49, var81);
    double[][] var85 = new double[][] { var81};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var15, var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var85);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     int[] var14 = new int[] { 1, 0, (-1)};
//     int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
//     int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
//     org.apache.commons.math3.random.RandomDataImpl var18 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var21 = var18.nextPermutation(100, 100);
//     int var22 = org.apache.commons.math3.util.MathArrays.distance1(var7, var21);
//     int[] var26 = new int[] { 1, 0, (-1)};
//     int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
//     org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(var26);
//     int var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 176);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var0.nextHexString(2099284361);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var75 = new double[] { (-1.0d), (-1.0d)};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var72, 548028350);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextF((-98.85902789850113d), (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d)};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    org.apache.commons.math3.util.MathArrays.checkOrder(var24);
    double[] var30 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var34 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var37 = new double[] { (-1.0d), (-1.0d)};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var30, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var41);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var47 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var48 = var47.getDirection();
    double[] var52 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var56 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var59 = new double[] { (-1.0d), (-1.0d)};
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var56, var59);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var52, var59);
    double[] var63 = org.apache.commons.math3.util.MathArrays.copyOf(var59, 1);
    double[] var67 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var71 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var74 = new double[] { (-1.0d), (-1.0d)};
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var71, var74);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var67, var74);
    double[] var78 = org.apache.commons.math3.util.MathArrays.copyOf(var74, 1);
    double var79 = org.apache.commons.math3.util.MathArrays.safeNorm(var78);
    double[][] var80 = new double[][] { var78};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var63, var80);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var24, var48, var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var83 = org.apache.commons.math3.util.MathArrays.linearCombination(var2, var24);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    java.lang.Object[] var13 = new java.lang.Object[] { var11};
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var13);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)375.6315311789929d, var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var13);
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy(0.5131366286482398d, 0.18528098186661676d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var13 = var4.nextLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5775301166847077d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("hi!", "org.apache.commons.math3.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (null)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var23 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var27 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var30 = new double[] { (-1.0d), (-1.0d)};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var23, var30);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    org.apache.commons.math3.util.MathArrays.checkOrder(var34);
    double[] var40 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var44 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var47 = new double[] { (-1.0d), (-1.0d)};
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var40, var47);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 1);
    double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var34, var51);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var57 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var58 = var57.getDirection();
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double[] var77 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var81 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var84 = new double[] { (-1.0d), (-1.0d)};
    boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var81, var84);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var77, var84);
    double[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var84, 1);
    double var89 = org.apache.commons.math3.util.MathArrays.safeNorm(var88);
    double[][] var90 = new double[][] { var88};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var73, var90);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var34, var58, var90);
    org.apache.commons.math3.exception.NotFiniteNumberException var93 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)1, (java.lang.Object[])var90);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.nextBeta(990.5444466590764d, (-10019.276570315034d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var14 = var0.nextExponential(219.80508910257697d);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var0.nextSample(var15, 2125371022);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 275296862);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    double var11 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.4948515015507633d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)110);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    int var14 = var4.nextBinomial(1, 0.16021426377524167d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var4.nextUniform(0.46038522946044763d, (-75.50392116110793d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.05185587726462d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)259766232686583471L, 2147483647);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var14);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    double var13 = var4.nextCauchy(1.8288931765060235d, 1.8301900518845509d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var4.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.3438501360557338d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)40.53524660505049d, (java.lang.Number)990.5444466590764d, true);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var13, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)(byte)0, (-184300078), var13, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-159.42639435948843d), (java.lang.Number)(-266.3994807003071d), 0, var13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("01f7639d7e", "6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.5355906107769632d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "85bc92b1aed84db3cd65223c4d1586eed817bf6b8bdc66996a2f511594e93eaf90ec31ec0561434d7c80d0a35e119def4f49"+ "'", var6.equals("85bc92b1aed84db3cd65223c4d1586eed817bf6b8bdc66996a2f511594e93eaf90ec31ec0561434d7c80d0a35e119def4f49"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 11L);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     double var6 = var0.nextChiSquare(35.85347665729908d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(0.0d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 440667481);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 34.46100311572474d);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)10.0f, 100);
//     boolean var5 = var4.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var4.getDirection();
//     boolean var8 = org.apache.commons.math3.util.MathArrays.isMonotonic(var0, var6, true);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var6, var26);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     double var11 = var0.nextUniform((-11.293482242235479d), 0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT((-630.0848204215227d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 25.44523356544166d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "f"+ "'", var6.equals("f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9817991242736026d));
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma((-98.85902789850113d), 77.69947062706046d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 29.554439860790463d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextSecureInt(0, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 43.022051776270295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3871274815250272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.954820237634364d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-19.31401039376143d));
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var12.nextChiSquare((-266.3994807003071d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextPascal(110, (-266.3994807003071d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.6124426586748855d);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     int[] var1 = null;
//     var0.setSeed(var1);
//     java.util.List var3 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var4 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var0, var3);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var32 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var36 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var39 = new double[] { (-1.0d), (-1.0d)};
    boolean var40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var36, var39);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var32, var39);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 1);
    double var44 = org.apache.commons.math3.util.MathArrays.safeNorm(var43);
    org.apache.commons.math3.util.MathArrays.checkOrder(var43);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeAdd(var27, var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.1697362923985073d, (-11.293482242235479d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 628.6068718539391d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.7159604646229247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.3054855752092d);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextSecureInt(435864187, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(-1.246395958433071d), true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.246395958433071d)+ "'", var5.equals((-1.246395958433071d)));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt((-1), 2125371022);
//     var0.reSeed(416L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1628920123);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var0, 575.3928572028764d);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     double var10 = var0.nextGaussian((-266.3994807003071d), 21.273116565335737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.806445132111327E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-260.9588833271992d));
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var2 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("", "01f7639d7e");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "6d44a76160"+ "'", var3.equals("6d44a76160"));
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1995398530);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextSecureInt(2099284361, 1745570210);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1675400647);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextChiSquare((-1040.9625410266885d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1888504336);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var0.nextHexString((-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 14.132499022172034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "145da5884704c7dec3910041707c794dc58722567b37d94d470ab502c5100fccc188b77fd54da8cc62502fd57af8eb21671a"+ "'", var6.equals("145da5884704c7dec3910041707c794dc58722567b37d94d470ab502c5100fccc188b77fd54da8cc62502fd57af8eb21671a"));
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)10, (java.lang.Number)(short)(-1), false);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException();
//     org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
//     java.lang.Object[] var9 = new java.lang.Object[] { var7};
//     org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var6, var9);
//     org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var9);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var0.nextSecureLong(53686164009667304L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c9c1e206440d2f0b869a56ba29e877cf4d26a95f179b237eb2fa547b20003c0a0da1668b6bd8540a9b5f42c46771044185bf", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6799801769427888d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var12.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var13, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)(byte)(-1), 2099284361, var13, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.020945796376795382d, (java.lang.Number)0.46038522946044763d, 2024169968, var13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    java.lang.Number var4 = var3.getMin();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
//     double var13 = var12.nextGaussian();
//     double var14 = var12.nextGaussian();
//     int[] var18 = new int[] { 1, 0, (-1)};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
//     var12.setSeed(var18);
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var18);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var24 = null;
//     int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var24);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
//     java.lang.Number var4 = var3.getMin();
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     double[] var8 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     boolean var11 = org.apache.commons.math3.util.MathArrays.isMonotonic(var8, var9, false);
//     java.lang.Object[] var12 = new java.lang.Object[] { var11};
//     org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var6, var12);
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, var12);
//     org.apache.commons.math3.exception.util.ExceptionContext var15 = var14.getContext();
//     java.lang.String var16 = var14.toString();
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var0.nextBinomial(176, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
//     var0.reSeed((-1L));
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 176);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)848835256306514304L);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextPascal(1, (-11.293482242235479d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4302.386311063859d);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    var0.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var11.nextSecureHexString((-194062463));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var9 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)10L);
    var2.addSuppressed((java.lang.Throwable)var9);
    java.lang.Number var11 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextPoisson((-1.0d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 784.4033652473677d);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextGamma(40.99947359710616d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.9815090229707755d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-184300078), (java.lang.Number)(-163904641), true);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var13, var14, false);
    java.lang.Object[] var17 = new java.lang.Object[] { var16};
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var11, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var17);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var3, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)2147483647, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var23 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.51857734f, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)21L);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1.0f, (java.lang.Number)(-1L), true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1L)+ "'", var6.equals((-1L)));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     int var8 = var0.nextInt(275296862, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(166959353, (-163904641));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1169011169);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGamma(12.658839462906196d, (-10.387394611748993d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 476L);
// 
//   }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(1000.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(435864187, 1745570210, 2125371022);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.27947882673329905d));
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextGamma((-10061.775830036235d), 216.6827952125197d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    float var11 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    double var14 = var13.nextGaussian();
    double var15 = var13.nextGaussian();
    var13.setSeed((-1));
    byte[] var21 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var13.nextBytes(var21);
    var1.nextBytes(var21);
    org.apache.commons.math3.random.RandomDataImpl var24 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var24.nextWeibull((-630.0848204215227d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var18 = var0.nextSecureLong((-2678358548675784704L), 300L);
//     double var21 = var0.nextCauchy(1.4062427447877337d, 40.99947359710616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 522.589744828329d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.2566940702719748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.254354031734219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-42.4140547575466d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-2508567299728403968L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-9.762994102622386d));
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getValue();
    java.lang.Number var14 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var14, false);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var16);
    boolean var18 = var16.getBoundIsAllowed();
    boolean var19 = var2.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0d+ "'", var12.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)(-1.246395958433071d), true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

//  public void test342() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
//
//
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//    double var2 = var1.nextGaussian();
//    double var3 = var1.nextGaussian();
//    int[] var7 = new int[] { 1, 0, (-1)};
//    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//    var1.setSeed(var7);
//    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
//    double var13 = var12.nextGaussian();
//    double var14 = var12.nextGaussian();
//    int[] var18 = new int[] { 1, 0, (-1)};
//    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
//    var12.setSeed(var18);
//    int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var18);
//    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(0);
//    double var27 = var26.nextGaussian();
//    float var28 = var26.nextFloat();
//    var26.setSeed(10L);
//    float var31 = var26.nextFloat();
//    float var32 = var26.nextFloat();
//    org.apache.commons.math3.random.Well19937c var34 = new org.apache.commons.math3.random.Well19937c(0);
//    double var35 = var34.nextGaussian();
//    double var36 = var34.nextGaussian();
//    int[] var40 = new int[] { 1, 0, (-1)};
//    int[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
//    var34.setSeed(var40);
//    int[] var47 = new int[] { 1, 0, (-1)};
//    int[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 1);
//    int var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var40, var47);
//    org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(0);
//    double var53 = var52.nextGaussian();
//    double var54 = var52.nextGaussian();
//    int[] var58 = new int[] { 1, 0, (-1)};
//    int[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 1);
//    var52.setSeed(var58);
//    org.apache.commons.math3.random.Well19937c var63 = new org.apache.commons.math3.random.Well19937c(0);
//    double var64 = var63.nextGaussian();
//    double var65 = var63.nextGaussian();
//    int[] var69 = new int[] { 1, 0, (-1)};
//    int[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
//    var63.setSeed(var69);
//    int var73 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var69);
//    double var74 = org.apache.commons.math3.util.MathArrays.distance(var40, var69);
//    org.apache.commons.math3.random.Well19937c var75 = new org.apache.commons.math3.random.Well19937c(var40);
//    var26.setSeed(var40);
//    int var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var40);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 998139946);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var2 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var3 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var13 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var18);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var20);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var22 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var23);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var24);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var27 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var28 == 0.9570892f);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var31 == 0.40877557f);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var32 == 0.23239756f);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var35 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var36 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var40);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var42);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var47);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var49);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var50 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var53 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var54 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var58);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var60);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var64 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var65 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var69);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var71);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var73 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var74 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var77 == 0);
//
//  }
//
  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    float var11 = var1.nextFloat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.49485147f);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.7084569304728279d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var8);
    float[] var14 = new float[] { 0.0f};
    float[] var17 = new float[] { 100.0f, (-1.0f)};
    float[] var19 = new float[] { 10.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    float[] var23 = new float[] { 100.0f, (-1.0f)};
    float[] var25 = new float[] { 10.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var23, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var23);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var19);
    float[] var32 = new float[] { 100.0f, (-1.0f)};
    float[] var34 = new float[] { 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var32, var34);
    float[] var38 = new float[] { 100.0f, (-1.0f)};
    float[] var40 = new float[] { 10.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var38, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var38);
    float[] var44 = new float[] { 0.0f};
    float[] var47 = new float[] { 100.0f, (-1.0f)};
    float[] var49 = new float[] { 10.0f};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var47, var49);
    float[] var53 = new float[] { 100.0f, (-1.0f)};
    float[] var55 = new float[] { 10.0f};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var53, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var53);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var44, var49);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var49);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var34);
    float[] var63 = new float[] { 100.0f, (-1.0f)};
    float[] var65 = new float[] { 10.0f};
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var63, var65);
    float[] var69 = new float[] { 100.0f, (-1.0f)};
    float[] var71 = new float[] { 10.0f};
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var69, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var65, var69);
    float[] var76 = new float[] { 100.0f, (-1.0f)};
    float[] var78 = new float[] { 10.0f};
    boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var76, var78);
    boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var69, var78);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)10.0f, 100);
    int var4 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var5, var12);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 1);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var33);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var16);
    double[] var39 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 21.273116565335737d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.nextCauchy((-6168.191987338353d), (-11.293482242235479d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.nextBinomial(100, 48.550599067346205d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-246349375317088864L));

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var8 = var7.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var8, true);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0, var8, true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2147483647, (java.lang.Number)430656544, (java.lang.Number)9.874886093050462d);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     int var10 = var0.nextBinomial(1819577945, 0.2395389662180223d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation((-163904641), (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.7193889778286362d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 435842537);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var13 = var4.nextCauchy(0.9426571811852562d, (-26.249224039236346d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var14 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var18 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var21 = new double[] { (-1.0d), (-1.0d)};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var14, var21);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    double var26 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var25);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    org.apache.commons.math3.util.MathArrays.checkOrder(var44);
    double[] var50 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var54 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var57 = new double[] { (-1.0d), (-1.0d)};
    boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var57);
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var50, var57);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var57, 1);
    double var62 = org.apache.commons.math3.util.MathArrays.safeNorm(var61);
    double[] var63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var44, var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var64 = org.apache.commons.math3.util.MathArrays.linearCombination(var9, var63);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 375.6315311789929d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    long var12 = var4.nextPoisson(1000.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var4.nextPascal(1745570210, (-3.956734617801294d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1008L);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric((-194062463), 1995398530, 875017788);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 811.7850850836546d);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    long var6 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 7540580061456263210L);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-10.387394611748993d), (-11.703609724860312d), 0.0d, (-26.249224039236346d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 121.57001259402712d);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     var0.reSeedSecure();
//     org.apache.commons.math3.distribution.RealDistribution var4 = null;
//     double var5 = var0.nextInversionDeviate(var4);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var8 = null;
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var11, false);
    double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    double[] var19 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var23 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d)};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var19, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    org.apache.commons.math3.util.MathArrays.checkOrder(var30);
    double[] var36 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var40 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var43 = new double[] { (-1.0d), (-1.0d)};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var40, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var36, var43);
    double[] var47 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 1);
    double var48 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var30, var47);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var52 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var6, var30);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var15 = var14.getMax();
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    long[] var17 = null;
    long[][] var18 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
    java.lang.Number var23 = var3.getHi();
    java.lang.Number var24 = var3.getLo();
    java.lang.Number var25 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + 1399632177780768928L+ "'", var24.equals(1399632177780768928L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double var8 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.00999950005d);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextInt(1179441559, 110);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7185749323041478d));
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-3.956734617801294d));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-1L));
    double var2 = var1.nextDouble();
    int var3 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2395389662180223d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1689900776);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var8);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var8, var17);
    float[] var22 = new float[] { 100.0f, (-1.0f)};
    float[] var24 = new float[] { 10.0f};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var22, var24);
    float[] var28 = new float[] { 100.0f, (-1.0f)};
    float[] var30 = new float[] { 10.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var28, var30);
    float[] var34 = new float[] { 100.0f, (-1.0f)};
    float[] var36 = new float[] { 10.0f};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var34, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var34);
    float[] var41 = new float[] { 100.0f, (-1.0f)};
    float[] var43 = new float[] { 10.0f};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var34, var43);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var24, var34);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var17, var24);
    float[] var49 = new float[] { 0.0f};
    float[] var52 = new float[] { 100.0f, (-1.0f)};
    float[] var54 = new float[] { 10.0f};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var52, var54);
    float[] var58 = new float[] { 100.0f, (-1.0f)};
    float[] var60 = new float[] { 10.0f};
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var58, var60);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var58);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var49, var54);
    float[] var66 = new float[] { 100.0f, (-1.0f)};
    float[] var68 = new float[] { 10.0f};
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var66, var68);
    float[] var72 = new float[] { 100.0f, (-1.0f)};
    float[] var74 = new float[] { 10.0f};
    boolean var75 = org.apache.commons.math3.util.MathArrays.equals(var72, var74);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var72);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var54, var68);
    boolean var78 = org.apache.commons.math3.util.MathArrays.equals(var17, var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextExponential(0.06400839652217086d);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var8 = var7.getIndex();
    var3.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var7.getDirection();
    java.lang.Number var11 = var7.getPrevious();
    boolean var12 = var7.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 1+ "'", var11.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(1745570210, (-8.05185587726462d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-10.276756760873262d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-24.904063548399087d));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    float[] var1 = new float[] { 0.0f};
    float[] var4 = new float[] { 100.0f, (-1.0f)};
    float[] var6 = new float[] { 10.0f};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var4, var6);
    float[] var10 = new float[] { 100.0f, (-1.0f)};
    float[] var12 = new float[] { 10.0f};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var10, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var10);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var1, var6);
    float[] var18 = new float[] { 100.0f, (-1.0f)};
    float[] var20 = new float[] { 10.0f};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equals(var18, var20);
    float[] var24 = new float[] { 100.0f, (-1.0f)};
    float[] var26 = new float[] { 10.0f};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var24, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var24);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var6, var20);
    float[] var32 = new float[] { 100.0f, (-1.0f)};
    float[] var34 = new float[] { 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var32, var34);
    float[] var38 = new float[] { 100.0f, (-1.0f)};
    float[] var40 = new float[] { 10.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var38, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var38);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    java.lang.Object[] var12 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)375.6315311789929d, var12);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.2566940702719748d, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)48.550599067346205d, (java.lang.Number)275296862, true);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(-10061.775830036235d), (java.lang.Number)0.01237694884401451d, (java.lang.Number)3.452827866077632d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    int var5 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 275296862);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     java.util.Collection var3 = null;
//     java.lang.Object[] var5 = var0.nextSample(var3, 782409001);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var17 = null;
//     int var18 = var0.nextInversionDeviate(var17);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    double[] var4 = null;
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var4, var6);
    double[] var13 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 375.6315311789929d);
    boolean var14 = var2.equals((java.lang.Object)var6);
    java.lang.Object var15 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy((-10019.332251989288d), 0.16021426377524167d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextChiSquare((-27.221845415161912d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-10019.276570315034d));

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getKey();
    java.lang.Object var14 = var2.getValue();
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(0);
    double var17 = var16.nextGaussian();
    float var18 = var16.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var19 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var16);
    double var22 = var19.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var26 = var19.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    boolean var27 = var2.equals((java.lang.Object)(-11.293482242235479d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 10.0d+ "'", var14.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-8.05185587726462d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure((-1L));
//     java.lang.String var11 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(153, 0, 1009135716);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9043696818788518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "7"+ "'", var11.equals("7"));
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     double var13 = var0.nextChiSquare(6.401745123441823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 228.5581296305497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5820250808619595d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-3.507053523554667d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.0347032432247736d);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextBeta((-1.246395958433071d), 990.5444466590764d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 398.55585272786413d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.24409050520938688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.1894085736399644d);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double[] var15 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var16 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var14, var15);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var3, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.isMonotonic(var19, var20, false);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    double[] var29 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var36 = new double[] { (-1.0d), (-1.0d)};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var29, var36);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var46 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var50 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var53 = new double[] { (-1.0d), (-1.0d)};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var46, var53);
    double[] var57 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 1);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var40, var57);
    double[] var63 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var67 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var70 = new double[] { (-1.0d), (-1.0d)};
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var70);
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var63, var70);
    double[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var70, 1);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var80 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var84 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var87 = new double[] { (-1.0d), (-1.0d)};
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var84, var87);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var80, var87);
    double[] var91 = org.apache.commons.math3.util.MathArrays.copyOf(var87, 1);
    double var92 = org.apache.commons.math3.util.MathArrays.safeNorm(var91);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var74, var91);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var59, var91);
    double[][] var95 = new double[][] { var91};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var25, var95);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var15, var95);
    org.apache.commons.math3.exception.NullArgumentException var98 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     double[] var11 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     boolean var14 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var12, false);
//     java.lang.Object[] var15 = new java.lang.Object[] { var14};
//     org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var9, var15);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var8, var15);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var7, var15);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    double[] var4 = null;
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var4, var6);
    double[] var13 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 375.6315311789929d);
    boolean var14 = var2.equals((java.lang.Object)var6);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)100);
    boolean var3 = var2.getBoundIsAllowed();
    java.lang.Number var4 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100+ "'", var4.equals(100));

  }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var17 = var0.nextPoisson(3.452827866077632d);
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextPascal(1835266026, (-5.075035468950752d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 264.7305266158252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3144016261483006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.6950601243856753d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-32.87924195512489d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 3L);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(short)10, (java.lang.Number)(short)(-1), false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     double var7 = var0.nextGaussian((-260.9588833271992d), 0.39543159219858365d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextGaussian(0.3438501360557338d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 179033452);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-260.9284884798743d));
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getKey();
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    java.lang.Object[] var18 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var19 = new org.apache.commons.math3.exception.NotFiniteNumberException(var15, (java.lang.Number)100, var18);
    org.apache.commons.math3.exception.NullArgumentException var20 = new org.apache.commons.math3.exception.NullArgumentException(var14, var18);
    boolean var21 = var2.equals((java.lang.Object)var18);
    java.lang.Object var22 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + 10.0d+ "'", var22.equals(10.0d));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100L+ "'", var5.equals(100L));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    long var12 = var4.nextPoisson(1000.0d);
    var4.reSeed((-246349375317088864L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1008L);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d)};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    org.apache.commons.math3.util.MathArrays.checkOrder(var24);
    double[] var30 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var34 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var37 = new double[] { (-1.0d), (-1.0d)};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var30, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var41);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = var50.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var53 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var51, true);
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var43, var51, false);
    double[] var59 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var63 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d)};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var63, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var59, var66);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 1);
    double[] var74 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var78 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var81 = new double[] { (-1.0d), (-1.0d)};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var78, var81);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var74, var81);
    double[] var85 = org.apache.commons.math3.util.MathArrays.copyOf(var81, 1);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
    double[][] var87 = new double[][] { var85};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var70, var87);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var87);
    double[] var91 = org.apache.commons.math3.util.MathArrays.normalizeArray(var43, 0.020945796376795382d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var92 = org.apache.commons.math3.util.MathArrays.linearCombination(var2, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(0.054710775280049806d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.072050751015354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "0"+ "'", var6.equals("0"));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(0);
    double var20 = var19.nextGaussian();
    double var21 = var19.nextGaussian();
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    var19.setSeed(var25);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(0);
    double var31 = var30.nextGaussian();
    double var32 = var30.nextGaussian();
    int[] var36 = new int[] { 1, 0, (-1)};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    var30.setSeed(var36);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var7, var36);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var7);
    org.apache.commons.math3.random.Well19937c var43 = new org.apache.commons.math3.random.Well19937c(var7);
    var43.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    int var8 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0, 10);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.clear();
    int var5 = var1.nextInt();
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    double var8 = var7.nextGaussian();
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(0);
    double var11 = var10.nextGaussian();
    double var12 = var10.nextGaussian();
    int[] var16 = new int[] { 1, 0, (-1)};
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 1);
    var10.setSeed(var16);
    float var20 = var10.nextFloat();
    org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(0);
    double var23 = var22.nextGaussian();
    double var24 = var22.nextGaussian();
    var22.setSeed((-1));
    byte[] var30 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var22.nextBytes(var30);
    var10.nextBytes(var30);
    var7.nextBytes(var30);
    var1.nextBytes(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-184300078));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException(var0);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure((-1L));
//     int var13 = var0.nextHypergeometric(2147483647, 0, 875017788);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(0.2793342356121425d, 0.2566940702719748d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-20.13107623366162d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getKey();
    java.lang.Object var6 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(0);
    double var9 = var8.nextGaussian();
    double var10 = var8.nextGaussian();
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    var8.setSeed(var14);
    int[] var21 = new int[] { 1, 0, (-1)};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    int var24 = org.apache.commons.math3.util.MathArrays.distanceInf(var14, var21);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(0);
    double var27 = var26.nextGaussian();
    double var28 = var26.nextGaussian();
    int[] var32 = new int[] { 1, 0, (-1)};
    int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 1);
    var26.setSeed(var32);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(0);
    double var38 = var37.nextGaussian();
    double var39 = var37.nextGaussian();
    int[] var43 = new int[] { 1, 0, (-1)};
    int[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var43, 1);
    var37.setSeed(var43);
    int var47 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var43);
    double var48 = org.apache.commons.math3.util.MathArrays.distance(var14, var32);
    var1.setSeed(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextPascal(3, 1.7084569304728279d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var3.getDirection();
    java.lang.Number var8 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1+ "'", var8.equals(1));

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1008L);
    double var2 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6513177047637154d);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var17 = var0.nextPoisson(3.452827866077632d);
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextPoisson((-0.5996555078851037d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 280.8555676337458d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.23534219182028743d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6.049552680256283d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-69.22256393232497d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 5L);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    long var12 = var4.nextPoisson(1000.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var15 = var4.nextPermutation((-528848821), 10);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1008L);

  }

  public void test414() throws Throwable {

    // if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    // org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    // double var2 = var1.nextGaussian();
    // double var3 = var1.nextGaussian();
    // var1.setSeed((-1));
    // boolean var6 = var1.nextBoolean();
    // long var7 = var1.nextLong();
    // var1.setSeed(275296862);
    // int var10 = var1.nextInt();
    // org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    // double var14 = var13.nextGaussian();
    // double var15 = var13.nextGaussian();
    // int[] var19 = new int[] { 1, 0, (-1)};
    // int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    // var13.setSeed(var19);
    // int[] var26 = new int[] { 1, 0, (-1)};
    // int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    // int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var26);
    // org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(0);
    // double var32 = var31.nextGaussian();
    // double var33 = var31.nextGaussian();
    // int[] var37 = new int[] { 1, 0, (-1)};
    // int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    // var31.setSeed(var37);
    // org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(0);
    // double var43 = var42.nextGaussian();
    // double var44 = var42.nextGaussian();
    // int[] var48 = new int[] { 1, 0, (-1)};
    // int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
    // var42.setSeed(var48);
    // int var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var37, var48);
    // double var53 = org.apache.commons.math3.util.MathArrays.distance(var19, var48);
    // var1.setSeed(var19);
    // // The following exception was thrown during execution.
    // // This behavior will recorded for regression testing.
    // try {
    //   int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 275296862);
    //   fail("Expected exception of type java.lang.OutOfMemoryError");
    // } catch (java.lang.OutOfMemoryError e) {
    //   // Expected exception.
    // }
    
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var2 == 1.908642352606886d);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var3 == (-0.27096157230053536d));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var6 == false);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var7 == 1399632177780768928L);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var10 == (-528848821));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var14 == 1.908642352606886d);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var15 == (-0.27096157230053536d));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var19);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var21);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var26);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var28);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var29 == 0);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var32 == 1.908642352606886d);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var33 == (-0.27096157230053536d));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var37);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var39);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var43 == 1.908642352606886d);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var44 == (-0.27096157230053536d));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var48);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var50);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var52 == 0);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var53 == 0.0d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     double var19 = org.apache.commons.math3.util.MathArrays.distance(var0, var15);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(0.6430115293363513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var18);
//     double[][] var20 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var18, var20);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextF(0.0d, 0.9777587052356126d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.2257363972524872d));
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal(1689900776, 2.7497630628293734d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.1680081431594336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var0.nextHypergeometric(631747952, (-528848821), 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var7);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    double var14 = var13.nextGaussian();
    double var15 = var13.nextGaussian();
    int[] var19 = new int[] { 1, 0, (-1)};
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    var13.setSeed(var19);
    var11.setSeed(var19);
    var11.setSeed(1008L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0d+ "'", var6.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var13 = null;
    double[] var15 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
    boolean var18 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var16, false);
    double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var13, var15);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    double[] var39 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var43 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d)};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var39, var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 1);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[][] var52 = new double[][] { var50};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var35, var52);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var15, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var55 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var35);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

//  public void test424() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
//
//
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//    double var2 = var1.nextGaussian();
//    float var3 = var1.nextFloat();
//    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
//    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      java.lang.String var13 = var4.nextHexString(430656544);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var2 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var3 == 0.9570892f);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == (-10019.332251989288d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var11 == (-8.05185587726462d));
//
//  }
//
  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    boolean var9 = var6.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

//  public void test426() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
//
//
//    double[] var0 = null;
//    double[] var2 = new double[] { (-1.0d)};
//    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
//    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var2, 353147569);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == true);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var9);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var10 == 1.0d);
//
//  }
//
  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var5, false);
    java.lang.Number var8 = var7.getMin();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var13, false);
    java.lang.Object[] var16 = new java.lang.Object[] { var15};
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var10, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var16);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var2, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)216.6827952125197d, (java.lang.Object[])var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure((-1L));
//     int var13 = var0.nextHypergeometric(2147483647, 0, 875017788);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextGamma((-6.27174892868895d), 21.273116565335737d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9010028.48719955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    long var11 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5326384455157762505L);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.015581072156227909d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt((-1), 2125371022);
//     double var6 = var0.nextExponential(687.4535731566205d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("6", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 597947801);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.948523969794003d);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1835266026);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextInt(1, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    double var11 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2887438691012194d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1), 2125371022);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1898741791, 353147569);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    byte[] var9 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var1.nextBytes(var9);
    boolean var11 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    boolean var31 = var2.equals((java.lang.Object)var29);
    java.lang.Object var32 = var2.getSecond();
    boolean var34 = var2.equals((java.lang.Object)(short)0);
    java.lang.Object var35 = var2.getValue();
    float[] var38 = new float[] { 100.0f, (-1.0f)};
    float[] var40 = new float[] { 10.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var38, var40);
    float[] var44 = new float[] { 100.0f, (-1.0f)};
    float[] var46 = new float[] { 10.0f};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var44, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var40, var44);
    float[] var51 = new float[] { 100.0f, (-1.0f)};
    float[] var53 = new float[] { 10.0f};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var51, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var44, var53);
    boolean var56 = var2.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + 10.0d+ "'", var32.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + 10.0d+ "'", var35.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var5 = var0.nextHypergeometric(1179441559, 0, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextBinomial((-163904641), 0.6513177047637154d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    boolean var31 = var2.equals((java.lang.Object)var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var33 = org.apache.commons.math3.util.MathArrays.normalizeArray(var29, 1.8288931765060235d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var5 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var8, false);
    java.lang.Number var11 = var10.getMin();
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var17 = var16.getMax();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    long[] var19 = null;
    long[][] var20 = new long[][] { var19};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var20);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var18, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var12, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-65.74388126764771d), (java.lang.Object[])var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (short)0+ "'", var17.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
//     int var10 = var4.nextInt(1, 275296862);
//     int var13 = var4.nextSecureInt(100, 12487350);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-266.3994807003071d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 166959353);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5494866);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var3 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var3);
//     double[] var10 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 375.6315311789929d);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
//     double[] var15 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var19 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var22 = new double[] { (-1.0d), (-1.0d)};
//     boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var22);
//     boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var15, var22);
//     double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 1);
//     double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var26);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var10, var26);
//     double var31 = org.apache.commons.math3.util.MathArrays.distance1(var0, var10);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1L), var2, (java.lang.Number)1898741791);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var12.nextUniform(13.603169545881526d, (-3.956734617801294d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    java.lang.Object[] var12 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
    org.apache.commons.math3.exception.MathArithmeticException var14 = new org.apache.commons.math3.exception.MathArithmeticException(var2, var12);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var18 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var22 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var25 = new double[] { (-1.0d), (-1.0d)};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var18, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[][] var31 = new double[][] { var29};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var14, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var14, (-194062463));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 782409001, 0);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
//     byte[] var2 = null;
//     var1.nextBytes(var2);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.normalizeArray(var15, (-0.5996555078851037d));
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var15);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var13 = var1.nextGaussian();
    var1.setSeed(21L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.39904814433673585d);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    java.lang.Number var18 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), var18, 782409001);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var20.getDirection();
    boolean var24 = org.apache.commons.math3.util.MathArrays.checkOrder(var14, var21, false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeed();
//     int var8 = var4.nextInt((-184300078), 100);
//     java.lang.String var10 = var4.nextHexString(1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-126472930));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2"+ "'", var10.equals("2"));
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     var1.setSeed((-1));
//     boolean var6 = var1.nextBoolean();
//     long var7 = var1.nextLong();
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var8);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    var4.reSeedSecure();
    var4.reSeed(1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)120.65610151834143d);
    boolean var2 = var1.getBoundIsAllowed();
    boolean var3 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)853.3307839689725d, (java.lang.Number)4.46220904881679d, 0);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     long var11 = var0.nextSecureLong(0L, 398L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "175968a356987126a845021e4134d93aa489cafb5f4fd0bcda88ffe020ef4135a02fddd13442da6d3ad1ac2cee8e65829035c60c976dae");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.372252075042526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "53605b52b7818cbb27a251209e2376c33a4defa60468c5a6197a220d7bf64ff6287b45aa9ea8414588c795d879ddd38680c8"+ "'", var6.equals("53605b52b7818cbb27a251209e2376c33a4defa60468c5a6197a220d7bf64ff6287b45aa9ea8414588c795d879ddd38680c8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 285L);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var15 = var14.getMax();
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    long[] var17 = null;
    long[][] var18 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(0.9746129402290591d, 0.33904363745058674d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-1.0d), (java.lang.Number)875017788);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var8);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var8, var17);
    float[] var22 = new float[] { 100.0f, (-1.0f)};
    float[] var24 = new float[] { 10.0f};
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var22, var24);
    float[] var28 = new float[] { 100.0f, (-1.0f)};
    float[] var30 = new float[] { 10.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var28, var30);
    float[] var34 = new float[] { 100.0f, (-1.0f)};
    float[] var36 = new float[] { 10.0f};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var34, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var34);
    float[] var41 = new float[] { 100.0f, (-1.0f)};
    float[] var43 = new float[] { 10.0f};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var34, var43);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var24, var34);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var17, var24);
    float[] var50 = new float[] { 100.0f, (-1.0f)};
    float[] var52 = new float[] { 10.0f};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var50, var52);
    float[] var56 = new float[] { 100.0f, (-1.0f)};
    float[] var58 = new float[] { 10.0f};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var56, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var52, var56);
    float[] var62 = new float[] { 0.0f};
    float[] var65 = new float[] { 100.0f, (-1.0f)};
    float[] var67 = new float[] { 10.0f};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var65, var67);
    float[] var71 = new float[] { 100.0f, (-1.0f)};
    float[] var73 = new float[] { 10.0f};
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var71, var73);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var71);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var62, var67);
    boolean var77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var67);
    float[] var78 = null;
    boolean var79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var78);
    boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var17, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)53686164009667304L);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var8 = var7.getIndex();
    var3.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var7.getDirection();
    boolean var11 = var7.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
    double[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var24, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var24);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)'#', (java.lang.Object)(-11.293482242235479d));
    java.lang.Object var3 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + '#'+ "'", var3.equals('#'));

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 251.42715463536425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 26.566401793740145d);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.33732388204490654d, 0.020945796376795382d, 304.47613478983845d, 253.55191374195655d, 0.33272672175073054d, 739.9960916531347d, 0.015581072156227909d, 884.5884346216443d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 77460.51304014731d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(253.55191374195655d, 12.57359046654414d, 0.27012747803685033d, (-10061.775830036235d), 0.13996529155952087d, 3.452827866077632d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 470.5790719190428d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    var0.reSeedSecure();
    var0.reSeed(848835256306514304L);
    double var7 = var0.nextGaussian(0.054710775280049806d, 216.6827952125197d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 43.688370836498265d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    double[] var6 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var9 = new double[] { (-1.0d), (-1.0d)};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var9);
    java.lang.Object[] var11 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)375.6315311789929d, var11);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var7, true);
    int var10 = var9.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(1179441559, 0, 100);
//     double var8 = var0.nextGamma(100.0d, 0.6531021513294903d);
//     double var10 = var0.nextT(0.020945796376795382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 70.08715146676043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-820.9307795507536d));
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     var0.reSeedSecure(848835256306514304L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGaussian(77.69947062706046d, (-10061.775830036235d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.20348423845114d));
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-10061.775830036235d), (java.lang.Number)(short)100, (java.lang.Number)(-11.703609724860312d));
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-11.703609724860312d)+ "'", var5.equals((-11.703609724860312d)));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextPascal(29, 9.874886093050462d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    double[] var6 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var9 = new double[] { (-1.0d), (-1.0d)};
    boolean var10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var6, var9);
    java.lang.Object[] var11 = new java.lang.Object[] { var9};
    org.apache.commons.math3.exception.MathIllegalArgumentException var12 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var11);
    org.apache.commons.math3.exception.MathArithmeticException var13 = new org.apache.commons.math3.exception.MathArithmeticException(var1, var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-791562805055479252L), var11);
    java.lang.Number var15 = var14.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-791562805055479252L)+ "'", var15.equals((-791562805055479252L)));

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var4 = var0.nextCauchy(3.452827866077632d, 120.65610151834143d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextSecureInt(1835266026, 1310072025);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 179.15383388408972d);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     double var7 = var0.nextGaussian((-260.9588833271992d), 0.39543159219858365d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 626131013);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-261.3306563414073d));
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)99.0d, (java.lang.Number)100L, true);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)2147483647, (java.lang.Number)122.57177270764146d, 782409001);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    byte[] var9 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var1.nextBytes(var9);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var14);
    var1.setSeed(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c", "608c2573e7b1ed33bc112ee1f5f41bc50404828e971897e0618fd696100ec2542e0e76635e19773c5529123a376b371dc542");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 685.7122710583953d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.24961711001925177d);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-159.42639435948843d), (java.lang.Number)0.0d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

//  public void test485() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
//
//
//    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//    double[] var10 = new double[] { (-1.0d), (-1.0d)};
//    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//    double[] var27 = new double[] { (-1.0d), (-1.0d)};
//    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
//    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
//    double[] var44 = new double[] { (-1.0d), (-1.0d)};
//    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
//    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
//    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
//    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
//    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
//    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
//    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
//    double[] var61 = new double[] { (-1.0d), (-1.0d)};
//    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
//    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
//    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
//    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
//    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
//    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
//    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
//    double[] var75 = new double[] { (-1.0d), (-1.0d)};
//    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
//    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
//    double[] var79 = org.apache.commons.math3.util.MathArrays.normalizeArray(var68, 0.39543159219858365d);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      double[] var81 = org.apache.commons.math3.util.MathArrays.copyOf(var68, 275296862);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var3);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var7);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var10);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var11 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var12 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var14);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var15 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var20);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var24);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var27);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var28 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var29 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var31);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var32 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var33);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var37);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var41);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var44);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var45 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var46 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var48);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var49 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var54);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var58);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var61);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var62 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var63 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var65);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var66 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var67);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var68);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var72);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var75);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var76 == false);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var77 == 2.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var79);
//
//  }
//
  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var3 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var3);
//     double[] var10 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 375.6315311789929d);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var10);
//     double var12 = org.apache.commons.math3.util.MathArrays.distance1(var0, var10);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var3, var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var35 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d)};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var31, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    org.apache.commons.math3.util.MathArrays.checkOrder(var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1), 153);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)5L, (java.lang.Number)(-9.762994102622386d), true);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(21L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-637204852));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)10};
    var1.nextBytes(var7);
    double var9 = var1.nextGaussian();
    int var11 = var1.nextInt(1835266026);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.246395958433071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 257196080);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    long var7 = var6.nextLong();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(0);
    double var10 = var9.nextGaussian();
    float var11 = var9.nextFloat();
    long var12 = var9.nextLong();
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(0);
    double var15 = var14.nextGaussian();
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(0);
    double var18 = var17.nextGaussian();
    double var19 = var17.nextGaussian();
    int[] var23 = new int[] { 1, 0, (-1)};
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    var17.setSeed(var23);
    float var27 = var17.nextFloat();
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(0);
    double var30 = var29.nextGaussian();
    double var31 = var29.nextGaussian();
    var29.setSeed((-1));
    byte[] var37 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var29.nextBytes(var37);
    var17.nextBytes(var37);
    var14.nextBytes(var37);
    var9.nextBytes(var37);
    var6.nextBytes(var37);
    float var43 = var6.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 9128399031861897490L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-7259342812136017821L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.8641691f);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var8 = new int[] { 1, 0, (-1)};
    int[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var8, 1);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
    double var13 = var12.nextGaussian();
    double var14 = var12.nextGaussian();
    int[] var18 = new int[] { 1, 0, (-1)};
    int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    var12.setSeed(var18);
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    int var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var18, var25);
    double var29 = org.apache.commons.math3.util.MathArrays.distance(var10, var25);
    int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var25);
    var1.setSeed(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test495() throws Throwable {

    // if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    // org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // var0.reSeedSecure();
    // var0.reSeedSecure();
    // // The following exception was thrown during execution.
    // // This behavior will recorded for regression testing.
    // try {
    //   java.lang.String var4 = var0.nextHexString(275296862);
    //   fail("Expected exception of type java.lang.OutOfMemoryError");
    // } catch (java.lang.OutOfMemoryError e) {
    //   // Expected exception.
    // }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSecureAlgorithm("", "5937e46334b53ba70929d0a57add6c7bda438ae9b0de360cfac27c31cc837ba70a61632b6cd3dbb3ba21119e406f1eee0f002a3cb64090");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));

  }

//  public void test497() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
//
//
//    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//    int[] var1 = null;
//    var0.setSeed(var1);
//    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
//    double var5 = var4.nextGaussian();
//    double var6 = var4.nextGaussian();
//    int[] var10 = new int[] { 1, 0, (-1)};
//    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//    var4.setSeed(var10);
//    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(0);
//    double var16 = var15.nextGaussian();
//    double var17 = var15.nextGaussian();
//    int[] var21 = new int[] { 1, 0, (-1)};
//    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
//    var15.setSeed(var21);
//    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var21);
//    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
//    var0.setSeed(var27);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 430656544);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var5 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var10);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var12);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var16 == 1.908642352606886d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var17 == (-0.27096157230053536d));
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var21);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var23);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var25 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var26);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var27);
//
//  }
//
  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     var0.reSeedSecure(12L);
//     long var12 = var0.nextLong(100L, 848835256306514304L);
//     double var15 = var0.nextGaussian((-1040.9625410266885d), 228.5581296305497d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0043332944685755236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 464774236431868608L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-816.0580927291034d));
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     double[] var21 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var25 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var28 = new double[] { (-1.0d), (-1.0d)};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var28);
//     boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var21, var28);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 1);
//     double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var15, var32);
//     double[] var36 = new double[] { 10.0d};
//     double[] var40 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var44 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var47 = new double[] { (-1.0d), (-1.0d)};
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var47);
//     boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var40, var47);
//     double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 1);
//     double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var51);
//     double[] var57 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var61 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var64 = new double[] { (-1.0d), (-1.0d)};
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var64);
//     boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var57, var64);
//     double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
//     double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var68);
//     double[] var70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var68);
//     double var71 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeDivide(var36, var51);
//     double[] var73 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var36);
//     double[] var74 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var34);
// 
//   }

}
