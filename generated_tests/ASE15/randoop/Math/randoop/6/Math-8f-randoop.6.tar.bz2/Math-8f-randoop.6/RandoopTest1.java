
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     double[] var16 = null;
//     double var17 = org.apache.commons.math3.util.MathArrays.distance(var14, var16);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     long var12 = var0.nextLong((-7259342812136017821L), 12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextSecureInt(1009783546, (-528848821));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-11.218180640821998d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 31.812155888904467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1358593815094649344L));
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-1), 1995398530);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), (java.lang.Number)(-6168.191987338353d), 631747952);
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = var11.getDirection();
    org.apache.commons.math3.util.MathArrays.checkOrder(var6, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var4.nextF(0.16021426377524167d, 2.7497630628293734d);
//     int var10 = var4.nextSecureInt(1, 1179441559);
//     double var12 = var4.nextT(0.33732388204490654d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.020945796376795382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 335062150);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.699397009323134d));
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    int var7 = var1.nextInt();
    boolean var8 = var1.nextBoolean();
    var1.setSeed(21L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 998139946);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     java.lang.Object var0 = null;
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getFirst();
//     java.lang.Object var4 = var2.getFirst();
//     double[] var6 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
//     boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     java.lang.Object var11 = var2.getKey();
//     java.lang.Object var12 = var2.getValue();
//     org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(0);
//     double var15 = var14.nextGaussian();
//     double var16 = var14.nextGaussian();
//     var14.setSeed((-1));
//     boolean var19 = var2.equals((java.lang.Object)var14);
//     long var20 = var14.nextLong();
//     java.util.List var21 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var22 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var14, var21);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure();
//     int var8 = var0.nextBinomial(1009135716, 0.01237694884401451d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextSecureLong(416L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 685259992);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12495080);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    int var8 = var1.nextInt(1);
    float var9 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.9548162f);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)100, (java.lang.Number)100.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy((-10019.332251989288d), 0.16021426377524167d);
    double var13 = var4.nextGamma(0.33732388204490654d, 1.908642352606886d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var4.nextF(0.0d, 0.4469289505534337d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-10019.276570315034d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.06400839652217086d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = var37.getDirection();
    double[] var42 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var46 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var49 = new double[] { (-1.0d), (-1.0d)};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equals(var42, var49);
    double[] var53 = org.apache.commons.math3.util.MathArrays.copyOf(var49, 1);
    double[] var57 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var61 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var64 = new double[] { (-1.0d), (-1.0d)};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var57, var64);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
    double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var68);
    double[][] var70 = new double[][] { var68};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var53, var70);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var14, var38, var70);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(353147569, 275296862);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(0);
    double var4 = var3.nextGaussian();
    double var5 = var3.nextGaussian();
    int[] var9 = new int[] { 1, 0, (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 1);
    var3.setSeed(var9);
    int[] var16 = new int[] { 1, 0, (-1)};
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 1);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var16);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(0);
    double var22 = var21.nextGaussian();
    double var23 = var21.nextGaussian();
    int[] var27 = new int[] { 1, 0, (-1)};
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    var21.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(0);
    double var33 = var32.nextGaussian();
    double var34 = var32.nextGaussian();
    int[] var38 = new int[] { 1, 0, (-1)};
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    var32.setSeed(var38);
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var9, var27);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var1, var27);
    org.apache.commons.math3.random.Well19937c var45 = new org.apache.commons.math3.random.Well19937c(var27);
    org.apache.commons.math3.random.Well19937c var47 = new org.apache.commons.math3.random.Well19937c(0);
    double var48 = var47.nextGaussian();
    double var49 = var47.nextGaussian();
    int[] var53 = new int[] { 1, 0, (-1)};
    int[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 1);
    var47.setSeed(var53);
    org.apache.commons.math3.random.Well19937c var58 = new org.apache.commons.math3.random.Well19937c(0);
    double var59 = var58.nextGaussian();
    double var60 = var58.nextGaussian();
    int[] var64 = new int[] { 1, 0, (-1)};
    int[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
    var58.setSeed(var64);
    int var68 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var64);
    var45.setSeed(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.33732388204490654d, (-25.94690396166603d), (-10019.276570315034d), 39.767656779690114d, 179.6175609414922d, (-261.3306563414073d), (-2.940839070076483d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-445391.47943073325d));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var35 = new double[] { 10.0d};
    double[] var39 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var43 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d)};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var39, var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 1);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var56 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var60 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var63 = new double[] { (-1.0d), (-1.0d)};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var56, var63);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var63, 1);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var50, var67);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var50);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var35);
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(1);
    double var10 = var1.nextDouble();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var16 = var15.getHi();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var16);
    org.apache.commons.math3.util.Pair var18 = new org.apache.commons.math3.util.Pair(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1.0d)+ "'", var16.equals((-1.0d)));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(0);
    double var7 = var6.nextGaussian();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(0);
    double var10 = var9.nextGaussian();
    double var11 = var9.nextGaussian();
    int[] var15 = new int[] { 1, 0, (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    var9.setSeed(var15);
    float var19 = var9.nextFloat();
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(0);
    double var22 = var21.nextGaussian();
    double var23 = var21.nextGaussian();
    var21.setSeed((-1));
    byte[] var29 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var21.nextBytes(var29);
    var9.nextBytes(var29);
    var6.nextBytes(var29);
    var1.nextBytes(var29);
    double var34 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-7259342812136017821L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-0.27096157230053536d));

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     java.lang.String var8 = var0.nextHexString(110);
//     double var10 = var0.nextChiSquare(0.6513177047637154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-8.707095652280664d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "842d2d8df0afaffae28f44e120dd9000d5dee58169b2c6f680419a87b9b3537c3baf8fcadc344ce01cff96eced5b4b7429c4d565a621c6"+ "'", var8.equals("842d2d8df0afaffae28f44e120dd9000d5dee58169b2c6f680419a87b9b3537c3baf8fcadc344ce01cff96eced5b4b7429c4d565a621c6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0407685321441484d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.33904363745058674d, (java.lang.Number)110, (java.lang.Number)1000.0d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1000.0d+ "'", var5.equals(1000.0d));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextBeta(3.3064578977516055d, 462.99687420008513d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.1397172653538374d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.005657595577368022d);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(21L);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.33272672175073054d, (java.lang.Number)(byte)10, (java.lang.Number)0.40877557f);
    double[] var8 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var12 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var15 = new double[] { (-1.0d), (-1.0d)};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var8, var15);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    double[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var21);
    org.apache.commons.math3.util.Pair var23 = new org.apache.commons.math3.util.Pair((java.lang.Object)0.33272672175073054d, (java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    var0.reSeed((-1L));
    double var11 = var0.nextCauchy(2.0d, 0.16021426377524167d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var0.nextBinomial(1, 3.3064578977516055d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.8288931765060235d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.13996529155952087d);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.0f, (java.lang.Number)10.0f, 100);
    boolean var4 = var3.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0f+ "'", var6.equals(10.0f));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-184300078), 0);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-184300078)+ "'", var3.equals((-184300078)));

  }

  public void test30() throws Throwable {

    // if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    // int[] var3 = new int[] { 1, 0, (-1)};
    // int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    // org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    // double var8 = var7.nextGaussian();
    // double var9 = var7.nextGaussian();
    // int[] var13 = new int[] { 1, 0, (-1)};
    // int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    // var7.setSeed(var13);
    // int[] var20 = new int[] { 1, 0, (-1)};
    // int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    // int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
    // double var24 = org.apache.commons.math3.util.MathArrays.distance(var5, var20);
    // // The following exception was thrown during execution.
    // // This behavior will recorded for regression testing.
    // try {
    //   int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 335062150);
    //   fail("Expected exception of type java.lang.OutOfMemoryError");
    // } catch (java.lang.OutOfMemoryError e) {
    //   // Expected exception.
    // }
    
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var3);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var5);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var8 == 1.908642352606886d);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var9 == (-0.27096157230053536d));
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var13);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var15);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var20);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertNotNull(var22);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var23 == 0);
    
    // // Regression assertion (captures the current behavior of the code)
    // assertTrue(var24 == 0.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(short)100, (java.lang.Number)100.0d, false);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 100.0d+ "'", var5.equals(100.0d));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(byte)10, (java.lang.Number)1.7084569304728279d, false);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     double var7 = var0.nextGaussian((-260.9588833271992d), 0.39543159219858365d);
//     double var10 = var0.nextWeibull(9.869894776045927d, 1.254354031734219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 293718977);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-261.2580792079068d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3322389030366206d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var8);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    boolean var19 = org.apache.commons.math3.util.MathArrays.equals(var8, var17);
    float[] var22 = new float[] { 1.0f, 100.0f};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var17, var22);
    float[] var26 = new float[] { 100.0f, (-1.0f)};
    float[] var28 = new float[] { 10.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var26, var28);
    float[] var32 = new float[] { 100.0f, (-1.0f)};
    float[] var34 = new float[] { 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var32, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var28, var32);
    float[] var38 = new float[] { 0.0f};
    float[] var41 = new float[] { 100.0f, (-1.0f)};
    float[] var43 = new float[] { 10.0f};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
    float[] var47 = new float[] { 100.0f, (-1.0f)};
    float[] var49 = new float[] { 10.0f};
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var47, var49);
    boolean var51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var47);
    boolean var52 = org.apache.commons.math3.util.MathArrays.equals(var38, var43);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var43);
    float[] var56 = new float[] { 100.0f, (-1.0f)};
    float[] var58 = new float[] { 10.0f};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var56, var58);
    float[] var62 = new float[] { 100.0f, (-1.0f)};
    float[] var64 = new float[] { 10.0f};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var62, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var58, var62);
    float[] var68 = new float[] { 0.0f};
    float[] var71 = new float[] { 100.0f, (-1.0f)};
    float[] var73 = new float[] { 10.0f};
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var71, var73);
    float[] var77 = new float[] { 100.0f, (-1.0f)};
    float[] var79 = new float[] { 10.0f};
    boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var77, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var73, var77);
    boolean var82 = org.apache.commons.math3.util.MathArrays.equals(var68, var73);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var73);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var58);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.9802138153623559d, 121.57001259402712d, (-8.05185587726462d), (-261.3306563414073d), 84.81643549678465d, 0.0d, 100.00999950005d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12224.361337055421d);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 110, 2147483647);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)157.18791807569124d, (java.lang.Number)(-1.6772154295120836d), 2125371022);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(short)0);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)12L, (java.lang.Number)251.42715463536425d, false);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 12L+ "'", var5.equals(12L));

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-98.85902789850113d), true);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var10 = var9.getMax();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    long[] var12 = null;
    long[][] var13 = new long[][] { var12};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var11, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
    java.lang.Number var17 = var3.getArgument();
    java.lang.Number var18 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)0+ "'", var10.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0.0f+ "'", var17.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
//     java.lang.Number var7 = var6.getMax();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     long[] var9 = null;
//     long[][] var10 = new long[][] { var9};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.21556675f, (java.lang.Object[])var10);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var10);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(687.4535731566205d, 70.08715146676043d, (-1.8066441508022335d), (-9.5459295762698d), 4.781478660401757d, 0.0043332944685755236d, (-1.7676329018930417d), 0.27012747803685033d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 48198.452039363816d);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     double var12 = var0.nextGaussian(122.57177270764146d, 99.0d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, 430656544);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    int var3 = var1.nextInt(2125371022);
    boolean var4 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2099284361);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getKey();
    java.lang.Object var14 = var2.getValue();
    java.lang.Object var15 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 10.0d+ "'", var14.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 10.0d+ "'", var15.equals(10.0d));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.24172957894946343d, (-159.42639435948843d), (-1.8066441508022335d), (-0.27096157230053536d), 70.08715146676043d, (-2.992979692193945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-247.81796506599633d));

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     long var4 = var0.nextLong(10L, 259766232686583471L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("a351ff1245602533a5bcb1598900dd2ffafc6149bd3d8c48853a436f91d4b2a244bd459da0732f90d2847db682c96660dfa4", "57f42ac6d33bfd7d90653cfe566768fa993bb07776dbb3813fccd17c0fb1f2654ba6ae3996d89fbedca54732d4343f25c0c1");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 123743228504249568L);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException(var3, (java.lang.Number)2125371022, var5, (java.lang.Number)(byte)100);
    java.lang.Number var8 = var7.getLo();
    var2.addSuppressed((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var8 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    boolean var4 = var3.getStrict();
    int var5 = var3.getIndex();
    java.lang.Number var6 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 275296862);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 2024169968+ "'", var6.equals(2024169968));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)626131013);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getValue();
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(0);
    double var15 = var14.nextGaussian();
    double var16 = var14.nextGaussian();
    var14.setSeed((-1));
    boolean var19 = var2.equals((java.lang.Object)var14);
    java.lang.Object var20 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0d+ "'", var12.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     int var9 = var0.nextInt(1, 1819577945);
//     long var12 = var0.nextLong((-2508567299728403968L), 1008L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(0L, (-582156205918565504L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 143.68527807120304d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 453.85184926410324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1357892632);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-2012255125336434944L));
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextWeibull((-10061.935445427129d), 228.5581296305497d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var3 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
//     boolean var6 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var4, false);
//     double var7 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var1, var3);
//     double[] var10 = org.apache.commons.math3.util.MathArrays.normalizeArray(var3, 375.6315311789929d);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var0, var3);
//     java.lang.Comparable[] var13 = new java.lang.Comparable[] { 2.7497630628293734d};
//     double[] var17 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var21 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var24 = new double[] { (-1.0d), (-1.0d)};
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var17, var24);
//     double[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 1);
//     double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var28);
//     double[] var34 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var38 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var41 = new double[] { (-1.0d), (-1.0d)};
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var38, var41);
//     boolean var43 = org.apache.commons.math3.util.MathArrays.equals(var34, var41);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var41, 1);
//     double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var28, var45);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var52 = var51.getDirection();
//     double[] var56 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var60 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var63 = new double[] { (-1.0d), (-1.0d)};
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var63);
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var56, var63);
//     double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var63, 1);
//     double[] var71 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var75 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var78 = new double[] { (-1.0d), (-1.0d)};
//     boolean var79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var75, var78);
//     boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var71, var78);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.copyOf(var78, 1);
//     double var83 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
//     double[][] var84 = new double[][] { var82};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var67, var84);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var28, var52, var84);
//     boolean var88 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var13, var52, true);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var92 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var93 = var92.getDirection();
//     boolean var95 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var13, var93, true);
//     boolean var98 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var93, true, false);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var10, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)(byte)(-1), 2099284361, var10, true);
    java.lang.Number var15 = var14.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     int var11 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var12.reSeed();
//     double var16 = var12.nextF(16.031433623080687d, 0.33904363745058674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2125371022);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 104.89778770459473d);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(2024169968, 64);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d)};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var29 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var36 = new double[] { (-1.0d), (-1.0d)};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var29, var36);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var40);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var2, var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
    org.apache.commons.math3.util.MathArrays.checkOrder(var15);
    double[] var19 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = null;
    boolean var22 = org.apache.commons.math3.util.MathArrays.isMonotonic(var19, var20, false);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var25 = null;
    double[] var29 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var36 = new double[] { (-1.0d), (-1.0d)};
    boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var29, var36);
    double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
    org.apache.commons.math3.util.MathArrays.checkOrder(var40);
    double[] var46 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var50 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var53 = new double[] { (-1.0d), (-1.0d)};
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var50, var53);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var46, var53);
    double[] var57 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 1);
    double var58 = org.apache.commons.math3.util.MathArrays.safeNorm(var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var40, var57);
    double[] var63 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var67 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var70 = new double[] { (-1.0d), (-1.0d)};
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var70);
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var63, var70);
    double[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var70, 1);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    org.apache.commons.math3.util.MathArrays.checkOrder(var74);
    double[] var80 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var84 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var87 = new double[] { (-1.0d), (-1.0d)};
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var84, var87);
    boolean var89 = org.apache.commons.math3.util.MathArrays.equals(var80, var87);
    double[] var91 = org.apache.commons.math3.util.MathArrays.copyOf(var87, 1);
    double var92 = org.apache.commons.math3.util.MathArrays.safeNorm(var91);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var74, var91);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var59, var91);
    double[][] var95 = new double[][] { var91};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var25, var95);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var15, var95);
    org.apache.commons.math3.exception.MathInternalError var98 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-0.5996555078851037d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var14);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    double var13 = var4.nextCauchy(1.8288931765060235d, 1.8301900518845509d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var4.nextWeibull((-11.293482242235479d), (-9.762994102622386d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.3438501360557338d);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    java.lang.Object[] var14 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)375.6315311789929d, var14);
    org.apache.commons.math3.exception.NullArgumentException var17 = new org.apache.commons.math3.exception.NullArgumentException(var2, var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var14);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.254354031734219d, 251.42715463536425d, (-2.992979692193945d), 122.12396088898325d, 87.41926244809311d, 0.0d, 48.550599067346205d, 0.5131366286482398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-25.222779042411965d));

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     var0.reSeedSecure(53686164009667304L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-3.7993682054111013d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     var0.reSeed(398L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGamma((-3.956734617801294d), (-159.42639435948843d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 516L);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    byte[] var9 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var1.nextBytes(var9);
    var1.clear();
    var1.setSeed((-791562805055479252L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 176);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
//     double var13 = var12.nextGaussian();
//     double var14 = var12.nextGaussian();
//     int[] var18 = new int[] { 1, 0, (-1)};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
//     var12.setSeed(var18);
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var18);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(0);
//     double var27 = var26.nextGaussian();
//     double var28 = var26.nextGaussian();
//     int[] var32 = new int[] { 1, 0, (-1)};
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 1);
//     var26.setSeed(var32);
//     int[] var39 = new int[] { 1, 0, (-1)};
//     int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 1);
//     int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var39);
//     org.apache.commons.math3.random.RandomDataImpl var43 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var46 = var43.nextPermutation(100, 100);
//     int var47 = org.apache.commons.math3.util.MathArrays.distance1(var32, var46);
//     int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var46);
//     org.apache.commons.math3.random.Well19937c var50 = new org.apache.commons.math3.random.Well19937c(0);
//     double var51 = var50.nextGaussian();
//     double var52 = var50.nextGaussian();
//     int[] var56 = new int[] { 1, 0, (-1)};
//     int[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 1);
//     var50.setSeed(var56);
//     org.apache.commons.math3.random.Well19937c var60 = new org.apache.commons.math3.random.Well19937c(var56);
//     int var61 = org.apache.commons.math3.util.MathArrays.distance1(var7, var56);
//     org.apache.commons.math3.random.Well19937c var63 = new org.apache.commons.math3.random.Well19937c(0);
//     double var64 = var63.nextGaussian();
//     double var65 = var63.nextGaussian();
//     int[] var69 = new int[] { 1, 0, (-1)};
//     int[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
//     var63.setSeed(var69);
//     org.apache.commons.math3.random.Well19937c var73 = new org.apache.commons.math3.random.Well19937c(var69);
//     double var74 = org.apache.commons.math3.util.MathArrays.distance(var56, var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 254);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 0.0d);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("eefa9f8c59c03699defa7f1bbd48762093a6a193eb595c61a08a1ab15d2983f9f9c908404f19e079d682d29a089fb5c0d9f7", "8");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)44.74362024702862d, var1);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1898741791);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var28 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var32 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d)};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var28, var35);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 1);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var22, var39);
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double var57 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var73);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var73);
    double[][] var77 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var1, var7, var77);
    double[] var82 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var86 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var89 = new double[] { (-1.0d), (-1.0d)};
    boolean var90 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var86, var89);
    boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var82, var89);
    double var92 = org.apache.commons.math3.util.MathArrays.distance1(var1, var89);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var89);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var18 = var0.nextSecureLong((-2678358548675784704L), 300L);
//     org.apache.commons.math3.distribution.RealDistribution var19 = null;
//     double var20 = var0.nextInversionDeviate(var19);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(2147483647, 5494866);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5494866);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    double var13 = var4.nextBeta(54.529582702346616d, 0.16021426377524167d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9984206161430301d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    double var8 = var7.nextGaussian();
    double var9 = var7.nextGaussian();
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    var7.setSeed(var13);
    int[] var20 = new int[] { 1, 0, (-1)};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
    double var24 = org.apache.commons.math3.util.MathArrays.distance(var5, var20);
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(var5);
    int[] var27 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var29 = new org.apache.commons.math3.random.Well19937c(0);
    double var30 = var29.nextGaussian();
    double var31 = var29.nextGaussian();
    int[] var35 = new int[] { 1, 0, (-1)};
    int[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 1);
    var29.setSeed(var35);
    int[] var42 = new int[] { 1, 0, (-1)};
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 1);
    int var45 = org.apache.commons.math3.util.MathArrays.distanceInf(var35, var42);
    org.apache.commons.math3.random.Well19937c var47 = new org.apache.commons.math3.random.Well19937c(0);
    double var48 = var47.nextGaussian();
    double var49 = var47.nextGaussian();
    int[] var53 = new int[] { 1, 0, (-1)};
    int[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var53, 1);
    var47.setSeed(var53);
    org.apache.commons.math3.random.Well19937c var58 = new org.apache.commons.math3.random.Well19937c(0);
    double var59 = var58.nextGaussian();
    double var60 = var58.nextGaussian();
    int[] var64 = new int[] { 1, 0, (-1)};
    int[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
    var58.setSeed(var64);
    int var68 = org.apache.commons.math3.util.MathArrays.distanceInf(var53, var64);
    double var69 = org.apache.commons.math3.util.MathArrays.distance(var35, var53);
    double var70 = org.apache.commons.math3.util.MathArrays.distance(var27, var53);
    int var71 = org.apache.commons.math3.util.MathArrays.distance1(var5, var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     java.lang.String var4 = var0.nextSecureHexString(153);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("d4dc7b4ca230b264fa19d3dad607cca767bd20a9e4cf41bfb1d67a1aa68b24cff4a7e9d8b1eafa3f74d22623b64e0f1225fefee105318b", "143b0403afcda0880d73281db0deb0074bcb920e831abe6991789f9ec45758562b34e2c899adb3340fa035793a9c5178fd4a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.29311050896953117d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6b954b7b5bdfda649a5e352b01ffc5c6e767333f7a0027b23485d6913fd254259d58c52ba659842f80150abb72dc9423fde2a7a6caf6e0bc95286f0f438b38f6288b172e138ab3a4fcc69e06b"+ "'", var4.equals("6b954b7b5bdfda649a5e352b01ffc5c6e767333f7a0027b23485d6913fd254259d58c52ba659842f80150abb72dc9423fde2a7a6caf6e0bc95286f0f438b38f6288b172e138ab3a4fcc69e06b"));
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     var0.reSeed();
//     int var12 = var0.nextSecureInt(0, 1995398530);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextUniform(6.401745123441823d, 1.8301900518845509d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.7252003118347234d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "18b80eb41fa1481cea61472a6f4d0da07fead42acf47953eea78e962fd9803724db29ec9c6cd8c024bc4e28046221380e09e"+ "'", var6.equals("18b80eb41fa1481cea61472a6f4d0da07fead42acf47953eea78e962fd9803724db29ec9c6cd8c024bc4e28046221380e09e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1091497571);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeed();
//     int var8 = var4.nextInt((-184300078), 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var4.nextPermutation(166959353, 875017788);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-76355287));
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var18 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 941.1526710026226d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var5 = var0.nextHexString(2099284361);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     double var6 = var0.nextBeta(575.3928572028764d, 12.658839462906196d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextPascal((-163904641), 40.99947359710616d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1.8016198947550066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9730519235264832d);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)64, (java.lang.Number)100L, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    var1.setSeed((-791562805055479252L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(1);
    double var10 = var1.nextDouble();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var16 = var15.getHi();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var16);
    var1.setSeed(398L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1.0d)+ "'", var16.equals((-1.0d)));

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt((-1), 2125371022);
//     double var6 = var0.nextExponential(687.4535731566205d);
//     long var8 = var0.nextPoisson(1.8301900518845509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 230354947);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 420.60535361978623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2L);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getKey();
    java.lang.Object var14 = var2.getValue();
    java.lang.Object var15 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 10.0d+ "'", var14.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    boolean var31 = var2.equals((java.lang.Object)var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1009783546);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(687.4535731566205d, 77460.51304014731d, 271.42067669747905d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5.3250506467994265E7d);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     int[] var0 = null;
//     int[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 0);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(0);
    double var9 = var8.nextGaussian();
    double var10 = var8.nextGaussian();
    var8.setSeed((-1));
    boolean var13 = var8.nextBoolean();
    long var14 = var8.nextLong();
    var8.setSeed(1);
    double var17 = var8.nextDouble();
    org.apache.commons.math3.exception.util.Localizable var18 = null;
    org.apache.commons.math3.exception.OutOfRangeException var22 = new org.apache.commons.math3.exception.OutOfRangeException(var18, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var23 = var22.getHi();
    org.apache.commons.math3.util.Pair var24 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var23);
    org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(0);
    double var27 = var26.nextGaussian();
    double var28 = var26.nextGaussian();
    var26.setSeed((-1));
    byte[] var34 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var26.nextBytes(var34);
    var8.nextBytes(var34);
    var1.nextBytes(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1.0d)+ "'", var23.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    int var8 = var1.nextInt();
    float var9 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-194062463));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.10467458f);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(64501470618535056L);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.16021426377524167d);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy(48.550599067346205d, 32.58103641305895d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var9 = var4.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 59.873976984192424d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
//     var4.reSeed(0L);
//     long var12 = var4.nextSecureLong(64501470618535056L, 259766232686583471L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setSecureAlgorithm("", "22af8221bdaf32b8cde1f6ecf02813f7cef3d2262f325484116166fc879ac01c2e41feb73d4025e228b2e0375d1cfcb35927");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-266.3994807003071d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 114439646745505360L);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed();
    int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
    var0.reSeed(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextHypergeometric(0, 875017788, 1165747026);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     var0.reSeed();
//     var0.reSeed(130L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.928111192687026d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "cd6526360a861cf347012b5b2728a1cf0db7c29cb173e30fca5d2ebd0e8272ce94ef8f88a7fffe4b912fb09149d4b7f5674c"+ "'", var6.equals("cd6526360a861cf347012b5b2728a1cf0db7c29cb173e30fca5d2ebd0e8272ce94ef8f88a7fffe4b912fb09149d4b7f5674c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 14L);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     double var18 = var0.nextGaussian((-10061.775830036235d), 0.3438501360557338d);
//     double var20 = var0.nextExponential(941.1526710026226d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 596.432989482352d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0819946458376075d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.3030061853281091d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-10061.846477140165d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 77.62839101964029d);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.7919676914856775d);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var8);
    float[] var15 = new float[] { 100.0f, (-1.0f)};
    float[] var17 = new float[] { 10.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var15, var17);
    float[] var21 = new float[] { 100.0f, (-1.0f)};
    float[] var23 = new float[] { 10.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var21, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var17, var21);
    float[] var28 = new float[] { 100.0f, (-1.0f)};
    float[] var30 = new float[] { 10.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var28, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var21, var30);
    float[] var35 = new float[] { 100.0f, (-1.0f)};
    float[] var37 = new float[] { 10.0f};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var35, var37);
    float[] var41 = new float[] { 100.0f, (-1.0f)};
    float[] var43 = new float[] { 10.0f};
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var41, var43);
    boolean var45 = org.apache.commons.math3.util.MathArrays.equals(var37, var41);
    float[] var47 = new float[] { 0.0f};
    float[] var50 = new float[] { 100.0f, (-1.0f)};
    float[] var52 = new float[] { 10.0f};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var50, var52);
    float[] var56 = new float[] { 100.0f, (-1.0f)};
    float[] var58 = new float[] { 10.0f};
    boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var56, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var56);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var47, var52);
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var52);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var37);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var4, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-1.699397009323134d), 0.0d, 104.89778770459473d, 0.9777587052356126d, 32.58103641305895d, 40.53524660505049d, (-42.4140547575466d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1687.4077771387995d));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var6 = var4.nextPoisson(33.67095195679566d);
    int var9 = var4.nextBinomial(1179441559, 0.020945796376795382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 32L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 24703818);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NullArgumentException var2 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Comparable[] var5 = new java.lang.Comparable[] { 2.7497630628293734d};
    double[] var9 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var13 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var16 = new double[] { (-1.0d), (-1.0d)};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var9, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 1);
    double var21 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    org.apache.commons.math3.util.MathArrays.checkOrder(var20);
    double[] var26 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var30 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var33 = new double[] { (-1.0d), (-1.0d)};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var26, var33);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 1);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var20, var37);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var44 = var43.getDirection();
    double[] var48 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var52 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d)};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var48, var55);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var55, 1);
    double[] var63 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var67 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var70 = new double[] { (-1.0d), (-1.0d)};
    boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var67, var70);
    boolean var72 = org.apache.commons.math3.util.MathArrays.equals(var63, var70);
    double[] var74 = org.apache.commons.math3.util.MathArrays.copyOf(var70, 1);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var74);
    double[][] var76 = new double[][] { var74};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var59, var76);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var20, var44, var76);
    boolean var80 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var44, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var85 = var84.getDirection();
    boolean var87 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var5, var85, true);
    org.apache.commons.math3.exception.MathIllegalStateException var88 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var89 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-4.049532677534791d), (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     org.apache.commons.math3.distribution.RealDistribution var7 = null;
//     double var8 = var0.nextInversionDeviate(var7);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    var4.reSeedSecure((-23350460807812264L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.05185587726462d));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(2024169968, 275296862);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var5, false);
    boolean var8 = var7.getBoundIsAllowed();
    java.lang.Throwable[] var9 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "cbefb379e3ba8cf0b95d7baf0f6c7ed4a134a31ca854347c0518fa3473ea5f2b305ea6550577613455f8ee0d56df4d166c6a"+ "'", var3.equals("cbefb379e3ba8cf0b95d7baf0f6c7ed4a134a31ca854347c0518fa3473ea5f2b305ea6550577613455f8ee0d56df4d166c6a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1026.0293588974607d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-144695662819935392L));
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)10};
    var1.nextBytes(var7);
    double var9 = var1.nextGaussian();
    var1.setSeed(230354947);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.246395958433071d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var4, var8);
    float[] var14 = new float[] { 0.0f};
    float[] var17 = new float[] { 100.0f, (-1.0f)};
    float[] var19 = new float[] { 10.0f};
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    float[] var23 = new float[] { 100.0f, (-1.0f)};
    float[] var25 = new float[] { 10.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var23, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var23);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var14, var19);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var19);
    float[] var32 = new float[] { 100.0f, (-1.0f)};
    float[] var34 = new float[] { 10.0f};
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var32, var34);
    float[] var38 = new float[] { 100.0f, (-1.0f)};
    float[] var40 = new float[] { 10.0f};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var38, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var34, var38);
    float[] var45 = new float[] { 100.0f, (-1.0f)};
    float[] var47 = new float[] { 10.0f};
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var45, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var38, var47);
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var4, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(0);
    double var20 = var19.nextGaussian();
    double var21 = var19.nextGaussian();
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    var19.setSeed(var25);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(0);
    double var31 = var30.nextGaussian();
    double var32 = var30.nextGaussian();
    int[] var36 = new int[] { 1, 0, (-1)};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    var30.setSeed(var36);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var7, var36);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var7);
    org.apache.commons.math3.random.Well19937c var43 = new org.apache.commons.math3.random.Well19937c(var7);
    float var44 = var43.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.49485147f);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getValue();
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(0);
    double var15 = var14.nextGaussian();
    double var16 = var14.nextGaussian();
    var14.setSeed((-1));
    boolean var19 = var2.equals((java.lang.Object)var14);
    java.lang.Object var20 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0d+ "'", var12.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 10.0d+ "'", var20.equals(10.0d));

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.nextGaussian(87.41926244809311d, (-2.940839070076483d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    double var14 = var13.nextGaussian();
    double var15 = var13.nextGaussian();
    int[] var19 = new int[] { 1, 0, (-1)};
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    var13.setSeed(var19);
    int[] var26 = new int[] { 1, 0, (-1)};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var26);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(0);
    double var32 = var31.nextGaussian();
    double var33 = var31.nextGaussian();
    int[] var37 = new int[] { 1, 0, (-1)};
    int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    var31.setSeed(var37);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(0);
    double var43 = var42.nextGaussian();
    double var44 = var42.nextGaussian();
    int[] var48 = new int[] { 1, 0, (-1)};
    int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
    var42.setSeed(var48);
    int var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var37, var48);
    double var53 = org.apache.commons.math3.util.MathArrays.distance(var19, var48);
    var1.setSeed(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1898741791);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    java.lang.String var9 = var6.toString();
    java.lang.Number var10 = var6.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)"+ "'", var9.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)(-1)+ "'", var10.equals((short)(-1)));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    double var13 = var4.nextChiSquare(0.015581072156227909d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.05185587726462d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     double var7 = var0.nextBeta(4.928111192687026d, 1.8301900518845509d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 38.015587695902326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9669310713174001d);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(-10061.983597329241d), 0);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)100.00999950005d, var2, false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 4.874293883290859d};
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), var3, 782409001);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = var5.getDirection();
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var6, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(21L);
    double[] var3 = new double[] { 10.0d};
    double[] var7 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    boolean var16 = org.apache.commons.math3.util.MathArrays.equals(var7, var14);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    org.apache.commons.math3.util.MathArrays.checkOrder(var18);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var35);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeDivide(var3, var18);
    double[] var40 = null;
    double[] var42 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = null;
    boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var42, var43, false);
    double var46 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var40, var42);
    double[] var49 = org.apache.commons.math3.util.MathArrays.normalizeArray(var42, 375.6315311789929d);
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var51, 1);
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var58 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var18, var42);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.42311526636401314d, (java.lang.Number)5.3250506467994265E7d, true);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     long var5 = var0.nextLong((-7259342812136017821L), 7540580061456263210L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1307808513406028800L);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    java.lang.Object[] var12 = new java.lang.Object[] { var10};
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
    org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, var12);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var1, var12);
    org.apache.commons.math3.exception.NullArgumentException var16 = new org.apache.commons.math3.exception.NullArgumentException(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     java.lang.String var8 = var0.nextHexString(110);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(0.27012747803685033d, (-8.05185587726462d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.4184270095523903d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a9fd1f8f42be47814d4aedf269ccf1c300fa53e5983fdd7c3dde05000a3ddad1e017ac86c6e745c1e26b09ef105839edcbeef2ea8e80e4"+ "'", var8.equals("a9fd1f8f42be47814d4aedf269ccf1c300fa53e5983fdd7c3dde05000a3ddad1e017ac86c6e745c1e26b09ef105839edcbeef2ea8e80e4"));
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(470.5790719190428d, 0.6513177047637154d, 1.1672233456208478d, 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 308.7242929445538d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    var1.setSeed(259766232686583471L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var2, false);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var11 = var10.getMax();
    org.apache.commons.math3.exception.util.Localizable var12 = null;
    long[] var13 = null;
    long[][] var14 = new long[][] { var13};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var12, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var14);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)0+ "'", var11.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(300L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextUniform(315.4949476501084d, 217.41609303033977d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     var0.reSeedSecure((-7259342812136017821L));
//     double var9 = var0.nextChiSquare(44.74362024702862d);
//     org.apache.commons.math3.distribution.IntegerDistribution var10 = null;
//     int var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextT(0.39904814433673585d);
//     int[] var11 = var0.nextPermutation(24703818, 24703818);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 15.05548105320244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "7"+ "'", var6.equals("7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.4909685755619178d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)44.74362024702862d, var2, false);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(300L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(1008L);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var72 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var76 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var79 = new double[] { (-1.0d), (-1.0d)};
    boolean var80 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var76, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var72, var79);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var79, 1);
    double var84 = org.apache.commons.math3.util.MathArrays.safeNorm(var83);
    double var85 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var5 = var0.nextLong(3757806182885320704L, (-93072929058176752L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.23051412492227324d));
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var29);
    boolean var31 = var2.equals((java.lang.Object)var29);
    double[] var35 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d)};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 176);
    double var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var41);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var46 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var47 = var46.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var41, var47, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    long var9 = var4.nextPoisson(120.65610151834143d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextBeta(0.4245701161410406d, (-42.4140547575466d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 130L);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var14, (-0.5996555078851037d));
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var23);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), var1, 782409001);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points 782,409,000 and 782,409,001 are not strictly increasing (null >= -3.957)"+ "'", var4.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points 782,409,000 and 782,409,001 are not strictly increasing (null >= -3.957)"));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    org.apache.commons.math3.util.Pair var9 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)430656544);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    java.lang.Object[] var14 = new java.lang.Object[] { var12};
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var5, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var16 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)375.6315311789929d, var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)(-1040.9625410266885d), var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeed();
//     long var13 = var0.nextSecureLong(14L, 5326384455157762505L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.341213801342904d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-28.157532246567285d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4372816109596290048L);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(1995398530, 153);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 471L);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(1835266026, 0);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var8 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)100, var8);
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var8);
    org.apache.commons.math3.exception.NullArgumentException var11 = new org.apache.commons.math3.exception.NullArgumentException(var3, var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)998139946, var8);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var3, false);
    boolean var6 = var5.getBoundIsAllowed();
    java.lang.Throwable[] var7 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)259766232686583471L, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     long var4 = var0.nextLong(10L, 259766232686583471L);
//     double var6 = var0.nextExponential(0.6513177047637154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 165233428670016224L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6907553650643599d);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)9.874886093050462d, (java.lang.Number)0.0f);
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    double[] var11 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var14 = new double[] { (-1.0d), (-1.0d)};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    java.lang.Object[] var16 = new java.lang.Object[] { var14};
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)375.6315311789929d, var16);
    java.lang.Number var19 = var18.getArgument();
    var4.addSuppressed((java.lang.Throwable)var18);
    java.lang.Number var21 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 375.6315311789929d+ "'", var19.equals(375.6315311789929d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 9.874886093050462d+ "'", var21.equals(9.874886093050462d));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-42.4140547575466d), 0.0819946458376075d, 0.25809207497872494d, (-9.762994102622386d), 462.99687420008513d, 4.46220904881679d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2059.9913648251763d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.clear();
    int var5 = var1.nextInt();
    long var6 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-184300078));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-7259342812136017821L));

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var17 = var0.nextPoisson(3.452827866077632d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 3);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    double[] var1 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var28 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var32 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d)};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var28, var35);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 1);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var22, var39);
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double var57 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var73);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var73);
    double[][] var77 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var1, var7, var77);
    double[] var82 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var86 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var89 = new double[] { (-1.0d), (-1.0d)};
    boolean var90 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var86, var89);
    boolean var91 = org.apache.commons.math3.util.MathArrays.equals(var82, var89);
    double var92 = org.apache.commons.math3.util.MathArrays.distance1(var1, var89);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var94 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1179441559);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextChiSquare((-0.7374423811409287d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.4466964945513068d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    java.lang.Number var0 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 2.7497630628293734d};
    double[] var8 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var12 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var15 = new double[] { (-1.0d), (-1.0d)};
    boolean var16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var12, var15);
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var8, var15);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
    org.apache.commons.math3.util.MathArrays.checkOrder(var19);
    double[] var25 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var29 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var32 = new double[] { (-1.0d), (-1.0d)};
    boolean var33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var29, var32);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var25, var32);
    double[] var36 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 1);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var36);
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var36);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var42 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var43 = var42.getDirection();
    double[] var47 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var51 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d)};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var54);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var47, var54);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var54, 1);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[][] var75 = new double[][] { var73};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var58, var75);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var19, var43, var75);
    boolean var79 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var4, var43, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var81 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)0.25809207497872494d, 1689900776, var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     int var9 = var0.nextPascal(3, 0.4245701161410406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 167.6248272593822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 132.55356468993725d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 4);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var18 = var0.nextSecureLong((-2678358548675784704L), 300L);
//     int var21 = var0.nextPascal(29, 0.22291664839491906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 176.39709159962663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.1044872086182173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-3.438064932233826d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-56.744252030318926d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1741698992107633152L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 109);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
//     double var5 = var4.nextGaussian();
//     double var6 = var4.nextGaussian();
//     int[] var10 = new int[] { 1, 0, (-1)};
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     var4.setSeed(var10);
//     float var14 = var4.nextFloat();
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(0);
//     double var17 = var16.nextGaussian();
//     double var18 = var16.nextGaussian();
//     var16.setSeed((-1));
//     byte[] var24 = new byte[] { (byte)100, (byte)(-1), (byte)0};
//     var16.nextBytes(var24);
//     var4.nextBytes(var24);
//     var1.nextBytes(var24);
//     java.util.List var28 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var29 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var28);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(9.874886093050462d, 0.0d, (-1.0386695297463309d), 0.0d, 288.7236722219395d, 522.589744828329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 150884.03019236148d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)165233428670016224L, var1, (java.lang.Number)4372816109596290048L);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    float var11 = var1.nextFloat();
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    double var14 = var13.nextGaussian();
    double var15 = var13.nextGaussian();
    var13.setSeed((-1));
    byte[] var21 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var13.nextBytes(var21);
    var1.nextBytes(var21);
    long var24 = var1.nextLong();
    float var25 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3976504751842537792L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.5590124f);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    long[] var0 = new long[] { };
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
    long[][] var3 = new long[][] { var0};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     var0.reSeed();
//     long var19 = var0.nextLong(32L, 259766232686583471L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 519.1936164236881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.13173043139636778d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.16591392070291489d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 134902802964544848L);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var14 = var0.nextExponential(219.80508910257697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextBinomial((-194062463), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 58.20121894695533d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3301365620329665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 287.226317195348d);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextF(0.16021426377524167d, 2.7497630628293734d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("175968a356987126a845021e4134d93aa489cafb5f4fd0bcda88ffe020ef4135a02fddd13442da6d3ad1ac2cee8e65829035c60c976dae", "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (1 >= 1)");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.020945796376795382d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextT(0.39904814433673585d);
//     java.lang.String var10 = var0.nextSecureHexString(64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 31.09004736777187d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "4"+ "'", var6.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.46944520156126024d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c0606a75259d3f67ca1501f1c1e75c650ff3e54796eb7917ee29965f8cc82345"+ "'", var10.equals("c0606a75259d3f67ca1501f1c1e75c650ff3e54796eb7917ee29965f8cc82345"));
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 2.7497630628293734d};
    double[] var5 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var5, var12);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 1);
    double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    org.apache.commons.math3.util.MathArrays.checkOrder(var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var33);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var39 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var40 = var39.getDirection();
    double[] var44 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var48 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var51 = new double[] { (-1.0d), (-1.0d)};
    boolean var52 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var48, var51);
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var44, var51);
    double[] var55 = org.apache.commons.math3.util.MathArrays.copyOf(var51, 1);
    double[] var59 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var63 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d)};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var63, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var59, var66);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 1);
    double var71 = org.apache.commons.math3.util.MathArrays.safeNorm(var70);
    double[][] var72 = new double[][] { var70};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var55, var72);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var16, var40, var72);
    boolean var76 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var40, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var80 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var81 = var80.getDirection();
    java.lang.Throwable[] var82 = var80.getSuppressed();
    boolean var83 = var80.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var84 = var80.getDirection();
    boolean var86 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var84, true);
    java.lang.Number var88 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var90 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), var88, 782409001);
    org.apache.commons.math3.util.MathArrays.OrderDirection var91 = var90.getDirection();
    boolean var93 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var1, var91, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == true);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy((-10019.332251989288d), 0.16021426377524167d);
    double var13 = var4.nextGamma(0.33732388204490654d, 1.908642352606886d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var4.nextPoisson((-25.94690396166603d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-10019.276570315034d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.06400839652217086d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)100, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.9669310713174001d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//     double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d)};
//     boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
//     double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var31 = new double[] { (-1.0d), (-1.0d)};
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
//     double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var35);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var11, var35);
//     double var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var11);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy(48.550599067346205d, 32.58103641305895d);
    double var9 = var4.nextExponential(13.603169545881526d);
    double var13 = var4.nextUniform(0.0d, 4.6868628527440326E11d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 59.873976984192424d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 11.225710856050238d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 5.6132803785096985E10d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var11 = var10.getIndex();
    var6.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var10.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0d, (java.lang.Number)3757806182885320704L, 1, var13, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(12486998, 230354947);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     int var8 = var0.nextInt(275296862, 2099284361);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextSecureInt(1819577945, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1444793660);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var18 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var22 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var25 = new double[] { (-1.0d), (-1.0d)};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var18, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[][] var31 = new double[][] { var29};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var14, var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-3.7993682054111013d), 0.0d, 3.0347032432247736d, (-10019.276570315034d), (-28.157532246567285d), 939.2076725668584d, 0.08679600259959512d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-56851.30142922574d));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextBinomial(87, 6.401745123441823d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1L), (java.lang.Number)10, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10+ "'", var5.equals(10));

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextPascal(548028350, 9.874886093050462d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0024727241241944d);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15);
//     double[] var21 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var25 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var28 = new double[] { (-1.0d), (-1.0d)};
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var28);
//     boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var21, var28);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var28, 1);
//     double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var32);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var15, var32);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var41 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var42 = var41.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var44 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var42, true);
//     boolean var46 = org.apache.commons.math3.util.MathArrays.isMonotonic(var34, var42, false);
//     double[] var50 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var54 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var57 = new double[] { (-1.0d), (-1.0d)};
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var54, var57);
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var50, var57);
//     double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var57, 1);
//     double[] var65 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var69 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d)};
//     boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var72);
//     boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var65, var72);
//     double[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var72, 1);
//     double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
//     double[][] var78 = new double[][] { var76};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var61, var78);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var34, var78);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.normalizeArray(var34, 0.020945796376795382d);
//     double[] var83 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var82);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var4.nextWeibull(1.908642352606886d, 0.9777587052356126d);
//     java.lang.String var9 = var4.nextSecureHexString(24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9426571811852562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "1f01887648856c7139bc086a"+ "'", var9.equals("1f01887648856c7139bc086a"));
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, var1, 1173104402);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    java.lang.Throwable[] var8 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)275296862, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var11.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    int var7 = var1.nextInt();
    boolean var8 = var1.nextBoolean();
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(0);
    double var11 = var10.nextGaussian();
    double var12 = var10.nextGaussian();
    var10.setSeed((-1));
    byte[] var18 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var10.nextBytes(var18);
    var1.nextBytes(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 998139946);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     var0.reSeedSecure((-7259342812136017821L));
//     double var9 = var0.nextChiSquare(44.74362024702862d);
//     double var13 = var0.nextUniform((-8.586495553343214d), 358.5742526832825d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 394.6481650409899d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 55.57100780343789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 166.73485835388425d);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextT(0.19834426208730332d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.5248295573436604d);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextPascal(109, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(548028350, 1689900776);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 42.96863934365409d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4284200302290598d);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(1819577945, 87);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 741.3989683623894d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.07113352106757642d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.17512681371246708d);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeedSecure();
//     double var13 = var0.nextCauchy((-25.222779042411965d), 596.432989482352d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8966210109053122d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 66.79123101403876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 501.07431175550084d);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     java.lang.String var8 = var0.nextHexString(110);
//     double var11 = var0.nextWeibull(0.01237694884401451d, 44.74362024702862d);
//     double var14 = var0.nextUniform((-6168.191987338353d), 884.5884346216443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextZipf(0, 39.767656779690114d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.0855286163412177d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "40b8482d849d91a0119b7788129d9f42761400795b0de20e2dd5c27a24e675f3cd96b913bf6e6adb449fcc2de2cd6f3d7e253842eafff1"+ "'", var8.equals("40b8482d849d91a0119b7788129d9f42761400795b0de20e2dd5c27a24e675f3cd96b913bf6e6adb449fcc2de2cd6f3d7e253842eafff1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.7468927195746574E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-5136.4437259517645d));
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var41, true);
    boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var33, var41, false);
    double[] var49 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var53 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var56 = new double[] { (-1.0d), (-1.0d)};
    boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var56);
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var49, var56);
    double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 1);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var60, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var62);
    double var64 = org.apache.commons.math3.util.MathArrays.safeNorm(var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var65 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var62);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure(1399632177780768928L);
    int var6 = var0.nextHypergeometric(254, 0, 254);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-582156205918565504L));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var31, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var51 = org.apache.commons.math3.util.MathArrays.linearCombination(var16, var48);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var6 = var4.nextPoisson(217.41609303033977d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var4.nextGamma(0.0d, 0.020945796376795382d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 212L);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var4.reSeed();
//     var4.reSeedSecure();
//     double var8 = var4.nextT(6.401745123441823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2.557501853098866d));
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-637204852), 61970744);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.lang.String var3 = var1.nextSecureHexString(10);
//     double var5 = var1.nextT(144.64259665111007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b1edf6a80b"+ "'", var3.equals("b1edf6a80b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.4823375725831536d);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextExponential(0.06400839652217086d);
//     int var11 = var0.nextZipf(110, 2.2879305597914734d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(1598992301, 12.57359046654414d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.5929563528261017d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c"+ "'", var6.equals("c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.061456207280835715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (-1));
    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100L, (java.lang.Number)(short)(-1), false);
    var2.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    java.lang.String var9 = var6.toString();
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.7084569304728279d, (java.lang.Number)122.12396088898325d, true);
    java.lang.Number var14 = var13.getMin();
    boolean var15 = var13.getBoundIsAllowed();
    var6.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)"+ "'", var9.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (-1)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 122.12396088898325d+ "'", var14.equals(122.12396088898325d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1687.4077771387995d));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d)};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    java.lang.Object[] var9 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var10, (java.lang.Object)var14);
    java.lang.Object var16 = var15.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     int var11 = var0.nextBinomial(100, 0.25809207497872494d);
//     double var15 = var0.nextUniform(2.901826881209396d, 3.452827866077632d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.2180780515435536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 3.450325028210327d);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var13, var14, false);
    double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    double var19 = org.apache.commons.math3.util.MathArrays.distance(var9, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 375.6315311789929d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 375.6315311789929d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 376.6315311789929d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d)};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    java.lang.Object[] var9 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var10, (java.lang.Object)var14);
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator();
    var16.reSeed();
    boolean var18 = var15.equals((java.lang.Object)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var16.nextUniform(0.5820250808619595d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var10, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100, (java.lang.Number)(byte)0, (-184300078), var10, false);
    java.lang.Number var15 = var14.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 100+ "'", var15.equals(100));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
    double[] var10 = org.apache.commons.math3.util.MathArrays.copyOf(var2);
    double[] var14 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var18 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var21 = new double[] { (-1.0d), (-1.0d)};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var14, var21);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    double[] var27 = org.apache.commons.math3.util.MathArrays.normalizeArray(var25, (-0.5996555078851037d));
    double[] var31 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var35 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d)};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var31, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    double[] var43 = null;
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var45, var46, false);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var43, var45);
    double[] var52 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 375.6315311789929d);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var45);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var25, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var55 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var10, var25);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)10.0d, (java.lang.Number)9.874886093050462d, (java.lang.Number)0.0f);
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)739.9960916531347d, var6, false);
    var4.addSuppressed((java.lang.Throwable)var8);
    boolean var10 = var8.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     var0.reSeedSecure(12L);
//     long var12 = var0.nextLong(100L, 848835256306514304L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.0578190919225893E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 508411937986428864L);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    int var5 = var0.nextPascal(110, 0.0d);
    var0.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.nextUniform(0.0d, (-1.6772154295120836d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextExponential((-11.703609724860312d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.4672573707561292d));
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 2.7497630628293734d};
    double[] var6 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var10 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var13 = new double[] { (-1.0d), (-1.0d)};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var6, var13);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    double[] var23 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var27 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var30 = new double[] { (-1.0d), (-1.0d)};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var23, var30);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var34);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double[] var60 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var64 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var67 = new double[] { (-1.0d), (-1.0d)};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var60, var67);
    double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 1);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[][] var73 = new double[][] { var71};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var56, var73);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var41, var73);
    boolean var77 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var41, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var81 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = var81.getDirection();
    java.lang.Throwable[] var83 = var81.getSuppressed();
    boolean var84 = var81.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var85 = var81.getDirection();
    boolean var87 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var85, true);
    org.apache.commons.math3.exception.MathIllegalStateException var88 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3976504751842537792L);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(1179441559, 0, 100);
//     double var8 = var0.nextGamma(100.0d, 0.6531021513294903d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial(0, 70.08715146676043d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 62.81895577992541d);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)216.6827952125197d, var1);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(1310072025, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9927121897553315d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "7"+ "'", var6.equals("7"));
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 1310072025);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    float[] var2 = new float[] { 100.0f, (-1.0f)};
    float[] var4 = new float[] { 10.0f};
    boolean var5 = org.apache.commons.math3.util.MathArrays.equals(var2, var4);
    float[] var8 = new float[] { 100.0f, (-1.0f)};
    float[] var10 = new float[] { 10.0f};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var8, var10);
    float[] var14 = new float[] { 100.0f, (-1.0f)};
    float[] var16 = new float[] { 10.0f};
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var14, var16);
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var14);
    float[] var21 = new float[] { 100.0f, (-1.0f)};
    float[] var23 = new float[] { 10.0f};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var21, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var14, var23);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var4, var14);
    float[] var29 = new float[] { 100.0f, (-1.0f)};
    float[] var31 = new float[] { 10.0f};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var29, var31);
    float[] var35 = new float[] { 100.0f, (-1.0f)};
    float[] var37 = new float[] { 10.0f};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var35, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var31, var35);
    float[] var41 = new float[] { 0.0f};
    float[] var44 = new float[] { 100.0f, (-1.0f)};
    float[] var46 = new float[] { 10.0f};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var44, var46);
    float[] var50 = new float[] { 100.0f, (-1.0f)};
    float[] var52 = new float[] { 10.0f};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var50, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var46, var50);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var41, var46);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var46);
    float[] var59 = new float[] { 100.0f, (-1.0f)};
    float[] var61 = new float[] { 10.0f};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equals(var59, var61);
    float[] var65 = new float[] { 100.0f, (-1.0f)};
    float[] var67 = new float[] { 10.0f};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var65, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var61, var65);
    float[] var71 = new float[] { 0.0f};
    float[] var74 = new float[] { 100.0f, (-1.0f)};
    float[] var76 = new float[] { 10.0f};
    boolean var77 = org.apache.commons.math3.util.MathArrays.equals(var74, var76);
    float[] var80 = new float[] { 100.0f, (-1.0f)};
    float[] var82 = new float[] { 10.0f};
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var80, var82);
    boolean var84 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var76, var80);
    boolean var85 = org.apache.commons.math3.util.MathArrays.equals(var71, var76);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var76);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var31, var61);
    boolean var88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var61);
    float[] var91 = new float[] { 10.0f, 0.0f};
    boolean var92 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-28.157532246567285d), (java.lang.Number)45958437, true);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-3.956734617801294d), (java.lang.Number)(-6168.191987338353d), 631747952);
    java.lang.Number var4 = var3.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    boolean var6 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-6168.191987338353d)+ "'", var4.equals((-6168.191987338353d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(87.41926244809311d, 87.41926244809311d, 0.4245701161410406d, 0.0d, (-247.81796506599633d), 84.81643549678465d, 3.247351743622313d, (-11.703609724860312d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-13414.914739442627d));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)(-1.0f), (java.lang.Number)(byte)1);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)10+ "'", var4.equals((short)10));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getValue();
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
    double var8 = var7.nextGaussian();
    double var9 = var7.nextGaussian();
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    var7.setSeed(var13);
    int[] var20 = new int[] { 1, 0, (-1)};
    int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
    org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(0);
    double var26 = var25.nextGaussian();
    double var27 = var25.nextGaussian();
    int[] var31 = new int[] { 1, 0, (-1)};
    int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    var25.setSeed(var31);
    org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(0);
    double var37 = var36.nextGaussian();
    double var38 = var36.nextGaussian();
    int[] var42 = new int[] { 1, 0, (-1)};
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 1);
    var36.setSeed(var42);
    int var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var31, var42);
    double var47 = org.apache.commons.math3.util.MathArrays.distance(var13, var42);
    org.apache.commons.math3.random.Well19937c var48 = new org.apache.commons.math3.random.Well19937c(var13);
    boolean var49 = var2.equals((java.lang.Object)var48);
    int var50 = var48.nextInt();
    int[] var54 = new int[] { 1, 0, (-1)};
    int[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var54, 1);
    org.apache.commons.math3.random.Well19937c var58 = new org.apache.commons.math3.random.Well19937c(0);
    double var59 = var58.nextGaussian();
    double var60 = var58.nextGaussian();
    int[] var64 = new int[] { 1, 0, (-1)};
    int[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
    var58.setSeed(var64);
    int[] var71 = new int[] { 1, 0, (-1)};
    int[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var71, 1);
    int var74 = org.apache.commons.math3.util.MathArrays.distanceInf(var64, var71);
    double var75 = org.apache.commons.math3.util.MathArrays.distance(var56, var71);
    int[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var71);
    var48.setSeed(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2125371022);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy(48.550599067346205d, 32.58103641305895d);
    double var9 = var4.nextExponential(13.603169545881526d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var4.nextSecureInt(1, (-194062463));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 59.873976984192424d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 11.225710856050238d);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     var0.reSeedSecure(12L);
//     long var12 = var0.nextLong(100L, 848835256306514304L);
//     int var15 = var0.nextInt(0, 1179441559);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5697783743998427E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 44626379703140080L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 262463199);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeed();
//     double var12 = var0.nextT(0.5775301166847077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-3.5898235818537954d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 47.03356375242188d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-0.1093123616992864d));
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    boolean var6 = var3.getStrict();
    int var7 = var3.getIndex();
    java.lang.Number var8 = var3.getPrevious();
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1+ "'", var8.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    boolean var4 = var3.getStrict();
    java.lang.Number var5 = var3.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1+ "'", var5.equals(1));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var15 = var14.getValue();
    java.lang.Object var16 = var14.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 10.0d+ "'", var15.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + 10.0d+ "'", var16.equals(10.0d));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var19 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, (-3.507053523554667d));
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d)};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    java.lang.Object[] var9 = new java.lang.Object[] { var7};
    org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NullArgumentException var12 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var12);
    org.apache.commons.math3.exception.util.ExceptionContext var14 = var13.getContext();
    org.apache.commons.math3.util.Pair var15 = new org.apache.commons.math3.util.Pair((java.lang.Object)var10, (java.lang.Object)var14);
    org.apache.commons.math3.random.RandomDataGenerator var16 = new org.apache.commons.math3.random.RandomDataGenerator();
    var16.reSeed();
    boolean var18 = var15.equals((java.lang.Object)var16);
    var16.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     int var11 = var0.nextBinomial(100, 0.25809207497872494d);
//     var0.reSeedSecure((-246349375317088864L));
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    var0.reSeedSecure();
    long var6 = var0.nextLong((-92980537556062544L), 0L);
    double var9 = var0.nextWeibull(0.33272672175073054d, 1.3322389030366206d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var0.nextLong(508411937986428864L, 300L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-23873527793096324L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.9578581700831809d);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(1000.0d);
//     double var4 = var0.nextT(157.18791807569124d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5458376476086099d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.34401133699718167d));
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(416L);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     java.lang.String var8 = var0.nextHexString(110);
//     double var11 = var0.nextWeibull(0.01237694884401451d, 44.74362024702862d);
//     double var14 = var0.nextUniform((-6168.191987338353d), 884.5884346216443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(87, 109, 275296862);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-10.045474402422359d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "7f4c13bbdab434165a6005844a064484a9684b8dc358160ba850faa869a64570c0c16ec324d7fc957ac40d939de861200ceea8c9aec3f7"+ "'", var8.equals("7f4c13bbdab434165a6005844a064484a9684b8dc358160ba850faa869a64570c0c16ec324d7fc957ac40d939de861200ceea8c9aec3f7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.501195138978223E-84d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1055.2231783179614d));
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     double var12 = var0.nextUniform((-10019.332251989288d), (-6168.191987338353d));
//     double var14 = var0.nextT(9.869894776045927d);
//     long var17 = var0.nextSecureLong(1L, 433L);
//     double var20 = var0.nextF(0.5248295573436604d, 0.4948515015507633d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4745968373686235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-7352.925227567752d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.300126890764717d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 318L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.287486503033214d);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(257196080);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NullArgumentException var3 = new org.apache.commons.math3.exception.NullArgumentException();
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Object[] var5 = new java.lang.Object[] { var3};
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var2, var5);
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var5);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeed();
    int var5 = var0.nextHypergeometric(1179441559, 0, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var0.nextUniform(394.6481650409899d, 0.0d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     double var11 = var0.nextUniform((-11.293482242235479d), 0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.277608058113781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-9.76154327037678d));
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 2.7497630628293734d};
    double[] var6 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var10 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var13 = new double[] { (-1.0d), (-1.0d)};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var6, var13);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    double[] var23 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var27 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var30 = new double[] { (-1.0d), (-1.0d)};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var23, var30);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var34);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double[] var60 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var64 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var67 = new double[] { (-1.0d), (-1.0d)};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var60, var67);
    double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 1);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[][] var73 = new double[][] { var71};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var56, var73);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var17, var41, var73);
    boolean var77 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var41, true);
    org.apache.commons.math3.exception.MathIllegalArgumentException var78 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var82 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var83 = var82.getDirection();
    boolean var85 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var83, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 176);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(0);
    double var20 = var19.nextGaussian();
    double var21 = var19.nextGaussian();
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    var19.setSeed(var25);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(0);
    double var31 = var30.nextGaussian();
    double var32 = var30.nextGaussian();
    int[] var36 = new int[] { 1, 0, (-1)};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    var30.setSeed(var36);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var7, var25);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     var0.reSeed(5326384455157762505L);
//     int[] var11 = var0.nextPermutation(5494866, 92);
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
//     double var14 = var13.nextGaussian();
//     float var15 = var13.nextFloat();
//     var13.setSeed(10L);
//     float var18 = var13.nextFloat();
//     float var19 = var13.nextFloat();
//     int[] var21 = new int[] { 100};
//     org.apache.commons.math3.random.Well19937c var23 = new org.apache.commons.math3.random.Well19937c(0);
//     double var24 = var23.nextGaussian();
//     double var25 = var23.nextGaussian();
//     int[] var29 = new int[] { 1, 0, (-1)};
//     int[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
//     var23.setSeed(var29);
//     int[] var36 = new int[] { 1, 0, (-1)};
//     int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
//     int var39 = org.apache.commons.math3.util.MathArrays.distanceInf(var29, var36);
//     org.apache.commons.math3.random.Well19937c var41 = new org.apache.commons.math3.random.Well19937c(0);
//     double var42 = var41.nextGaussian();
//     double var43 = var41.nextGaussian();
//     int[] var47 = new int[] { 1, 0, (-1)};
//     int[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 1);
//     var41.setSeed(var47);
//     org.apache.commons.math3.random.Well19937c var52 = new org.apache.commons.math3.random.Well19937c(0);
//     double var53 = var52.nextGaussian();
//     double var54 = var52.nextGaussian();
//     int[] var58 = new int[] { 1, 0, (-1)};
//     int[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var58, 1);
//     var52.setSeed(var58);
//     int var62 = org.apache.commons.math3.util.MathArrays.distanceInf(var47, var58);
//     double var63 = org.apache.commons.math3.util.MathArrays.distance(var29, var47);
//     double var64 = org.apache.commons.math3.util.MathArrays.distance(var21, var47);
//     var13.setSeed(var47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var66 = org.apache.commons.math3.util.MathArrays.distance(var11, var47);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.233510586966717d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.40877557f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.23239756f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 99.0d);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     double var10 = var0.nextWeibull(48.550599067346205d, 0.5775301166847077d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextInt(0, (-194062463));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 78.69095576278832d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5374102149268405d);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, (-1));
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var9 = var0.nextLong(32L, 212L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var11 = var0.nextHexString(1310072025);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.842227265887696d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2"+ "'", var6.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 60L);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var11 = var10.getIndex();
    var6.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = var10.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var15 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)100.00999950005d, (java.lang.Number)0.33732388204490654d, 5494866, var13, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.39543159219858365d, (java.lang.Number)29, true);
    java.lang.Object var4 = null;
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var4, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getFirst();
    java.lang.Object var8 = var6.getFirst();
    double[] var10 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    boolean var13 = org.apache.commons.math3.util.MathArrays.isMonotonic(var10, var11, false);
    boolean var14 = var6.equals((java.lang.Object)var13);
    java.lang.Object var15 = var6.getFirst();
    java.lang.Object var16 = var6.getFirst();
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var33);
    boolean var35 = var6.equals((java.lang.Object)var33);
    java.lang.Object var36 = var6.getSecond();
    org.apache.commons.math3.util.Pair var37 = new org.apache.commons.math3.util.Pair((java.lang.Object)true, (java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + 10.0d+ "'", var36.equals(10.0d));

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var41, true);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var33, var41, false);
//     double[] var46 = null;
//     double[] var48 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var49 = null;
//     boolean var51 = org.apache.commons.math3.util.MathArrays.isMonotonic(var48, var49, false);
//     double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
//     boolean var53 = org.apache.commons.math3.util.MathArrays.equals(var46, var48);
//     double[] var54 = org.apache.commons.math3.util.MathArrays.ebeAdd(var33, var46);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double[] var18 = null;
    double[] var20 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = null;
    boolean var23 = org.apache.commons.math3.util.MathArrays.isMonotonic(var20, var21, false);
    double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var20);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var18, var20);
    double[] var27 = org.apache.commons.math3.util.MathArrays.normalizeArray(var20, 375.6315311789929d);
    double[] var29 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var30 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.isMonotonic(var29, var30, false);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var34);
    double var36 = org.apache.commons.math3.util.MathArrays.distanceInf(var16, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var16);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var38 = var37.getDirection();
    boolean var40 = org.apache.commons.math3.util.MathArrays.isMonotonic(var33, var38, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var41 = org.apache.commons.math3.util.MathArrays.ebeAdd(var16, var33);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 0);
//     org.apache.commons.math3.util.MathArrays.checkPositive(var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16);
//     double[] var19 = null;
//     boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
//     double[] var21 = null;
//     double var22 = org.apache.commons.math3.util.MathArrays.linearCombination(var19, var21);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)631747952);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var15 = var14.getMax();
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    long[] var17 = null;
    long[][] var18 = new long[][] { var17};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
    org.apache.commons.math3.exception.MathInternalError var23 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)0+ "'", var15.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)(-10061.983597329241d), 0);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (-10,061.984 >= null)"+ "'", var4.equals("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (-10,061.984 >= null)"));

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    var1.setSeed(12486998);
    float var14 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8420423f);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var5, false);
    java.lang.Number var8 = var7.getMin();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    double[] var12 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var13 = null;
    boolean var15 = org.apache.commons.math3.util.MathArrays.isMonotonic(var12, var13, false);
    java.lang.Object[] var16 = new java.lang.Object[] { var15};
    org.apache.commons.math3.exception.MathArithmeticException var17 = new org.apache.commons.math3.exception.MathArithmeticException(var10, var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var16);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)231.61046862721562d, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalArgumentException var22 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)3976504751842537792L, (java.lang.Number)(-1.4304785683372014d), (java.lang.Number)0.06400839652217086d);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = var3.getDirection();
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var3.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 45, 4);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[][] var13 = null;
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var13);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure((-1L));
//     long var9 = var0.nextSecureLong(1L, 416L);
//     int var12 = var0.nextZipf(3, 0.5119517370126986d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 778904761);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 82L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var18 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var15);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.2787313252014696d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextWeibull(1.908642352606886d, 0.9777587052356126d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var4.nextF(166.73485835388425d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.9426571811852562d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     java.lang.Object var0 = null;
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getFirst();
//     java.lang.Object var4 = var2.getFirst();
//     java.lang.Object var5 = var2.getValue();
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(0);
//     double var8 = var7.nextGaussian();
//     double var9 = var7.nextGaussian();
//     int[] var13 = new int[] { 1, 0, (-1)};
//     int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
//     var7.setSeed(var13);
//     int[] var20 = new int[] { 1, 0, (-1)};
//     int[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var20);
//     org.apache.commons.math3.random.Well19937c var25 = new org.apache.commons.math3.random.Well19937c(0);
//     double var26 = var25.nextGaussian();
//     double var27 = var25.nextGaussian();
//     int[] var31 = new int[] { 1, 0, (-1)};
//     int[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
//     var25.setSeed(var31);
//     org.apache.commons.math3.random.Well19937c var36 = new org.apache.commons.math3.random.Well19937c(0);
//     double var37 = var36.nextGaussian();
//     double var38 = var36.nextGaussian();
//     int[] var42 = new int[] { 1, 0, (-1)};
//     int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 1);
//     var36.setSeed(var42);
//     int var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var31, var42);
//     double var47 = org.apache.commons.math3.util.MathArrays.distance(var13, var42);
//     org.apache.commons.math3.random.Well19937c var48 = new org.apache.commons.math3.random.Well19937c(var13);
//     boolean var49 = var2.equals((java.lang.Object)var48);
//     java.util.List var50 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var51 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var48, var50);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     double var11 = var0.nextWeibull(0.33732388204490654d, 121.57001259402712d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextF((-159.42639435948843d), 462.99687420008513d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "e5173f67d69c8930bbb4d291011b016bf3748c6369c25676db8e39f992b8d79ac4184d899869625c4460e7301f2a32c24059"+ "'", var3.equals("e5173f67d69c8930bbb4d291011b016bf3748c6369c25676db8e39f992b8d79ac4184d899869625c4460e7301f2a32c24059"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1228.6177128007673d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-192587640484830272L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.43585783247089527d);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getValue();
    java.lang.Object var6 = var2.getValue();
    java.lang.Object var7 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 10.0d+ "'", var5.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 10.0d+ "'", var6.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    int[] var1 = null;
    var0.setSeed(var1);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
    double var5 = var4.nextGaussian();
    double var6 = var4.nextGaussian();
    int[] var10 = new int[] { 1, 0, (-1)};
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    var4.setSeed(var10);
    org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(0);
    double var16 = var15.nextGaussian();
    double var17 = var15.nextGaussian();
    int[] var21 = new int[] { 1, 0, (-1)};
    int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    var15.setSeed(var21);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var10, var21);
    int[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var10);
    var0.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(0);
    double var31 = var30.nextGaussian();
    double var32 = var30.nextGaussian();
    var30.setSeed((-1));
    boolean var35 = var30.nextBoolean();
    long var36 = var30.nextLong();
    var30.setSeed(1);
    double var39 = var30.nextDouble();
    org.apache.commons.math3.exception.util.Localizable var40 = null;
    org.apache.commons.math3.exception.OutOfRangeException var44 = new org.apache.commons.math3.exception.OutOfRangeException(var40, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var45 = var44.getHi();
    org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var30, (java.lang.Object)var45);
    java.lang.Object var47 = var46.getKey();
    org.apache.commons.math3.util.Pair var48 = new org.apache.commons.math3.util.Pair((java.lang.Object)var0, (java.lang.Object)var46);
    java.lang.Object var49 = var46.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1.0d)+ "'", var45.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + (-1.0d)+ "'", var49.equals((-1.0d)));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.5775301166847077d, (java.lang.Number)0.42311526636401314d, (java.lang.Number)0.25809207497872494d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     long[][] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 176);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 10);
    double[] var15 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var19 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var22 = new double[] { (-1.0d), (-1.0d)};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var15, var22);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 1);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
    double[] var31 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var35 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d)};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var31, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    double[] var43 = null;
    double[] var45 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var46 = null;
    boolean var48 = org.apache.commons.math3.util.MathArrays.isMonotonic(var45, var46, false);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var45);
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var43, var45);
    double[] var52 = org.apache.commons.math3.util.MathArrays.normalizeArray(var45, 375.6315311789929d);
    double var53 = org.apache.commons.math3.util.MathArrays.distanceInf(var42, var45);
    double var54 = org.apache.commons.math3.util.MathArrays.distance1(var26, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var55 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var26);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = var9.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var12 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var10, true);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var14 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)(byte)(-1), 2099284361, var10, true);
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    org.apache.commons.math3.util.MathArrays.checkOrder(var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    double[] var50 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var31, var48);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var54 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var55 = var54.getDirection();
    double[] var59 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var63 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d)};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var63, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var59, var66);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 1);
    double[] var74 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var78 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var81 = new double[] { (-1.0d), (-1.0d)};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var78, var81);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var74, var81);
    double[] var85 = org.apache.commons.math3.util.MathArrays.copyOf(var81, 1);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
    double[][] var87 = new double[][] { var85};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var70, var87);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var55, var87);
    org.apache.commons.math3.exception.NotFiniteNumberException var90 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(byte)1, (java.lang.Object[])var87);
    org.apache.commons.math3.exception.MathIllegalStateException var91 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var15, (java.lang.Object[])var87);
    boolean var92 = var14.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure(848835256306514304L);
//     int var12 = var0.nextZipf(45, 9.869894776045927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 49.85320620660685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getHi();
    java.lang.Number var7 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.0d)+ "'", var6.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)10+ "'", var7.equals((short)10));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var72 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var75 = new double[] { (-1.0d), (-1.0d)};
    boolean var76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var72, var75);
    double var77 = org.apache.commons.math3.util.MathArrays.distanceInf(var68, var72);
    double[] var81 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var85 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var88 = new double[] { (-1.0d), (-1.0d)};
    boolean var89 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var85, var88);
    boolean var90 = org.apache.commons.math3.util.MathArrays.equals(var81, var88);
    double[] var92 = org.apache.commons.math3.util.MathArrays.copyOf(var88, 1);
    double var93 = org.apache.commons.math3.util.MathArrays.safeNorm(var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var68, var92);
    double var95 = org.apache.commons.math3.util.MathArrays.safeNorm(var94);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var97 = org.apache.commons.math3.util.MathArrays.copyOf(var94, 945548341);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 1.0d);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     long var10 = var0.nextPoisson(0.39543159219858365d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextZipf(230354947, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 514.371834303958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.2746640120048481d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6531021513294903d, (java.lang.Number)(-26.249224039236346d), true);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    double var9 = var4.nextExponential(0.33904363745058674d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.27978816471901674d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     double var11 = var0.nextWeibull(0.33732388204490654d, 121.57001259402712d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(64, (-6794.82298306819d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "85d53f8267bb72721f02728a27bef9ae2650257dcc03149cc4c077ae03c53c122114ce11ec4380f94a4eab66dd293bf1c922"+ "'", var3.equals("85d53f8267bb72721f02728a27bef9ae2650257dcc03149cc4c077ae03c53c122114ce11ec4380f94a4eab66dd293bf1c922"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 692.021891624637d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-84839603615866000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1081.1023838638548d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(1);
    double var10 = var1.nextDouble();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    org.apache.commons.math3.exception.OutOfRangeException var15 = new org.apache.commons.math3.exception.OutOfRangeException(var11, (java.lang.Number)1.0d, (java.lang.Number)(short)10, (java.lang.Number)(-1.0d));
    java.lang.Number var16 = var15.getHi();
    org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var1, (java.lang.Object)var16);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(0);
    double var20 = var19.nextGaussian();
    double var21 = var19.nextGaussian();
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    var19.setSeed(var25);
    float var29 = var19.nextFloat();
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(0);
    double var32 = var31.nextGaussian();
    double var33 = var31.nextGaussian();
    var31.setSeed((-1));
    byte[] var39 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var31.nextBytes(var39);
    var19.nextBytes(var39);
    float var42 = var19.nextFloat();
    boolean var43 = var17.equals((java.lang.Object)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2787313252014696d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1.0d)+ "'", var16.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.21556675f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var8 = var7.getMax();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    long[] var10 = null;
    long[][] var11 = new long[][] { var10};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var9, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.21556675f, (java.lang.Object[])var11);
    org.apache.commons.math3.util.MathArrays.checkRectangular(var11);
    org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)0+ "'", var8.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    int var5 = var0.nextBinomial(64, 3.806445132111327E-6d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.nextBinomial(778904761, (-13414.914739442627d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     var1.setSeed((-1));
//     boolean var6 = var1.nextBoolean();
//     long var7 = var1.nextLong();
//     var1.setSeed(275296862);
//     int var10 = var1.nextInt();
//     org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var13 = var11.nextSecureHexString(64);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var11.nextZipf(1819577945, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1399632177780768928L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-528848821));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "325a52a2751a8bdb4e9b1ea849650cd0d85b0185e7cc57bfc40d9fbd5919d37a"+ "'", var13.equals("325a52a2751a8bdb4e9b1ea849650cd0d85b0185e7cc57bfc40d9fbd5919d37a"));
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var5 = var0.nextChiSquare(1.6281116695939835d);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.27709893814304387d);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    var4.reSeed(0L);
    long var12 = var4.nextLong((-246349375317088864L), 53686164009667304L);
    var4.reSeedSecure(5326384455157762505L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var17 = var4.nextBeta((-5.075035468950752d), 0.9791637145970279d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-23350460807812264L));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0L);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var1, false);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.Number var7 = var3.getArgument();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var20 = new double[] { (-1.0d), (-1.0d)};
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
    boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
    double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    org.apache.commons.math3.util.MathArrays.checkOrder(var24);
    double[] var30 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var34 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var37 = new double[] { (-1.0d), (-1.0d)};
    boolean var38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var34, var37);
    boolean var39 = org.apache.commons.math3.util.MathArrays.equals(var30, var37);
    double[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var41);
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var41);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var50 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var51 = var50.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var53 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var51, true);
    boolean var55 = org.apache.commons.math3.util.MathArrays.isMonotonic(var43, var51, false);
    double[] var59 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var63 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d)};
    boolean var67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var63, var66);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equals(var59, var66);
    double[] var70 = org.apache.commons.math3.util.MathArrays.copyOf(var66, 1);
    double[] var74 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var78 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var81 = new double[] { (-1.0d), (-1.0d)};
    boolean var82 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var78, var81);
    boolean var83 = org.apache.commons.math3.util.MathArrays.equals(var74, var81);
    double[] var85 = org.apache.commons.math3.util.MathArrays.copyOf(var81, 1);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var85);
    double[][] var87 = new double[][] { var85};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var70, var87);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var43, var87);
    org.apache.commons.math3.exception.MathInternalError var90 = new org.apache.commons.math3.exception.MathInternalError(var9, (java.lang.Object[])var87);
    org.apache.commons.math3.exception.MathIllegalStateException var91 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var8, (java.lang.Object[])var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0f+ "'", var7.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    double var11 = var4.nextUniform((-11.293482242235479d), 0.16021426377524167d, false);
    int var14 = var4.nextBinomial(1, 0.16021426377524167d);
    double var16 = var4.nextExponential(100.00999950005d);
    double var18 = var4.nextExponential(939.2076725668584d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-8.05185587726462d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4.243739267853726d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 487.8294604791323d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)435864187);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeedSecure();
    var0.reSeedSecure();
    var0.reSeed(848835256306514304L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var0.nextLong(3976504751842537792L, 12L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     double var9 = var0.nextBeta(4.874293883290859d, 9.874886093050462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 240.0149220088491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 389.64156193514617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.3965103203985803d);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var0, (java.lang.Number)3757806182885320704L, 92, var7, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.0f);
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var3, false);
    java.lang.Number var6 = var5.getMin();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var12 = var11.getMax();
    org.apache.commons.math3.exception.util.Localizable var13 = null;
    long[] var14 = null;
    long[][] var15 = new long[][] { var14};
    org.apache.commons.math3.util.MathArrays.checkRectangular(var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var11, var13, (java.lang.Object[])var15);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var7, (java.lang.Object[])var15);
    var1.addSuppressed((java.lang.Throwable)var18);
    boolean var20 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (short)0+ "'", var12.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 0, 293718977);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(0);
    double var14 = var13.nextGaussian();
    double var15 = var13.nextGaussian();
    int[] var19 = new int[] { 1, 0, (-1)};
    int[] var21 = org.apache.commons.math3.util.MathArrays.copyOf(var19, 1);
    var13.setSeed(var19);
    int[] var26 = new int[] { 1, 0, (-1)};
    int[] var28 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    int var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var19, var26);
    org.apache.commons.math3.random.Well19937c var31 = new org.apache.commons.math3.random.Well19937c(0);
    double var32 = var31.nextGaussian();
    double var33 = var31.nextGaussian();
    int[] var37 = new int[] { 1, 0, (-1)};
    int[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var37, 1);
    var31.setSeed(var37);
    org.apache.commons.math3.random.Well19937c var42 = new org.apache.commons.math3.random.Well19937c(0);
    double var43 = var42.nextGaussian();
    double var44 = var42.nextGaussian();
    int[] var48 = new int[] { 1, 0, (-1)};
    int[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
    var42.setSeed(var48);
    int var52 = org.apache.commons.math3.util.MathArrays.distanceInf(var37, var48);
    double var53 = org.apache.commons.math3.util.MathArrays.distance(var19, var48);
    var1.setSeed(var19);
    float var55 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var56 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.49485147f);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     var0.reSeed();
//     int var12 = var0.nextSecureInt(0, 1995398530);
//     double var15 = var0.nextBeta(69.65752740908655d, 116.39029946236744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.1609554592546993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8426e7e322b24e35a4c55ead641b5143210bb9fac8ce7be6b1047587c21181f3436841f0e7d0610ab420d99bccea1bb8f5c9"+ "'", var6.equals("8426e7e322b24e35a4c55ead641b5143210bb9fac8ce7be6b1047587c21181f3436841f0e7d0610ab420d99bccea1bb8f5c9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1837490728);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.4135467751262189d);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextCauchy(35.85347665729908d, (-6794.82298306819d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 67.41130939663387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.6917849680752495d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-5.311866859834735d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-53.56051691255462d));
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)116.39029946236744d, (java.lang.Number)(-1863896756680379904L), (java.lang.Number)596.432989482352d);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    double var9 = var4.nextExponential(0.27012747803685033d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var4.nextCauchy(445.66983836660324d, (-0.5996555078851037d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.22291664839491906d);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextSecureInt(29, 109);
//     var0.reSeedSecure(21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 38);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     int var9 = var0.nextInt(1, 1819577945);
//     long var12 = var0.nextLong((-582156205918565504L), 15L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation(1898741791, 254);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 154.97148070455015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.383662745889d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1174175596);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-155080908669798144L));
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
//     double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var20 = new double[] { (-1.0d), (-1.0d)};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
//     double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var29 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var36 = new double[] { (-1.0d), (-1.0d)};
//     boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var29, var36);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var40);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var40);
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var2, var43);
//     double[] var45 = null;
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeDivide(var2, var45);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var17);
    double[] var19 = org.apache.commons.math3.util.MathArrays.copyOf(var17);
    org.apache.commons.math3.util.MathArrays.checkPositive(var19);
    double[] var24 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var28 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var31 = new double[] { (-1.0d), (-1.0d)};
    boolean var32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var28, var31);
    boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var24, var31);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 1);
    double var36 = org.apache.commons.math3.util.MathArrays.safeNorm(var35);
    org.apache.commons.math3.util.MathArrays.checkOrder(var35);
    double[] var41 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var45 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var48 = new double[] { (-1.0d), (-1.0d)};
    boolean var49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var45, var48);
    boolean var50 = org.apache.commons.math3.util.MathArrays.equals(var41, var48);
    double[] var52 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 1);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var52);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var35, var52);
    double[] var56 = new double[] { 10.0d};
    double[] var60 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var64 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var67 = new double[] { (-1.0d), (-1.0d)};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var60, var67);
    double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 1);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    org.apache.commons.math3.util.MathArrays.checkOrder(var71);
    double[] var77 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var81 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var84 = new double[] { (-1.0d), (-1.0d)};
    boolean var85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var81, var84);
    boolean var86 = org.apache.commons.math3.util.MathArrays.equals(var77, var84);
    double[] var88 = org.apache.commons.math3.util.MathArrays.copyOf(var84, 1);
    double var89 = org.apache.commons.math3.util.MathArrays.safeNorm(var88);
    double[] var90 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var71, var88);
    double var91 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeDivide(var56, var71);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var94 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var19, var93);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(159L);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0d), (java.lang.Number)100, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100+ "'", var4.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (100)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (100)"));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.9802138153623559d, (java.lang.Number)0.42311526636401314d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.42311526636401314d+ "'", var4.equals(0.42311526636401314d));

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     int var5 = var0.nextPascal(110, 0.0d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 293718977);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     double var11 = var0.nextWeibull(0.33732388204490654d, 121.57001259402712d);
//     double var14 = var0.nextGaussian(54.529582702346616d, 0.3438501360557338d);
//     var0.reSeed(14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "538109af6ace7727c234d542d659226cffc9fec7328b0e507609b94f1d767c4c23db8e93cc9e6ae0d9132d14d6dab8ef818a"+ "'", var3.equals("538109af6ace7727c234d542d659226cffc9fec7328b0e507609b94f1d767c4c23db8e93cc9e6ae0d9132d14d6dab8ef818a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 940.679333246855d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-47103720363397112L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.01053461017636881d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 54.15995616551996d);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    long var10 = var4.nextLong((-582156205918565504L), (-93072929058176752L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var13 = var4.nextSecureLong(9128399031861897490L, 13L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-443735806521307840L));

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var28 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var32 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d)};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var28, var35);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 1);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var22, var39);
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double var57 = org.apache.commons.math3.util.MathArrays.safeNorm(var56);
    org.apache.commons.math3.util.MathArrays.checkOrder(var56);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var73);
    double[] var76 = org.apache.commons.math3.util.MathArrays.ebeDivide(var41, var73);
    org.apache.commons.math3.exception.NumberIsTooLargeException var80 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var85 = var84.getIndex();
    var80.addSuppressed((java.lang.Throwable)var84);
    org.apache.commons.math3.util.MathArrays.OrderDirection var87 = var84.getDirection();
    boolean var90 = org.apache.commons.math3.util.MathArrays.checkOrder(var41, var87, true, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var91 = null;
    boolean var94 = org.apache.commons.math3.util.MathArrays.checkOrder(var41, var91, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var95 = org.apache.commons.math3.util.MathArrays.ebeAdd(var6, var41);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == true);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.19834426208730332d);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var4.reSeed();
    var4.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var4.nextBinomial(998139946, (-0.34401133699718167d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    float var11 = var1.nextFloat();
    boolean var12 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double[] var26 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var30 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var33 = new double[] { (-1.0d), (-1.0d)};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var26, var33);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 1);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[][] var39 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var22, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var2, var22);
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 0);
    double[] var62 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var65 = new double[] { (-1.0d), (-1.0d)};
    boolean var66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var62, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var65);
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var56, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var67);
    double[] var71 = org.apache.commons.math3.util.MathArrays.normalizeArray(var67, 0.2566940702719748d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     var0.reSeed();
//     int var19 = var0.nextInt(315774327, 1009135716);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 667.2527291914216d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.3044083663677275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.014197265325401665d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 778484104);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var19 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var20 = var19.getDirection();
//     boolean var22 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var20, false);
//     double var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var15);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }
// 
// 
//     org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.0d, (java.lang.Number)1399632177780768928L, (java.lang.Number)(-1));
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Number var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
//     java.lang.Number var9 = var8.getMin();
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
//     java.lang.Number var15 = var14.getMax();
//     org.apache.commons.math3.exception.util.Localizable var16 = null;
//     long[] var17 = null;
//     long[][] var18 = new long[][] { var17};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var14, var16, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, (java.lang.Object[])var18);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var18);
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var18);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    float var7 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.07587421f);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    var0.reSeedSecure();
    long var6 = var0.nextLong((-7259342812136017821L), 300L);
    double var10 = var0.nextUniform(0.10377755771785362d, 87.41926244809311d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1863896756680379904L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 51.77851988158331d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     double var6 = var0.nextBeta(575.3928572028764d, 12.658839462906196d);
//     var0.reSeedSecure();
//     long var10 = var0.nextLong(0L, 2L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(0, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9440986178873232d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9782042469297524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var7 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)100, var7);
    org.apache.commons.math3.exception.MathIllegalArgumentException var9 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var7);
    org.apache.commons.math3.exception.NullArgumentException var10 = new org.apache.commons.math3.exception.NullArgumentException(var2, var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)998139946, var7);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
//     double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
//     double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var14);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var41 = var40.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var43 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)1, (java.lang.Number)(-1L), 1, var41, true);
//     boolean var45 = org.apache.commons.math3.util.MathArrays.isMonotonic(var33, var41, false);
//     double[] var49 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var53 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var56 = new double[] { (-1.0d), (-1.0d)};
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var56);
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var49, var56);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 1);
//     double[] var64 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var68 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var71 = new double[] { (-1.0d), (-1.0d)};
//     boolean var72 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var68, var71);
//     boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var64, var71);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.copyOf(var71, 1);
//     double var76 = org.apache.commons.math3.util.MathArrays.safeNorm(var75);
//     double[][] var77 = new double[][] { var75};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var60, var77);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var33, var77);
//     double[] var80 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var81 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var33, var80);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     int var9 = var0.nextInt(1, 1819577945);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextInt(1173104402, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 259.5339273841545d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 582.311502147536d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1340661031);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2125371022);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    int[] var1 = new int[] { 100};
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(0);
    double var4 = var3.nextGaussian();
    double var5 = var3.nextGaussian();
    int[] var9 = new int[] { 1, 0, (-1)};
    int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 1);
    var3.setSeed(var9);
    int[] var16 = new int[] { 1, 0, (-1)};
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 1);
    int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var16);
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(0);
    double var22 = var21.nextGaussian();
    double var23 = var21.nextGaussian();
    int[] var27 = new int[] { 1, 0, (-1)};
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    var21.setSeed(var27);
    org.apache.commons.math3.random.Well19937c var32 = new org.apache.commons.math3.random.Well19937c(0);
    double var33 = var32.nextGaussian();
    double var34 = var32.nextGaussian();
    int[] var38 = new int[] { 1, 0, (-1)};
    int[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    var32.setSeed(var38);
    int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var27, var38);
    double var43 = org.apache.commons.math3.util.MathArrays.distance(var9, var27);
    double var44 = org.apache.commons.math3.util.MathArrays.distance(var1, var27);
    int[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 12486998);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 99.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)100, var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, var4);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = var10.getDirection();
    var6.addSuppressed((java.lang.Throwable)var10);
    boolean var13 = var10.getStrict();
    int var14 = var10.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var7);
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var7);
    int[] var16 = new int[] { 1, 0, (-1)};
    int[] var18 = org.apache.commons.math3.util.MathArrays.copyOf(var16, 1);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var16);
    var12.setSeed(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     int var5 = var0.nextPascal(110, 0.0d);
//     int var8 = var0.nextSecureInt(1009783546, 1179441559);
//     long var11 = var0.nextSecureLong((-246349375317088864L), 3976504751842537792L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextZipf((-184300078), 228.5581296305497d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1137520859);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1514382758116659456L);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(10, 61970744);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(0);
    double var7 = var6.nextGaussian();
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(0);
    double var10 = var9.nextGaussian();
    double var11 = var9.nextGaussian();
    int[] var15 = new int[] { 1, 0, (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    var9.setSeed(var15);
    float var19 = var9.nextFloat();
    org.apache.commons.math3.random.Well19937c var21 = new org.apache.commons.math3.random.Well19937c(0);
    double var22 = var21.nextGaussian();
    double var23 = var21.nextGaussian();
    var21.setSeed((-1));
    byte[] var29 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var21.nextBytes(var29);
    var9.nextBytes(var29);
    var6.nextBytes(var29);
    var1.nextBytes(var29);
    boolean var34 = var1.nextBoolean();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-7259342812136017821L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(100);
//     long var8 = var0.nextPoisson(10.0d);
//     long var11 = var0.nextSecureLong(0L, 398L);
//     long var14 = var0.nextLong(3L, 300L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.2950040638140674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "85f256e95a8a0f617e88461be98347dd9a093c35321e3125015aad9e845b587952c078e46412bddbfa16f06bcbac8b753214"+ "'", var6.equals("85f256e95a8a0f617e88461be98347dd9a093c35321e3125015aad9e845b587952c078e46412bddbfa16f06bcbac8b753214"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 32L);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var10 = new double[] { (-1.0d), (-1.0d)};
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
//     java.lang.Object[] var12 = new java.lang.Object[] { var10};
//     org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var12);
//     org.apache.commons.math3.exception.MathInternalError var14 = new org.apache.commons.math3.exception.MathInternalError(var2, var12);
//     org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-10061.775830036235d), var12);
//     org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var0, var12);
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     java.lang.Object[] var18 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var16, var17, var18);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    java.lang.Object var15 = null;
    org.apache.commons.math3.util.Pair var16 = new org.apache.commons.math3.util.Pair((java.lang.Object)1, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    var0.reSeed(0L);
    int var5 = var0.nextPascal(110, 0.0d);
    var0.reSeedSecure();
    var0.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2147483647);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     double var3 = var0.nextExponential(1.908642352606886d);
//     int var6 = var0.nextSecureInt(0, 45958437);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.10734415506657334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 38993473);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = var6.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var9 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)10.0d, (java.lang.Number)2125371022, 0, var7, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getFirst();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     var0.reSeed(5326384455157762505L);
//     int[] var11 = var0.nextPermutation(5494866, 92);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-11.188818248264482d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     float var3 = var1.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
//     double var10 = var4.nextCauchy(0.5131366286482398d, 0.18528098186661676d);
//     int var13 = var4.nextSecureInt(262463199, 945548341);
//     double var16 = var4.nextBeta(884.5884346216443d, 6468.970123339094d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-266.3994807003071d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5775301166847077d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 844898690);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.1180940192895705d);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, (-184300078));
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     int var7 = var0.nextBinomial(0, 0.2793342356121425d);
//     var0.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal(166959353, 4.6868628527440326E11d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8351185044535446d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }


    int[] var3 = new int[] { 1, 0, (-1)};
    int[] var5 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 1);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var3);
    int var8 = var6.nextInt(230354947);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 141265723);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.5119517370126986d, (java.lang.Number)(-27.221845415161912d), false);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var4, false);
    java.lang.Number var7 = var6.getMin();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    double[] var11 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
    boolean var14 = org.apache.commons.math3.util.MathArrays.isMonotonic(var11, var12, false);
    java.lang.Object[] var15 = new java.lang.Object[] { var14};
    org.apache.commons.math3.exception.MathArithmeticException var16 = new org.apache.commons.math3.exception.MathArithmeticException(var9, var15);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, var15);
    org.apache.commons.math3.exception.MathIllegalArgumentException var18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, var15);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var1, var15);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var15);
    java.lang.Throwable[] var21 = var20.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     long var12 = var0.nextLong((-7259342812136017821L), 12L);
//     var0.reSeed(4372816109596290048L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-4.780135263320407d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 100.7199181725493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-2323345821869510144L));
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
    double var5 = var4.nextGaussian();
    double var6 = var4.nextGaussian();
    int[] var10 = new int[] { 1, 0, (-1)};
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    var4.setSeed(var10);
    float var14 = var4.nextFloat();
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(0);
    double var17 = var16.nextGaussian();
    double var18 = var16.nextGaussian();
    var16.setSeed((-1));
    byte[] var24 = new byte[] { (byte)100, (byte)(-1), (byte)0};
    var16.nextBytes(var24);
    var4.nextBytes(var24);
    var1.nextBytes(var24);
    int var29 = var1.nextInt(435864187);
    double var30 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataImpl var31 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.49485147f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 430656544);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-0.27096157230053536d));

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     double var7 = var0.nextChiSquare(0.08679600259959512d);
//     var0.reSeedSecure(12L);
//     long var12 = var0.nextLong(100L, 848835256306514304L);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var0.nextSample(var13, 1179441559);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double var23 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var22);
    double[] var28 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var32 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d)};
    boolean var36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var32, var35);
    boolean var37 = org.apache.commons.math3.util.MathArrays.equals(var28, var35);
    double[] var39 = org.apache.commons.math3.util.MathArrays.copyOf(var35, 1);
    double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var22, var39);
    double var42 = org.apache.commons.math3.util.MathArrays.safeNorm(var22);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var22);
    double[] var47 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var51 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var54 = new double[] { (-1.0d), (-1.0d)};
    boolean var55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var51, var54);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var47, var54);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var54, 1);
    double[] var59 = null;
    double[] var61 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var62 = null;
    boolean var64 = org.apache.commons.math3.util.MathArrays.isMonotonic(var61, var62, false);
    double var65 = org.apache.commons.math3.util.MathArrays.safeNorm(var61);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var59, var61);
    double[] var68 = org.apache.commons.math3.util.MathArrays.normalizeArray(var61, 375.6315311789929d);
    double var69 = org.apache.commons.math3.util.MathArrays.distanceInf(var58, var61);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeDivide(var22, var58);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var74 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var75 = var74.getDirection();
    java.lang.Throwable[] var76 = var74.getSuppressed();
    boolean var77 = var74.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var78 = var74.getDirection();
    boolean var80 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var78, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(300L);
    var1.setSeed(548028350);
    var1.setSeed((-163904641));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    long var10 = var4.nextLong((-582156205918565504L), (-93072929058176752L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.nextPascal(430656544, 389.64156193514617d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-443735806521307840L));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)848835256306514304L);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     double var18 = var0.nextGaussian((-10061.775830036235d), 0.3438501360557338d);
//     double var20 = var0.nextChiSquare(100.0d);
//     long var23 = var0.nextLong((-93072929058176752L), 21L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 702.3566082929535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.39195713731045295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.09449816225130292d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-10061.74146855842d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 102.024640919311d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-92906296736871760L));
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     double var9 = var0.nextGaussian(0.33904363745058674d, 48.550599067346205d);
//     var0.reSeedSecure();
//     double var13 = var0.nextCauchy((-25.222779042411965d), 596.432989482352d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(0.5131366286482398d, (-1.699397009323134d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.917176048134679d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 72.85026255561893d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-14175.914415726229d));
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextExponential(0.06400839652217086d);
//     double var11 = var0.nextGaussian(0.0d, 144.64259665111007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.4834278925709983d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b"+ "'", var6.equals("b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.2531882672496792d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-289.2912262869159d));
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var4 = var0.nextSecureInt(10, 2099284361);
//     var0.reSeedSecure();
//     double var8 = var0.nextCauchy(0.2887438691012194d, 0.2787313252014696d);
//     double var11 = var0.nextGaussian(55.57100780343789d, 5.3250506467994265E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 923559755);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.835194607600344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.1591969597216666E7d);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
//     var0.reSeed((-1L));
//     long var11 = var0.nextSecureLong(32L, 398L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 33L);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    int var10 = var4.nextInt(1, 275296862);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var4.nextSecureInt(1179441559, 12487350);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 166959353);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int[] var14 = new int[] { 1, 0, (-1)};
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var14, 1);
    int var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var14);
    org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(0);
    double var20 = var19.nextGaussian();
    double var21 = var19.nextGaussian();
    int[] var25 = new int[] { 1, 0, (-1)};
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    var19.setSeed(var25);
    org.apache.commons.math3.random.Well19937c var30 = new org.apache.commons.math3.random.Well19937c(0);
    double var31 = var30.nextGaussian();
    double var32 = var30.nextGaussian();
    int[] var36 = new int[] { 1, 0, (-1)};
    int[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
    var30.setSeed(var36);
    int var40 = org.apache.commons.math3.util.MathArrays.distanceInf(var25, var36);
    double var41 = org.apache.commons.math3.util.MathArrays.distance(var7, var25);
    int[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
    int[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, (java.lang.Number)937.2538604380529d, true);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextWeibull(1.908642352606886d, 0.9777587052356126d);
    int var11 = var4.nextHypergeometric(945548341, 434252903, 782409001);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.9426571811852562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3639);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var12 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    java.lang.Object var17 = null;
    org.apache.commons.math3.util.Pair var19 = new org.apache.commons.math3.util.Pair(var17, (java.lang.Object)10.0d);
    java.lang.Object var20 = var19.getFirst();
    java.lang.Object var21 = var19.getFirst();
    double[] var23 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var24 = null;
    boolean var26 = org.apache.commons.math3.util.MathArrays.isMonotonic(var23, var24, false);
    boolean var27 = var19.equals((java.lang.Object)var26);
    java.lang.Object var28 = var19.getFirst();
    java.lang.Object var29 = var19.getFirst();
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 0);
    org.apache.commons.math3.util.MathArrays.checkPositive(var46);
    boolean var48 = var19.equals((java.lang.Object)var46);
    double[] var52 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d)};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var55);
    double[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 176);
    double var59 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var58);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var14, var58);
    double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0d);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     int var18 = var0.nextSecureInt(230354947, 430656544);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 435.6838364913144d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.287651270317472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.17904538172208154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 353839326);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     int var12 = var0.nextHypergeometric(2024169968, 0, 100);
//     double var15 = var0.nextGamma(65.35066907981259d, 121.57001259402712d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var18 = var0.nextPermutation(0, 5494866);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "b96d894bed2006f74335974ca396a03bf2ee7326ff0580aa154a727b5c2e4614ff67ad82325b52833ecf26d90b34ffeb18ff"+ "'", var3.equals("b96d894bed2006f74335974ca396a03bf2ee7326ff0580aa154a727b5c2e4614ff67ad82325b52833ecf26d90b34ffeb18ff"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 594.1225297334701d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-84977662105540288L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 8101.17798152822d);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)48.550599067346205d, (java.lang.Number)1310072025, (java.lang.Number)353839326);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt((-184300078), (-194062463));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 452L);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var4 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = var4.getDirection();
    java.lang.Throwable[] var6 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathArithmeticException var7 = new org.apache.commons.math3.exception.MathArithmeticException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getSecond();
    org.apache.commons.math3.util.Pair var12 = new org.apache.commons.math3.util.Pair(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10.0d+ "'", var11.equals(10.0d));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)87.41926244809311d, (java.lang.Number)1689900776, false);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(300L);
    var1.setSeed(548028350);
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5602296638158786d);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     float var11 = var1.nextFloat();
//     java.util.List var12 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var13 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var12);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)778484104, (java.lang.Number)0.9570892f, (java.lang.Number)844898690);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(0);
    double var18 = var17.nextGaussian();
    double var19 = var17.nextGaussian();
    int[] var23 = new int[] { 1, 0, (-1)};
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    var17.setSeed(var23);
    int[] var30 = new int[] { 1, 0, (-1)};
    int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var30);
    double var34 = org.apache.commons.math3.util.MathArrays.distance(var15, var30);
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    var1.setSeed(var35);
    org.apache.commons.math3.random.RandomDataImpl var37 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     int var5 = var0.nextPascal(110, 0.0d);
//     int var8 = var0.nextSecureInt(1009783546, 1179441559);
//     long var11 = var0.nextSecureLong((-246349375317088864L), 3976504751842537792L);
//     double var14 = var0.nextUniform((-1.8066441508022335d), 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var17 = var0.nextPermutation(257196080, 2024169968);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1053893155);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2266242626589419776L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.7374423811409287d));
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.287486503033214d, (-7352.925227567752d), 1.8288931765060235d, 48.550599067346205d, 0.020945796376795382d, 1.1609554592546993d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-2025.0485842519508d));

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    java.lang.Number var4 = var3.getMax();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (0)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 100 is larger than, or equal to, the maximum (0)"));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    long[] var1 = new long[] { (-1L)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var1);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(2024169968, 275296862);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    boolean var9 = var8.getBoundIsAllowed();
    java.lang.Throwable[] var10 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)(-1));
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)(-1)+ "'", var3.equals((short)(-1)));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextWeibull(1.908642352606886d, 0.9777587052356126d);
    var4.reSeedSecure();
    double var11 = var4.nextGaussian((-11.188818248264482d), 271.42067669747905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.9426571811852562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-84.73339156108868d));

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportLowerBound();
    double var98 = var95.density(3.247351743622313d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == 0.0d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var3 = var0.nextPermutation(100, 100);
    int var6 = var0.nextPascal(2024169968, 0.05063040741363588d);
    var0.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var0.nextPascal(0, 0.6531021513294903d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    int[] var7 = new int[] { 1, 0, (-1)};
    int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
    var1.setSeed(var7);
    int var11 = var1.nextInt();
    var1.setSeed(12486998);
    int var15 = var1.nextInt(293718977);
    long var16 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2125371022);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 45958437);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 142543565145077485L);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     int var5 = var0.nextSecureInt(61970744, 435864187);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 182601844);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportUpperBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var95.probability((-7.341213801342904d), (-11.188818248264482d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 1835266026);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    long[] var2 = new long[] { (-1L), 1L};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkNonNegative(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextF((-1.4304785683372014d), 0.4135467751262189d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)'#', (java.lang.Object)(-11.293482242235479d));
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
    double var5 = var4.nextGaussian();
    float var6 = var4.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    boolean var8 = var2.equals((java.lang.Object)var7);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(0);
    double var11 = var10.nextGaussian();
    float var12 = var10.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var10);
    double var16 = var13.nextCauchy((-10061.775830036235d), 122.12396088898325d);
    boolean var17 = var2.equals((java.lang.Object)(-10061.775830036235d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-10019.332251989288d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var98 = var95.sample(2099284361);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     boolean var5 = var1.nextBoolean();
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var9 = var6.nextSecureInt((-126472930), 293718977);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1053878));
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    double[] var3 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var6 = new double[] { (-1.0d), (-1.0d)};
    boolean var7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var3, var6);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var3, 176);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.00999950005d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(short)100);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var15 = var0.nextCauchy(0.16021426377524167d, 0.05063040741363588d);
//     double var18 = var0.nextGaussian((-10061.775830036235d), 0.3438501360557338d);
//     long var20 = var0.nextPoisson(0.4948515015507633d);
//     int var23 = var0.nextSecureInt(12486998, 626131013);
//     long var26 = var0.nextLong(82L, 1008L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 766.3310262543371d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.10756677395092208d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.1573120633244962d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-10062.103212383237d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 97283156);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 843L);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    double[] var2 = new double[] { 0.0d, 1.0d};
    double[] var4 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var5 = null;
    boolean var7 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var5, false);
    double[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var4, 1);
    org.apache.commons.math3.util.MathArrays.OrderDirection var10 = null;
    double[] var14 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var18 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var21 = new double[] { (-1.0d), (-1.0d)};
    boolean var22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var18, var21);
    boolean var23 = org.apache.commons.math3.util.MathArrays.equals(var14, var21);
    double[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var21, 1);
    double var26 = org.apache.commons.math3.util.MathArrays.safeNorm(var25);
    org.apache.commons.math3.util.MathArrays.checkOrder(var25);
    double[] var31 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var35 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var38 = new double[] { (-1.0d), (-1.0d)};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var31, var38);
    double[] var42 = org.apache.commons.math3.util.MathArrays.copyOf(var38, 1);
    double var43 = org.apache.commons.math3.util.MathArrays.safeNorm(var42);
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var25, var42);
    double[] var48 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var52 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var55 = new double[] { (-1.0d), (-1.0d)};
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var52, var55);
    boolean var57 = org.apache.commons.math3.util.MathArrays.equals(var48, var55);
    double[] var59 = org.apache.commons.math3.util.MathArrays.copyOf(var55, 1);
    double var60 = org.apache.commons.math3.util.MathArrays.safeNorm(var59);
    org.apache.commons.math3.util.MathArrays.checkOrder(var59);
    double[] var65 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var69 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var72 = new double[] { (-1.0d), (-1.0d)};
    boolean var73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var69, var72);
    boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var65, var72);
    double[] var76 = org.apache.commons.math3.util.MathArrays.copyOf(var72, 1);
    double var77 = org.apache.commons.math3.util.MathArrays.safeNorm(var76);
    double[] var78 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var59, var76);
    double[] var79 = org.apache.commons.math3.util.MathArrays.ebeDivide(var44, var76);
    double[][] var80 = new double[][] { var76};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var10, var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var82 = org.apache.commons.math3.util.MathArrays.ebeAdd(var2, var4);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(2125371022, 2125371022, 0);
//     long var7 = var0.nextPoisson(462.99687420008513d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial(782409001, 358.5742526832825d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 431L);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     double var8 = var0.nextT(0.39904814433673585d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24.126763608440896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2"+ "'", var6.equals("2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 17.515130549276076d);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(300L);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("", "c946fe0ea0e140c5e9bbe46a9bc3b6924fbd0c209798e65cb0d3c835f87a025e90743a6574cb86fb14f69577342281728b27e43694d9dd8af11bd5f59f6abb2dd0460b7fd27cdb96e6f1dc398");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    double[] var4 = null;
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var6);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var4, var6);
    double[] var13 = org.apache.commons.math3.util.MathArrays.normalizeArray(var6, 375.6315311789929d);
    boolean var14 = var2.equals((java.lang.Object)var6);
    double[] var18 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var22 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var25 = new double[] { (-1.0d), (-1.0d)};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var18, var25);
    double[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 1);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    org.apache.commons.math3.util.MathArrays.checkOrder(var29);
    double[] var35 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var39 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var42 = new double[] { (-1.0d), (-1.0d)};
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var39, var42);
    boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var35, var42);
    double[] var46 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 1);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var29, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var6, var29);
    double[] var51 = new double[] { 10.0d};
    double[] var55 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var59 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var62 = new double[] { (-1.0d), (-1.0d)};
    boolean var63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var59, var62);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var55, var62);
    double[] var66 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 1);
    double var67 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    org.apache.commons.math3.util.MathArrays.checkOrder(var66);
    double[] var72 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var76 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var79 = new double[] { (-1.0d), (-1.0d)};
    boolean var80 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var76, var79);
    boolean var81 = org.apache.commons.math3.util.MathArrays.equals(var72, var79);
    double[] var83 = org.apache.commons.math3.util.MathArrays.copyOf(var79, 1);
    double var84 = org.apache.commons.math3.util.MathArrays.safeNorm(var83);
    double[] var85 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var66, var83);
    double var86 = org.apache.commons.math3.util.MathArrays.safeNorm(var66);
    double[] var87 = org.apache.commons.math3.util.MathArrays.ebeDivide(var51, var66);
    double[] var89 = org.apache.commons.math3.util.MathArrays.normalizeArray(var66, (-2.940839070076483d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var90 = org.apache.commons.math3.util.MathArrays.linearCombination(var29, var66);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var1, (java.lang.Object)10.0d);
    java.lang.Object var4 = var3.getFirst();
    java.lang.Object var5 = var3.getFirst();
    double[] var7 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var8 = null;
    boolean var10 = org.apache.commons.math3.util.MathArrays.isMonotonic(var7, var8, false);
    boolean var11 = var3.equals((java.lang.Object)var10);
    java.lang.Object var12 = var3.getFirst();
    java.lang.Object var13 = var3.getFirst();
    java.lang.Object var14 = var3.getKey();
    org.apache.commons.math3.exception.util.Localizable var15 = null;
    org.apache.commons.math3.exception.util.Localizable var16 = null;
    java.lang.Object[] var19 = new java.lang.Object[] { (short)0};
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var16, (java.lang.Number)100, var19);
    org.apache.commons.math3.exception.NullArgumentException var21 = new org.apache.commons.math3.exception.NullArgumentException(var15, var19);
    boolean var22 = var3.equals((java.lang.Object)var19);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
    boolean var3 = var2.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(998139946);
    int[] var5 = new int[] { 1, 0, (-1)};
    int[] var7 = org.apache.commons.math3.util.MathArrays.copyOf(var5, 1);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(0);
    double var10 = var9.nextGaussian();
    double var11 = var9.nextGaussian();
    int[] var15 = new int[] { 1, 0, (-1)};
    int[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var15, 1);
    var9.setSeed(var15);
    int[] var22 = new int[] { 1, 0, (-1)};
    int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var22, 1);
    int var25 = org.apache.commons.math3.util.MathArrays.distanceInf(var15, var22);
    double var26 = org.apache.commons.math3.util.MathArrays.distance(var7, var22);
    int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var22);
    int[] var29 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 29);
    var1.setSeed(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextBeta(0.0d, 0.4745968373686235d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.31057336285415327d);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
//     java.lang.Number var7 = var6.getMax();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     long[] var9 = null;
//     long[][] var10 = new long[][] { var9};
//     org.apache.commons.math3.util.MathArrays.checkRectangular(var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var8, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.21556675f, (java.lang.Object[])var10);
//     org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var14);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
//     double var2 = var1.nextGaussian();
//     double var3 = var1.nextGaussian();
//     int[] var7 = new int[] { 1, 0, (-1)};
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 1);
//     var1.setSeed(var7);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(0);
//     double var13 = var12.nextGaussian();
//     double var14 = var12.nextGaussian();
//     int[] var18 = new int[] { 1, 0, (-1)};
//     int[] var20 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
//     var12.setSeed(var18);
//     int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var18);
//     int[] var23 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     int[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var7);
//     org.apache.commons.math3.random.Well19937c var26 = new org.apache.commons.math3.random.Well19937c(0);
//     double var27 = var26.nextGaussian();
//     double var28 = var26.nextGaussian();
//     int[] var32 = new int[] { 1, 0, (-1)};
//     int[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var32, 1);
//     var26.setSeed(var32);
//     int[] var39 = new int[] { 1, 0, (-1)};
//     int[] var41 = org.apache.commons.math3.util.MathArrays.copyOf(var39, 1);
//     int var42 = org.apache.commons.math3.util.MathArrays.distanceInf(var32, var39);
//     org.apache.commons.math3.random.RandomDataImpl var43 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var46 = var43.nextPermutation(100, 100);
//     int var47 = org.apache.commons.math3.util.MathArrays.distance1(var32, var46);
//     int var48 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var46);
//     org.apache.commons.math3.random.Well19937c var50 = new org.apache.commons.math3.random.Well19937c(0);
//     double var51 = var50.nextGaussian();
//     double var52 = var50.nextGaussian();
//     int[] var56 = new int[] { 1, 0, (-1)};
//     int[] var58 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 1);
//     var50.setSeed(var56);
//     org.apache.commons.math3.random.Well19937c var60 = new org.apache.commons.math3.random.Well19937c(var56);
//     int var61 = org.apache.commons.math3.util.MathArrays.distance1(var7, var56);
//     int[] var65 = new int[] { 1, 0, (-1)};
//     int[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var65, 1);
//     org.apache.commons.math3.random.Well19937c var69 = new org.apache.commons.math3.random.Well19937c(0);
//     double var70 = var69.nextGaussian();
//     double var71 = var69.nextGaussian();
//     int[] var75 = new int[] { 1, 0, (-1)};
//     int[] var77 = org.apache.commons.math3.util.MathArrays.copyOf(var75, 1);
//     var69.setSeed(var75);
//     int[] var82 = new int[] { 1, 0, (-1)};
//     int[] var84 = org.apache.commons.math3.util.MathArrays.copyOf(var82, 1);
//     int var85 = org.apache.commons.math3.util.MathArrays.distanceInf(var75, var82);
//     double var86 = org.apache.commons.math3.util.MathArrays.distance(var67, var82);
//     int[] var87 = org.apache.commons.math3.util.MathArrays.copyOf(var82);
//     int[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var87, 29);
//     int[] var90 = org.apache.commons.math3.util.MathArrays.copyOf(var89);
//     double var91 = org.apache.commons.math3.util.MathArrays.distance(var56, var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 165);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == (-0.27096157230053536d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 0.0d);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    double[] var1 = new double[] { 100.0d};
    double[] var5 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var9 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var12 = new double[] { (-1.0d), (-1.0d)};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var9, var12);
    boolean var14 = org.apache.commons.math3.util.MathArrays.equals(var5, var12);
    double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var12, 1);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)110, (java.lang.Number)2024169968, 275296862);
    org.apache.commons.math3.util.MathArrays.OrderDirection var21 = var20.getDirection();
    boolean var23 = org.apache.commons.math3.util.MathArrays.isMonotonic(var16, var21, false);
    double[] var24 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var1, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkPositive(var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)4.928111192687026d, (java.lang.Number)49.85320620660685d, true);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportLowerBound();
    boolean var97 = var95.isSupportUpperBoundInclusive();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var37 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var41 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var44 = new double[] { (-1.0d), (-1.0d)};
    boolean var45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var41, var44);
    boolean var46 = org.apache.commons.math3.util.MathArrays.equals(var37, var44);
    double[] var48 = org.apache.commons.math3.util.MathArrays.copyOf(var44, 1);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var48);
    org.apache.commons.math3.util.MathArrays.checkOrder(var48);
    double[] var54 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var58 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var61 = new double[] { (-1.0d), (-1.0d)};
    boolean var62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var58, var61);
    boolean var63 = org.apache.commons.math3.util.MathArrays.equals(var54, var61);
    double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var61, 1);
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var48, var65);
    double[] var68 = org.apache.commons.math3.util.MathArrays.ebeDivide(var33, var65);
    double[] var69 = null;
    double[] var71 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var72 = null;
    boolean var74 = org.apache.commons.math3.util.MathArrays.isMonotonic(var71, var72, false);
    double var75 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    boolean var76 = org.apache.commons.math3.util.MathArrays.equals(var69, var71);
    double[] var78 = org.apache.commons.math3.util.MathArrays.normalizeArray(var71, 375.6315311789929d);
    double[] var79 = org.apache.commons.math3.util.MathArrays.copyOf(var71);
    double var80 = org.apache.commons.math3.util.MathArrays.distanceInf(var33, var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 2.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double[] var6 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var10 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var13 = new double[] { (-1.0d), (-1.0d)};
    boolean var14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var10, var13);
    boolean var15 = org.apache.commons.math3.util.MathArrays.equals(var6, var13);
    double[] var17 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    double var18 = org.apache.commons.math3.util.MathArrays.safeNorm(var17);
    org.apache.commons.math3.util.MathArrays.checkOrder(var17);
    double[] var23 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var27 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var30 = new double[] { (-1.0d), (-1.0d)};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var27, var30);
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var23, var30);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    double var35 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var17, var34);
    double[] var40 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var44 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var47 = new double[] { (-1.0d), (-1.0d)};
    boolean var48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var44, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var40, var47);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 1);
    double var52 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    org.apache.commons.math3.util.MathArrays.checkOrder(var51);
    double[] var57 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var61 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var64 = new double[] { (-1.0d), (-1.0d)};
    boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var61, var64);
    boolean var66 = org.apache.commons.math3.util.MathArrays.equals(var57, var64);
    double[] var68 = org.apache.commons.math3.util.MathArrays.copyOf(var64, 1);
    double var69 = org.apache.commons.math3.util.MathArrays.safeNorm(var68);
    double[] var70 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var68);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var36, var68);
    org.apache.commons.math3.exception.NumberIsTooLargeException var75 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)100.0d, (java.lang.Number)(short)0, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var79 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)1.0f, (java.lang.Number)1, 0);
    int var80 = var79.getIndex();
    var75.addSuppressed((java.lang.Throwable)var79);
    org.apache.commons.math3.util.MathArrays.OrderDirection var82 = var79.getDirection();
    boolean var85 = org.apache.commons.math3.util.MathArrays.checkOrder(var36, var82, true, false);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var87 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)153, (java.lang.Number)(-5.075035468950752d), 275296862, var82, false);
    java.lang.Number var88 = var87.getPrevious();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + (-5.075035468950752d)+ "'", var88.equals((-5.075035468950752d)));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-1.0d), (java.lang.Number)100, true);
    java.lang.Number var4 = var3.getMax();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100+ "'", var4.equals(100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-3.956734617801294d), 308.199125549581d, true);
//     double var6 = var0.nextExponential(216.6827952125197d);
//     int var9 = var0.nextInt(1, 1819577945);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextBinomial(23, 264.66597497687104d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 63.05285398973629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 40.28759502490975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 984252983);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)'#', (java.lang.Object)(-11.293482242235479d));
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(0);
//     double var5 = var4.nextGaussian();
//     float var6 = var4.nextFloat();
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
//     boolean var8 = var2.equals((java.lang.Object)var7);
//     int var11 = var7.nextSecureInt(1819577945, 1837490728);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.908642352606886d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9570892f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1821891800);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var99 = var95.probability((-10019.332251989288d), (-445391.47943073325d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 1179441559, 315774327);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     int var5 = var0.nextHypergeometric(1179441559, 0, 100);
//     double var8 = var0.nextGamma(100.0d, 0.6531021513294903d);
//     double var10 = var0.nextChiSquare(389.64156193514617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 73.32610324960949d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 392.0017402781067d);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     double var11 = var0.nextCauchy(1.908642352606886d, 1.908642352606886d);
//     var0.reSeedSecure();
//     double var15 = var0.nextUniform((-75.50392116110793d), 1.908642352606886d);
//     long var17 = var0.nextPoisson(3.452827866077632d);
//     var0.reSeed();
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 362.8719815939322d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5451116726438122d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.055655516942733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-74.10940516805954d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4L);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     double var5 = var0.nextExponential(445.66983836660324d);
//     long var8 = var0.nextSecureLong((-246349375317088864L), 433L);
//     int var12 = var0.nextHypergeometric(2024169968, 0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextGaussian(0.39325425615704396d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "7a796beabe4a7cc04c66534efe26115a5e5468bb4ae8a1f2b96247411fd6929212ec29c449b30ae05ba71923d6ec62a3bcc1"+ "'", var3.equals("7a796beabe4a7cc04c66534efe26115a5e5468bb4ae8a1f2b96247411fd6929212ec29c449b30ae05ba71923d6ec62a3bcc1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 443.41269188527605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-203159954384203424L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var96 = var95.getSupportUpperBound();
    boolean var97 = var95.isSupportUpperBoundInclusive();
    double var99 = var95.density(0.020945796376795382d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == 0.0d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     double var5 = var0.nextUniform((-0.27096157230053536d), 1000.0d, false);
//     double var8 = var0.nextBeta(1.0d, 1.908642352606886d);
//     int var12 = var0.nextHypergeometric(2099284361, 110, 1);
//     double var14 = var0.nextExponential(219.80508910257697d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextPoisson((-261.2580792079068d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 800.5507422096657d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.07348769898920744d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 386.07324618924207d);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double var97 = var95.probability(16.031433623080687d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == 0.0d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[] var16 = null;
    double[] var18 = new double[] { 10.0d};
    double[] var22 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var26 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var29 = new double[] { (-1.0d), (-1.0d)};
    boolean var30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var26, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var22, var29);
    double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 1);
    double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    org.apache.commons.math3.util.MathArrays.checkOrder(var33);
    double[] var39 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var43 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d)};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var39, var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 1);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var33, var50);
    double var53 = org.apache.commons.math3.util.MathArrays.safeNorm(var33);
    double[] var54 = org.apache.commons.math3.util.MathArrays.ebeDivide(var18, var33);
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var16, var33);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     java.lang.String var4 = var0.nextSecureHexString(153);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var8 = var0.nextPermutation(2024169968, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-44.593726361939694d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6cd40b7bd76e99986e3a99262694867e11fe8dbc4c7ef9a8545849c36f4b409c1d4766854bffa25a96a127e9ddbc97637c858890e79302703a59a35725886fe6b4875ee13fa14bcb8ea4462bf"+ "'", var4.equals("6cd40b7bd76e99986e3a99262694867e11fe8dbc4c7ef9a8545849c36f4b409c1d4766854bffa25a96a127e9ddbc97637c858890e79302703a59a35725886fe6b4875ee13fa14bcb8ea4462bf"));
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     int var5 = var0.nextPascal(110, 0.0d);
//     var0.reSeedSecure();
//     int var9 = var0.nextSecureInt(23, 1598992301);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1226007349);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextWeibull(1.908642352606886d, 0.9777587052356126d);
    double var9 = var4.nextT(884.5884346216443d);
    double var11 = var4.nextChiSquare(470.5790719190428d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.9426571811852562d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-0.5741086845442146d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 434.7760975886023d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getFirst();
    java.lang.Object var4 = var2.getFirst();
    double[] var6 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    boolean var10 = var2.equals((java.lang.Object)var9);
    java.lang.Object var11 = var2.getKey();
    java.lang.Object var12 = var2.getFirst();
    java.lang.Object var13 = var2.getValue();
    org.apache.commons.math3.util.Pair var14 = new org.apache.commons.math3.util.Pair(var2);
    java.lang.Object var15 = var14.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeed(0L);
//     int var5 = var0.nextPascal(110, 0.0d);
//     int var8 = var0.nextSecureInt(1009783546, 1179441559);
//     var0.reSeed(12L);
//     org.apache.commons.math3.distribution.IntegerDistribution var11 = null;
//     int var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     var0.reSeed();
//     java.lang.String var3 = var0.nextSecureHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextHypergeometric(434252903, 1689900776, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "1639c6048ff5505caa724ab22139f059dd03bc44227f9b76fae6286ad7619be01a2c3e01a027b4df67f07014ae01b3201fa2"+ "'", var3.equals("1639c6048ff5505caa724ab22139f059dd03bc44227f9b76fae6286ad7619be01a2c3e01a027b4df67f07014ae01b3201fa2"));
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextT(0.33272672175073054d);
//     var0.reSeedSecure(1399632177780768928L);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.12593130365147912d);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var3 = var0.nextPermutation(100, 100);
//     double var6 = var0.nextUniform((-11.703609724860312d), 0.0d);
//     java.lang.String var8 = var0.nextHexString(110);
//     double var11 = var0.nextWeibull(0.01237694884401451d, 44.74362024702862d);
//     double var14 = var0.nextUniform((-6168.191987338353d), 884.5884346216443d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextHypergeometric(38993473, 197678313, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-9.841984334927528d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "059e329126f96c838eff0837eace6979ba935a82f37534621074ca06f45ee033e628d96ea24558fecec01400144c7199bdc0de04e90e06"+ "'", var8.equals("059e329126f96c838eff0837eace6979ba935a82f37534621074ca06f45ee033e628d96ea24558fecec01400144c7199bdc0de04e90e06"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.273036329870299E-40d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-3440.939904968213d));
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     double var4 = var0.nextExponential(10.0d);
//     java.lang.String var6 = var0.nextSecureHexString(1);
//     long var8 = var0.nextPoisson(0.33904363745058674d);
//     double var11 = var0.nextUniform((-11.293482242235479d), 0.33272672175073054d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextExponential((-4.363147560615763d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.9908607970728618d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "a"+ "'", var6.equals("a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-5.428385920495838d));
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(48.550599067346205d, (-8.586495553343214d), (-261.00399710490456d), (-3.438064932233826d), 0.9746129402290591d, (-2.557501853098866d), 884.5884346216443d, 0.9746129402290591d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1340.1079473738455d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    long var4 = var1.nextLong();
    var1.setSeed(10);
    float var7 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-7259342812136017821L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.76195765f);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    boolean var4 = var1.nextBoolean();
    var1.setSeed(2099284361);
    boolean var7 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Number var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.0f, var6, false);
    java.lang.Number var9 = var8.getMin();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    double[] var13 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
    boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var13, var14, false);
    java.lang.Object[] var17 = new java.lang.Object[] { var16};
    org.apache.commons.math3.exception.MathArithmeticException var18 = new org.apache.commons.math3.exception.MathArithmeticException(var11, var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var8, var10, var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var4, var17);
    org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var3, var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)2147483647, var17);
    org.apache.commons.math3.exception.NullArgumentException var23 = new org.apache.commons.math3.exception.NullArgumentException(var0, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int var10 = var1.nextInt();
    org.apache.commons.math3.random.RandomDataGenerator var11 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    float var12 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataImpl var13 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-528848821));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.28874385f);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var11 = new double[] { (-1.0d), (-1.0d)};
//     boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
//     boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var15);
//     double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var27 = new double[] { (-1.0d), (-1.0d)};
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
//     double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
//     double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var31);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeAdd(var15, var31);
//     double[] var35 = null;
//     double[] var37 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var38 = null;
//     boolean var40 = org.apache.commons.math3.util.MathArrays.isMonotonic(var37, var38, false);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
//     boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var35, var37);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.normalizeArray(var37, 375.6315311789929d);
//     double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
//     double[] var49 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var53 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var56 = new double[] { (-1.0d), (-1.0d)};
//     boolean var57 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var53, var56);
//     boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var49, var56);
//     double[] var60 = org.apache.commons.math3.util.MathArrays.copyOf(var56, 1);
//     double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var60);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var60);
//     double[] var64 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var44, var60);
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var34, var60);
//     double[] var66 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var34);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var4.nextGaussian(2.0d, 990.5444466590764d);
    double var10 = var4.nextCauchy(0.5131366286482398d, 0.18528098186661676d);
    var4.reSeedSecure();
    double var13 = var4.nextExponential(496.2393300447168d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var4.nextInt(778484104, 165);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-266.3994807003071d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5775301166847077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 409.5103876852459d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)43.688370836498265d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    double[] var4 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var8 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var11 = new double[] { (-1.0d), (-1.0d)};
    boolean var12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var8, var11);
    boolean var13 = org.apache.commons.math3.util.MathArrays.equals(var4, var11);
    double[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var11, 1);
    double[] var19 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var23 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d)};
    boolean var27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var23, var26);
    boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var19, var26);
    double[] var30 = org.apache.commons.math3.util.MathArrays.copyOf(var26, 1);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
    double[][] var32 = new double[][] { var30};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var15, var32);
    org.apache.commons.math3.exception.NullArgumentException var34 = new org.apache.commons.math3.exception.NullArgumentException(var0, (java.lang.Object[])var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    double[] var0 = null;
    double[] var2 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
    double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    double[] var11 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var15 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d)};
    boolean var19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var15, var18);
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var11, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.copyOf(var18, 1);
    double[] var26 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var30 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var33 = new double[] { (-1.0d), (-1.0d)};
    boolean var34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var30, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var26, var33);
    double[] var37 = org.apache.commons.math3.util.MathArrays.copyOf(var33, 1);
    double var38 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double[][] var39 = new double[][] { var37};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var22, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var2, var22);
    double[] var45 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var49 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var52 = new double[] { (-1.0d), (-1.0d)};
    boolean var53 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var49, var52);
    boolean var54 = org.apache.commons.math3.util.MathArrays.equals(var45, var52);
    double[] var56 = org.apache.commons.math3.util.MathArrays.copyOf(var52, 1);
    double[] var60 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var64 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var67 = new double[] { (-1.0d), (-1.0d)};
    boolean var68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var64, var67);
    boolean var69 = org.apache.commons.math3.util.MathArrays.equals(var60, var67);
    double[] var71 = org.apache.commons.math3.util.MathArrays.copyOf(var67, 1);
    double var72 = org.apache.commons.math3.util.MathArrays.safeNorm(var71);
    double[][] var73 = new double[][] { var71};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var56, var73);
    boolean var75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    var1.setSeed(10L);
    float var6 = var1.nextFloat();
    float var7 = var1.nextFloat();
    double var8 = var1.nextGaussian();
    double[] var10 = new double[] { 100.0d};
    double[] var12 = new double[] { 10.0d};
    double[] var16 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var20 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d)};
    boolean var24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var20, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var16, var23);
    double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    double var28 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    org.apache.commons.math3.util.MathArrays.checkOrder(var27);
    double[] var33 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var37 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d)};
    boolean var41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var40);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var33, var40);
    double[] var44 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 1);
    double var45 = org.apache.commons.math3.util.MathArrays.safeNorm(var44);
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var44);
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var12, var27);
    double[] var49 = null;
    double[] var51 = new double[] { (-1.0d)};
    org.apache.commons.math3.util.MathArrays.OrderDirection var52 = null;
    boolean var54 = org.apache.commons.math3.util.MathArrays.isMonotonic(var51, var52, false);
    double var55 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
    boolean var56 = org.apache.commons.math3.util.MathArrays.equals(var49, var51);
    double[] var58 = org.apache.commons.math3.util.MathArrays.normalizeArray(var51, 375.6315311789929d);
    double[] var62 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var66 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var69 = new double[] { (-1.0d), (-1.0d)};
    boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var66, var69);
    boolean var71 = org.apache.commons.math3.util.MathArrays.equals(var62, var69);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var69, 1);
    double var74 = org.apache.commons.math3.util.MathArrays.safeNorm(var73);
    double[] var78 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var82 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var85 = new double[] { (-1.0d), (-1.0d)};
    boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var82, var85);
    boolean var87 = org.apache.commons.math3.util.MathArrays.equals(var78, var85);
    double[] var89 = org.apache.commons.math3.util.MathArrays.copyOf(var85, 1);
    double var90 = org.apache.commons.math3.util.MathArrays.safeNorm(var89);
    org.apache.commons.math3.util.MathArrays.checkOrder(var89);
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeAdd(var73, var89);
    boolean var93 = org.apache.commons.math3.util.MathArrays.equals(var51, var92);
    double[] var94 = org.apache.commons.math3.util.MathArrays.ebeDivide(var48, var92);
    org.apache.commons.math3.distribution.DiscreteRealDistribution var95 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var94);
    double[] var97 = org.apache.commons.math3.util.MathArrays.normalizeArray(var94, 100.7199181725493d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.40877557f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.23239756f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1672233456208478d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { (-1.0d)};
//     org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
//     boolean var5 = org.apache.commons.math3.util.MathArrays.isMonotonic(var2, var3, false);
//     double var6 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
//     boolean var7 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
//     double[] var9 = org.apache.commons.math3.util.MathArrays.normalizeArray(var2, 375.6315311789929d);
//     double[] var13 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var17 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var20 = new double[] { (-1.0d), (-1.0d)};
//     boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var17, var20);
//     boolean var22 = org.apache.commons.math3.util.MathArrays.equals(var13, var20);
//     double[] var24 = org.apache.commons.math3.util.MathArrays.copyOf(var20, 1);
//     double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var29 = new double[] { (-1.0d), 100.0d, 0.0d};
//     double[] var33 = new double[] { 1.0d, 100.0d, 1.0d};
//     double[] var36 = new double[] { (-1.0d), (-1.0d)};
//     boolean var37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var33, var36);
//     boolean var38 = org.apache.commons.math3.util.MathArrays.equals(var29, var36);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.copyOf(var36, 1);
//     double var41 = org.apache.commons.math3.util.MathArrays.safeNorm(var40);
//     org.apache.commons.math3.util.MathArrays.checkOrder(var40);
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeAdd(var24, var40);
//     boolean var44 = org.apache.commons.math3.util.MathArrays.equals(var2, var43);
//     double[] var45 = null;
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var2, var45);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    double var3 = var1.nextGaussian();
    var1.setSeed((-1));
    boolean var6 = var1.nextBoolean();
    long var7 = var1.nextLong();
    var1.setSeed(275296862);
    int[] var13 = new int[] { 1, 0, (-1)};
    int[] var15 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 1);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(0);
    double var18 = var17.nextGaussian();
    double var19 = var17.nextGaussian();
    int[] var23 = new int[] { 1, 0, (-1)};
    int[] var25 = org.apache.commons.math3.util.MathArrays.copyOf(var23, 1);
    var17.setSeed(var23);
    int[] var30 = new int[] { 1, 0, (-1)};
    int[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 1);
    int var33 = org.apache.commons.math3.util.MathArrays.distanceInf(var23, var30);
    double var34 = org.apache.commons.math3.util.MathArrays.distance(var15, var30);
    int[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var30);
    var1.setSeed(var35);
    org.apache.commons.math3.random.Well19937c var37 = new org.apache.commons.math3.random.Well19937c(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1399632177780768928L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-0.27096157230053536d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    double[] var3 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var7 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var10 = new double[] { (-1.0d), (-1.0d)};
    boolean var11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var10);
    boolean var12 = org.apache.commons.math3.util.MathArrays.equals(var3, var10);
    double[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var10, 1);
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    org.apache.commons.math3.util.MathArrays.checkOrder(var14);
    double[] var20 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var24 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var27 = new double[] { (-1.0d), (-1.0d)};
    boolean var28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var24, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var20, var27);
    double[] var31 = org.apache.commons.math3.util.MathArrays.copyOf(var27, 1);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var14, var31);
    double[] var35 = new double[] { 10.0d};
    double[] var39 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var43 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var46 = new double[] { (-1.0d), (-1.0d)};
    boolean var47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var43, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var39, var46);
    double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 1);
    double var51 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    org.apache.commons.math3.util.MathArrays.checkOrder(var50);
    double[] var56 = new double[] { (-1.0d), 100.0d, 0.0d};
    double[] var60 = new double[] { 1.0d, 100.0d, 1.0d};
    double[] var63 = new double[] { (-1.0d), (-1.0d)};
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var60, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var56, var63);
    double[] var67 = org.apache.commons.math3.util.MathArrays.copyOf(var63, 1);
    double var68 = org.apache.commons.math3.util.MathArrays.safeNorm(var67);
    double[] var69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var50, var67);
    double var70 = org.apache.commons.math3.util.MathArrays.safeNorm(var50);
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var50);
    double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var35);
    double[] var73 = org.apache.commons.math3.util.MathArrays.copyOf(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1053878), 38993473);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)228.5581296305497d, (java.lang.Number)231.61046862721562d, (-126472930));

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 110, 2099284361);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 110+ "'", var4.equals(110));

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    double var2 = var1.nextGaussian();
    float var3 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var4.nextLong(0L, 1399632177780768928L);
    var4.reSeedSecure();
    var4.reSeedSecure();
    var4.reSeedSecure(8743292399698869772L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.908642352606886d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.9570892f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 848835256306514304L);

  }

}
