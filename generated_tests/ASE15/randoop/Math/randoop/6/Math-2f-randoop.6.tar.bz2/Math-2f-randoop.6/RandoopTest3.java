
import junit.framework.*;

public class RandoopTest3 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test1"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.7432415f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7432415f);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test2"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-3857963799456177917L));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)0);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test4"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test5"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    long var7 = var6.nextLong();
    double var8 = var6.nextGaussian();
    byte[] var12 = new byte[] { (byte)0, (byte)0, (byte)1};
    var6.nextBytes(var12);
    var1.nextBytes(var12);
    org.apache.commons.math3.random.RandomDataGenerator var15 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test6"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial(12993707, 1.0801020401604586d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2955853198931393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.9562904739101248d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test7"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(5646616835816284903L, 58365653636984266L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.04406442611257439d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8ba"+ "'", var4.equals("8ba"));
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test8"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-79134244));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test9"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test10"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    int var16 = var2.nextInt(17, 2147483647);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var2.nextUniform(0.6313298547021015d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1146122894);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test11"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var8 = var0.nextT(0.059279958251462046d);
//     int var11 = var0.nextZipf(125, 2.8961942241580267E-5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.02110854366590658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.7751748825139425d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 3.643849584899851d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 71);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var11 = var0.nextGamma(0.20951305448319416d, 1.9518401855672245d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.8481728232252896d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "570"+ "'", var4.equals("570"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.9204617763473553d);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test13"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    double var4 = var1.nextDouble();
    long var5 = var1.nextLong();
    int var6 = var1.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 9, 1665346298, 29);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401381795025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7009605301686414442L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-79134244));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test14"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test15"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.07180988227597636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07180988227597636d);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test16"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)100.0d, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test17"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)12.190933f);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test18"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var2 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var2, (java.lang.Number)0.0f);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Throwable[] var7 = var4.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Number var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var8, (java.lang.Object[])var14);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var14);
//     java.lang.String var18 = var17.toString();
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test19"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    double var11 = var6.upperCumulativeProbability(1);
    double var13 = var6.cumulativeProbability(143);
    boolean var14 = var6.isSupportConnected();
    int var15 = var6.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.3542161596574423E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3542161596574425E-9d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test21"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1024, 146);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test22"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     java.lang.String var10 = var2.nextSecureHexString(26);
//     double var13 = var2.nextUniform(0.0d, 1.665429362717771d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var2.nextHexString((-79134244));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "432ad47f8eac4cc15222f05085"+ "'", var10.equals("432ad47f8eac4cc15222f05085"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.06232358102760782d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test23"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.00363892281204757d, (java.lang.Number)0.05034846331660371d, false);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test24"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5707963267948966d, (java.lang.Number)3.993369341651611E-5d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextChiSquare(23.729908791521954d);
//     int var13 = var0.nextBinomial(0, 0.29486290084058253d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextHexString((-8));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.20522532751594627d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e6a"+ "'", var4.equals("e6a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 25.31728593676629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.8140149187445599d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.08936763556649133d));

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test27"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     long var20 = var0.nextLong(1L, 577710999442321806L);
//     var0.reSeed(1L);
//     double var25 = var0.nextCauchy(0.0d, 0.8202972454764327d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "eb8"+ "'", var10.equals("eb8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.3498285808027702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 301);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.3407807929942259E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 531314051124651644L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-3.5250547392990157d));
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.009019054625249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test29"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    int var13 = var5.getSupportLowerBound();
    double var15 = var5.probability(715);
    double var16 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test30"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    double var14 = var5.cumulativeProbability(563228325);
    double var17 = var5.cumulativeProbability((-2083745733), 9);
    double var19 = var5.cumulativeProbability(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test31"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, false);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathInternalError var15 = new org.apache.commons.math3.exception.MathInternalError(var7, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var5, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.util.ExceptionContext var18 = var17.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var19 = var17.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1L+ "'", var4.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test32"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
//     double var7 = var2.nextExponential(0.001426069753303551d);
//     int var10 = var2.nextInt(6, 563228325);
//     long var13 = var2.nextSecureLong(1961224671979052586L, 4093755611243242726L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 25.70543202901362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0017299837809377156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 281614168);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2393649683061784327L);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     int var12 = var0.nextZipf(213, 6.651369377311819E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4040925433889235d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.2230696024596024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4681852906402168768L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var5 = var0.nextZipf(391442915, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0504394278001283d);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test35"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.8605623f, 1069190818);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test36"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure((-947337978656517030L));
//     long var20 = var0.nextSecureLong(10L, 153907406580627565L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "7ef"+ "'", var10.equals("7ef"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.07000652604384996d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 624);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 71809645423893558L);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test37"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test38"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
//     double var16 = var2.nextGamma(1.8348931695478938d, 0.5418954798163614d);
//     int var19 = var2.nextSecureInt(0, 364);
//     var2.reSeed((-278974959396645380L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.925797012802406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.46511422979512007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 321);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test39"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8152769730283367d);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var8, (java.lang.Number)0.0f);
    java.lang.Number var11 = var10.getLo();
    java.lang.Number var12 = var10.getLo();
    java.lang.Throwable[] var13 = var10.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var14 = null;
    java.lang.Number var15 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var20 = var19.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException(var15, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var10, var14, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var6, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var25 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)30.969689879991442d, (java.lang.Object[])var20);
    org.apache.commons.math3.exception.NotFiniteNumberException var26 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.07180988227597636d, (java.lang.Object[])var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var8 = var0.nextT(0.059279958251462046d);
//     var0.reSeed(2241856882564607076L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.08088031748191599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.275081695636736d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7.28061600500171d);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test41"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.792126722906372d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test42"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7432416f);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test43"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)2.08515805168829d, false);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test44"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.27754671516368096d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test45"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     long var16 = var0.nextLong((-3759508027876256838L), 13L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2d4", "a0b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.3388367551991351d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.2862528772859615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1011716550987743639L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "380bb"+ "'", var11.equals("380bb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.8341646794316356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1884486049158400701L));
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test46"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     int var21 = var0.nextZipf(4, 0.06923784643353914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.019350131912089147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a34"+ "'", var4.equals("a34"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 4.425724842747143E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.5309994478775268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test47"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     byte[] var2 = null;
//     var1.nextBytes(var2);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test48"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.972385400411732d, false);
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)0.01179864038469449d, true);
    var3.addSuppressed((java.lang.Throwable)var7);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test49"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     int var9 = var2.nextPascal(6, 1.4210854715202004E-14d);
//     long var12 = var2.nextLong((-7034676902218012687L), 26L);
//     double var14 = var2.nextExponential(0.14961208608543997d);
//     double var16 = var2.nextT(0.8993762294100577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-4442865441428132941L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.43909968487488055d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-1.3169246149495106d));
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test50"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeedSecure();
    var2.reSeed(5L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextF(0.0d, 0.8534683546359614d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test51"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0880612428470614d, 0.6449378492082781d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20866604530927532d);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test52"); }
// 
// 
//     int[] var0 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextGaussian(0.0d, 222.3528063767103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 110.64570005983036d);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test53"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    long var12 = var2.nextLong(3L, 10L);
    int var15 = var2.nextPascal(987587419, 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2147483647);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test54"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.3145794197714908d, 5.011012903266713E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.999420634880145d);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var13 = var0.nextGamma(2.0000000000000004d, 0.5303092014603302d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextWeibull((-0.5039116999145312d), 1.8490661410352736d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.19845849436900825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.21673335820666145d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.6734754660904636d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.8825019772896727d);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    double var15 = var2.nextBeta(0.04015334158805609d, 0.04943097798541802d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.00402053689632849d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test57"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(2.9748236757560673d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.9748236757560673d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test58"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    double var12 = var5.cumulativeProbability(563228325);
    int var13 = var5.getSampleSize();
    int var14 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test59"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    int var9 = var1.nextInt(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var11 = var1.nextLong((-1855314268955432625L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(2.8058364697442126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.228431402119442d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test61"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.5418954798163613d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.1116073535960684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.04595141109528686d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test63"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-11.7204516580769d), 7.02545717536151d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0308044078648224d));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)100.0d, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test65"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    var2.reSeed((-6069125204240848293L));
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextSecureLong(26L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test66"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(6, 597052871);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.005514177742691755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005514205686892511d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test68"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(30.973188990298414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31.0d);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "053"+ "'", var10.equals("053"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.07251473295590015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.1262295336778325d);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test70"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    var1.clear();
    var1.setSeed(5646616835816284903L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2419047238712938144L);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test71"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.9098275504956358d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7382182317762098d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     java.lang.String var14 = var0.nextSecureHexString(147);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(123.86826212129738d, 1.0880328565492918d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ecc"+ "'", var10.equals("ecc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.11357215995958392d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "46d727be5b3b7153fde7714571bcad5ba02dd5c3c247c8e9e6bcdacfac13d17aa1aec44595c5225c84b16669ec74ec1f997293351d75b23ed1722ff1568b4d6fea807efe3e9d1dbe6fd"+ "'", var14.equals("46d727be5b3b7153fde7714571bcad5ba02dd5c3c247c8e9e6bcdacfac13d17aa1aec44595c5225c84b16669ec74ec1f997293351d75b23ed1722ff1568b4d6fea807efe3e9d1dbe6fd"));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test73"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    int var10 = var5.getSupportLowerBound();
    int var11 = var5.getNumberOfSuccesses();
    int var12 = var5.getSampleSize();
    int var13 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test74"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    boolean var8 = var1.nextBoolean();
    var1.clear();
    var1.clear();
    long var11 = var1.nextLong();
    var1.setSeed(263621476);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8358790072200349527L);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test75"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(8.324347882049603d, 422573888);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test76"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.util.ExceptionContext var11 = var10.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test77"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var6 = var4.nextChiSquare(1.0d);
//     double var8 = var4.nextT(2.9748236757560673d);
//     long var10 = var4.nextPoisson(12.978452428686579d);
//     double var13 = var4.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     double var16 = var4.nextCauchy(0.8394859904584389d, 3.141592653589793d);
//     int[] var19 = var4.nextPermutation(10, 6);
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     var1.setSeed(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.02828147219118588d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.97781977578718d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 14L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 6.651369377311913E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 4.789926525808668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test78"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.4E-45f, 12.190933f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.190933f);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test79"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-2592370801787852563L), (java.lang.Number)119.87204169238177d, (java.lang.Number)0.7450520880645611d);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test80"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test81"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalVariance();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.cumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test82"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    int var13 = var5.getSupportLowerBound();
    double var15 = var5.probability(715);
    int var16 = var5.getNumberOfSuccesses();
    int var17 = var5.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(0.9040580270688509d, 1.4100249074148754d);
//     double var6 = var0.nextBeta(3.552713678800501E-15d, 5.530681361120931E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.756110776268993d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.5151521550253319E-9d);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var0.nextInt(1132524014, 45);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2707059146737662152L);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test85"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    boolean var11 = var6.isSupportConnected();
    double var13 = var6.upperCumulativeProbability((-438907248));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test86"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.734723475976807E-18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.734723475976807E-18d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test87"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(563228325);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test88"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.7432415f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7432415f);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     long var12 = var0.nextLong((-214947668324021772L), 8L);
//     double var15 = var0.nextCauchy(10.90009547671185d, 0.019948546946239154d);
//     int var18 = var0.nextZipf(352, 0.001426069753303551d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var21 = var0.nextSecureLong(2L, (-214947668324021772L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 6.1793039756272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.40258495335032196d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3418072091154473190L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-35628772742213707L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.919170699101482d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 313);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test90"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var1, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    java.lang.Throwable[] var6 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Number var8 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var13 = var12.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var8, (java.lang.Object[])var13);
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var7, (java.lang.Object[])var13);
    java.lang.Number var16 = var3.getLo();
    org.apache.commons.math3.exception.util.ExceptionContext var17 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test91"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     var0.reSeedSecure((-4787408160038539288L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(8358790072200349527L, (-5510741753851645455L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.316462224240006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.44451741803044764d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11L);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test92"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     java.lang.String var11 = var2.nextHexString(12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.129338512214582E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "dc953afe8813"+ "'", var11.equals("dc953afe8813"));
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "1be"+ "'", var10.equals("1be"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9030967598336614d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 484);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)100.0d, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test95"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-243207998406690132L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 243207998406690132L);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test96"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var12 = var6.getSupportUpperBound();
    double var14 = var6.probability(422573888);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test97"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     double var16 = var0.nextBeta(3.9925440556337284d, 1.7904776031539309E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1997124204897321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-5.567589299849478d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1846455658719605323L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "1c080"+ "'", var11.equals("1c080"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.284214464170154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0d);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.19048333f, (java.lang.Number)Double.NaN, false);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, (-1));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test100"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)9.409188131594754E27d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test101"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.8872303f, 1.5111572E23f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8872303f);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test102"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.6208928579421887d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6208928579421887d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test103"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    int var4 = var1.nextInt(10);
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var7 = var1.nextLong(0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test104"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var8 = var1.nextLong(15L);
    float var9 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8605623f);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     double var12 = var0.nextCauchy(0.8394859904584389d, 3.141592653589793d);
//     int[] var15 = var0.nextPermutation(10, 6);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     int var18 = var16.nextInt(524);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.1799765433777663d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.3858383461410915d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.6513693773118516E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.9274800725714432d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 363);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test106"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test107"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    int var11 = var5.sample();
    int var12 = var5.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test108"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    double var14 = var5.upperCumulativeProbability(281614168);
    double var16 = var5.cumulativeProbability((-6));
    int var17 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test109"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.8167069219439684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test110"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int[] var5 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 6, 0, 1);
//     boolean var11 = var10.isSupportConnected();
//     int var12 = var10.sample();
//     double var14 = var10.upperCumulativeProbability((-1));
//     double var16 = var10.upperCumulativeProbability(6);
//     int var17 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextWeibull((-0.08936763556649133d), 0.13453087765780822d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1345922701067204d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "71d"+ "'", var4.equals("71d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test111"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test112"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(7.321941349665098d, 0.6153990834719214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7.321941349665097d);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test113"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(13L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var4);
    long var7 = var4.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var10 = new int[] { };
    var9.setSeed(var10);
    byte[] var12 = new byte[] { };
    var9.nextBytes(var12);
    var4.nextBytes(var12);
    var1.nextBytes(var12);
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var18 = new int[] { };
    var17.setSeed(var18);
    byte[] var20 = new byte[] { };
    var17.nextBytes(var20);
    var1.nextBytes(var20);
    int var24 = var1.nextInt(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test114"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure(100L);
//     long var11 = var2.nextLong(0L, 26L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var2.nextSample(var12, 125);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test115"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    var1.setSeed(6);
    double var12 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.6709920656782435d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test116"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-38748060543528751L), (java.lang.Number)6.211368153355547E-4d, true);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test117"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)18.999999999999996d, (java.lang.Number)3.432600494654796d, false);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NotPositiveException var6 = new org.apache.commons.math3.exception.NotPositiveException(var4, (java.lang.Number)5.873060404051843d);
    var3.addSuppressed((java.lang.Throwable)var6);
    boolean var8 = var6.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test118"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    double var4 = var1.nextDouble();
    var1.setSeed((-127));
    var1.setSeed((-51616135));
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var9.nextSecureInt(263621476, 897);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401381795025d);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     long var20 = var0.nextPoisson(2.286069913668499d);
//     double var23 = var0.nextWeibull(0.012829087820977834d, 0.006493101352562512d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var26 = var0.nextPascal(46, 4.020494098909096E28d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.032407108627346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a78"+ "'", var4.equals("a78"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5074195530702173E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.6193810979121093d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.1521888852459421E-144d);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test120"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.4681888166880769d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.46818881668807694d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test121"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)29, (java.lang.Number)3.942186149242891d, false);
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Object[])var9);
    java.lang.Number var11 = var10.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    var3.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4997320104385629d, (java.lang.Number)0.8394859904584389d, (java.lang.Number)(-6.010754535962853d));
    var10.addSuppressed((java.lang.Throwable)var17);
    java.lang.Number var19 = var10.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test122"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     int var11 = var2.nextBinomial(5, 0.07180988227597636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextUniform(0.7145762379908008d, 0.20866604530927532d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test123"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(100.0f, (-597052871));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test124"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.9462734954627106d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test125"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-3759508027876256838L), (java.lang.Number)1.4210804127942926d, (java.lang.Number)2.6645883331377274d);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-3759508027876256838L)+ "'", var5.equals((-3759508027876256838L)));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test126"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)15L, (java.lang.Number)5.338762598682091E31d, (java.lang.Number)(-2349309494509100384L));
    java.lang.Number var5 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 5.338762598682091E31d+ "'", var5.equals(5.338762598682091E31d));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test127"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)31.4104f, (java.lang.Number)(-127), false);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test128"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.09025870420782302d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-4));

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test129"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     org.apache.commons.math3.random.RandomGenerator var10 = var2.getRandomGenerator();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextGaussian(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 76.72079896125076d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test130"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalMean();
    double var8 = var5.upperCumulativeProbability(364);
    int var10 = var5.inverseCumulativeProbability(0.059279958251462046d);
    double var11 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test131"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    long var6 = var1.nextLong(9L);
    long var7 = var1.nextLong();
    double var8 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-7034676902218012687L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.09598026068363885d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test132"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(3.993369341651611E-5d, 1413078328);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test133"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.9802322E-8f, 0.9815751f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9815751f);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test134"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test135"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 3.4028235E38f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test136"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    var1.setSeed(100L);
    long var8 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3513799009476651814L);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test137"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
//     double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
//     double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
//     java.lang.String var11 = var2.nextSecureHexString(29);
//     long var14 = var2.nextSecureLong(0L, 12L);
//     double var17 = var2.nextF(1.7904776031539309E-6d, 3.774581056178469E252d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.00797810778992547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "56a6b0564b4f654a04186f63a4504"+ "'", var11.equals("56a6b0564b4f654a04186f63a4504"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.828348298723561E-9d);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test138"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    java.lang.String var8 = var6.toString();
    java.lang.Number var9 = var6.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.apache.commons.math3.exception.NotFiniteNumberException: null is not a finite number"+ "'", var8.equals("org.apache.commons.math3.exception.NotFiniteNumberException: null is not a finite number"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test139"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)1L, false);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    var1.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test140"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(5646616835816284903L, 5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5L);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test141"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     double var18 = var0.nextGaussian(119.87204169238177d, 2.008674318963529d);
//     double var21 = var0.nextUniform(1.041798895676483d, 1.5430806348152437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.840022451836383d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "db2"+ "'", var4.equals("db2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.314054678743974E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.2693776317229906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 120.21866843107132d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.5091823190407068d);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test142"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    boolean var4 = var3.getBoundIsAllowed();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var13 = var0.nextGamma(2.0000000000000004d, 0.5303092014603302d);
//     java.lang.String var15 = var0.nextHexString(17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03239144909956485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.8285951536920466d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.1640673133565531d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4608458684286658d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "059380976485ce927"+ "'", var15.equals("059380976485ce927"));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test144"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.sample();
    var5.reseedRandomGenerator((-5510741753851645455L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test145"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    double var14 = var5.cumulativeProbability(563228325);
    double var16 = var5.cumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test146"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    long var12 = var2.nextLong(3L, 10L);
    long var14 = var2.nextPoisson(8.653297910537354d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var17 = var2.nextPermutation((-1023), (-494780561));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4L);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.4747701594260527d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0958786587821821d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test148"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    boolean var11 = var6.isSupportConnected();
    double var13 = var6.probability(1146122894);
    double var15 = var6.upperCumulativeProbability(86);
    double var18 = var6.cumulativeProbability(125, 987587419);
    var6.reseedRandomGenerator(17L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.1442539017638377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1551773728656876d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test150"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong((-2349309494509100384L), 343034188110465231L);
//     int var18 = var0.nextSecureInt(207, 1146122894);
//     double var21 = var0.nextWeibull(0.09025870420782302d, 2.6645883331377274d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.926834430338674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.26890501843692566d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.0300718132741955d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1.3083316696736136d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-2278760241382969439L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1103072311);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1.6937501411165762E-6d);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3L);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test152"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-438907248));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 438907248);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test153"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5418954798163613d, 2.6251584714114255E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5418954798164249d);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     var0.reSeedSecure(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "73c"+ "'", var10.equals("73c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.13181211102500967d);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test155"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     int var16 = var0.nextBinomial(39, 0.0d);
//     int var19 = var0.nextSecureInt(0, 147);
//     double var21 = var0.nextT(0.005021941705612214d);
//     double var24 = var0.nextBeta(1.4210804127942926d, 0.19592488215851694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "189"+ "'", var10.equals("189"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.09708908246125969d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 5.429424745720057E40d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.7875082751010134d);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     double var9 = var0.nextBeta(2.0311506179736343d, 0.19592488215851694d);
//     double var11 = var0.nextT(75.30019670754133d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextHypergeometric(1132524014, (-79134244), 263621476);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.012973191061085592d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "352a1bae58eace559c6f1f9ffc999a4887bb18c644e0e1addcd86f7a6cd739d59e27ccea424bdb7fc9616ad77db70c6751e81029923245267e0bfc441fd25f34199279faa7f18bab92f4f1341666e277384bb265e32d77e06461dc5c6361600f215a81f6d3af773c72a88cb62509b8685ed1489ef59c3c081e398c09f74d16d3d1507a0b7250887d4c427e57dd45b292105247658ad1f2a4063a73c8e46921850b0fdb6853d9f7d68b2fa93e0f726784c3377868619e682dbee6c9627de97f7b532c16a8fcbf35ae2fa31b0848aba231f986f45f7703d39a56dbff8aba89c90177d0eaf60699c898991ad91cdb56f39d6149e2855b53f4f7bddd084d54353738937d576c849c8241bd4973c20b4a52d939a5ba61d445df022344361275606ee10f3adbdace7b245197945df6b64539e583ae88b322ed0fcc60fbbec41086b9db4905281ec8037597fd54b47948b8b5948590d7194ee036846a13c92fd2c173bf93a508da81d5db3929d51601a2e40cdd643c1a140ea00b38d061ed0e3517040bc0dc40b3a713fde58e80d8662737541c5a429081489057f49f55e10644436368fde6bdcc3b7e0670eb4a4428cf8c433cfb4dfb44d8a42b0384ece8a8edf7f2a02d1579948a9a8e6e9369c75d7f02eeb33da5451866ddc627d110c769c64fd0fdaa575bf093c60002ba1a479dd024c1ac4ba09d8eef0495d670b4a761c7b28a85"+ "'", var4.equals("352a1bae58eace559c6f1f9ffc999a4887bb18c644e0e1addcd86f7a6cd739d59e27ccea424bdb7fc9616ad77db70c6751e81029923245267e0bfc441fd25f34199279faa7f18bab92f4f1341666e277384bb265e32d77e06461dc5c6361600f215a81f6d3af773c72a88cb62509b8685ed1489ef59c3c081e398c09f74d16d3d1507a0b7250887d4c427e57dd45b292105247658ad1f2a4063a73c8e46921850b0fdb6853d9f7d68b2fa93e0f726784c3377868619e682dbee6c9627de97f7b532c16a8fcbf35ae2fa31b0848aba231f986f45f7703d39a56dbff8aba89c90177d0eaf60699c898991ad91cdb56f39d6149e2855b53f4f7bddd084d54353738937d576c849c8241bd4973c20b4a52d939a5ba61d445df022344361275606ee10f3adbdace7b245197945df6b64539e583ae88b322ed0fcc60fbbec41086b9db4905281ec8037597fd54b47948b8b5948590d7194ee036846a13c92fd2c173bf93a508da81d5db3929d51601a2e40cdd643c1a140ea00b38d061ed0e3517040bc0dc40b3a713fde58e80d8662737541c5a429081489057f49f55e10644436368fde6bdcc3b7e0670eb4a4428cf8c433cfb4dfb44d8a42b0384ece8a8edf7f2a02d1579948a9a8e6e9369c75d7f02eeb33da5451866ddc627d110c769c64fd0fdaa575bf093c60002ba1a479dd024c1ac4ba09d8eef0495d670b4a761c7b28a85"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "7179f0"+ "'", var6.equals("7179f0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.9981286904462684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3235119398023725d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test157"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.39823927240827994d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 22.817429545355136d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var25 = var0.nextSecureHexString((-1737377827));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "cd8"+ "'", var10.equals("cd8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.04287808319711073d);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test159"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    int var13 = var5.getSupportLowerBound();
    int var14 = var5.getSupportUpperBound();
    int var16 = var5.inverseCumulativeProbability(0.004591489248785328d);
    int[] var18 = var5.sample(972);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test160"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.6937501411165762E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test161"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(12L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 12L);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test162"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var10 = var2.nextT(2.8822137015004015d);
//     var2.reSeedSecure((-3984960309769776189L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.11317443320471543d));
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test163"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test164"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    long var11 = var1.nextLong(26L);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9L);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test165"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextChiSquare(23.729908791521954d);
//     int var13 = var0.nextBinomial(0, 0.29486290084058253d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextLong(3759508027876256838L, 2548228850011803885L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4282651455034381d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3a8"+ "'", var4.equals("3a8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 21.914220178553748d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test166"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     long var18 = var0.nextSecureLong((-6069125204240848293L), 2419047238712938144L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(0.9092974268256814d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.13720540644896878d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "be1"+ "'", var4.equals("be1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.1832417851847771E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.227694966659944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-816875527225826117L));
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test167"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.3824846535938333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1277591147170036d);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test168"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-0.9513406221111023d), (java.lang.Number)(-650.5734518382083d));

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test169"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.19048333f, 0.7432416f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test170"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var2, (java.lang.Number)0.0f);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    java.lang.Number var9 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var15 = new org.apache.commons.math3.exception.NotFiniteNumberException(var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var8, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1024, (java.lang.Object[])var14);
    java.lang.Throwable[] var18 = var17.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test171"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)23.729908791521954d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test172"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var3.reSeedSecure();
    int[] var5 = new int[] { };
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
    org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 6, 0, 1);
    boolean var11 = var10.isSupportConnected();
    int var12 = var10.sample();
    int var13 = var10.getSampleSize();
    double var16 = var10.cumulativeProbability(10, 17);
    boolean var17 = var10.isSupportConnected();
    int var18 = var3.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test173"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.7941925865739156d));
    java.lang.Number var2 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + (-0.7941925865739156d)+ "'", var2.equals((-0.7941925865739156d)));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.03975222781371839d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9992099842346611d);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test175"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-2349309494509100384L), (java.lang.Number)0.9992099842346611d, true);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test176"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.148628176310107d, (java.lang.Number)1.9668566104518523d, (java.lang.Number)1.4747701594260527d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test177"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.9795398342351607d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.663230432444379d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test178"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(-11.0d));

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test179"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     var2.reSeed();
//     double var11 = var2.nextChiSquare(1.1551773728656876d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.6081725617413046E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.10432686826383897d);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test180"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     int var14 = var2.nextInt((-1413078328), 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextWeibull(0.0d, (-1.0333020151941643d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-597052871));
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test181"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var5.cumulativeProbability(422573888, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test182"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)12.190933f);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test183"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var3.nextPermutation(2147483647, 1707870484);
      fail("Expected exception of type java.lang.OutOfMemoryError");
    } catch (java.lang.OutOfMemoryError e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1753021164154851d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test184"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.2203158490481973d, (-0.6751447494035615d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2203158490481973d);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test185"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.1997124204897321d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19838747551728764d);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test186"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     int var19 = var0.nextZipf(364, 2.522056159962681d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var0.nextGamma(1.9518401855672245d, (-1.4432295444183707d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9930993975258443d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test187"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)3.4724687469699105d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test188"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(26L);
    double var12 = var5.getNumericalMean();
    int var13 = var5.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test189"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-4740792029645458057L), (java.lang.Number)(-213915053556550245L), false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test190"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    double var3 = var0.nextWeibull(5.6164742204878395E28d, 0.4119933541006996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.4119933541006996d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test191"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextBinomial(16, 0.9731408681251136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 16);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test192"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0768010541618303d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test193"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test194"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-7113760168377139929L));
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test195"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "812");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7817357844668752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.9877956297855255d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.08884947924821136d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0886167810346583d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     int var21 = var0.nextHypergeometric(280397493, 280397493, 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var24 = var0.nextLong(1228372035613083129L, (-3415793725169262878L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2900705320759653d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "fe6"+ "'", var4.equals("fe6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.004132175339987546d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.160121383081118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1024);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test198"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalMean();
    double var8 = var5.upperCumulativeProbability(364);
    int var10 = var5.inverseCumulativeProbability(0.059279958251462046d);
    double var12 = var5.cumulativeProbability((-597052871));
    int var13 = var5.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test199"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test200"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.31911931783537784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.284190073061048d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test201"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.03683822491099731d, 327709799);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test202"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.8E-322d, 1.3407807929942155E154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3407807929942155E154d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test203"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    long var11 = var1.nextLong(26L);
    org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9L);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test204"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    double var16 = var2.nextGamma(1.8348931695478938d, 0.5418954798163614d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.46511422979512007d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test205"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)22.817429545355136d, (java.lang.Number)(-343034188110465231L), true);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test206"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    long var4 = var1.nextLong();
    int var5 = var1.nextInt();
    var1.setSeed(2L);
    var1.setSeed(2L);
    long var10 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var13 = new int[] { };
    var12.setSeed(var13);
    byte[] var15 = new byte[] { };
    var12.nextBytes(var15);
    var1.nextBytes(var15);
    var1.setSeed(715);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2083745733));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1538236582175553973L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     int[] var10 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(var10);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var15 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var11, 6, 0, 1);
//     boolean var16 = var15.isSupportConnected();
//     int var17 = var15.sample();
//     double var19 = var15.upperCumulativeProbability((-1));
//     double var21 = var15.upperCumulativeProbability(6);
//     int var23 = var15.inverseCumulativeProbability(Double.NaN);
//     double var25 = var15.cumulativeProbability((-51616135));
//     int var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.021856485149522823d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.6341914326695551d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.651369377311959E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test208"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    double var16 = var2.nextGamma(1.8348931695478938d, 0.5418954798163614d);
    org.apache.commons.math3.random.RandomGenerator var17 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.46511422979512007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test209"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(13L);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var4 = var1.nextInt(438907248);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 250253022);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test210"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong((-2349309494509100384L), 343034188110465231L);
//     int var18 = var0.nextSecureInt(207, 1146122894);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, (-7));
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     double var10 = var0.nextBeta(1.2177286606506965d, 3.540721859458478E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.044612088417354236d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b8b"+ "'", var4.equals("b8b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test212"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var17 = var0.nextGaussian(0.792126722906372d, 0.6779239362577469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d38"+ "'", var10.equals("d38"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.02320304733490052d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.2021884362627042d);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test214"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure();
//     double var6 = var2.nextCauchy(3.1622776601683795d, 0.5207931322143664d);
//     int var9 = var2.nextSecureInt((-79134244), 524);
//     java.util.Collection var10 = null;
//     java.lang.Object[] var12 = var2.nextSample(var10, (-8));
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test215"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalVariance();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.probability(16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test216"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(100L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test217"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(26L);
    double var12 = var5.getNumericalMean();
    int var14 = var5.inverseCumulativeProbability(0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test218"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)3.993369341651611E-5d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test219"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.8605623f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8605623f);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test220"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    var1.setSeed(100L);
    var1.setSeed((-213915053556550245L));
    int var11 = var1.nextInt(2);
    org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(6);
    long var14 = var13.nextLong();
    double var15 = var13.nextGaussian();
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var18 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var17);
    var17.clear();
    int var20 = var17.nextInt();
    byte[] var24 = new byte[] { (byte)10, (byte)100, (byte)(-1)};
    var17.nextBytes(var24);
    var13.nextBytes(var24);
    var1.nextBytes(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1413078328));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test221"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-55258480997125034L));
    long var2 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7152607889026566320L);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test222"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     int var11 = var2.nextBinomial(5, 0.07180988227597636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextGaussian(1.3677307645144745E-6d, (-1.6955707661562176d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong((-2349309494509100384L), 343034188110465231L);
//     int var18 = var0.nextSecureInt(207, 1146122894);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.01637200419504605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.6253005809777104d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.26792992747972233d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.2761400758681119d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1334583219037485034L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 700349994);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test224"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)15.925797012802406d);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test225"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
//     double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
//     double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
//     java.lang.String var11 = var2.nextSecureHexString(29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextSecureInt(26, (-51616135));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.00797810778992547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "1c77164510d7413c2898ef3b7eef4"+ "'", var11.equals("1c77164510d7413c2898ef3b7eef4"));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(0.6313298547021015d, 6.651369377311933E13d, false);
    org.apache.commons.math3.random.RandomGenerator var14 = var2.getRandomGenerator();
    int var17 = var2.nextBinomial(0, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var20 = var2.nextBinomial(46, (-1.1268915383987363d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.424391929298217E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test227"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    var2.reSeed((-6069125204240848293L));
    double var19 = var2.nextUniform(2.220446049250313E-16d, 68.73655708174395d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.3401575347980685d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test228"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    var1.setSeed(1132524014);
    float var12 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.771788f);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.99357828012885d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.8690002296036647d));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test230"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.12334501037357812d, (java.lang.Number)1.4747701594260527d, true);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test231"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-650.5734518382083d), 0.19963560609026354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 650.5734824683963d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test232"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    org.apache.commons.math3.random.RandomGenerator var7 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.2948629008405826d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test234"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot((-117.58082258639261d), (-1.3407807929942273E154d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3407807929942273E154d);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-1.3401769730181888E15d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test236"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Number var7 = var4.getArgument();
//     java.lang.String var8 = var4.toString();
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test237"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.3616878291415171d, 2.3401575347980685d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3616878291415171d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test238"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.0018854762754577272d, 0.46511422979512007d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.46511422979512007d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test239"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.27754671516368096d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2775467151636809d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test240"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    boolean var8 = var7.isSupportConnected();
    int var9 = var7.sample();
    double var11 = var7.upperCumulativeProbability((-1));
    var7.reseedRandomGenerator(26L);
    int var14 = var7.getSupportLowerBound();
    int[] var16 = var7.sample(732);
    var1.setSeed(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var1.nextInt((-1737377827));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test241"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-0.6321205588285577d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test242"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     int var8 = var2.nextSecureInt(100, 1024);
//     double var11 = var2.nextF(2.46742664166224d, 1.2239675137479333d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextSecureInt(5, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 782);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4850233742754995d);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test243"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    double var14 = var5.cumulativeProbability(563228325);
    double var17 = var5.cumulativeProbability((-2083745733), 9);
    double var18 = var5.getNumericalMean();
    int var19 = var5.getSupportLowerBound();
    var5.reseedRandomGenerator((-4649104417600447144L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test244"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.27873126f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test245"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.6531967712257384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test246"); }


    long var1 = org.apache.commons.math3.util.FastMath.round((-5.21416038369738d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-5L));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test247"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    boolean var8 = var7.isSupportConnected();
    int var9 = var7.sample();
    double var11 = var7.upperCumulativeProbability((-1));
    var7.reseedRandomGenerator(26L);
    int var14 = var7.getSupportLowerBound();
    int[] var16 = var7.sample(732);
    var1.setSeed(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var19 = var1.nextLong((-126731243878266010L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test248"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     long var20 = var0.nextPoisson(2.286069913668499d);
//     long var23 = var0.nextSecureLong((-947337978656517030L), 58365653636984266L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7721184530320563d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "ea8"+ "'", var4.equals("ea8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4221524586107774d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21742755174195881L);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.1306629546226212d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test250"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var5.sample((-1023));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.012911733613348696d, 270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test252"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    int var4 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var9 = var5.nextUniform(0.04015334158805609d, 0.05036975957415425d, false);
    double var12 = var5.nextGamma(0.7700247882582713d, 0.04762305207136196d);
    double var14 = var5.nextT(2.08515805168829d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.04847797978133815d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.005663673264529156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 3.1990635971325787d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test253"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(2.826539778492393d, (-0.5039116999145312d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.871106776264265d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    boolean var6 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2419047238712938144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test255"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var13 = var6.inverseCumulativeProbability(0.5403023058681398d);
    double var16 = var6.cumulativeProbability(2, 1024);
    double var18 = var6.cumulativeProbability(364);
    int var19 = var6.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 6);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test256"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)100.0d, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)100L, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test257"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)6L, true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 6L+ "'", var5.equals(6L));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test258"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.009158274463423011d, (-0.29430114618146475d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.009158274463423011d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test259"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.709377217938145d, (java.lang.Number)364, false);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator(var0);
//     double var4 = var1.nextUniform(0.03132321019379296d, 2.286069913668499d);
//     double var8 = var1.nextUniform(0.20650036564733387d, 3.432600494654796d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.3634122204881139d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.357064393258053d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test261"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     long var2 = var1.nextLong();
//     double var3 = var1.nextGaussian();
//     var1.clear();
//     long var6 = var1.nextLong(9L);
//     org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeed((-7034676902218012687L));
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var7.nextInversionDeviate(var10);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     double var18 = var0.nextGaussian(0.020946536357894976d, 0.07014657489128577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 10.56349941771777d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3c2"+ "'", var4.equals("3c2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.671484896286031E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.3623907634894425d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.03305137498467392d);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test263"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.47348801367674015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test264"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("0f9", "05a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2705147788304642001L);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test265"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(6.744770635234011E-22d, 0.1997124204897321d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1997124204897321d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test266"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    double var16 = var2.nextUniform(1.7538036993385602d, 2.3283872144743825d, true);
    var2.reSeedSecure(26L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.008674318963529d);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test267"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     double var16 = var0.nextUniform(0.3916905744695509d, 30.973188990298418d);
//     double var18 = var0.nextExponential(1.1916061660198558d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6644217516619209d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.9086812958032022d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-819129858440852754L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "10597"+ "'", var11.equals("10597"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3284685062766586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 11.469567356972489d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2.3569876225685187d);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test268"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.27873126f, 1665346298);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test269"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    double var12 = var5.cumulativeProbability(1024);
    double var14 = var5.probability(281614168);
    int var15 = var5.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 6);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test270"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.0037879760327523236d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.003787966974016121d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test271"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1.7626381930754416d));

  }

//  public void test272() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest3.test272"); }
//
//
//    int[] var0 = new int[] { };
//    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
//    boolean var6 = var5.isSupportConnected();
//    int var7 = var5.sample();
//    int var8 = var5.getSampleSize();
//    double var10 = var5.upperCumulativeProbability(3);
//    double var12 = var5.cumulativeProbability(1024);
//    double var14 = var5.probability(281614168);
//    // The following exception was thrown during execution.
//    // This behavior will recorded for regression testing.
//    try {
//      int[] var16 = var5.sample(438907248);
//      fail("Expected exception of type java.lang.OutOfMemoryError");
//    } catch (java.lang.OutOfMemoryError e) {
//      // Expected exception.
//    }
//    
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var6 == true);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var7 == 0);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var8 == 1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var10 == 0.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var12 == 1.0d);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var14 == 0.0d);
//
//  }
//
  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test273"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.26890501843692566d, 1.5091823190407068d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.26890501843692566d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test274"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    int[] var8 = var5.sample(100);
    double var9 = var5.getNumericalMean();
    int var10 = var5.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test275"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test276"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.030847570617025418d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test277"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.9073486E-6f, (-56171189));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test278"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    long var14 = var2.nextLong(9L, 31L);
    var2.reSeedSecure(0L);
    var2.reSeedSecure((-2349309494509100384L));
    double var21 = var2.nextF(4.485849767689555d, 130.89136659412873d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 26L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 2.4842079507516117d);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     double var6 = var0.nextWeibull(0.29486290084058253d, 5.177167373130586E28d);
//     double var9 = var0.nextGamma(0.7800627982038152d, 0.8140149187445599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.768913584845684d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.280198111344145E30d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.4214038364674166d);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextExponential(0.5418954798163613d);
//     org.apache.commons.math3.distribution.RealDistribution var11 = null;
//     double var12 = var0.nextInversionDeviate(var11);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(0.6313298547021015d, 6.651369377311933E13d, false);
    long var15 = var2.nextPoisson(0.004422735551269067d);
    double var18 = var2.nextBeta(0.1442539017638377d, 1.2239675137479333d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var21 = var2.nextPascal((-4), 0.6208928579421887d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.424391929298217E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.8045578577343295d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test282"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.1336467843554507d, (java.lang.Number)4093755611243242726L, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.0363607041614546d, 1.8453830087804857d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5516422987415587d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test284"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure();
//     int var6 = var2.nextPascal(17, 0.9458707273495791d);
//     java.lang.String var8 = var2.nextSecureHexString(246);
//     int var11 = var2.nextSecureInt(687, 13906712);
//     int var14 = var2.nextSecureInt(39, 250253022);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "0ca4e9e642ab15821a0c288ff8334404bd8a1d67b01adb3e021de68d147ea31f3751eb745a91b59a2e651f9557637791f56d4358f12105bc37d0cd9b02bf6e3595ef8f55ac88588d62370c421854e177c4243c557101b62bb3afc03234049392fdea6ffe8cbfc8a41e660a5a0a5ad7d1ee0d5f797cdf311caacc04"+ "'", var8.equals("0ca4e9e642ab15821a0c288ff8334404bd8a1d67b01adb3e021de68d147ea31f3751eb745a91b59a2e651f9557637791f56d4358f12105bc37d0cd9b02bf6e3595ef8f55ac88588d62370c421854e177c4243c557101b62bb3afc03234049392fdea6ffe8cbfc8a41e660a5a0a5ad7d1ee0d5f797cdf311caacc04"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4733618);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 46963995);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test285"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     org.apache.commons.math3.distribution.RealDistribution var13 = null;
//     double var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test286"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.22987486320805342d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test287"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.799453453475944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 103.10108831441222d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     int var9 = var0.nextSecureInt((-2), 0);
//     long var12 = var0.nextLong(4L, 6L);
//     long var14 = var0.nextPoisson(1.8330570943101214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4875106962593804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "79df01e5fa94dcd17c62485f55b03ec0cd44956fbd7aefea77647310bd80e3d8bc6ec16974ab2149bcbd699cf4e96a2b3921d1b75c5c44ee24cf52c68dd86b63869542b234576e5e010e6e69ce3900da49e96033f753411f44f608bc982bee7e701fd6fd9cd4cd200de542a2ba5165bdf6f0cba66634df061b196b15b1e00c0c95c65648e86fc5cabfab549a273712c11bbaf4849156af6dad23c327628b5100c9ffdb1e6113c5284ab02c4053e26514bb0921d1a1604ba4edc71513a07b556184b6f46c5da6b6752633f141a245ac95a7bd5a094be5e5550e005f0eb8719de67521e6fe92443a8c7200f341e469b76516b00613106f0414d98d17e424619e98b3a1f9106dc148a710fa0db0bc8710240965a1a086eefdcdb17394c60cbde6ac50933fbfaab997923ec9c94f180b930bd23471dde84d059e1b68e8ee4fac0b9865a66d66adaf8c943967ca0eaf4f2ab96ab908806b391d7a6403ed8824ad526c0398ad157d3a9f23a25ba47c3c8623c9d8c5513428554eae9080f265a621f277f9a63028015d0c8f4ac443183cb8ef0243616edfc67e8bbe0e2ae716c1dd6b54a118b519f77fb059e4274d41383544404f6983bfe1a1d68dcdf95218354b2f3ce047933f110cb6945ef4de4497246d0f4a170eb877a25db5955a309db8b62e4d2b7589dbf582a20760a77621dcb6b6ac01b24894554fc4f1bc0a7954ad615689"+ "'", var4.equals("79df01e5fa94dcd17c62485f55b03ec0cd44956fbd7aefea77647310bd80e3d8bc6ec16974ab2149bcbd699cf4e96a2b3921d1b75c5c44ee24cf52c68dd86b63869542b234576e5e010e6e69ce3900da49e96033f753411f44f608bc982bee7e701fd6fd9cd4cd200de542a2ba5165bdf6f0cba66634df061b196b15b1e00c0c95c65648e86fc5cabfab549a273712c11bbaf4849156af6dad23c327628b5100c9ffdb1e6113c5284ab02c4053e26514bb0921d1a1604ba4edc71513a07b556184b6f46c5da6b6752633f141a245ac95a7bd5a094be5e5550e005f0eb8719de67521e6fe92443a8c7200f341e469b76516b00613106f0414d98d17e424619e98b3a1f9106dc148a710fa0db0bc8710240965a1a086eefdcdb17394c60cbde6ac50933fbfaab997923ec9c94f180b930bd23471dde84d059e1b68e8ee4fac0b9865a66d66adaf8c943967ca0eaf4f2ab96ab908806b391d7a6403ed8824ad526c0398ad157d3a9f23a25ba47c3c8623c9d8c5513428554eae9080f265a621f277f9a63028015d0c8f4ac443183cb8ef0243616edfc67e8bbe0e2ae716c1dd6b54a118b519f77fb059e4274d41383544404f6983bfe1a1d68dcdf95218354b2f3ce047933f110cb6945ef4de4497246d0f4a170eb877a25db5955a309db8b62e4d2b7589dbf582a20760a77621dcb6b6ac01b24894554fc4f1bc0a7954ad615689"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "efb1f4"+ "'", var6.equals("efb1f4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2L);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test289"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    java.lang.Number var7 = var6.getArgument();
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var12 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var10, var11);
    java.lang.Number var13 = var12.getMin();
    var9.addSuppressed((java.lang.Throwable)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0+ "'", var13.equals(0));

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test290"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    boolean var11 = var6.isSupportConnected();
    double var12 = var6.getNumericalMean();
    double var13 = var6.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.665429362717771d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.287943208075393d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test292"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(Float.POSITIVE_INFINITY, (-1.784667018651192d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028235E38f);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test293"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-24));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test294"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.8489671157925772d, 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8489671157925772d);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test295"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
//     double var16 = var2.nextGamma(0.7350525871447157d, 5.56752948887997d);
//     var2.reSeed();
//     double var20 = var2.nextUniform(0.5002970871024577d, 1.3073009153062434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.925797012802406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.78527454092035d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.570663941018278d);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test296"); }


    double var2 = org.apache.commons.math3.util.FastMath.min((-0.08936763556649133d), 0.48413030032922305d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.08936763556649133d));

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test297"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var7 = var4.nextGaussian(30.9570417874309d, 9.568906036844316d);
//     double var9 = var4.nextExponential(0.001426069753303551d);
//     int var12 = var4.nextInt(6, 563228325);
//     int[] var15 = var4.nextPermutation(1024, 886);
//     var0.setSeed(var15);
//     var0.setSeed(39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 25.70543202901362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0017299837809377156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 281614168);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test298"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.5418954798164249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.572690800295348d);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test299"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(4.67271537421983E-8d, 0.9971373189742552d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9971373189742552d);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test300"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.0662706847592482d, 1.2239675137479333d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0360164897891408d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test301"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.26890501843692566d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2626909723171418d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test302"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8152769730283367d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Number var5 = null;
    org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var5, (java.lang.Number)0.0f);
    java.lang.Number var8 = var7.getLo();
    java.lang.Number var9 = var7.getLo();
    java.lang.Throwable[] var10 = var7.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var11 = null;
    java.lang.Number var12 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var17 = var16.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var11, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var17);
    org.apache.commons.math3.exception.NotFiniteNumberException var21 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)18.392781021818884d, (java.lang.Object[])var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test303"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test304"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
    var2.reSeed((-4740792029645458057L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var14 = var2.nextSecureLong(66513693773119L, (-546372290278750085L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.00797810778992547d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test305"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    int var8 = var7.getNumberOfSuccesses();
    int[] var10 = var7.sample(100);
    var1.setSeed(var10);
    var1.setSeed(564);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test306"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var3.nextBeta(0.5418954798163614d, 1.035898339779694d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.03859317612772693d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test307"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)16L, (java.lang.Number)301, false);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test308"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 9.999998f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999998f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test309"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    double var12 = var5.probability(327709799);
    var5.reseedRandomGenerator((-4414831352295630789L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.06934869829732719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06940429744336618d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test311"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.1410449111309419d, 1.0505485287042118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14104491113094192d);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test312"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(5.567529488879971d, 5.722713467366433E11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.567529488879971d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.7635378011037546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5673219057371348d);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     long var13 = var0.nextSecureLong(0L, 26L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextExponential((-1.017745364083061d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11762768821149125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.5624916949061554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.4253734493332453d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12L);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test315"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-3012399215156379713L), (java.lang.Number)0.31174213159242253d, true);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test316"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     java.lang.Number var7 = var4.getHi();
//     java.lang.Number var8 = var4.getHi();
//     org.apache.commons.math3.exception.NotPositiveException var10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.242017221677235d);
//     var4.addSuppressed((java.lang.Throwable)var10);
//     org.apache.commons.math3.exception.util.Localizable var12 = null;
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var18 = var17.getSuppressed();
//     java.lang.Throwable[] var19 = var17.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var20 = new org.apache.commons.math3.exception.MathInternalError(var13, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var12, (java.lang.Object[])var19);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(23.729908791521954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.208013393355151d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test318"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-5.214160383697379d));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test319"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(1.8330570943101214d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3663829218834473d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test320"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.021856485149522823d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0220970878333835d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test321"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.1372214103398305E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1372214103398305E28d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test322"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("8d3", "3140a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.02482660739466E-4d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test323"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.31174213159242253d, 1.0880328565492918d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.31174213159242253d);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test324"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     long var2 = var0.nextLong(1L);
//     int var3 = var0.nextInt();
//     long var4 = var0.nextLong();
//     boolean var5 = var0.nextBoolean();
//     org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var6.nextUniform(0.21901181603374026d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2048322915);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4082363265342021297L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test325"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
//     double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
//     double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
//     java.lang.String var11 = var2.nextSecureHexString(29);
//     long var14 = var2.nextSecureLong(0L, 12L);
//     double var16 = var2.nextChiSquare(0.00402053689632849d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.00797810778992547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "3c863a2de6f00ad49e59582a668fd"+ "'", var11.equals("3c863a2de6f00ad49e59582a668fd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 9L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.0801574070492376E-4d);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test326"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var9 = var0.nextT(3.215307210570628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.813726355797788d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.37937811838569185d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0030705969581458162d);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test327"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.8210039787872987d, (java.lang.Number)8778092, (java.lang.Number)(-51616135));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test328"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.17948253149278287d, 107);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.912270576349546E31d);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test329"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextSecureInt(700349994, 376458525);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "31d"+ "'", var10.equals("31d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.10089773279529653d);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test330"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var11 = var2.nextGaussian(0.0d, 14.975162885657241d);
//     org.apache.commons.math3.random.RandomGenerator var12 = var2.getRandomGenerator();
//     var2.reSeedSecure(7009605301686414442L);
//     var2.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 8.098419535253764E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-3.580533937630666d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test331"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    int[] var8 = var5.sample(100);
    org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.6937501411165762E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.001301441562697525d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test333"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(0.6313298547021015d, 6.651369377311933E13d, false);
    org.apache.commons.math3.random.RandomGenerator var14 = var2.getRandomGenerator();
    var2.reSeedSecure((-214947668324021772L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 3.424391929298217E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test334"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(31.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test335"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9815751f, 0.0958786587821821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.981575f);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test336"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5.395512929437507d);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    java.lang.Number var3 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test337"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(0.9040580270688509d, 1.4100249074148754d);
//     double var6 = var0.nextUniform(0.5142856083511866d, 4.765158102961618d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     int var16 = var12.getSupportLowerBound();
//     int var17 = var12.getSupportLowerBound();
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     int[] var19 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var20 = new org.apache.commons.math3.random.Well19937c(var19);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var24 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var20, 6, 0, 1);
//     boolean var25 = var24.isSupportConnected();
//     int var26 = var24.sample();
//     int var27 = var24.getSampleSize();
//     int var28 = var24.getSupportLowerBound();
//     double var29 = var24.getNumericalVariance();
//     double var31 = var24.probability((-1));
//     double var33 = var24.upperCumulativeProbability(281614168);
//     int var34 = var24.getSupportLowerBound();
//     double var36 = var24.cumulativeProbability(246);
//     int var37 = var24.getSampleSize();
//     int var38 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var24);
//     int var41 = var0.nextInt((-597052871), 199);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.2976244489636173d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2.5298468206596474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-36450909));
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     var0.reSeedSecure(1L);
//     int var28 = var0.nextZipf(500, 0.00752126284215363d);
//     double var30 = var0.nextChiSquare(1.5430806348152437d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ef3"+ "'", var10.equals("ef3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.006059596988060951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 166);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1.2787900282241718d);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test339"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.9815751f, 1.1246805537464089d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.98157513f);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test340"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong((-2349309494509100384L), 343034188110465231L);
//     int var18 = var0.nextInt((-1267720276), 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("bb497c6a90b1ac12de29a9e64ab8d", "c77");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6270759303598532d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-5.255319715438766d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.871706084604153d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-8.292220001305841d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1898961144159750862L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-513034908));
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test341"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test342"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    boolean var11 = var6.isSupportConnected();
    double var12 = var6.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test343"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    var5.reseedRandomGenerator((-145779445778080084L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test344"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    java.lang.String var7 = var2.nextHexString(6);
    double var10 = var2.nextGamma(2.08515805168829d, 1.1116073535960684d);
    double var13 = var2.nextF(0.5123778273012989d, 14.975162885657241d);
    org.apache.commons.math3.random.RandomGenerator var14 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "629ec7"+ "'", var7.equals("629ec7"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.8046560752276581d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.4700804467918638d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test345"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     int[] var2 = new int[] { };
//     var1.setSeed(var2);
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var6 = var4.nextSecureHexString(1);
//     org.apache.commons.math3.random.RandomGenerator var7 = var4.getRandomGenerator();
//     var4.reSeedSecure();
//     org.apache.commons.math3.random.RandomGenerator var9 = var4.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "1"+ "'", var6.equals("1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test346"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.2787312f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test347"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    double var9 = var2.nextUniform((-0.9262160379374064d), 2.9748236757560673d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextSecureLong(6L, (-584986072174970266L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0821957873042685d);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test348"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    var2.reSeed((-6069125204240848293L));
    int var8 = var2.nextBinomial(2, 6.211368153355547E-4d);
    double var11 = var2.nextGamma(2.847732150080772d, 9.329378986158627d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 15.087483205158318d);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test349"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1.3813117226938723d));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test350"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(26L);
    double var12 = var5.getNumericalMean();
    int var13 = var5.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test351"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    int var13 = var5.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test352"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     double var20 = var0.nextBeta(3.659423199395708d, 0.20650036564733387d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var0.nextSecureInt(270, 125);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ca5"+ "'", var10.equals("ca5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0553666448101526d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 975);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.9750996896424563d);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test353"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(1413078328);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1413078328);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test354"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.39434982251580614d);
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var1);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var16 = var0.nextT(0.26234589613270526d);
//     double var19 = var0.nextF(0.26234589613270526d, 16.092568818840984d);
//     double var21 = var0.nextExponential(75.91055213056157d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var25 = var0.nextUniform(1.0219596934646156d, 0.5142856083511866d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "097"+ "'", var10.equals("097"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.028467604195503857d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12.243282189397942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.3289085296046085E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 115.6658645927793d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test356"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    int var8 = var7.getNumberOfSuccesses();
    int[] var10 = var7.sample(100);
    var1.setSeed(var10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var15 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 17, 3, 3);
    long var16 = var1.nextLong();
    int var17 = var1.nextInt();
    double var18 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-2470797712490912764L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-686183305));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.27273239543003536d);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test357"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var10 = var2.nextT(2.8822137015004015d);
//     int var13 = var2.nextSecureInt((-79134244), 1413078328);
//     int var16 = var2.nextBinomial(41, 0.37557878440901027d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.782806459973279d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 372779487);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 18);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.7946877449054939d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 102.82803332693611d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test359"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(31.4104f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test360"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     var2.reSeedSecure((-6069125204240848293L));
//     long var13 = var2.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("a25", "org.apache.commons.math3.exception.NotFiniteNumberException: null is not a finite number");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.114535603576975d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 24L);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test361"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-56171189));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(39, 0, 1632050914);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var22 = var17.sample();
//     int var23 = var17.getSampleSize();
//     double var25 = var17.cumulativeProbability((-127));
//     int var26 = var17.getSupportLowerBound();
//     boolean var27 = var17.isSupportConnected();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "bbb"+ "'", var10.equals("bbb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test364"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    int var10 = var5.getSupportLowerBound();
    int var12 = var5.inverseCumulativeProbability(0.5303092014603302d);
    double var14 = var5.probability(422573888);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test365"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0348711345288815d, (java.lang.Number)500, false);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 500+ "'", var4.equals(500));

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test366"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-38748060543528751L), (-3012399215156379713L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3012399215156379713L));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test367"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    int var4 = var1.nextInt(10);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var7 = var5.nextT(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.051269438986972d);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test368"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.0f, 2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000002f);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test369"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.2787312f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test370"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    double var16 = var2.nextUniform(1.7538036993385602d, 2.3283872144743825d, true);
    var2.reSeed((-6069125204240848293L));
    double var21 = var2.nextCauchy(0.41933189414688476d, 2.1799765433777663d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.008674318963529d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-19.884786111375366d));

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test371"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var10 = var0.nextF(2.770727193912281E-6d, 0.7350525871447157d);
//     double var13 = var0.nextGaussian((-0.12952473180939125d), 1.3284685062766586d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.21072189635212948d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "64a"+ "'", var4.equals("64a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9.909092431968886E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1.5114598992716166d));
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test372"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.31174213159242253d, 0.570663941018278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5141944034677624d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var16 = var0.nextT(0.26234589613270526d);
//     long var19 = var0.nextSecureLong((-339878989410455899L), 8L);
//     double var21 = var0.nextT(0.6217097382835118d);
//     double var24 = var0.nextF(0.005824698872533255d, 5.28554289799445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "514"+ "'", var10.equals("514"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.08366921340430551d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.601836514370935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-26705070681179934L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 5.688737833588375d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test374"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     long var2 = var0.nextLong(1L);
//     int var3 = var0.nextInt();
//     long var4 = var0.nextLong();
//     boolean var5 = var0.nextBoolean();
//     var0.setSeed(143);
//     var0.setSeed(26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-836758079));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 928597107798688276L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test375"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     int[] var16 = var0.nextPermutation(564, 51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c32"+ "'", var10.equals("c32"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.035741624018879675d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test376"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(6.243664374135753E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.243664374135753E-4d);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test377"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeedSecure(0L);
//     double var16 = var0.nextBeta(1.841302061763438d, 0.13756245024239486d);
//     var0.reSeed();
//     double var20 = var0.nextWeibull(7.321941349665098d, 3.659423199395708d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.22864380139783771d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5fa"+ "'", var4.equals("5fa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.07335759135339205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.6539404600571004d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9988486709362354d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3.925122309471531d);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     double var19 = var0.nextGamma(8.653297910537354d, 0.14105942329814983d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("718", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "a51"+ "'", var10.equals("a51"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.08893040339933676d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.011934646693864043d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.0618208393716624d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test379"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.5418954798164249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1504536571010027d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test380"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.19986763567428228d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5846745072923851d));

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "116"+ "'", var10.equals("116"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.02720844351114784d);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test382"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.799453453475944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test383"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.0914080102183936d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.981302894390247d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test384"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-1.3401769730181888E15d), 0.005514177742691754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0016939492570481364d);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test385"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getSupportUpperBound();
    double var15 = var5.probability((-686183305));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test386"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.14105942329814983d, 0.9606558445097196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14105942329814983d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test387"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.61864936f, 82.33428358078145d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6186494f);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test388"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
    int var12 = var2.nextBinomial(143, 0.8052334543333898d);
    var2.reSeedSecure(31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.00797810778992547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 125);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test389"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.5111573E23f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5111573E23f);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test390"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.873060404051843d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
//     var2.addSuppressed((java.lang.Throwable)var7);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var15 = var14.getSuppressed();
//     java.lang.Throwable[] var16 = var14.getSuppressed();
//     org.apache.commons.math3.exception.MathInternalError var17 = new org.apache.commons.math3.exception.MathInternalError(var10, (java.lang.Object[])var16);
//     org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var9, (java.lang.Object[])var16);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test391"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)9.999999f, var1, false);
    java.lang.Number var4 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 9.999999f+ "'", var4.equals(9.999999f));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     long var20 = var0.nextLong(1L, 577710999442321806L);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var24 = var0.nextSecureHexString((-127));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "3e9"+ "'", var10.equals("3e9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.26672428173391555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 663);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.3407807929942255E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 233677547695228063L);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test393"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextExponential(0.6820038473615311d);
//     int var7 = var0.nextSecureInt(107, 715);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8559813479180989d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.730706479598306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 316);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test394"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int var3 = var1.nextInt(2);
    org.apache.commons.math3.random.Well19937c var5 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var5);
    long var8 = var5.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var11 = new int[] { };
    var10.setSeed(var11);
    byte[] var13 = new byte[] { };
    var10.nextBytes(var13);
    var5.nextBytes(var13);
    var1.nextBytes(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test395"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    var1.setSeed(6);
    double var12 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.5488202871045419d));

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test396"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    var2.reSeed();
    org.apache.commons.math3.random.RandomGenerator var8 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     int var19 = var0.nextZipf(1, 1.3698102998742017d);
//     int var23 = var0.nextHypergeometric(732, 5, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.00934491515995183d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test398"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    int var10 = var2.nextInt(6, 563228325);
    long var12 = var2.nextPoisson(3.432600494654796d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var15 = var2.nextSecureLong(4L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 281614168);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3L);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test399"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeed();
//     long var9 = var2.nextPoisson(0.4593664907342236d);
//     var2.reSeed((-214947668324021772L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var2.nextChiSquare((-0.6759610448260509d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test400"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextExponential(0.6820038473615311d);
//     double var7 = var0.nextCauchy(0.0d, 51.52530840076039d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6081076194379873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.4218735308509082d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-60.599412618194435d));
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test401"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    java.lang.Object[] var7 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)100.0d, var7);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)100L, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test402"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test403"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(9.317898532933117E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test404"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.2676508E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test405"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test406"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0958786587821821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.3446718580183608d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test407"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.98157513f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test408"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.06934869829732719d, (java.lang.Number)1.1996792375614571d, (java.lang.Number)19L);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test409"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(5.429969493008637E8d, 0.6217097382835118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.429969493008637E8d);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test410"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var10 = var2.nextT(2.8822137015004015d);
//     int var13 = var2.nextSecureInt((-79134244), 1413078328);
//     double var16 = var2.nextCauchy(22.817429545355136d, 1.876784835166937d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.010779405087741d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 586023158);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 22.573250543034202d);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextSecureLong(3513799009476651814L, 1228372035613083129L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test412"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 1);
//     double var14 = var2.nextT(5.455868397056974d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var2.nextInt((-8), (-1023));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.23821830818640652d);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test413"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.8590209732404706d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.6937511036741402d);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test414"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    long var8 = var2.nextLong(9L, 11L);
    java.lang.String var10 = var2.nextHexString(3);
    double var13 = var2.nextBeta(3.9204617763473553d, 4.67271537421983E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var2.nextInt(438907248, 13906712);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "342"+ "'", var10.equals("342"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.9999999988451441d);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test415"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(86, 92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 92);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test416"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    long var9 = var2.nextPoisson(0.5516422987415587d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test417"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    org.apache.commons.math3.random.RandomGenerator var4 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test418"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    double var4 = var1.nextDouble();
    var1.clear();
    float var6 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401381795025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.3799914f);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test419"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.07490127724881365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07504166270867715d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test420"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int var3 = var1.nextInt(2);
    long var5 = var1.nextLong(3513799009476651814L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1978582553411825728L);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test421"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.19048333f, 2.0000002f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test422"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1753021164154851d);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.8592814963431623d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9689985644359164d);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test424"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(1.5430806348152437d, 1132524014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.570663941018278d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5185695106952425d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test426"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.009019054625249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.008978625856438481d);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     double var19 = var0.nextGaussian(0.14961208608543997d, 0.6208928579421888d);
//     int var22 = var0.nextInt(715, 281614168);
//     double var25 = var0.nextGamma(0.5515717085759244d, 0.2785634988453677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "76b"+ "'", var10.equals("76b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.06819651400854143d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 20.985342000102214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-0.49840378966686794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 239073915);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.40586085840040853d);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test428"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-597052871));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test429"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.39823927240827994d, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.6751447494035615d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test431"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    boolean var8 = var7.isSupportConnected();
    int var9 = var7.sample();
    double var11 = var7.upperCumulativeProbability((-1));
    double var12 = var7.getNumericalMean();
    int[] var14 = var7.sample(1);
    var1.setSeed(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     int var19 = var0.nextInt(4, 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var22 = var0.nextPermutation(0, 732);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "b93"+ "'", var10.equals("b93"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.060362958922223195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.781429294682202d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 8);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest3.test433"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.8639409256878998d, var2, false);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test434"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     long var18 = var0.nextPoisson(0.9030227212818156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.22403947026637783d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest3.test435"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var10 = var2.nextT(2.8822137015004015d);
//     int var13 = var2.nextSecureInt((-79134244), 1413078328);
//     java.lang.String var15 = var2.nextHexString(263621476);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.2791577991302968E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.14421285581974938d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1280977844);
// 
//   }

}
