
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var16 = var14.nextChiSquare(1.0d);
//     double var18 = var14.nextT(2.9748236757560673d);
//     long var20 = var14.nextPoisson(12.978452428686579d);
//     int[] var21 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var22, 6, 0, 1);
//     boolean var27 = var26.isSupportConnected();
//     int var28 = var26.sample();
//     int var29 = var26.getSampleSize();
//     double var31 = var26.upperCumulativeProbability(3);
//     int var32 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var26);
//     int var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("a0b", "12a");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.2747915119166824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a04"+ "'", var4.equals("a04"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3805280017012789d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.7520095153637616d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.008529511421813326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-0.9587212066296796d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 17L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    long var12 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-3415793725169262878L));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(4.616457832727979E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9707682629055043d);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.20951305448319416d, 0.00797810778992547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.20951305448319416d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextCauchy(3.1622776601683795d, 0.5207931322143664d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextZipf(524, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.4724687469699105d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.974823675756067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9948000358043659d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var12 = var6.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var14 = var6.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var10 = var6.probability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9933001668755689d);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.6891841496949834d, 0.2948629008405826d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6891841496949834d);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(1146122894, Double.NaN);
//       fail("Expected exception of type org.apache.commons.math3.exception.MathInternalError");
//     } catch (org.apache.commons.math3.exception.MathInternalError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.1189402727028496d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a88"+ "'", var4.equals("a88"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.4382037266346042d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(128657.01f, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(9.999999f, 128657.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.9815751f, 0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1023), 281614168, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.007632528566718829d, 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 25.70543202901362d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.04943097798541802d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2223307850600497d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.003787966974016121d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0037879760327523236d);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     long var18 = var0.nextSecureLong((-6069125204240848293L), 2419047238712938144L);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 563228325);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     var0.reSeedSecure();
//     double var10 = var0.nextT(1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.434412355162676E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "de8"+ "'", var4.equals("de8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5.934367433599625d);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.5148401f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(9.317898532933117E29d, 0.03923685462767229d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1641345547549355455L);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(1.1996792375614571d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 68.73655708174395d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(199, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 199);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var5 = var4.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var4.nextPascal(2, 4.09605742500227d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(5.28554289799445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.285542897994451d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.059279958251462046d, 1.4210804127942926d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.059279958251462046d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9223372036854775807L, (java.lang.Number)0.4829771442965295d, true);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT((-2.0703237889114567d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2230932846047955d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.37422162411448995d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1275177323955643657L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "3f529"+ "'", var11.equals("3f529"));
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.4210854715202004E-14d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.8140149187445599d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    int var13 = var5.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 6);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.9933001668755689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.999999f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(1.0319942553198942d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.4724687469699105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 16.092568818840984d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int var11 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     var2.reSeedSecure((-6069125204240848293L));
//     long var13 = var2.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var2.nextF((-1.1268915383987363d), 9.317898532933117E29d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-137.802414651168d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 13L);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.005514177742691755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005514233632027932d);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextBeta(0.0d, 5.395512929437507d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 17);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(45);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextGamma(2.9748236757560673d, (-0.4790107940873415d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "acbecdd6dffe406b9e0d6a6f74484a51410253d012775"+ "'", var10.equals("acbecdd6dffe406b9e0d6a6f74484a51410253d012775"));
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.09853607366262629d, 0.577427448394613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.26234589613270526d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.05036975957415425d, 5.395512929437507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05036975957415425d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.005514233632027932d, var2, (java.lang.Number)2419047238712938144L);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    double var4 = var1.nextDouble();
    int var5 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401381795025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1632050914);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(2.6645883331377274d, 4.1260084413717255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.4614201082339981d));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.1916061660198558d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.292365047749425d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Throwable[] var3 = var2.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var4 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.7538036993385602d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.161454653402884d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.5574599702686449d, (java.lang.Number)6.651369377311933E13d, false);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    int var9 = var2.nextZipf(45, 0.8201071802366467d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(5646616835816284903L, (-1572004544900232135L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, 45, 281614168, 1146122894);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(5, (-1), 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-343034188110465231L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 343034188110465231L);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)100);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    int var4 = var1.nextInt(10);
    boolean var5 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.07180988227597636d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06934869829732719d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.9333761944765003d, 0.00797810778992547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.24169447797085E-5d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.4006531419542196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2239675137479333d);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1572004544900232135L), (-4740792029645458057L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-4740792029645458057L));

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.00752126284215363d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.000028284830708d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "48a2462bdb2a5ac7bb104c0334291850629ec7e1ea2c3"+ "'", var4.equals("48a2462bdb2a5ac7bb104c0334291850629ec7e1ea2c3"));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getSupportUpperBound();
    boolean var14 = var5.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var5.inverseCumulativeProbability(1.7088179325293313d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(18.392781021818884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9649008845409517d);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     var0.reSeed();
//     double var18 = var0.nextGamma(0.1306629546226212d, 0.7216599837973326d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var20 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5084736724395932424L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 3.9997407722229177E-10d);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    double var14 = var5.cumulativeProbability(563228325);
    double var16 = var5.cumulativeProbability(147);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(50.23276478699215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.609715589221844d);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.745789665287738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.2526046981442637d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.3871986638222313E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(18.085416045348254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7219777580805842d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.1306629546226212d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.12992440337056316d);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-11.0d), 25.99999999999489d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-10.999999999999998d));

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalMean();
    double var8 = var5.upperCumulativeProbability(715);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    int var16 = var2.nextInt(17, 2147483647);
    double var19 = var2.nextGaussian(0.29486290084058253d, 12.742325413815996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1146122894);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.009019054625249d);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.4829771442965295d, (java.lang.Number)5.934367433599625d, true);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)128657.01f, (java.lang.Number)(-1433502403876603448L), false);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    long var11 = var2.nextLong(0L, 26L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextCauchy(0.39823927240827994d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 12L);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(18.085416045348254d, 6.243664374135753E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.243664374135753E-4d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    double var8 = var5.probability((-2083745733));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextDouble();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5148401381795025d);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextWeibull(1.8639409256878998d, (-1.0333020151941645d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11450665726891565d);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    var2.reSeed();
    var2.reSeed(4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-1L), 26L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1L));

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     double var17 = var12.upperCumulativeProbability(3);
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextBinomial((-6), 0.3916905744695509d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.011583513155281215d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.0599699782526044d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0017299837809377156d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    int var10 = var2.nextInt(6, 563228325);
    double var13 = var2.nextBeta(0.24542394462207118d, 2.161909012740015d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var16 = var2.nextLong(16L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 281614168);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05547762620443311d);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     java.lang.String var19 = var0.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var22 = var0.nextPermutation(45, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c97"+ "'", var10.equals("c97"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.7190085569632445d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "d646b6a4821e54f3f3ed6e11b93c22713d2c599349d15f4b2777a4e6ded24210b8c1df7095f51a33bad2876a1ad4d39789f7"+ "'", var19.equals("d646b6a4821e54f3f3ed6e11b93c22713d2c599349d15f4b2777a4e6ded24210b8c1df7095f51a33bad2876a1ad4d39789f7"));
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var5.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(5.764512407651128E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.698200250254447d));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-0.0010733045953172857d), (java.lang.Number)0.007632528566718829d, false);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.0000000000000004d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.000000000000001d);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     var0.reSeed();
//     var0.reSeedSecure((-214947668324021772L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9594552990421228d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "512"+ "'", var4.equals("512"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(1.370316637323428E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.1268915383987363d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1268915383987361d));

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6075784142978823d));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    var1.setSeed(2L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.05547762620443311d, 0.9933001668755689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9948482238634754d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(524, (-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 524);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.2676506E30f, (java.lang.Number)0.001426069753303551d, true);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(15L, 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 15L);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(11L);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextInt((-1), 5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 7.235074216892208E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.8058364697442126d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.944161429707643d));

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.2029965220937808d, (java.lang.Number)0.4681888166880769d, false);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.2676506E30f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2676506E30f);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     double var17 = var12.upperCumulativeProbability(3);
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var12.inverseCumulativeProbability(1.031818944398912d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5623852477620356d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.8713244244826284d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.4382037266346042d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.960465E-8f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    double var11 = var6.upperCumulativeProbability(1);
    int var12 = var6.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("2d6", "f20");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.19209600733337137d, (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 27.09962763741051d);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.8453830087804857d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0456976837475302d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var17.probability(1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "ede"+ "'", var10.equals("ede"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.0d);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)Double.NaN);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    var1.setSeed(0L);
    float var9 = var1.nextFloat();
    double var10 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.972385400411732d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     long var12 = var2.nextLong((-7034676902218012687L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextF(0.0d, 11.505629813076833d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.05806445834883205d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-6251505802435943278L));
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     double var19 = var0.nextGaussian(0.14961208608543997d, 0.6208928579421888d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextPascal(0, 0.6247958739991177d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "867"+ "'", var10.equals("867"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.04712370461613757d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0740584466217368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.0355424101767028d));
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    boolean var10 = var6.isSupportConnected();
    int var11 = var6.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 6);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.19209600733337137d, 29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0313075864862578E8d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.03167492013216357d, 0.6247958739991177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.050653064495188416d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.047791141802258E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000000054893314d);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.2229124214424774d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(45);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextCauchy((-0.9393471627043656d), (-0.12916527366424163d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "b91785dd6907c5f9303756bdd819de1734257d50b70ab"+ "'", var10.equals("b91785dd6907c5f9303756bdd819de1734257d50b70ab"));
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }


    float var2 = org.apache.commons.math3.util.FastMath.max((-1.0f), 0.74324155f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var2 = var0.nextChiSquare((-113.92302816326081d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    double var9 = var2.nextUniform((-0.9262160379374064d), 2.9748236757560673d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var2.nextSecureHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0821957873042685d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.20951305448319416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.20650036564733387d);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     double var20 = var0.nextWeibull(2.974823675756067d, 0.6891841496949834d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var23 = var0.nextPermutation((-2), 563228325);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "49a"+ "'", var10.equals("49a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.08144720544966494d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 636);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3407807929942128E154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.7768812641845435d);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.298292365610485d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     int var14 = var2.nextInt((-2083745733), 107);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1267720276));
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var10 = var6.cumulativeProbability(500);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("c66", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 43);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.1181413835030423d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9714897973416567d);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)281614168, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + Double.NEGATIVE_INFINITY+ "'", var4.equals(Double.NEGATIVE_INFINITY));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0465229407002035d);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)4L, (java.lang.Number)2.302228544983558E-5d, true);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.8639409256878998d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3652622186554126d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.5455044084900889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextInt(500, 3);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.665429362717771d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(3, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextDouble();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1753021164154851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.8605623f);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.1268915383987361d), (java.lang.Number)0.006405110490684677d, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.006405110490684677d+ "'", var5.equals(0.006405110490684677d));

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var0.nextInversionDeviate(var13);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong(31L, 7009605301686414442L);
//     double var18 = var0.nextUniform(2.6645883331377274d, 123.86826212129738d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.21965079674790544d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.019662360115310532d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.22007267450553075d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 7423.205266225695d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 995670436341972829L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 51.52530840076039d);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, false);
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var3);
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (1)"));

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     double var6 = var0.nextExponential(Double.POSITIVE_INFINITY);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial((-494780561), 5.6164742204878395E28d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.303191641308306E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.5462798737319413d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var0, 107, 270, 897);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, (-0.22007267450553075d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)3.951613336081869d, (java.lang.Number)715, (java.lang.Number)1.0319942553198942d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(3.993369341651611E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    double var5 = var1.nextGaussian();
    int var6 = var1.nextInt();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 563228325);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal((-127), 1.4382037266346042d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.2255935272226104d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5d5"+ "'", var4.equals("5d5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var0.nextBinomial(147, 2.9748236757560673d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "a7a"+ "'", var10.equals("a7a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.29972310194415935d);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int var3 = var0.nextSecureInt(0, 270);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 207);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-0.0010733045953172857d), (-6));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.5412698750025651E17d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.004920541968978763d, 2.027583163938867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0910494117743932E-5d);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     java.lang.String var19 = var0.nextHexString(100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d10"+ "'", var10.equals("d10"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.031571377805249344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "219efedc12ea82f36c4274d8a4c3493b32369bdc7ab7d49f5a1ea23082208f339040299ab3c726752096d6abd59311874148"+ "'", var19.equals("219efedc12ea82f36c4274d8a4c3493b32369bdc7ab7d49f5a1ea23082208f339040299ab3c726752096d6abd59311874148"));
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.RealDistribution var8 = null;
//     double var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    java.lang.Object[] var5 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var3, (java.lang.Number)100.0d, var5);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.7432415f, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1.2239675137479333d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var1, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    int var8 = var7.getNumberOfSuccesses();
    int[] var10 = var7.sample(100);
    var1.setSeed(var10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var15 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 17, 3, 3);
    int var16 = var15.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 17);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var18 = var0.nextF(119.87204169238177d, 0.0017299837809377156d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "fd6"+ "'", var10.equals("fd6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.26316126951012736d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 840);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.4675804129174533E11d);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1.1268915383987361d), (java.lang.Number)0.006405110490684677d, true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.NotPositiveException var8 = new org.apache.commons.math3.exception.NotPositiveException(var6, (java.lang.Number)5.873060404051843d);
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var9, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
//     var8.addSuppressed((java.lang.Throwable)var13);
//     java.lang.Throwable[] var15 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var15);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextSecureInt(0, (-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, (-213915053556550245L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent((-650.5734518382083d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.2029965220937808d, 1.4210854715202004E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2029965220937808d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.70543202901362d);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextExponential(0.6820038473615311d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c4ea07f27632d20502d1defb23", "629ec7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.702060615593958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.20859365255611528d);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2((-0.9393471627043656d), 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.05891448395899795d));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-2.0703237889114567d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.026767216961736d);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("98e", "3bc");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.010321824206543246d);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     java.util.Collection var22 = null;
//     java.lang.Object[] var24 = var0.nextSample(var22, 0);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextBeta(4.020494098909096E28d, (-11.7204516580769d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.74324155f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    int var9 = var2.nextZipf(45, 0.8201071802366467d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "9de");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.028491120899159596d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "39d"+ "'", var4.equals("39d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.5495612062864376E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.72806567749441d);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var2 = new int[] { };
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var3, 6, 0, 1);
    int var8 = var7.getNumberOfSuccesses();
    int[] var10 = var7.sample(100);
    var1.setSeed(var10);
    org.apache.commons.math3.distribution.HypergeometricDistribution var15 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 17, 3, 3);
    int var16 = var15.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.567529488879971d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 130.89136659412873d);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial((-79134244), 0.6891841496949834d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0719767257575745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f350a8c8d11e27be9f2ad22b879006f99f6629655a5ec97a52d3c65f04e7f8130fb3d5513a7ae90a0421e640964a3c9065bc3a52088e18afc2649d4a4d434e8ddfdc47d02bf23a91532a5b30f744c6612a61d8771ce9606f9d794a78e4733cb7c8914418f6c68729110e5a40eb2cbae736b9fb3e5af45616a7da117b62a1980b8195b6ab4aceabf53124cc54ae839b7baaea80e824c398f7d3cff36439e92ce08581b40d17860f165b8e4e93ee78b847b98bd677eccef802ef7f23da522750d539621d6f0e6c7c089d6b06c9dbdfdcf9de56e66fff58a18f2e2b79a1902ee63c969b14e52d66962decc21f6d4dd50b4d8f1e609c0bc9ffcc595e742d28eb8e98108f4862db4314ce2632b2c95637e5ea1f5b9cad0a1f3a20ff462977aba377be5fa6eb12cb027d8b1332175316d32a904e9375ceb8d301173805ec150fb8e6ad3f0907d5210a9d11d4af6b592a6d64b823ec5498dee21cd502f9aeb63b60e9cd67fe800d19e862fa6df529edfb8aec90c6b07f1ee5da9ee552a88c9a27172dbdae172319915fa5937537b3b3d0a7b1331a96af8ccd0b26218dc60369f203ff0a02691355d85f39a3f31fa4e3ec89b9f717bcd90532ab8080e3f901ae248f146f8fd5fe971872e9737ee4492fc052ddd4595513fbae3f6def4bcb9a0fff7eebc91068c84934c1700622c79db0281415f4990f6d7390c7744c17d5cc86615cab73"+ "'", var4.equals("f350a8c8d11e27be9f2ad22b879006f99f6629655a5ec97a52d3c65f04e7f8130fb3d5513a7ae90a0421e640964a3c9065bc3a52088e18afc2649d4a4d434e8ddfdc47d02bf23a91532a5b30f744c6612a61d8771ce9606f9d794a78e4733cb7c8914418f6c68729110e5a40eb2cbae736b9fb3e5af45616a7da117b62a1980b8195b6ab4aceabf53124cc54ae839b7baaea80e824c398f7d3cff36439e92ce08581b40d17860f165b8e4e93ee78b847b98bd677eccef802ef7f23da522750d539621d6f0e6c7c089d6b06c9dbdfdcf9de56e66fff58a18f2e2b79a1902ee63c969b14e52d66962decc21f6d4dd50b4d8f1e609c0bc9ffcc595e742d28eb8e98108f4862db4314ce2632b2c95637e5ea1f5b9cad0a1f3a20ff462977aba377be5fa6eb12cb027d8b1332175316d32a904e9375ceb8d301173805ec150fb8e6ad3f0907d5210a9d11d4af6b592a6d64b823ec5498dee21cd502f9aeb63b60e9cd67fe800d19e862fa6df529edfb8aec90c6b07f1ee5da9ee552a88c9a27172dbdae172319915fa5937537b3b3d0a7b1331a96af8ccd0b26218dc60369f203ff0a02691355d85f39a3f31fa4e3ec89b9f717bcd90532ab8080e3f901ae248f146f8fd5fe971872e9737ee4492fc052ddd4595513fbae3f6def4bcb9a0fff7eebc91068c84934c1700622c79db0281415f4990f6d7390c7744c17d5cc86615cab73"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "8432e1"+ "'", var6.equals("8432e1"));
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.7941925865739156d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.017745364083061d));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    boolean var6 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var2, (java.lang.Number)1L, false);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var5);
    var1.addSuppressed((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(5.285542897994451d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7230896019545159d);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-145779445778080084L), 2419047238712938144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2419047238712938144L);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.5111573E23f, 2.008674318963529d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5111572E23f);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.26234589613270526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.640164261330767d);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.047791141802258E-4d);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh((-117.58082258639261d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3bc", "21b");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d51"+ "'", var10.equals("d51"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6479613416444623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 972);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextChiSquare((-0.9262160379374064d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "6b8"+ "'", var10.equals("6b8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var10 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    long var7 = var1.nextLong();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 1632050914, 2147483647, 2147483647);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2548228850011803885L);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-113.92302816326081d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6527.308703104859d));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.05036975957415425d, (-5.21416038369738d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05036975957415425d);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(2.000000000000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9092974268256814d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    long var14 = var2.nextLong(9L, 31L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 26L);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int var11 = var5.sample();
    double var12 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)0);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)3L);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     java.lang.String var7 = var5.toString();
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.417866337976411d);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-0.7835436474897771d), 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    java.lang.Number var7 = var6.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     int var9 = var2.nextPascal(6, 1.4210854715202004E-14d);
//     long var12 = var2.nextLong((-7034676902218012687L), 26L);
//     double var14 = var2.nextExponential(0.14961208608543997d);
//     var2.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-584986072174970266L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.12429879709104297d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210855E-14f);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.24542394462207118d);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    double var16 = var2.nextUniform(1.7538036993385602d, 2.3283872144743825d, true);
    var2.reSeed((-1433502403876603448L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.008674318963529d);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     double var17 = var12.upperCumulativeProbability(3);
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     double var19 = var12.getNumericalMean();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6779239362577469d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.1831717298115714d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeed();
//     long var9 = var2.nextPoisson(0.4593664907342236d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var2.nextHypergeometric(1024, 281614168, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     double var20 = var0.nextWeibull(2.974823675756067d, 0.6891841496949834d);
//     double var22 = var0.nextT(0.23194910076661474d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "e82"+ "'", var10.equals("e82"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.792126722906372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 213);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3407807929942597E154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.6449378492082781d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.4910577556659521d));
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong(31L, 7009605301686414442L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextBeta(0.0d, Double.POSITIVE_INFINITY);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.15266613782263172d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.6317794429944932d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.5054053156185794d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6031657149872769d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1039066757713619706L);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.1116073535960684d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.035898339779694d);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.5111573E23f, 1.1920929E-7f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5111573E23f);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.28813506261264255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.041798895676483d);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     java.lang.String var14 = var0.nextSecureHexString(147);
//     double var17 = var0.nextF(1.6504069890375178E-5d, 2.4652771117010555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "b63"+ "'", var10.equals("b63"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.1708623445839765d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "dff4cf0fadc50ad9c821a1b006215e1986c9d747143ce27a15fdbdcaa8038916c4994bf0cfe09807a0b0cd62c71452fd3af900469dc62e3ca99380bd604e95c46d486ca55fd8312d1bb"+ "'", var14.equals("dff4cf0fadc50ad9c821a1b006215e1986c9d747143ce27a15fdbdcaa8038916c4994bf0cfe09807a0b0cd62c71452fd3af900469dc62e3ca99380bd604e95c46d486ca55fd8312d1bb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3542161596574423E-9d);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     int[] var17 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var22 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 6, 0, 1);
//     boolean var23 = var22.isSupportConnected();
//     int var24 = var22.sample();
//     int var25 = var22.getSampleSize();
//     int var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var22);
//     int var27 = var22.sample();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.4187781918456641d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "89c"+ "'", var4.equals("89c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.6251584714114255E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0219596934646156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0333020151941645d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0333020151941643d));

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.0000000054893314d, (-2083745733));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 29, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    java.lang.Number var7 = var4.getMax();
    boolean var8 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (byte)10+ "'", var7.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.4210855E-14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(19L);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(4.09605742500227d, 1.000028284830708d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.09605742500227d);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p((-0.6686436237479013d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.1045608173793948d));

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    double var16 = var2.nextUniform(1.7538036993385602d, 2.3283872144743825d, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = var2.nextPascal((-188551922), 1.3652622186554126d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.008674318963529d);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var7 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2419047238712938144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-745794403086227031L));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.6449378492082781d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7009419562497021d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     int var10 = var0.nextBinomial(147, 2.0910494117743932E-5d);
//     double var13 = var0.nextUniform(0.3616878291415171d, 0.5123778273012989d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextSecureLong(577710999442321806L, (-1572004544900232135L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6128083709584189d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "94d"+ "'", var4.equals("94d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.39109064293088563d);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(12.978452428686579d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.2579185699311153d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(50.23276478699215d, 6.651369377311792E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.23276478699215d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.1085112749294624d);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(17, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 17);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2083745733), 107);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 107);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(4.609715589221844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)128657.01f, var1, false);
    java.lang.Number var4 = var3.getMin();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 128,657.008 is smaller than, or equal to, the minimum (null)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 128,657.008 is smaller than, or equal to, the minimum (null)"));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    var2.reSeed((-6069125204240848293L));
    double var18 = var2.nextCauchy(8.826912868420822d, 0.6217097382835118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0363607041614546d);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.161454653402884d, 1.0294368809983006E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0294368809983006E-9d);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.7219777580805842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6253243595640073d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var8 = var2.nextSecureHexString((-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.7145762379908008d, 4.67271537421983E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707962614034783d);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.16780540535714117d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.16939840861717922d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.5517493820104129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8516088383845121d);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Number var6 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var11 = var10.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Object[])var11);
//     org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var11);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextExponential(0.5418954798163613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextUniform(0.6820038473615311d, 0.11045359570096497d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0883710367761742d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "59e"+ "'", var4.equals("59e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.4251898545393499d);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(9.317898532933117E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.338762598682091E31d);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-0.4790107940873415d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8874512834207764d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)6.5412698750025651E17d, (java.lang.Number)0.4829771442965295d, (java.lang.Number)4.936138296956352d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.4829771442965295d+ "'", var4.equals(0.4829771442965295d));

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 5, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)0);
//     java.lang.String var3 = var2.toString();
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.7432415f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.4910577556659521d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(1.7877593912976595d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-3759508027876256838L), (java.lang.Number)1.4210804127942926d, (java.lang.Number)2.6645883331377274d);
    java.lang.Number var5 = var4.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 2.6645883331377274d+ "'", var5.equals(2.6645883331377274d));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     var0.reSeedSecure(1L);
//     long var27 = var0.nextPoisson(0.006050121963214739d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2a5"+ "'", var10.equals("2a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.7517333227644281d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0L);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(5.960465E-8f, 0.8605623f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.960465E-8f);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.1951970479591294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(0.9040580270688509d, 1.4100249074148754d);
//     double var6 = var0.nextUniform(0.5142856083511866d, 4.765158102961618d);
//     java.lang.String var8 = var0.nextSecureHexString(1);
//     java.util.Collection var9 = null;
//     java.lang.Object[] var11 = var0.nextSample(var9, 107);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong((-1486998192385879714L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextInt(1, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9709318996110915d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.0659087509550917d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.8226107899683175d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-3141.9588618503435d));
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.9933001668755689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7001306665979763d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.004920541968978763d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.07014657489128577d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var2.nextPermutation(9, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(18.085416045348254d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1036.2180101366348d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0010733045953172857d), (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)3, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)6, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1433502403876603448L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1433502403876603448L);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     double var11 = var0.nextWeibull(1.4458039286025248d, 0.006050121963214739d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var0.nextPermutation((-127), 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0014986328447007162d);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var2.nextLong(577710999442321806L, (-343034188110465231L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     double var6 = var0.nextExponential(Double.POSITIVE_INFINITY);
//     double var9 = var0.nextGamma(0.7341229033056471d, 5.285542897994451d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.004422735551269067d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.2478975457833115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.341383316641235d);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    long var12 = var2.nextLong(3L, 10L);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6L);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     long var15 = var0.nextSecureLong(31L, 7009605301686414442L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextUniform(12.978452428686579d, 1.4382037266346042d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2666738035014131d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.20683719628951522d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-0.6462605420525868d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9933609.75523486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 4322318760491289010L);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(4.485849767689555d, 0.9092974268256814d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.06334950076970383d));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.5148401f, 1.4E-45f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     long var18 = var0.nextSecureLong((-6069125204240848293L), 2419047238712938144L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextHypergeometric(281614168, (-494780561), 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.934422993361722d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "750"+ "'", var4.equals("750"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.3929337690484958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4200900832942507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-4897216618139242984L));
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)100, (java.lang.Number)0.9815751f);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { 1.841302061763438d};
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.6208928579421887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(68.73655708174395d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-11.35464876064149d));
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.7531426648781896d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9098275504956358d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-127), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-127));

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(3.659423199395708d, 4.9E-324d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5232272417797005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5ec6e0583b474bb0e31ad89d1a7b696c288884cf21f2182e67af460b5de233533174655816ca85e61333d1ab0df21529a1053c763b4d4dbff1f63725652e4d1103b8f3e652aaa5ce17cc4c34381f0349fac05cb61be556c23157e9d9a754eb8ba7de0185ea776fff6d3a58f927ed561fdc79857d2cbf1aafac68f3bf9e5e1960fb394a55661b1ebb852ed73f4e845b3ced93254b68543e3121564f793271a3f861b07e6213755490e57ce03ddf64f695cd55ed619db1d104703dbd73214407c3fbbb8135c40e666d5123f1eed616ae21a448da98154502baecae520e867afee44267fe6025ff895d336fb3aa48edf256172ae57c59f6303580b20002ed11e3f5ec253f53ff7385717e05d46ef31ed264686eed395ac058c5096d40331a6abc9eb092d2dc261d3d0e5572e33da6884b8255e442a12a7004818bf231c2e10a86a82c3d46ae02d1c21da530aecb14e993bb18337d854008468045cd49433162288c9112beacdf3118ac784633a7059eb6e693837abea9d83f9599463a8633d188719d86d4da6553011eaa62cb80fdd68c2f3fba028fc48906fbce142077c838238309bed4aa336bde430f0d12020cf86bfa6ec79dd27c29ac6449c5fdf72059696b89ff7f9da9e01293210db4512a14449a1a8bc19a3cb1f4fb18a8a673e33f737b8817572bd77d29a4da249cc4883747184476f73bdc416757b7dd90d34f6c0e02"+ "'", var4.equals("5ec6e0583b474bb0e31ad89d1a7b696c288884cf21f2182e67af460b5de233533174655816ca85e61333d1ab0df21529a1053c763b4d4dbff1f63725652e4d1103b8f3e652aaa5ce17cc4c34381f0349fac05cb61be556c23157e9d9a754eb8ba7de0185ea776fff6d3a58f927ed561fdc79857d2cbf1aafac68f3bf9e5e1960fb394a55661b1ebb852ed73f4e845b3ced93254b68543e3121564f793271a3f861b07e6213755490e57ce03ddf64f695cd55ed619db1d104703dbd73214407c3fbbb8135c40e666d5123f1eed616ae21a448da98154502baecae520e867afee44267fe6025ff895d336fb3aa48edf256172ae57c59f6303580b20002ed11e3f5ec253f53ff7385717e05d46ef31ed264686eed395ac058c5096d40331a6abc9eb092d2dc261d3d0e5572e33da6884b8255e442a12a7004818bf231c2e10a86a82c3d46ae02d1c21da530aecb14e993bb18337d854008468045cd49433162288c9112beacdf3118ac784633a7059eb6e693837abea9d83f9599463a8633d188719d86d4da6553011eaa62cb80fdd68c2f3fba028fc48906fbce142077c838238309bed4aa336bde430f0d12020cf86bfa6ec79dd27c29ac6449c5fdf72059696b89ff7f9da9e01293210db4512a14449a1a8bc19a3cb1f4fb18a8a673e33f737b8817572bd77d29a4da249cc4883747184476f73bdc416757b7dd90d34f6c0e02"));
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-1413078328));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1413078328);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
//     java.lang.Number var5 = var4.getMax();
//     java.lang.Number var6 = var4.getMax();
//     java.lang.String var7 = var4.toString();
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.3407807929942155E154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.5209450637949877d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18211352771403055d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-1.0644436491518945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9262160379374065d));

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.161909012740015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5137842659022371d);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     java.lang.String var13 = var0.nextHexString(2);
//     long var15 = var0.nextPoisson(1.4210804127942926d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "01"+ "'", var13.equals("01"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var0.nextInversionDeviate(var12);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1024, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var16 = var0.nextT(0.26234589613270526d);
//     double var19 = var0.nextGamma(1.0456976837475302d, 0.8592814963431623d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c2d"+ "'", var10.equals("c2d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.04762305207136196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.3385634111155174d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1.799453453475944d);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.7700247882582713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9697164247009268d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var4, (java.lang.Number)0.0f);
    java.lang.Number var7 = var6.getLo();
    java.lang.Number var8 = var6.getLo();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var10, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)17, (java.lang.Object[])var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.26234589613270526d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.5811257250652634d));

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)1};
    var1.nextBytes(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var9.nextPermutation((-79134244), 246);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.004422735551269067d, 18.392781021818884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.004422735551269067d);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)29, (java.lang.Number)3.942186149242891d, false);
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Object[])var9);
    java.lang.Number var11 = var10.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    var3.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4997320104385629d, (java.lang.Number)0.8394859904584389d, (java.lang.Number)(-6.010754535962853d));
    var10.addSuppressed((java.lang.Throwable)var17);
    java.lang.Number var20 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var22 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)128657.01f, var20, false);
    var17.addSuppressed((java.lang.Throwable)var22);
    java.lang.Number var24 = var17.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-6.010754535962853d)+ "'", var24.equals((-6.010754535962853d)));

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     double var12 = var2.nextCauchy(0.11045359570096497d, 3.2579185699311153d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.208890769709859E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4.334648690068764d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.0d, (java.lang.Number)0.24586382473244683d, false);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.3782367207154096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     long var9 = var2.nextSecureLong((-2349309494509100384L), 2L);
//     int var12 = var2.nextSecureInt(199, 1665346298);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1653127820370205960L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 532989891);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     java.lang.String var10 = var2.nextSecureHexString(17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "61f20674b67d63b72"+ "'", var10.equals("61f20674b67d63b72"));
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.2223307850600497d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     long var8 = var0.nextPoisson(0.005514177742691754d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma(0.0d, 0.7069172585519206d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.120410329129518d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7067457b19b684cb7a5559b8e8ad88a382048d1ae2ce6573d6b538550cf8813f1558b78c84cb22af3b9f6939c9b6a78727b43a6986fa45c0aa2e644a3d8147382723d682897c54dc8fcb5ad6053d3a2e889a682e9cce0c435ac052da5ca0deddff0dde6543f23c6f40ecc58731a7dc16924f6f933f8aa289b4e6c134b8f8aef01bdaf04ef264bebe8a5dc658ffc9507ea68026514395d30853ec4d472813b7a73cb012fe66ee55434e72e2e3dbe7712dc53e0026b413e003ddfd42cefe001f4576937155f808714fccf899c5f8e2b09a0fc63ac413ed17b7cf6b67a3d0299bfa9100e3c9261152d0a62b224753f4d5eadf3dc0b3bf97b61c991921e0ff5485c4299668128568b13c6822be46900bf9f11ce93043fca0a75746074ee7e183526c7c47f9b599d2077b6a621cc7e958f9f2d44fccb2540c4c03d77e359ec4977b16c4f507b6be170fa6403cd35a73c70c38e7162567c395ca6f343ba625d1de31290c0446caa2dcd7ecd98719987400ade37ec44a624ac7dd2c4f0160015e75de27323e1394962c0464d1e8e7facd1f763b8cc270fd1be01271ae5bae253920bdb7da8eb1e8035c6c3d150aeaf9293d12fb8973f884486075250cce007a466c3a5094f69efce4330d9f18cbb146fe2c56aee369c432c9076b3ee457d0e268d867f535eefefb83c6b96ffe8440992ba390ccc04c524f9c4fbba82edda875362d2829"+ "'", var4.equals("7067457b19b684cb7a5559b8e8ad88a382048d1ae2ce6573d6b538550cf8813f1558b78c84cb22af3b9f6939c9b6a78727b43a6986fa45c0aa2e644a3d8147382723d682897c54dc8fcb5ad6053d3a2e889a682e9cce0c435ac052da5ca0deddff0dde6543f23c6f40ecc58731a7dc16924f6f933f8aa289b4e6c134b8f8aef01bdaf04ef264bebe8a5dc658ffc9507ea68026514395d30853ec4d472813b7a73cb012fe66ee55434e72e2e3dbe7712dc53e0026b413e003ddfd42cefe001f4576937155f808714fccf899c5f8e2b09a0fc63ac413ed17b7cf6b67a3d0299bfa9100e3c9261152d0a62b224753f4d5eadf3dc0b3bf97b61c991921e0ff5485c4299668128568b13c6822be46900bf9f11ce93043fca0a75746074ee7e183526c7c47f9b599d2077b6a621cc7e958f9f2d44fccb2540c4c03d77e359ec4977b16c4f507b6be170fa6403cd35a73c70c38e7162567c395ca6f343ba625d1de31290c0446caa2dcd7ecd98719987400ade37ec44a624ac7dd2c4f0160015e75de27323e1394962c0464d1e8e7facd1f763b8cc270fd1be01271ae5bae253920bdb7da8eb1e8035c6c3d150aeaf9293d12fb8973f884486075250cce007a466c3a5094f69efce4330d9f18cbb146fe2c56aee369c432c9076b3ee457d0e268d867f535eefefb83c6b96ffe8440992ba390ccc04c524f9c4fbba82edda875362d2829"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c16325"+ "'", var6.equals("c16325"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.6779239362577469d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8052334543333898d);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var13 = var6.inverseCumulativeProbability(0.5403023058681398d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var6.cumulativeProbability(897, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.31174213159242253d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)18.392781021818884d, (java.lang.Number)(-1L), true);
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var1, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var3.getContext();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    long var12 = var2.nextLong(3L, 10L);
    long var14 = var2.nextPoisson(8.653297910537354d);
    double var17 = var2.nextF(0.9606558445097196d, 3.993369341651611E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5.722713467366433E11d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    int var10 = var2.nextInt(6, 563228325);
    int[] var13 = var2.nextPermutation(1024, 886);
    org.apache.commons.math3.random.Well19937c var14 = new org.apache.commons.math3.random.Well19937c(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 281614168);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(26L, 16L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(45);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(4.334648690068764d, 0.5349547626632668d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "797f436dd861d5b2c3ed6e808766c0a8c542d3bfab29d"+ "'", var10.equals("797f436dd861d5b2c3ed6e808766c0a8c542d3bfab29d"));
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 1.3844286356444537d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.14105942329814983d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.37557878440901027d);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var18 = var0.nextF(119.87204169238177d, 0.0017299837809377156d);
//     double var21 = var0.nextF(5.721627121435389E-7d, 1.4675804129174384E11d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c78", "386");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "253"+ "'", var10.equals("253"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.017484183570694d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 628);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.4675804129174084E11d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0.0d);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalStateException var2 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var1);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.8822137015004015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8822137015004015d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    var7.addSuppressed((java.lang.Throwable)var11);
    org.apache.commons.math3.exception.MathInternalError var13 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    var5.reseedRandomGenerator(3L);
    int var14 = var5.sample();
    int var15 = var5.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var2.nextLong(0L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.7219777580805842d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     long var3 = var0.nextSecureLong((-6069125204240848293L), 5646616835816284903L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1961224671979052586L);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(2.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0f);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)29, (java.lang.Number)3.942186149242891d, false);
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Object[])var9);
    java.lang.Number var11 = var10.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var12 = var10.getContext();
    var3.addSuppressed((java.lang.Throwable)var10);
    org.apache.commons.math3.exception.OutOfRangeException var17 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4997320104385629d, (java.lang.Number)0.8394859904584389d, (java.lang.Number)(-6.010754535962853d));
    var10.addSuppressed((java.lang.Throwable)var17);
    java.lang.Number var19 = var17.getHi();
    org.apache.commons.math3.exception.util.ExceptionContext var20 = var17.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-6.010754535962853d)+ "'", var19.equals((-6.010754535962853d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure();
//     double var6 = var2.nextCauchy(3.1622776601683795d, 0.5207931322143664d);
//     int var9 = var2.nextSecureInt((-79134244), 524);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var2.nextUniform(3.432600494654796d, 2.1831717298115714d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4724687469699105d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-50517936));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"+ "'", var1.equals("org.apache.commons.math3.exception.MathInternalError: illegal state: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.nextSecureHexString((-188551922));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalVariance();
    int var7 = var5.sample();
    double var8 = var5.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.07180988227597636d, (-0.3343452383657629d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(327709799, 39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 39);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    var2.reSeed((-6069125204240848293L));
    var2.reSeedSecure();
    int var9 = var2.nextInt((-6), 524);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 503);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.006493101352562512d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var11 = var2.nextGaussian(0.0d, 14.975162885657241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextCauchy(0.012829087820977834d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4083318863451865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 26.878838156126896d);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.00752126284215363d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-8));

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    java.lang.Number var7 = var6.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var14);
    var6.addSuppressed((java.lang.Throwable)var15);
    org.apache.commons.math3.exception.NotPositiveException var18 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-1.4614201082339981d));
    var6.addSuppressed((java.lang.Throwable)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     int var9 = var0.nextSecureInt((-2), 0);
//     long var12 = var0.nextLong(4L, 6L);
//     double var15 = var0.nextGamma(3.141592653589793d, 0.13756245024239486d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3010672345889634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "b8691150fc268767205d341a176c74c24073c3d2d6c160dbb8fe03bd9ff45492c28d46f8f3818977a89d5263ef5a0e0c1a85333114e540529fbbe4b1d35a899f421e23070ee32a9d5f4eff1d461d0015af478dcaf724946658d37eb845ec050f36d9fdafc0550a50f3d135a58f7edd52437cdb84d55a1a3039b5cf014c4b8647b14266d1b496cbcf53c353d1199be272310c42d03111baf14172a26dfce8bb67bd611a47b39622e1d445d5348e02513187491362560f8bc45100ee5ba07466b24705f27c80ba2227d683823863acaeeb6bcad3eda963773735beaead99bb06b25e787cb23a3a898d300a6bcf1741381a357169c58fcb7d7b568f60ef6ca3c5b5abb3b71e284669e3a0648733ee5e3465f8d81a4406d55b0fa565700e71db75f3048653c6570ccd4a7cdb0ab2f67985cd78c5f1fdf86f3f4a9b5f1616a5d15043681d5f3f39383bb7c8ec1c91149ac51f5cd69d7ff10da449d77da22bb06ebdc38450c289e27cf4bc6499ba6447996f72b18f47b299323dad91ecd0268ba79e9dd8caf8ddbe2a7fe42a77f90b975ab66502cffaa2acc15aa1f20308d3b891893730d14f906aefa4e185d0b5fcea88ec29f9c06b70fc6fb5ceedfcaf0060fc22f7a5291823c97ca02f7663752941bf3b94e8f153ae25a13cb65ca2e881d482c09c56dd9abdd023193635e4cac3e7eb638fd091a886356da083728cabb4451cfb19"+ "'", var4.equals("b8691150fc268767205d341a176c74c24073c3d2d6c160dbb8fe03bd9ff45492c28d46f8f3818977a89d5263ef5a0e0c1a85333114e540529fbbe4b1d35a899f421e23070ee32a9d5f4eff1d461d0015af478dcaf724946658d37eb845ec050f36d9fdafc0550a50f3d135a58f7edd52437cdb84d55a1a3039b5cf014c4b8647b14266d1b496cbcf53c353d1199be272310c42d03111baf14172a26dfce8bb67bd611a47b39622e1d445d5348e02513187491362560f8bc45100ee5ba07466b24705f27c80ba2227d683823863acaeeb6bcad3eda963773735beaead99bb06b25e787cb23a3a898d300a6bcf1741381a357169c58fcb7d7b568f60ef6ca3c5b5abb3b71e284669e3a0648733ee5e3465f8d81a4406d55b0fa565700e71db75f3048653c6570ccd4a7cdb0ab2f67985cd78c5f1fdf86f3f4a9b5f1616a5d15043681d5f3f39383bb7c8ec1c91149ac51f5cd69d7ff10da449d77da22bb06ebdc38450c289e27cf4bc6499ba6447996f72b18f47b299323dad91ecd0268ba79e9dd8caf8ddbe2a7fe42a77f90b975ab66502cffaa2acc15aa1f20308d3b891893730d14f906aefa4e185d0b5fcea88ec29f9c06b70fc6fb5ceedfcaf0060fc22f7a5291823c97ca02f7663752941bf3b94e8f153ae25a13cb65ca2e881d482c09c56dd9abdd023193635e4cac3e7eb638fd091a886356da083728cabb4451cfb19"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9e923a"+ "'", var6.equals("9e923a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 6L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.3156495651539553d);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.709377217938145d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6169917137278239d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.03167492013216357d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.4992844715101683d));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-0.019662360115310532d), (-0.0010733045953172857d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.019662360115310532d));

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    float var2 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.27873123f);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.39434982251580614d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4161488505674885d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int var2 = var1.nextInt();
    var1.setSeed(9L);
    long var6 = var1.nextLong(19L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1413078328));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(5.298292365610485d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.2851550316794538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7383055209465659d);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextChiSquare(23.729908791521954d);
//     int[] var11 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var16 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var12, 6, 0, 1);
//     double var17 = var16.getNumericalMean();
//     double var19 = var16.upperCumulativeProbability(364);
//     int var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.477700611594034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "395"+ "'", var4.equals("395"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20.220676696579805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    double var8 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.07490127724881365d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.9031679812916723E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0000000000000422d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(2.1831717298115714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.157878099031699d);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(199, 1134509119);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 199);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextWeibull(0.0d, 0.10333323811005823d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2987799205122179d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "687"+ "'", var4.equals("687"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.10743554297149024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.6132618205715805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     var2.reSeedSecure((-6069125204240848293L));
//     long var13 = var2.nextPoisson(12.978452428686579d);
//     double var16 = var2.nextF(1.0313075864862578E8d, 1.665429362717771d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var2.nextHypergeometric((-51616135), 732, 563228325);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 32.75373291116756d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1.1072940486247236d);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var6.nextSecureInt(5, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2419047238712938144L);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.21965079674790544d, (java.lang.Number)4.765158102961618d);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-650.5734518382083d), 1.009019054625249d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-650.5734518382081d));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var9 = var6.nextLong(26L, 4137880971203176105L);
    double var12 = var6.nextCauchy(1.8453830087804857d, 0.012829087820977834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3831766526879059053L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.8167069219439684d);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var5 = var0.nextHexString((-16849120));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.037303290519056065d);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeedSecure();
//     long var9 = var2.nextSecureLong((-4740792029645458057L), 13L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var2.nextCauchy(0.8874512834207764d, (-1.0644436491518947d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1857285706696701459L));
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.2851550316794538d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1336467843554507d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6L, 8L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6L);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
//     java.lang.String var11 = var10.toString();
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0000002f);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)1};
    var1.nextBytes(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setSecureAlgorithm("96e", "f20");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.006405110490684677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5643911725079902d);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.nextHypergeometric((-494780561), 10, 503);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.27873123f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.27873126f);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(26L);
    int var12 = var5.getPopulationSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(0.5207931322143664d, (-11.720451658076898d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11.720451658076898d));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.1442539017638377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1447589466120501d);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var5 = var0.nextPermutation(1024, 503);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.013664005291732968d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-0.6321205588285577d));

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(1.73260320806421E-6d, 0.6253243595640073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.770727193912281E-6d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.031333458403791564d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.4100249074148754d, var1, false);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.944161429707643d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.99357828012885d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    long var6 = var1.nextLong(9L);
    org.apache.commons.math3.random.RandomDataImpl var7 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var9 = var7.nextPoisson(1.0313075864862578E8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 103130624L);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(26L);
    boolean var12 = var5.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     double var21 = var0.nextCauchy(0.012829087820977834d, 1.4382037266346042d);
//     org.apache.commons.math3.distribution.RealDistribution var22 = null;
//     double var23 = var0.nextInversionDeviate(var22);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.873060404051843d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
    var2.addSuppressed((java.lang.Throwable)var7);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.9518401855672245d, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-55258480997125034L));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextSecureLong(577710999442321806L, 4L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalMean();
    double var8 = var5.upperCumulativeProbability(364);
    double var9 = var5.getNumericalVariance();
    int var10 = var5.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    double var4 = var1.nextDouble();
    long var5 = var1.nextLong();
    long var6 = var1.nextLong();
    float var7 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5148401381795025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7009605301686414442L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-339878989410455899L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.61864936f);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var13 = var6.inverseCumulativeProbability(0.5403023058681398d);
    double var16 = var6.cumulativeProbability(2, 1024);
    double var18 = var6.upperCumulativeProbability(532989891);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextExponential(0.6820038473615311d);
//     double var7 = var0.nextCauchy(0.0d, 51.52530840076039d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextF(Double.NaN, (-1.7626381930754416d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.5472092778031326d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.016099346658229804d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == (-161.7873450756804d));
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeedSecure();
    var2.reSeed(5L);
    var2.reSeedSecure(5L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 1.841302061763438d};
    org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    var5.reseedRandomGenerator(3L);
    int var14 = var5.sample();
    int var15 = var5.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.5349547626632668d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.6253243595640073d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)3.993369341651611E-5d);
    boolean var2 = var1.getBoundIsAllowed();
    java.lang.Number var3 = var1.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 3.993369341651611E-5d+ "'", var3.equals(3.993369341651611E-5d));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 1.4210855E-14f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var4 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0010733045953172857d), (java.lang.Object[])var5);
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)(-0.99357828012885d), (java.lang.Object[])var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var11 = var2.nextGaussian(0.0d, 14.975162885657241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var14 = var2.nextPermutation(5, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0038215905261950473d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-15.836995874225964d));
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     java.lang.String var10 = var2.nextSecureHexString(26);
//     double var13 = var2.nextUniform(0.0d, 1.665429362717771d);
//     org.apache.commons.math3.random.RandomGenerator var14 = var2.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "30be1e98bcf7f18050103e9614"+ "'", var10.equals("30be1e98bcf7f18050103e9614"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.2203158490481973d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2147483647);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log((-1.0d), (-0.09653689510610847d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(0.0d, (-4.719910314140863d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.011073670326408271d);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int[] var8 = new int[] { (-1), 100};
    var1.setSeed(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(31.4104f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9073486E-6f);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.5111573E23f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-1267720276), 45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 45);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.5455044084900889d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7254785089177432d);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    long var8 = var2.nextLong(9L, 11L);
    java.lang.String var10 = var2.nextHexString(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextInt(100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "342"+ "'", var10.equals("342"));

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(1.157878099031699d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06366283943928104d);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    int[] var12 = var5.sample(3);
    double var14 = var5.upperCumulativeProbability(6);
    int var15 = var5.sample();
    int var16 = var5.getSampleSize();
    int var17 = var5.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.19048333f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.9604645E-8f);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    long var5 = var1.nextLong();
    boolean var6 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-339878989410455899L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var9 = var5.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.1442539017638377d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.1452629033943059d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
//     java.lang.Number var5 = var4.getMax();
//     boolean var6 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
//     java.lang.Number var8 = var4.getMax();
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.util.Localizable var10 = null;
//     java.lang.Object[] var12 = null;
//     org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var10, (java.lang.Number)100.0d, var12);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var9, (java.lang.Object[])var14);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(1.7906390950841864d, 0.6891841496949834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7906390950841862d);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)4.765158102961618d, (java.lang.Number)1.417866337976411d, (java.lang.Number)6.500004162645404E-4d);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(5.395512929437507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextBinomial(1, 0.031493100493387514d);
//     double var14 = var2.nextExponential(0.03408634154283945d);
//     double var16 = var2.nextExponential(66.89123388852185d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var2.nextHypergeometric(199, (-597052871), (-494780561));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3.4904133572695295E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.013127870188382924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 117.33855574109458d);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.4997320104385629d, (java.lang.Number)0.8394859904584389d, (java.lang.Number)(-6.010754535962853d));
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextBinomial(1, 0.031493100493387514d);
//     java.lang.String var14 = var2.nextSecureHexString(107);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var2.nextPascal((-2083745733), 0.7450520880645611d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9.475159071119835E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "085e3ecbe50958615fe0e4f476e6134cb563d10c36c9e816a5c5bfc2074a14a549482eb7be58190de93fda420d07b8fb586f0c2b842"+ "'", var14.equals("085e3ecbe50958615fe0e4f476e6134cb563d10c36c9e816a5c5bfc2074a14a549482eb7be58190de93fda420d07b8fb586f0c2b842"));
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(30.973188990298418d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.5111573E23f, 0.9815751f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9815751f);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10L);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    int var10 = var2.nextInt(6, 563228325);
    double var13 = var2.nextBeta(0.24542394462207118d, 2.161909012740015d);
    double var15 = var2.nextChiSquare(0.00752126284215363d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 281614168);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05547762620443311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var18 = var0.nextF(119.87204169238177d, 0.0017299837809377156d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextPascal(45, 6.46743983995431E28d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "638"+ "'", var10.equals("638"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.06667873205838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 849);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.467580412917416E11d);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)9223372036854775807L, (java.lang.Number)0.4829771442965295d, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextF(0.4681888166880769d, 1.9581294241070768d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.nextSecureInt(503, 102);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.936138296956352d);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     long var9 = var0.nextPoisson(0.577427448394613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.47348801367674015d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e1d"+ "'", var4.equals("e1d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextBinomial(1, 0.031493100493387514d);
//     java.lang.String var14 = var2.nextSecureHexString(107);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var2.nextSample(var15, 732);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.9933001668755689d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    long var14 = var2.nextLong(9L, 31L);
    var2.reSeedSecure(0L);
    var2.reSeedSecure((-2349309494509100384L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var21 = var2.nextBeta((-0.6751447494035615d), 0.1306629546226212d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 26L);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    boolean var8 = var1.nextBoolean();
    boolean var9 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, 1024);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, 0.5829516681541402d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.9E-324d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    double var5 = var1.nextGaussian();
    long var7 = var1.nextLong(104650724081867330L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 58365653636984266L);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.006493101352562512d, 0.19808294885646338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.6232857187980742d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }


    org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(886, 39, 147);
    double var5 = var3.cumulativeProbability((-6));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var12 = var6.getSupportLowerBound();
    double var13 = var6.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    double var9 = var2.nextUniform((-0.9262160379374064d), 2.9748236757560673d, false);
    double var12 = var2.nextF(0.8850169682561488d, 3.659423199395708d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var2.nextHypergeometric((-494780561), (-56171189), 732);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0821957873042685d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.24586382473244683d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.5123778273012989d, 0.6820038473615311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5723403566107892d);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.8605623f, 31.4104f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31.4104f);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextWeibull(30.973188990298414d, 18.58616942859271d);
    double var11 = var2.nextExponential(0.05547762620443311d);
    double var13 = var2.nextT(0.04943097798541802d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 18.392781021818884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0673006305030055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.1372214103398305E28d);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(524);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 524);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(7.713044735798083E-4d, 532989891);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    long var8 = var2.nextLong(9L, 11L);
    org.apache.commons.math3.random.RandomGenerator var9 = var2.getRandomGenerator();
    double var11 = var2.nextT(0.48426586993164683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.0914080102183936d);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 2419047238712938144L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2419047238712938144L);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, 352, 886);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow((-1.3813117226938723d), 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.9080220752515131d);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(1.0219596934646156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(5.395512929437507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6312190494145568d);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 5.960465E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    double var12 = var5.cumulativeProbability(1024);
    double var14 = var5.probability(281614168);
    int var15 = var5.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.16780540535714117d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5515717085759244d);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    long var12 = var2.nextLong(3L, 10L);
    double var14 = var2.nextChiSquare(34.09010925358515d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 6L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 25.70088361328929d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    var2.reSeed((-6069125204240848293L));
    int var8 = var2.nextBinomial(2, 6.211368153355547E-4d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextF(0.0d, (-5.214160383697379d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     int var19 = var0.nextInt(4, 9);
//     double var23 = var0.nextUniform(0.4984499233766489d, 0.7531426648781896d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "fc5"+ "'", var10.equals("fc5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.13453087765780822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.0311506179736343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0.5247304743765772d);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(1);
    int var3 = var1.nextInt(2);
    int var4 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1737377827));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    long var7 = var1.nextLong();
    double var8 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2548228850011803885L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.7635378011037546d);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     var2.reSeedSecure(4137880971203176105L);
//     java.lang.String var12 = var2.nextHexString(1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextCauchy(0.47348801367674015d, (-1.017745364083061d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "c9194ca7f5cb2db79ae7ad2e5c186ab1295567eb5d006f691a77a21dbc082cbc520b17dac3a9a25f6378cfb4c40ed6527ff5114f56a1ae91d168aa4fb5bd9245291dc63c00f04d9d4fe18cac8a68f4bf468cda5fc8cdc0a5194f82e7e5da66aa5e7864f2a60508ee5a759c203ec95437fd5567be89a9e29defca7c5f331c6a38ccf9bd07db4927bfd166d782c92909763b727ede3f845575b7d4127b345bb344d86d40643793594fd637796806b1c5493318dc28c111666c6fd343319c8641cb4235940e646f41146a09ec1d4958e036cbb5b9783dfee15b387f635d1746f46aa5e4312468f416e14c6b8da4393a05a3bfe49cf021e6d6e36ed9bfd3cad3013a607b613a49134edcf259cc28abe7d81b54a4a66d3d0fb3d1bef4d3a15caf3737c00c8fc0a7f6a54819627bf41316d5f9fe6ee83843a14f50889d58013bbf4e186ccc7060796744bd0d7439fbd9dacd28b5841da42c3b86a44aa081187c2475bce9f6ba6c863eca5959581c0e0decb584b8b13e7c10d43a40efcf8b213f2324293ec0140de9bf216069c7074bb942b7be567fdb3a30f069a2c5274a540b551c9560173fc81cd8bb77ff18078d768c87d7c6fffb0cc7bcd0d4c6dc11b0aab809953de32c2ba8a243909f6d15266621e19c1db620975180bea7ba177a79b62f1ed990fdb65ca6f2abebb710dc0a29369601379fe1f4bb24d74135d59b892b1e4cca"+ "'", var12.equals("c9194ca7f5cb2db79ae7ad2e5c186ab1295567eb5d006f691a77a21dbc082cbc520b17dac3a9a25f6378cfb4c40ed6527ff5114f56a1ae91d168aa4fb5bd9245291dc63c00f04d9d4fe18cac8a68f4bf468cda5fc8cdc0a5194f82e7e5da66aa5e7864f2a60508ee5a759c203ec95437fd5567be89a9e29defca7c5f331c6a38ccf9bd07db4927bfd166d782c92909763b727ede3f845575b7d4127b345bb344d86d40643793594fd637796806b1c5493318dc28c111666c6fd343319c8641cb4235940e646f41146a09ec1d4958e036cbb5b9783dfee15b387f635d1746f46aa5e4312468f416e14c6b8da4393a05a3bfe49cf021e6d6e36ed9bfd3cad3013a607b613a49134edcf259cc28abe7d81b54a4a66d3d0fb3d1bef4d3a15caf3737c00c8fc0a7f6a54819627bf41316d5f9fe6ee83843a14f50889d58013bbf4e186ccc7060796744bd0d7439fbd9dacd28b5841da42c3b86a44aa081187c2475bce9f6ba6c863eca5959581c0e0decb584b8b13e7c10d43a40efcf8b213f2324293ec0140de9bf216069c7074bb942b7be567fdb3a30f069a2c5274a540b551c9560173fc81cd8bb77ff18078d768c87d7c6fffb0cc7bcd0d4c6dc11b0aab809953de32c2ba8a243909f6d15266621e19c1db620975180bea7ba177a79b62f1ed990fdb65ca6f2abebb710dc0a29369601379fe1f4bb24d74135d59b892b1e4cca"));
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.04443376754242554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.5458673480463676d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(2.9031679812916723E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9031679812916723E-7d);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     int var11 = var2.nextBinomial(5, 0.07180988227597636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextGaussian(0.8548643823367507d, (-0.6751447494035615d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }


    long var2 = org.apache.commons.math3.util.FastMath.min((-745794403086227031L), (-343034188110465231L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-745794403086227031L));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(270);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 270);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.799453453475944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2163172678973952d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(281614168, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     int var9 = var2.nextPascal(6, 1.4210854715202004E-14d);
//     var2.reSeedSecure(2548228850011803885L);
//     double var13 = var2.nextT(0.5303092014603302d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.3433718707484554d);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(352);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 352);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    int var4 = var1.nextInt();
    int var6 = var1.nextInt(500);
    var1.setSeed(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1413078328));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 397);

  }

}
