
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(1, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5403023058681398d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0f));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.9570417874309d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.0d, 30.9570417874309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30.973188990298414d);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = null;
//     org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, var2);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Object var5 = new java.lang.Object();
//     java.lang.Object[] var6 = new java.lang.Object[] { var5};
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, var6);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    int var1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6321205588285577d));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh((-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asinh(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1L), 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, var1);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var8 = var7.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var8);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal(6, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1622776601683795d);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var2.nextPermutation(100, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(30.973188990298414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 31L);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextHypergeometric(10, 0, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var2.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.298342365610589d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.exception.MathIllegalStateException var0 = new org.apache.commons.math3.exception.MathIllegalStateException();

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.ulp(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = null;
//     org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, var2);
//     java.lang.Throwable[] var4 = var3.getSuppressed();
//     java.lang.String var5 = var3.toString();
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7350525871447157d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 19.0d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0d), (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("hi!", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-57.29577951308232d));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(6, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.7350525871447157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012829087820977834d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(3, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(100L, 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100L);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var4 = var1.nextLong((-6069125204240848293L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5430806348152437d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9489244855586554d);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(31L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(5.298342365610589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.298342365610589d);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-57.29577951308232d), 0.012829087820977834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0010733045953172857d));

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.7350525871447157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9040580270688509d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)6);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.13813975938570944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.974823675756067d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
//     boolean var5 = var4.getBoundIsAllowed();
//     org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var4);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var5.inverseCumulativeProbability((-0.0010733045953172857d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4100249074148754d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210854715202004E-14d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 26.0d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.7350525871447157d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7450520880645611d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(2.974823675756067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9748236757560673d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)1.5430806348152437d);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var2.nextPermutation(1, (-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100L);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3, (java.lang.Number)(byte)10, true);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(2.974823675756067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4382037266346042d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.7350525871447157d, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.317898532933117E29d);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.4210854715202004E-14d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4210854715202004E-14d);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(2.974823675756067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var2.nextPermutation(6, 1024);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(byte)0);
    java.lang.Number var3 = var2.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)0+ "'", var3.equals((byte)0));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(2.9748236757560673d, (-1.3850762971330945d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var5.inverseCumulativeProbability(9.317898532933117E29d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     double var0 = org.apache.commons.math3.util.FastMath.random();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == 0.6313298547021015d);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.220446049250313E-16d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(10L, 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5418954798163613d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.5418954798163613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5418954798163614d);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)9.568906036844316d);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("", "629ec7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.07686407895342469d);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    var1.setSeed(100L);
    float var8 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.19048333f);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(1.4100249074148754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.09605742500227d);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(5.298342365610589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(1.0f, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2676506E30f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.1622776601683795d, (java.lang.Number)(-0.0010733045953172857d), true);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.6313298547021015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6313298547021015d);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4997320104385629d);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0f);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.5430806348152437d, 3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.942186149242891d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.5418954798163614d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8152769730283367d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)3.4006531419542196d);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation((-1), 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "0f7"+ "'", var10.equals("0f7"));
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(2.9489244855586554d, 5.298342365610589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.298342365610589d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.5403023058681398d, 3.4006531419542196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4006531419542196d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextLong(100L, 26L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform(Double.NaN, 0.5148401381795025d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotANumberException");
//     } catch (org.apache.commons.math3.exception.NotANumberException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.020057959244916924d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "86a"+ "'", var4.equals("86a"));
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var2 = null;
//     org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)100.0d, var2);
//     java.lang.String var4 = var3.toString();
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)9.317898532933117E29d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextF(0.0d, 1.4100249074148754d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = var0.nextInt((-1));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var7 = var0.nextBinomial(2, 12.978452428686579d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.20388246197431584d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.3218644933039536d);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-5.21416038369738d), 2.027583163938867d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-5.214160383697379d));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
//     long var14 = var2.nextLong(9L, 31L);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var2.nextSample(var15, 3);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.974823675756067d, 0.001426069753303551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6.010754535962853d));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(2.974823675756067d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7538036993385602d);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var5);
//     java.lang.String var7 = var6.toString();
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextBinomial((-1), 30.973188990298414d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19048333f);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(1024, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1024);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.apache.commons.math3.exception.MathInternalError var0 = new org.apache.commons.math3.exception.MathInternalError();
    org.apache.commons.math3.exception.util.ExceptionContext var1 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-57.29577951308232d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var5.inverseCumulativeProbability(2.027583163938867d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextF(0.0d, 30.9570417874309d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 80);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(10.0f, 0.48426586993164683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-127));

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure(100L);
//     long var11 = var2.nextLong(0L, 26L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var2.nextSample(var12, 2);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.7450520880645611d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6891841496949834d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.167472272076316d);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(2.302228544983558E-5d, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.8417828359868464E-4d);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(26.0d, 0.6313298547021015d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.8267910113012649d);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.48426586993164683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8850169682561488d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.nextUniform(0.03132321019379296d, (-1.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.tan(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(30.973188990298414d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 30.973188990298418d);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.sample();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal(2, Double.NaN);
      fail("Expected exception of type org.apache.commons.math3.exception.MathInternalError");
    } catch (org.apache.commons.math3.exception.MathInternalError e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextExponential((-0.0010733045953172857d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(2, 0, 270);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation((-1), 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.9613730463649484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "25a"+ "'", var4.equals("25a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 3.91193993478635E-5d);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.19048333f, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.190933f);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.5403023058681398d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-113.92302816326081d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-114.0d));

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, (-1413078328));
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(26.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9572960942783878E11d);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.4382037266346042d, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11.505629813076833d);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.1622776601683795d, (java.lang.Number)(-0.0010733045953172857d), true);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     org.apache.commons.math3.exception.util.Localizable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var8, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var7, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var6, (java.lang.Object[])var13);
//     org.apache.commons.math3.exception.MathIllegalStateException var17 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var13);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)18.58616942859271d);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.031493100493387514d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0319942553198942d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees((-11.35464876064149d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-650.5734518382083d));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.0d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.0d);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.48426586993164683d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)12.978452428686579d, var1, false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh((-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.12916527366424163d));

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(7009605301686414442L, 3L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.981575f, 18.392781021818884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9815751f);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5403023058681398d, 0.001426069753303551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5403041878436351d);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(17, 6);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8464173146853822d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "671"+ "'", var4.equals("671"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, (-11.35464876064149d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.141592653589793d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7450520880645611d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7450520880645612d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.616474220487839E28d);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.9489244855586554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.9040580270688509d, (java.lang.Number)30.973188990298418d, true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(Double.NEGATIVE_INFINITY);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    double var8 = var5.probability(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = var2.nextPascal((-1413078328), Double.NEGATIVE_INFINITY);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-11.35464876064149d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7763568394002505E-15d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)1L, false);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.7450520880645611d, (java.lang.Number)0, false);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.7350525871447157d, (java.lang.Number)1.0d, (java.lang.Number)1);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2676506E30f);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9262160379374064d));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor((-0.0010733045953172857d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(6, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("904", "30f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6964575328002911d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.022498775555244665d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(2.9748236757560673d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.9815751f, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128657.01f);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var12 = var5.sample((-2));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.5142856083511866d, 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.26448968695715014d);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin((-1.7626381930754416d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.9572960942783878E11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 25.99999999999489d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5707963267948966d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1.4382037266346042d, (java.lang.Number)3, (java.lang.Number)3.141592653589793d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)30.973188990298414d, (java.lang.Number)12L, (java.lang.Number)0.5207931322143664d);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.apache.commons.math3.exception.NotANumberException var0 = new org.apache.commons.math3.exception.NotANumberException();
    java.lang.Number var1 = var0.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(2.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    var1.setSeed(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8010699356605312d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "eb8"+ "'", var4.equals("eb8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.036065507482574866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.2061445275648257d);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.03132321019379296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.031333458403791564d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextZipf(0, (-0.6321205588285577d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 69);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.03132321019379296d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextExponential(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(1.7763568394002505E-15d, 0.0d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4421455911864334d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "efb858f6c5abc90f26661bf85ea83ada4de2cfc32535f1b46760b115551753f7139ddef5ee3c20c5dd66c788e0c6ea0daef1b65e430ddaab694afc4d5449a1eb90ba82e4e4d9242203e067133f626a8702516c6bc589746918b47b85ae106604e0700a10c6bfe968ac06afef22d14284d7d0822ef960713ad96d82433007f9b6cc10d0db98719d783f1b55046d64582237070ac4618553e2dd2fb6914d7a7ae44cffab4c985cb97842a409482b2c80e4c4a71342c7a56cb58749eb998be46931aa2dca877721ed265db09682ffaa308f5bb273632bfb2e2e0d8813c79db8fe310e7e81ccdb362f01d494f3012105cc631ac50860ad231da0113832cca39b16960863e7862da012ecceb39843e2ec93fed83a6c5354d43599687149b0bbde315afdccae2feeb26f1bda4fe252e84e047be89a88250714f0bcdc2bec970709a28b320b981d1a178c74e13cdd4c775bfb9f44c4863df1e6563eeca67fd056ae5fa10edee9c53a014b1c25467ada4dcdb5d2a4138a8d1a2bdff49d86481fb9fb295b7e4a1bea5a9d469de57ac4f121001fde55eda59603716d4bab7fbba09ba2f4ce14bdb2cd2fbdcd268f303a7cc4d94ccd8e83c1276a5e6d794ecc54c40b34e6d5421ed8ad4c82d8730a5952471bf3b3fe8ee6cdce83f5476af4a1d7917efc2782d24defb71c3cb93f204f79e9a3f00e14123b4b352aeb02f0a3638480594008bf"+ "'", var4.equals("efb858f6c5abc90f26661bf85ea83ada4de2cfc32535f1b46760b115551753f7139ddef5ee3c20c5dd66c788e0c6ea0daef1b65e430ddaab694afc4d5449a1eb90ba82e4e4d9242203e067133f626a8702516c6bc589746918b47b85ae106604e0700a10c6bfe968ac06afef22d14284d7d0822ef960713ad96d82433007f9b6cc10d0db98719d783f1b55046d64582237070ac4618553e2dd2fb6914d7a7ae44cffab4c985cb97842a409482b2c80e4c4a71342c7a56cb58749eb998be46931aa2dca877721ed265db09682ffaa308f5bb273632bfb2e2e0d8813c79db8fe310e7e81ccdb362f01d494f3012105cc631ac50860ad231da0113832cca39b16960863e7862da012ecceb39843e2ec93fed83a6c5354d43599687149b0bbde315afdccae2feeb26f1bda4fe252e84e047be89a88250714f0bcdc2bec970709a28b320b981d1a178c74e13cdd4c775bfb9f44c4863df1e6563eeca67fd056ae5fa10edee9c53a014b1c25467ada4dcdb5d2a4138a8d1a2bdff49d86481fb9fb295b7e4a1bea5a9d469de57ac4f121001fde55eda59603716d4bab7fbba09ba2f4ce14bdb2cd2fbdcd268f303a7cc4d94ccd8e83c1276a5e6d794ecc54c40b34e6d5421ed8ad4c82d8730a5952471bf3b3fe8ee6cdce83f5476af4a1d7917efc2782d24defb71c3cb93f204f79e9a3f00e14123b4b352aeb02f0a3638480594008bf"));
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(2147483647, (-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2147483647);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8d3", "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4241394861641134d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.7386140239535611d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14L);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(3.942186149242891d, (-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.9925440556337284d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan((-5.21416038369738d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.3813117226938723d));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     double var11 = var2.nextExponential(2.027583163938867d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4.719910314140863d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.161909012740015d);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-0.6321205588285577d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.03923685462767229d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.19808294885646338d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextPascal(10, 1.9572960942783878E11d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(30.9570417874309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    boolean var6 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextExponential(0.5418954798163613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("028", "dbd");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.1732500681266194d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c5c"+ "'", var4.equals("c5c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.08376388418049867d);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(2.9748236757560673d, 1.5430806348152437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5430806348152437d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(7009605301686414442L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 7009605301686414442L);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0f, 1024);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextSecureLong(2419047238712938144L, 31L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.7538036993385602d, (java.lang.Number)(-1), false);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.03132321019379296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.031818944398912d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)2.220446049250313E-16d);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.0017012253171059017d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0L);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextExponential((-0.9262160379374064d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8975826165960203d);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5517493820104129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6208928579421888d);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 270, (-127), 270);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(7009605301686414442L, 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7009605301686414442L);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     int var8 = var2.nextSecureInt(100, 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var2.nextInt(100, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 706);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3bc", "35c");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1050186097632508d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "592"+ "'", var4.equals("592"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.047540015592312d);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(3.4006531419542196d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 14.975162885657241d);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(25.70543202901362d, 1.4458039286025248d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4458039286025248d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    boolean var9 = var6.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum((-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.9E-324d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(1.9090738156391573d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3816923737356146d);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(1.1175052971553494E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1175052971553494E-9d);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)6);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.653297910537354d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var2.nextSecureLong(31L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.037904133499767505d);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5207931322143664d);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var3.nextPermutation(0, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(5.56752948887997d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.567529488879971d);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3bc", "30f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6506103213370111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "23d"+ "'", var4.equals("23d"));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.1753021164154851d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1916061660198558d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-2.0703237889114567d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.4790107940873415d));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(2, 100, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03680844452139805d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "8d4"+ "'", var4.equals("8d4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.19808294885646338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 11.349316962981089d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(147);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextUniform(0.0d, (-0.12916527366424163d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(4, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextWeibull(0.19808294885646338d, (-6.010754535962853d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5130802117948507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "da08c7b2c702ec15b48b8f20786817a7bd3ab7404cb53e3ef791147e36f76e9a7ab73e644b5ba1f30a6ae8d4b55f6a298f2bd48fb04f764636706c3153775b02e35c9ffa8a35c99382c070f9cf301f57e4909e84c11fcc3784c1d31b54cfad294ac9ef2ce30da5d4f18752b303c43ae9a54a617863b068877495b42157a781b3a7b940c98f3c20d17768d067a4a855d31ecc9b680c895da5fb14b1b4b723907a4c50a523a22c8587119bfdf97c6e52f519fe4f49842c8209b3bcb0fac6fd8549d77381e92d629fd7350af02c6e154adbffe39525b03b2c1d902d075c9d7fa63fe477481db47b62ddf6224e388530be2ab3b18f18484a0f67c119880f228e530a16eac81405550be0e0e39de6f24c24b7bb77fe5e4ed3b975facbd80003b5e786a0ef3406ad4972fcb85eac56e06566839487fdbf516acf8b0de7c32aeb3c4506c60bcb1f530791ca5cb911dbf12d8da136a0343a2152e5c7d99b6298c6d451108e4b997275a362bae9bf402604092ff042b9db77b4c969b6f577c506ecebb903b7aea7fd115b51cc4d1258def3e130fbec33c1d036e98df1a8d6e3847ba8462c628348d8e078af9d9cc4c94d1d8470b7028efe0f1157175861d5671409086e8dd04d3ede33d0738aa792170a24c3a5943f607267e062b0c372b86626be036736df2dadb71919ee15a69ee77c53ed3ba214f1e52becdc799a76b4f3b87b82a065"+ "'", var4.equals("da08c7b2c702ec15b48b8f20786817a7bd3ab7404cb53e3ef791147e36f76e9a7ab73e644b5ba1f30a6ae8d4b55f6a298f2bd48fb04f764636706c3153775b02e35c9ffa8a35c99382c070f9cf301f57e4909e84c11fcc3784c1d31b54cfad294ac9ef2ce30da5d4f18752b303c43ae9a54a617863b068877495b42157a781b3a7b940c98f3c20d17768d067a4a855d31ecc9b680c895da5fb14b1b4b723907a4c50a523a22c8587119bfdf97c6e52f519fe4f49842c8209b3bcb0fac6fd8549d77381e92d629fd7350af02c6e154adbffe39525b03b2c1d902d075c9d7fa63fe477481db47b62ddf6224e388530be2ab3b18f18484a0f67c119880f228e530a16eac81405550be0e0e39de6f24c24b7bb77fe5e4ed3b975facbd80003b5e786a0ef3406ad4972fcb85eac56e06566839487fdbf516acf8b0de7c32aeb3c4506c60bcb1f530791ca5cb911dbf12d8da136a0343a2152e5c7d99b6298c6d451108e4b997275a362bae9bf402604092ff042b9db77b4c969b6f577c506ecebb903b7aea7fd115b51cc4d1258def3e130fbec33c1d036e98df1a8d6e3847ba8462c628348d8e078af9d9cc4c94d1d8470b7028efe0f1157175861d5671409086e8dd04d3ede33d0738aa792170a24c3a5943f607267e062b0c372b86626be036736df2dadb71919ee15a69ee77c53ed3ba214f1e52becdc799a76b4f3b87b82a065"));
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.19048333f, 0.9815751f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19048333f);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextWeibull(30.973188990298414d, 18.58616942859271d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("386", "9de");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 18.392781021818884d);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)10+ "'", var5.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var3.nextSecureInt(0, (-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-6069125204240848293L), (-1486998192385879714L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1486998192385879714L));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-1413078328), 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1413078328));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.8850169682561488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.417866337976411d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(3.552713678800501E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.552713678800501E-15d);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.atanh(57.8782148542884d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(1.417866337976411d, (-0.12916527366424163d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.12916527366424163d));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(3.9925440556337284d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3844286356444537d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(128657.01f, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128657.01f);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var2.nextHypergeometric(4, (-2), 26);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-11.7204516580769d), 4.440892098500626E-16d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-11.720451658076898d));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6208928579421888d, (-0.7225540191019567d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6208928579421887d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var4 = null;
//     int var5 = var0.nextInversionDeviate(var4);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.548552626348489d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.07180988227597636d, (java.lang.Number)2.027583163938867d, true);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1486998192385879714L), 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3L);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(10L, 13L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10L);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(5.567529488879971d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     java.lang.String var13 = var0.nextHexString(2);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, (-1413078328));
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(3.4724687469699105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.9581294241070768d);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     double var17 = var12.upperCumulativeProbability(3);
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var21 = var0.nextInt(2147483647, 4);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.23871128652582368d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.06909409358377612d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextGaussian(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03218542801096123d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.0573141754618551d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13L);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    int var4 = var1.nextInt();
    byte[] var8 = new byte[] { (byte)10, (byte)100, (byte)(-1)};
    var1.nextBytes(var8);
    double var10 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1413078328));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5148401381795025d);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-2), 2147483647, 147);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.1306629546226212d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    long var14 = var2.nextLong(9L, 31L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var17 = var2.nextPermutation(2, 1024);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 26L);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 29);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(Float.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Float.POSITIVE_INFINITY);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.0f, 12.190933f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    double var14 = var5.upperCumulativeProbability(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.9489244855586554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.577427448394613d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextBeta((-0.0010733045953172857d), 0.24542394462207118d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "dcd"+ "'", var10.equals("dcd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.43007770399434064d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    var7.addSuppressed((java.lang.Throwable)var11);
    org.apache.commons.math3.exception.util.ExceptionContext var13 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 29);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(0.13813975938570944d, (-5.214160383697379d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(30.9570417874309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.432600494654796d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(1, 29, 147);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(1.4100249074148754d, 0.19808294885646338d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.070432487691579d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextWeibull(30.973188990298414d, 18.58616942859271d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var11 = var2.nextT((-5.214160383697379d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 18.392781021818884d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)17);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)30.973188990298414d, (java.lang.Number)4.09605742500227d, false);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var6);
    org.apache.commons.math3.exception.util.ExceptionContext var8 = var7.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4E-45f);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.03923685462767229d, 9.317898532933117E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.03923685462767229d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextExponential(0.5418954798163613d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("d73", "");
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5.19677807580522d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "c1f"+ "'", var4.equals("c1f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2760925935050965d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.6891841496949834d, 3.4724687469699105d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.19592488215851694d);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSecureAlgorithm("0c8", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    java.lang.Number var4 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0L+ "'", var4.equals(0L));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var0.nextWeibull(0.0d, 1.9090738156391573d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.12805958758702873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "cfa"+ "'", var4.equals("cfa"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.486065195141994E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.1582003256244138d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(0.24542394462207118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextInt(0, (-2));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3521954620913603d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "16d"+ "'", var4.equals("16d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var3 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.74324155f, (java.lang.Number)1.8821522703441236d, var3);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(2.161909012740015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 123.86826212129738d);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    int[] var8 = var5.sample(100);
    double var10 = var5.upperCumulativeProbability(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(19.0d, (-11.720451658076898d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 18.999999999999996d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.8822137015004015d, 18.999999999999996d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.429969493008637E8d);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextHypergeometric(3, 1024, (-1413078328));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7216599837973326d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var6.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var22 = var17.getNumericalVariance();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "848"+ "'", var10.equals("848"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0d);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.8201071802366467d, 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.73260320806421E-6d);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 100.0d);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(2.0d, 2.286069913668499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0000000000000004d);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1));
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(1.1916061660198558d, 1.1175052971553494E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-117.58082258639261d));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    double var5 = var1.nextGaussian();
    int var6 = var1.nextInt();
    int[] var7 = null;
    var1.setSeed(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 563228325);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.74324155f, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.7432415f);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure(100L);
//     long var11 = var2.nextLong(0L, 26L);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var2.nextSample(var12, 1024);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-0.09653689510610847d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.873060404051843d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
//     var2.addSuppressed((java.lang.Throwable)var7);
//     java.lang.String var9 = var2.toString();
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    long var6 = var1.nextLong(9L);
    long var7 = var1.nextLong();
    double var8 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-7034676902218012687L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2029965220937808d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(11.505629813076833d, 5.395512929437507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1322995253728005d);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(100.0f, 12.190933f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(2.847732150080772d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)(short)0);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)3L);
//     var2.addSuppressed((java.lang.Throwable)var5);
//     java.lang.String var7 = var2.toString();
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.9262160379374064d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0644436491518945d));

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(1.1277591147170036d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3824846535938333d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.6815472213374374d, 5.395512929437507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.7088179325293313d);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-1));
//     org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.4593664907342236d, 0.7216599837973326d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.41933189414688476d);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var22 = var17.sample();
//     int var23 = var17.getNumberOfSuccesses();
//     int[] var25 = var17.sample(4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "708"+ "'", var10.equals("708"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1413078328), (java.lang.Number)(-114.0d), true);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(0.9040580270688509d, 1.4100249074148754d);
//     double var6 = var0.nextUniform(0.5142856083511866d, 4.765158102961618d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("hi!", "028");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.4826178234750866d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9544954168761107d);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(5.616474220487839E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.6164742204878395E28d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(14.975162885657241d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(25.99999999999489d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.951613336081869d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, var2, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.41933189414688476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5209450637949877d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(30.9570417874309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.1260084413717255d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextUniform(0.24542394462207118d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var7 = var0.nextPermutation(0, 1146122894);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6245140043527732d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "548"+ "'", var4.equals("548"));
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    var5.reseedRandomGenerator(12L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-5.21416038369738d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.POSITIVE_INFINITY);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    double var16 = var2.nextGamma(0.7350525871447157d, 5.56752948887997d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.78527454092035d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta(0.0d, 1.5707963267948966d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0254324088303963d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.6529612257831074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(128657.01f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 128657.01f);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.5430806348152437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int var11 = var5.getNumberOfSuccesses();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var5.cumulativeProbability(1024, 9);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb((-0.0010733045953172857d), 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var15 = var2.nextBeta(66.89123388852185d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    boolean var3 = var1.getBoundIsAllowed();
    java.lang.Number var4 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0+ "'", var4.equals(0));

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(9.568906036844316d, 3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.568906036844316d);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(1.1429675474380903d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.019948546946239154d);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(0.4997320104385629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7069172585519206d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.5418954798163614d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5726908002952725d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.7432415f, (java.lang.Number)2.9748236757560673d, true);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(128657.01f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 128657.01f);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.40178331265804124d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3916905744695509d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.0d, (java.lang.Number)8.653297910537354d, false);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(1.5430806348152437d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9333761944765003d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.20951305448319416d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2080097758206445d);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acos(1.9090738156391573d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.19963560609026354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3698102998742017d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(2.9489244855586554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.440892098500626E-16d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(2.9489244855586554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 18.085416045348254d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.11045359570096497d, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.11045359570096497d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.8E-322d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.36787944117144233d);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var16 = var0.nextSecureLong(0L, (-6069125204240848293L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "e15"+ "'", var10.equals("e15"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.05863548868019882d);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.9815751f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9815751f);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var7 = var6.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var9 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var7);
//     org.apache.commons.math3.exception.MathInternalError var11 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var10);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    double var12 = var2.nextUniform(1.167472272076316d, 9.317898532933117E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.540721859458478E29d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.1175052971553494E-9d, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.721627121435389E-7d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(19.993810591096988d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(15L, (-3759508027876256838L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-3759508027876256838L));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1920929E-7f);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(3.0273865279850015E-5d, 17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.968056069960501d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    double var9 = var2.nextT(8.653297910537354d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.4652771117010555d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(2.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     double var11 = var0.nextChiSquare(1.0477911379678095E-4d);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 1146122894);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(6, 563228325);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(3.540721859458478E29d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9223372036854775807L);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure(100L);
    long var11 = var2.nextLong(0L, 26L);
    var2.reSeed((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 12L);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(1.2676506E30f, 0.7432415f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.2676506E30f);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(1.1920929E-7f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1920929E-7f);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextGamma(0.6247958739991177d, (-4.719910314140863d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(Double.NEGATIVE_INFINITY, 0.019948546946239154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Double.NEGATIVE_INFINITY);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)2.847732150080772d);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(2.8822137015004015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3L);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "e"+ "'", var4.equals("e"));

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1023));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos((-4.719910314140863d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.00752126284215363d);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextPascal(0, 5.135803824339533E-6d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4394606102058582656L);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 0);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     double var11 = var0.nextWeibull(1.4458039286025248d, 0.006050121963214739d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(45, 1.031818944398912d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.006041595642410538d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(100.0d, 0.019948546946239154d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0000019897226d);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)6.651369377311933E13d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp((-1.0644436491518945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.34491969776264375d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 364);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5111573E23f);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextCauchy(3.1622776601683795d, 0.5207931322143664d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var9 = var2.nextPermutation(17, 29);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.4724687469699105d);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     int[] var7 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var8 = new org.apache.commons.math3.random.Well19937c(var7);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var8, 6, 0, 1);
//     boolean var13 = var12.isSupportConnected();
//     int var14 = var12.sample();
//     int var15 = var12.getSampleSize();
//     double var17 = var12.upperCumulativeProbability(3);
//     int var18 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var12);
//     java.util.Collection var19 = null;
//     java.lang.Object[] var21 = var0.nextSample(var19, 563228325);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var0.nextWeibull(0.0d, 4.020494098909096E28d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "cf4"+ "'", var10.equals("cf4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0544837431405767d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 543);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    double var15 = var2.nextUniform((-28.613219701103965d), 9.317898532933117E29d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 5.764512407651128E29d);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     java.util.Collection var18 = null;
//     java.lang.Object[] var20 = var0.nextSample(var18, 2147483647);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp((-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.7755575615628914E-17d);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(5, 524, 100);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.2676506E30f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 100.0f);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.6208928579421887d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 35.57454028990319d);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.3916905744695509d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.479479851731295d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0644436491518945d), (-5.21416038369738d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0644436491518947d));

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-1433502403876603448L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1433502403876603448L);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.NEGATIVE_INFINITY);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    var2.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.0035242230983847343d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0035242230983847343d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.4210854715202004E-14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-31.884770305757485d));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.005514177742691754d, 7.713044735798083E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.3782367207154096d);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextExponential(4.992655698293412d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 12.742325413815996d);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal(26, (-0.9262160379374064d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.lang.Throwable var0 = null;
    org.apache.commons.math3.exception.MathInternalError var1 = new org.apache.commons.math3.exception.MathInternalError(var0);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.43512733717637914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    long var2 = org.apache.commons.math3.util.FastMath.max((-1486998192385879714L), 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.8058364697442126d, 9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10778.571382009482d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.141592653589793d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4210804127942926d);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.7432415f, 2.9489244855586554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.74324155f);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 100);
//     int var15 = var2.nextZipf(29, 1.9572960942783878E11d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var19 = var2.nextUniform(2.9748236757560673d, 0.7700247882582713d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos(0.6820038473615311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8202972454764327d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(2.9748236757560673d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0d);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5574599702686449d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "abf"+ "'", var4.equals("abf"));
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     int var19 = var0.nextInt(4, 9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var21 = var0.nextSecureHexString((-188551922));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "93b"+ "'", var10.equals("93b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0633221608691665d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.8004949419093006d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 4);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(1.4E-45f, 0.7432415f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4E-45f);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextPascal((-188551922), 1.479479851731295d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.8993237201528976d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2.331160355227944d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.65136937731181E13d);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)10, (java.lang.Number)0.20951305448319416d, (java.lang.Number)0.5148401381795025d);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.5148401381795025d+ "'", var4.equals(0.5148401381795025d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.20951305448319416d+ "'", var5.equals(0.20951305448319416d));

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)30.9570417874309d, (java.lang.Number)1, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1+ "'", var4.equals(1));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.024276702549221277d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6));

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(119.87204169238177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.948609121362484d);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     int var14 = var2.nextBinomial(0, 0.5148401381795025d);
//     var2.reSeed(100L);
//     long var18 = var2.nextPoisson(0.8140149187445599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0L);
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     long var8 = var0.nextPoisson(0.005514177742691754d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextHypergeometric(29, 524, 9);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4659274717487932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e9e9e1538f029b9b8248db47d6eb9a4f2510f484b22ddde6413a1905d895bee5b6be66286b53bd995494386ec876894caa78701c2f18092f55a3aab3262eedfc7fe96efc8299bb64869596e329ca45fd9c6c9f2c457b7987a9fdc825761773e06e5a3b9897fa15db9cfe3d5d68e17754364119e953c2776b7d78643ccdab0c9204c5d1a0f52698b57c268eb7ff01214f325d69d75a1c894cf1336e8b3e09ac8c73485eaa8f221ac9af422907ad6471adc131f18a9c445706d74f164f855540a9cb3bafb6db49c2fc87a0aaa7666ecdabe34033407f29bbdd121e168481f5df241b998f5094c0739c3e778c18563175fe2abb3dfa55b8033dbb6daa9b71a169d278c77ba078451ec01416a0dbcf24664eb2a402ae58c60762b915d08a0df4e1a52b404c31464a9a269a5f95e906b381b2ec18182692101a4dc31e5555c116afa9b78f514744b563a9cf3fa163b57b2f0fa912d934cfee847912cc39ca3b2354cf649a83c4cd81fe8f0a09d496afcdb429a83639d15fcd50e9d324ad6c6d91844c8beb1b185b3363a05cbb71e2956443db05947fe9845f430ef7f5209f0314b330f923b9d86069cfd1560fb61f177468653a50b01172408b4d829e29e87693171e0358638db54d30020cf4babc23d452d06ddd62a1d575bf387700b1f14aaa41c5e309294ed6e0139b546d4e19d8c70fea2a31cb0162f265fd84f9d993cd74930b"+ "'", var4.equals("e9e9e1538f029b9b8248db47d6eb9a4f2510f484b22ddde6413a1905d895bee5b6be66286b53bd995494386ec876894caa78701c2f18092f55a3aab3262eedfc7fe96efc8299bb64869596e329ca45fd9c6c9f2c457b7987a9fdc825761773e06e5a3b9897fa15db9cfe3d5d68e17754364119e953c2776b7d78643ccdab0c9204c5d1a0f52698b57c268eb7ff01214f325d69d75a1c894cf1336e8b3e09ac8c73485eaa8f221ac9af422907ad6471adc131f18a9c445706d74f164f855540a9cb3bafb6db49c2fc87a0aaa7666ecdabe34033407f29bbdd121e168481f5df241b998f5094c0739c3e778c18563175fe2abb3dfa55b8033dbb6daa9b71a169d278c77ba078451ec01416a0dbcf24664eb2a402ae58c60762b915d08a0df4e1a52b404c31464a9a269a5f95e906b381b2ec18182692101a4dc31e5555c116afa9b78f514744b563a9cf3fa163b57b2f0fa912d934cfee847912cc39ca3b2354cf649a83c4cd81fe8f0a09d496afcdb429a83639d15fcd50e9d324ad6c6d91844c8beb1b185b3363a05cbb71e2956443db05947fe9845f430ef7f5209f0314b330f923b9d86069cfd1560fb61f177468653a50b01172408b4d829e29e87693171e0358638db54d30020cf4babc23d452d06ddd62a1d575bf387700b1f14aaa41c5e309294ed6e0139b546d4e19d8c70fea2a31cb0162f265fd84f9d993cd74930b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b2988e"+ "'", var6.equals("b2988e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var14 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var16 = var14.nextChiSquare(1.0d);
//     double var18 = var14.nextT(2.9748236757560673d);
//     long var20 = var14.nextPoisson(12.978452428686579d);
//     int[] var21 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var22, 6, 0, 1);
//     boolean var27 = var26.isSupportConnected();
//     int var28 = var26.sample();
//     int var29 = var26.getSampleSize();
//     double var31 = var26.upperCumulativeProbability(3);
//     int var32 = var14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var26);
//     int var33 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var37 = var0.nextUniform(2.161909012740015d, 1.7538036993385602d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.44935745566413615d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "36d"+ "'", var4.equals("36d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.3380442013860776d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.03402480723560111d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.42437496740731107d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var4 = var2.nextHexString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "ee1960ac2c"+ "'", var4.equals("ee1960ac2c"));

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     org.apache.commons.math3.distribution.RealDistribution var10 = null;
//     double var11 = var0.nextInversionDeviate(var10);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.302228544983558E-5d, (java.lang.Number)1.5707963267948966d, true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.981575f, 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31.4104f);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(0.5517493820104129d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var6.nextChiSquare((-5.214160383697379d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil((-11.720451658076898d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-11.0d));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0f));

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextSecureInt((-6), (-1413078328));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.29486290084058253d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2948629008405826d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(0.005514177742691754d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005514177742691755d);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.031493100493387514d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(897, 1024);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.38802063594435987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.012656055492394928d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13L);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.sqrt((-0.12952473180939125d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     org.apache.commons.math3.distribution.IntegerDistribution var14 = null;
//     int var15 = var0.nextInversionDeviate(var14);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var10 = var2.nextT(2.8822137015004015d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var2.nextPermutation((-127), 2);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.8017933909029345E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5160414548901331d);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh(1.0477911379678095E-4d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.047791141802258E-4d);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.0644436491518947d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6550803022373564d));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.9333761944765003d, 0.03132321019379296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 50.23276478699215d);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     double var19 = var0.nextGaussian(0.14961208608543997d, 0.6208928579421888d);
//     org.apache.commons.math3.distribution.RealDistribution var20 = null;
//     double var21 = var0.nextInversionDeviate(var20);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     long var20 = var0.nextPoisson(2.286069913668499d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextBeta(0.0d, (-1.7626381930754416d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.017414851010824d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "623"+ "'", var4.equals("623"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.06903527048830978d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.520321459560525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 3L);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(0.6208928579421888d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.4829771442965295d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(0.05034846331660371d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05036975957415425d);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.nextExponential(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0597684430358103d);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     long var8 = var0.nextPoisson(0.005514177742691754d);
//     double var11 = var0.nextGaussian(4.992655698293412d, 0.8140149187445599d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.18039163719555346d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "acec2a929f1809b20bb7818c6dfd9397b58c72da316ba113bdf9be7e301efb8cf8dd210c320fe9b47ed9d42439e8500ce9b44c7c019d0ebf9d2d0e231d416613dcd6f22ec04cd447f7623f65e0d7062fc96c7e4835d6d78921ff7ac629d94af34ff6effda6fec751f2ee819b537467f2aef04b5586a72a63ec6f97661fe0616f9dd8f3e2fa6e9160adf20ea783a0a2674904bda06a7abc2c433789ff64c4a11a677366b5dc393471ffa0de00458b09511ce08ea8a18769cf1a53f236d6a37a6619dd9ab97167f0737502a6bece99449f3f89f0fa98781bfd065cef05e379d8c22a4ef22d0511f10c7b21884929420d4feeb1a682264c6ccb86a8653d87daae02d046450ad694f2f10f4be2dad95f2acfedfe4ea5aad647787f1acea7d6a29c9c24853bb4452b5c74029ff4d8c633523fe1956e5433090f2a4365e93ad180aac6dea77e18f475728dbb6501df349888afc901f9df9902694e161f02c96f6fd8cc76831f13c6e2a12a2c175199b7a14539d26cc5b1231bb41f3ac17b5140727fda7a1ab57bd86e2db2b55da73315c899fca6fbd48fc8afc9ed5cc734c1015e266da296f3be9645afccbf088fc220dfd147dc458a7c9a5d1e7b2ad620d8a1ff650a75431fa4423be6bc0d1c197526909fcab85815f83308da6da44941fdb799a5293060829c5417bb78c2b4b5f210ee0d96d194ef6140cd959e90fdce4a0acc47bd"+ "'", var4.equals("acec2a929f1809b20bb7818c6dfd9397b58c72da316ba113bdf9be7e301efb8cf8dd210c320fe9b47ed9d42439e8500ce9b44c7c019d0ebf9d2d0e231d416613dcd6f22ec04cd447f7623f65e0d7062fc96c7e4835d6d78921ff7ac629d94af34ff6effda6fec751f2ee819b537467f2aef04b5586a72a63ec6f97661fe0616f9dd8f3e2fa6e9160adf20ea783a0a2674904bda06a7abc2c433789ff64c4a11a677366b5dc393471ffa0de00458b09511ce08ea8a18769cf1a53f236d6a37a6619dd9ab97167f0737502a6bece99449f3f89f0fa98781bfd065cef05e379d8c22a4ef22d0511f10c7b21884929420d4feeb1a682264c6ccb86a8653d87daae02d046450ad694f2f10f4be2dad95f2acfedfe4ea5aad647787f1acea7d6a29c9c24853bb4452b5c74029ff4d8c633523fe1956e5433090f2a4365e93ad180aac6dea77e18f475728dbb6501df349888afc901f9df9902694e161f02c96f6fd8cc76831f13c6e2a12a2c175199b7a14539d26cc5b1231bb41f3ac17b5140727fda7a1ab57bd86e2db2b55da73315c899fca6fbd48fc8afc9ed5cc734c1015e266da296f3be9645afccbf088fc220dfd147dc458a7c9a5d1e7b2ad620d8a1ff650a75431fa4423be6bc0d1c197526909fcab85815f83308da6da44941fdb799a5293060829c5417bb78c2b4b5f210ee0d96d194ef6140cd959e90fdce4a0acc47bd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "3c8887"+ "'", var6.equals("3c8887"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 5.28554289799445d);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.5148401f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

}
