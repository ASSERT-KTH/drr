
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.013664005291732968d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.734723475976807E-18d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4203357266970343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "250b6962173d90d054dee0c3fdf8b6045d15d69ef3dcdb47a24aa30b468679fd4f1bf8b3d81dccea09e94725131fb673951992bf697a10b96a204a52a3248a72f3c2e6c9d11cf7525d15848a3cb91e758b40448125bd792a5653765ee4e7958c92ce4394e7935cc206f6031f97517292bf3405619e8122ead5e2142675a4a4ce399769acbb0be333c8b4de586f291932e816a58070f2dd99da00506cbdf5284b1f9683ca606f15329a2b7b184cb7c967510617ed7d76926169ec31d1810c603a7d6704001efe34a935913808a4a7eb7cb7c11d9a62dc983c3f9918ae928988e6520051d231ff68fe8ff68f8abccbf5dfef008dc4929545d426cf561f0acf4fe32f87c74f3ab2a13431e40b6ae7719783d906cbfc606799bde4310b0318877725a2222046f53f9db16200da7479cc18d07cd20c29c0eaa3a9cb0fae0c00524a473aad3c653410bf571a95f05a0e913d4693745942aa10cf71f08f7888805903e75a0b0bac556fb13f4e75595ef59b010639afba0a3e73251ef89d4a89bb27204383eb8ec3f42874ec0baf2e46917e64387280987ec2341ab24ccb8574151931362424c3fbf512fd075c3c33fed3d28f55e0295b12fb2f90e4100a0fa7efa67689f0d360e2194256a4817ab79bf4cdd67232d4761260705ff826969ce95b554957edd73f2a125e3f70c13022a18747f6aa9eed337a1b324b687801b46e3a45a0ee"+ "'", var4.equals("250b6962173d90d054dee0c3fdf8b6045d15d69ef3dcdb47a24aa30b468679fd4f1bf8b3d81dccea09e94725131fb673951992bf697a10b96a204a52a3248a72f3c2e6c9d11cf7525d15848a3cb91e758b40448125bd792a5653765ee4e7958c92ce4394e7935cc206f6031f97517292bf3405619e8122ead5e2142675a4a4ce399769acbb0be333c8b4de586f291932e816a58070f2dd99da00506cbdf5284b1f9683ca606f15329a2b7b184cb7c967510617ed7d76926169ec31d1810c603a7d6704001efe34a935913808a4a7eb7cb7c11d9a62dc983c3f9918ae928988e6520051d231ff68fe8ff68f8abccbf5dfef008dc4929545d426cf561f0acf4fe32f87c74f3ab2a13431e40b6ae7719783d906cbfc606799bde4310b0318877725a2222046f53f9db16200da7479cc18d07cd20c29c0eaa3a9cb0fae0c00524a473aad3c653410bf571a95f05a0e913d4693745942aa10cf71f08f7888805903e75a0b0bac556fb13f4e75595ef59b010639afba0a3e73251ef89d4a89bb27204383eb8ec3f42874ec0baf2e46917e64387280987ec2341ab24ccb8574151931362424c3fbf512fd075c3c33fed3d28f55e0295b12fb2f90e4100a0fa7efa67689f0d360e2194256a4817ab79bf4cdd67232d4761260705ff826969ce95b554957edd73f2a125e3f70c13022a18747f6aa9eed337a1b324b687801b46e3a45a0ee"));
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var8 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var9 = new org.apache.commons.math3.exception.MathInternalError(var1, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.MathInternalError var10 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     int[] var16 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var21 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var17, 6, 0, 1);
//     boolean var22 = var21.isSupportConnected();
//     int var23 = var21.sample();
//     int var24 = var21.getSampleSize();
//     double var26 = var21.upperCumulativeProbability(3);
//     double var28 = var21.cumulativeProbability(1024);
//     double var30 = var21.probability(281614168);
//     int var31 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.016070048990239574d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "627"+ "'", var4.equals("627"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.9592615570774238d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.876784835166937d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
//     double var7 = var2.nextExponential(0.001426069753303551d);
//     int var10 = var2.nextInt(6, 563228325);
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, (-1737377827));
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan((-0.5811257250652634d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6567785746778827d));

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    java.lang.String var7 = var2.nextHexString(6);
    org.apache.commons.math3.random.RandomGenerator var8 = var2.getRandomGenerator();
    double var11 = var2.nextCauchy((-6.010754535962853d), 2.4652771117010555d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "629ec7"+ "'", var7.equals("629ec7"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 36.53201443003865d);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(0.23194910076661474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalVariance();
    int var7 = var5.getSupportUpperBound();
    double var8 = var5.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     double var14 = var0.nextF(23.729908791521954d, 5.873060404051843d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3769531022985003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "953"+ "'", var4.equals("953"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.625098279255794d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 7.321941349665098d);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-2349309494509100384L), (java.lang.Number)1.2203158490481973d, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(0.5148401381795025d, 840);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.774581056178469E252d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    double var6 = var2.nextGamma(0.07180988227597636d, 0.6820038473615311d);
    int var9 = var2.nextZipf(45, 0.8201071802366467d);
    long var12 = var2.nextLong(995670436341972829L, 4137880971203176105L);
    double var15 = var2.nextWeibull(1.7538036993385602d, 3.0929813548336E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.003787966974016121d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2241856882564607076L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.8961942241580267E-5d);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    double var12 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var14 = var1.nextGaussian();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7700247882582713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.784667018651192d));

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (-438907248));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(50.23276478699215d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     var0.reSeed(12L);
//     org.apache.commons.math3.distribution.RealDistribution var16 = null;
//     double var17 = var0.nextInversionDeviate(var16);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.9518401855672245d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.27873123f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.9802322E-8f);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(0.6637501057317085d, 2.302228544983558E-5d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var2.nextHypergeometric((-2), 281614168, 39);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.578384573151231E-5d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(1.9581294241070768d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(35.13605081944778d, 0.24542394462207118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.24542394462207118d);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     double var19 = var0.nextGaussian(0.14961208608543997d, 0.6208928579421888d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextChiSquare((-0.06334950076970383d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "483"+ "'", var10.equals("483"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.07105915501249677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2.98499607738682d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.49027310137335334d);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(2.78527454092035d, 0.01179864038469449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0121592249101665d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric((-494780561), 147, 524);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3662289994817323d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f70"+ "'", var4.equals("f70"));
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextBinomial(1, 0.031493100493387514d);
//     double var14 = var2.nextExponential(0.03408634154283945d);
//     double var16 = var2.nextExponential(66.89123388852185d);
//     int var19 = var2.nextInt((-79134244), 352);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setSecureAlgorithm("b71", "fd6");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.2538039769544998E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.13331275536141382d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 91.97211887717958d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-67467601));
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getSupportUpperBound();
    boolean var14 = var5.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var5.inverseCumulativeProbability(6.46743983995431E28d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.5148401f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5148401f);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextDouble();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong((-1665514280923435908L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5148401381795025d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextBeta(1.1277591147170036d, 2.625098279255794d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.31938343262455215d);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }
// 
// 
//     java.lang.Number var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Object[])var5);
//     java.lang.Number var7 = var6.getArgument();
//     org.apache.commons.math3.exception.util.ExceptionContext var8 = var6.getContext();
//     org.apache.commons.math3.exception.util.Localizable var9 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var14 = var13.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var14);
//     var6.addSuppressed((java.lang.Throwable)var15);
//     org.apache.commons.math3.exception.util.Localizable var17 = null;
//     org.apache.commons.math3.exception.util.Localizable var18 = null;
//     org.apache.commons.math3.exception.util.Localizable var19 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var22 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
//     java.lang.Throwable[] var23 = var22.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var24 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0010733045953172857d), (java.lang.Object[])var23);
//     org.apache.commons.math3.exception.MathIllegalStateException var25 = new org.apache.commons.math3.exception.MathIllegalStateException(var19, (java.lang.Object[])var23);
//     org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var18, (java.lang.Object[])var23);
//     org.apache.commons.math3.exception.MathIllegalStateException var27 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var15, var17, (java.lang.Object[])var23);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-3012399215156379713L), (java.lang.Number)19L, true);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(3.540721859458478E29d, (-0.019662360115310532d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.11894009318368966d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.3710675832155867d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1169233265406826211L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "37d2e"+ "'", var11.equals("37d2e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 5.511768395722838d);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextInt((-1), 5);
//     long var14 = var2.nextPoisson(130.89136659412873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2.922175992488695E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 126L);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)5.873060404051843d);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Throwable[] var10 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.log(2.6815472213374374d, (-0.9262160379374065d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(5.177167373130586E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     int var11 = var0.nextSecureInt(2, 147);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.9416675583542324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "5f6"+ "'", var4.equals("5f6"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 143);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     double var12 = var0.nextT(0.14961208608543997d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var0.nextPermutation(0, 10);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0667712762183498d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.17884888119806358d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.3250715326709295d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-596.7845051524192d));
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.4540416792480151d, 0.9948000358043659d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.4540416792480151d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.19048333f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-55258480997125034L));
    int var2 = var1.nextInt();
    float var3 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1665346298);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.6058011f);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(2.9031679812916723E-7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9999999999999578d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.8140149187445599d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs((-0.6686436237479013d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.6686436237479013d);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1737377827), (java.lang.Number)(-55258480997125034L), false);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     double var10 = var0.nextUniform(0.4540416792480151d, 1.4458039286025248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.2204504455203737d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "681"+ "'", var4.equals("681"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2177286606506965d);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.167472272076316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var9 = var2.nextPermutation(1146122894, 1413078328);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.002201246981949341d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2.657331226469821d));

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     var0.reSeed();
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var0.nextSample(var4, 503);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     int[] var17 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var22 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 6, 0, 1);
//     boolean var23 = var22.isSupportConnected();
//     int var24 = var22.sample();
//     int var25 = var22.getSampleSize();
//     int var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("a25", "681");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.686628298700702d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "67d"+ "'", var4.equals("67d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.292832721188187E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.1719697354010554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-2349309494509100384L));

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     int var12 = var2.nextBinomial(1, 0.031493100493387514d);
//     double var14 = var2.nextExponential(0.03408634154283945d);
//     double var18 = var2.nextUniform(0.7230896019545159d, 0.7800365586178574d, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.530681361120931E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.04015334158805609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.7250348506688564d);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.47348801367674015d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.47348801367674015d);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(3.4006531419542196d, 1.0121592249101665d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.009874359589718192d);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var11 = var0.nextPermutation((-2083745733), 1134509119);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.8202972454764327d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.19808850992563581d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.nextInt(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    double var12 = var1.nextGaussian();
    int var14 = var1.nextInt(715);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7700247882582713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 687);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(1.370316637323428E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.370316637323428E-9d);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }


    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)281614168, (java.lang.Number)0.18851783636889247d, var2);
    java.lang.Number var4 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     double var13 = var0.nextT(1.8210039787872987d);
//     double var16 = var0.nextBeta(1.3824846535938333d, 26.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-0.6817343684844458d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.00424048057217666d);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeedSecure(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextUniform(5.298292365610485d, (-57.29577951308232d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.831526405260244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bb9"+ "'", var4.equals("bb9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 8.872056182345882E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.4803285457976d);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     double var16 = var0.nextGamma(1.1521888852459421E-144d, 3.3433718707484554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0015122501221104393d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.9513406221111023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-4787408160038539288L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "3140a"+ "'", var11.equals("3140a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.17072816867202195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0d);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     long var20 = var0.nextLong((-4649104417600447144L), 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.06547008362712589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "32e"+ "'", var4.equals("32e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.117520913003792E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.8193708791871448d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-3857963799456177917L));
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
//     double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
//     double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
//     java.lang.String var11 = var2.nextSecureHexString(29);
//     double var13 = var2.nextExponential(2.286069913668499d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var2.nextUniform(0.18039163719555346d, 1.8417828359868464E-4d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.00797810778992547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "e1a57403b7ec207ad8536f009d49c"+ "'", var11.equals("e1a57403b7ec207ad8536f009d49c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.15208868127787076d);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    double var9 = var2.nextUniform(1.4382037266346042d, 66.89123388852185d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextHypergeometric(6, 440041583, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 35.13605081944778d);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.7700247882582713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(3.141592653589793d, 0.8152769730283367d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.316886621352482d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-0.6550803022373564d));
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    long var4 = var1.nextLong();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-6069125204240848293L));

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(1.5707963267948966d, 0.41933189414688476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.625804520144151d);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     int var16 = var0.nextBinomial(39, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(1665346298, 1.316886621352482d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "5ce"+ "'", var10.equals("5ce"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.07208168917108529d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)0.6253243595640073d, (java.lang.Number)0.40178331265804124d, false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    long var11 = var1.nextLong(26L);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9L);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     int var10 = var0.nextBinomial(147, 2.0910494117743932E-5d);
//     double var13 = var0.nextWeibull(1.7675901530199292d, 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.19257370967488874d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "10b"+ "'", var4.equals("10b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 64.02359586290171d);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    long var8 = var2.nextLong(9L, 11L);
    java.lang.String var10 = var2.nextHexString(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("f49f79f49d9d61b50e5508210f5c08b5e11ea35a4e82fec1bb5a2c4a1ba7a99a3abe0d26b860e941a76d1d33955ca105fbc9815333a3f719edfe9f3fe2416cf31a2781c7a58153a72b5bac741dfb4c457cec89fde392b6fcd7593dc44ed506a89eef5fce91953230a1fcbfb867525daaf49250367fe0c0cdc92fc8eea0a76d3cbd7bac1a311e34bacece016cea6f6f600e56f92806a1c00c89902aaef1fef63bbad2f66b76e5acbeba4d6cdaebc9e62ed23d789a095f762f554544c47a6f55f57af9153633d4dc9bcc36be07f369d4596097e5ffb296b40c16eafe02a84f200e21a99846c704a5c99675ac7f38eadabd0d70ba0699045d01550d0129444b957d3754cfcfbe864c73982e0e57f8e406767d4f4f10da28f78182d1362b9d8ac425f46de0184840b5dd439f84708af713f2fbee41bea36f5975ffde8e8fbb4f2eb947bc8deef89a0f6d0e53a8f426f5ec7a1f2bd3e0a82ad88bc1ea4b6e21e1139de539d0ce5ba8d25f5819b7ad6038a8bdc2b1fcc293b03c12640f2f7166e58a2e4135ee688dd1bc098fe90b9142b52b23c06ac41a500a227a8f9481d87a04d80a2507f5917e4a82e782a92544887b805889a9112d59c2f99231ac450c97bf486cde3f584ad39e5bc823cb9a24c452b0f9ca3beaa9e31c2c8e82cd82e9aaad419c977c36264a715db9fd0c4dd82068e7f93100136f9bffd6e5a04230fd218e74f0", "a25");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "342"+ "'", var10.equals("342"));

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var5 = var4.getSuppressed();
//     org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var5);
//     java.lang.String var7 = var6.toString();
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9.536743E-7f);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     long var20 = var0.nextLong(1L, 577710999442321806L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var0.nextUniform(0.6312190494145568d, 0.2223307850600497d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "064"+ "'", var10.equals("064"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5356303756265344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 998);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.3407807929942597E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 276042672928070924L);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(1.9073486E-6f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 9);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    double var1 = org.apache.commons.math3.util.FastMath.floor(10.886181290558456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(2.1831717298115714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.33908789895978414d);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var4 = var0.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8461248610895128d);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.6232857187980742d, 11.128184573958329d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 11.145625913305262d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.3010672345889634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.35130019259683d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-1267720276), 199, 207);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var3 = var1.nextLong(10L);
    org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var6 = var4.nextT(0.7635378011037546d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.04939738523446797d);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "868"+ "'", var10.equals("868"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.037468724019029405d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.5685258925938912d);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var4 = var1.nextLong(10L);
//     float var5 = var1.nextFloat();
//     byte[] var6 = null;
//     var1.nextBytes(var6);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.asin(1.479479851731295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     int var9 = var2.nextPascal(6, 1.4210854715202004E-14d);
//     var2.reSeedSecure(2548228850011803885L);
//     double var14 = var2.nextUniform((-5.214160383697379d), 0.0d);
//     var2.reSeedSecure((-194415137384884516L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-0.19986763567428228d));
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    org.apache.commons.math3.exception.util.ExceptionContext var10 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    var1.setSeed(3831766526879059053L);
    int var7 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 987587419);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    double var1 = org.apache.commons.math3.util.FastMath.rint(0.9458707273495791d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    double var2 = var1.nextDouble();
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 0, 397, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.1753021164154851d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(0.012829087820977834d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.012911733613348696d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var8 = var5.sample(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     int[] var17 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var17);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var22 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var18, 6, 0, 1);
//     boolean var23 = var22.isSupportConnected();
//     int var24 = var22.sample();
//     int var25 = var22.getSampleSize();
//     int var26 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var29 = var0.nextGamma((-4.719910314140863d), 1.0121592249101665d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2622662666088525d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "bb7"+ "'", var4.equals("bb7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.003934858029420922d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.25871880953638d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, var1);
//     java.lang.Number var3 = var2.getMin();
//     java.lang.String var4 = var2.toString();
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1024, (java.lang.Number)0.031493100493387514d, true);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)100.0d, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var6);
    org.apache.commons.math3.exception.MathInternalError var8 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSupportLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var5.inverseCumulativeProbability(30.973188990298414d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var8 = var2.nextExponential(1.1372214103398305E28d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.319995488080491E28d);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(1.3816923737356146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3233091055860727d);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.9815751f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    long var2 = org.apache.commons.math3.util.FastMath.max(0L, 7009605301686414442L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 7009605301686414442L);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getSupportUpperBound();
    double var15 = var5.upperCumulativeProbability(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var12 = var2.nextLong(26L, 16L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.18851783636889247d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10.801276386875394d);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     var2.reSeed();
//     int var10 = var2.nextInt(9, 1146122894);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextUniform(4.616457832727979E28d, 1.742022212531411d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 292240467);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.9815751f, 9.999999f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9815751f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var5 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    java.lang.Object[] var9 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var7, (java.lang.Number)100.0d, var9);
    java.lang.Throwable[] var11 = var10.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var5, (java.lang.Number)100L, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.04943097798541802d, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.NotFiniteNumberException var14 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)1.5111572E23f, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalArgumentException var15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var11);
    org.apache.commons.math3.exception.MathIllegalStateException var16 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.02567516585570634d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.233974192184279d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    var1.setSeed(9L);
    float var14 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8872303f);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.001426069753303551d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0014260707200251114d);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)0.17072816867202195d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.06934869829732719d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.06923784643353914d);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(143, 199, 102);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-1.0644436491518947d), 0.15262583023320947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextUniform(1.4100249074148754d, 66.89123388852185d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextT((-0.7225540191019567d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 57.8782148542884d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-3759508027876256838L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3759508027876256838L);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     int var10 = var0.nextBinomial(147, 2.0910494117743932E-5d);
//     double var13 = var0.nextUniform(0.3616878291415171d, 0.5123778273012989d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var16 = var0.nextSecureInt(2147483647, (-79134244));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.07348231664546219d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a83"+ "'", var4.equals("a83"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4189365822929346d);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.2579185699311153d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9932417666287611d));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    double var12 = var6.upperCumulativeProbability(207);
    var6.reseedRandomGenerator(31L);
    int var15 = var6.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.1622776601683795d, (java.lang.Number)(-0.0010733045953172857d), true);
    java.lang.Number var5 = var4.getMax();
    boolean var6 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-0.0010733045953172857d)+ "'", var5.equals((-0.0010733045953172857d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var9 = var8.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException(var4, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var3, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalStateException var12 = new org.apache.commons.math3.exception.MathIllegalStateException(var2, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, (java.lang.Object[])var9);
    org.apache.commons.math3.exception.MathIllegalArgumentException var14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, (java.lang.Object[])var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    var1.clear();
    int var6 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-79134244));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.220446049250313E-16d, (java.lang.Number)0.00752126284215363d, (java.lang.Number)1.1916061660198558d);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure((-1L));
//     int[] var18 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var19, 6, 0, 1);
//     boolean var24 = var23.isSupportConnected();
//     int var25 = var23.sample();
//     double var27 = var23.upperCumulativeProbability((-1));
//     double var28 = var23.getNumericalMean();
//     int[] var30 = var23.sample(1);
//     int var31 = var23.getSupportLowerBound();
//     double var33 = var23.probability(715);
//     int var34 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("838", "89c");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "8ba"+ "'", var10.equals("8ba"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6475950244240154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure((-1L));
//     int[] var18 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var19 = new org.apache.commons.math3.random.Well19937c(var18);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var23 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var19, 6, 0, 1);
//     boolean var24 = var23.isSupportConnected();
//     int var25 = var23.sample();
//     double var27 = var23.upperCumulativeProbability((-1));
//     double var28 = var23.getNumericalMean();
//     int[] var30 = var23.sample(1);
//     int var31 = var23.getSupportLowerBound();
//     double var33 = var23.probability(715);
//     int var34 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var37 = var0.nextSecureLong(2548228850011803885L, 343034188110465231L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "608"+ "'", var10.equals("608"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0856294837391268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 672);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)2.1831717298115714d, (java.lang.Number)100, (java.lang.Number)0.08111900113979116d);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100+ "'", var4.equals(100));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0010733045953172857d), (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)3, (java.lang.Object[])var4);
    java.lang.Number var7 = var6.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 3+ "'", var7.equals(3));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    double var5 = var1.nextGaussian();
    int[] var6 = new int[] { };
    org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var6);
    var1.setSeed(var6);
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(6);
    long var11 = var10.nextLong();
    double var12 = var10.nextGaussian();
    float var13 = var10.nextFloat();
    double var14 = var10.nextGaussian();
    int[] var15 = new int[] { };
    org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
    var10.setSeed(var15);
    var1.setSeed(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     double var19 = var0.nextT(1.6845993484197912E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9987546359241628d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9a5"+ "'", var4.equals("9a5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 7.867655037594576E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.0768010541618303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1.3407807929942273E154d));
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int var11 = var5.sample();
    int var12 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure((-343034188110465231L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    double var12 = var5.cumulativeProbability(563228325);
    double var13 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)19.0d, (java.lang.Number)17, false);
    boolean var4 = var3.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    long var5 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2419047238712938144L);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Object[] var4 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)100.0d, var4);
    java.lang.Throwable[] var6 = var5.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.7432415f, (java.lang.Object[])var6);
    java.lang.Number var8 = var7.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.7432415f+ "'", var8.equals(0.7432415f));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)5.011012903266713E-4d);
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextInt(0, (-16849120));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    double var1 = org.apache.commons.math3.util.FastMath.acos((-0.6751447494035615d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.3119572324656517d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     int var14 = var2.nextBinomial(0, 0.5148401381795025d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var2.nextInt(987587419, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9.568906036844316d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.23194910076661474d, 2429.182726643309d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    double var7 = var1.nextDouble();
    long var9 = var1.nextLong(10L);
    long var11 = var1.nextLong(26L);
    long var12 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.13813975938570944d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-6052487647205118893L));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var2.nextPoisson(1.0299461408566821d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     java.lang.String var10 = var2.nextSecureHexString(26);
//     double var13 = var2.nextUniform(4.440892098500626E-16d, 1.0821957873042685d);
//     double var16 = var2.nextCauchy(19.309391629693934d, 0.24586382473244683d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var2.nextUniform(1.876784835166937d, 0.8140149187445599d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "26675ff5561bf3389073d8d716"+ "'", var10.equals("26675ff5561bf3389073d8d716"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.0424072053895674d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 18.952859919268164d);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
//     double var16 = var2.nextGamma(1.8348931695478938d, 0.5418954798163614d);
//     int var19 = var2.nextSecureInt(0, 364);
//     int var22 = var2.nextSecureInt(0, 236);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.925797012802406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.46511422979512007d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 179);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 108);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var20 = var0.nextInt(1413078328, (-16849120));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "935"+ "'", var10.equals("935"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6705007289609038d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 795);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3407807929942597E154d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     int var16 = var0.nextPascal(17, 0.4484441139355288d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.3145794197714908d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a4d"+ "'", var4.equals("a4d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2.4081525086373747E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.311019112572912d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.873060404051843d);
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var7 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var3, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
    var2.addSuppressed((java.lang.Throwable)var7);
    java.lang.Throwable[] var9 = var7.getSuppressed();
    java.lang.Number var10 = var7.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0f)+ "'", var10.equals((-1.0f)));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(9.999999f, 0.4997320104385629d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999998f);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    double var12 = var1.nextGaussian();
    boolean var13 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7700247882582713d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-57.29577951308232d), 1.4862784988981086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6690819439439122d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
    java.lang.Throwable[] var5 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed((-2349309494509100384L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.4522501851384604d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "589"+ "'", var4.equals("589"));
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.3816923737356146d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    double var14 = var5.upperCumulativeProbability(281614168);
    int var15 = var5.getSampleSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Throwable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    int[] var3 = new int[] { };
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
    org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
    boolean var9 = var8.isSupportConnected();
    int var10 = var8.sample();
    double var12 = var8.upperCumulativeProbability((-1));
    double var13 = var8.getNumericalMean();
    int[] var15 = var8.sample(1);
    int var16 = var8.getPopulationSize();
    java.lang.Object[] var17 = new java.lang.Object[] { var8};
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var2, var17);
    org.apache.commons.math3.exception.MathIllegalArgumentException var19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     long var20 = var0.nextLong(1L, 577710999442321806L);
//     var0.reSeed(1L);
//     org.apache.commons.math3.distribution.RealDistribution var23 = null;
//     double var24 = var0.nextInversionDeviate(var23);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    java.lang.String var6 = var4.nextHexString(26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setSecureAlgorithm("a2a8c6fb36ad8bdd23d3adffbb", "f09");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "c4ea07f27632d20502d1defb23"+ "'", var6.equals("c4ea07f27632d20502d1defb23"));

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     double var12 = var0.nextCauchy(0.8394859904584389d, 3.141592653589793d);
//     int[] var15 = var0.nextPermutation(10, 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("96e", "9c8");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.2590313821525685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.4331627733373298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 13L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.651369377311739E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-7.1721785240800155d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     java.lang.String var14 = var0.nextSecureHexString(147);
//     double var17 = var0.nextBeta(12.978452428686579d, 2.8058364697442126d);
//     double var19 = var0.nextExponential(0.4265203093171999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "c77"+ "'", var10.equals("c77"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0880328565492918d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "1053a6daafc5317adccf3c925119d387399ac0796c5895401c7c81990b81cf228d3f9c34afc0cc7dd6cb07686156ce6b88f372a3ae7ff59a569e19080f3abba70aa3911078dc1ffb5f5"+ "'", var14.equals("1053a6daafc5317adccf3c925119d387399ac0796c5895401c7c81990b81cf228d3f9c34afc0cc7dd6cb07686156ce6b88f372a3ae7ff59a569e19080f3abba70aa3911078dc1ffb5f5"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9277207344782321d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.03673576304862897d);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     double var6 = var0.nextExponential(Double.POSITIVE_INFINITY);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull(0.0d, 0.1306629546226212d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5078434992733856d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.7565041176736462d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, 1632050914, 9, (-127));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(503, 732);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 503);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    double var10 = var2.nextWeibull(3.4724687469699105d, 15.925797012802406d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var12 = var2.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 23.729908791521954d);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     var2.reSeed();
//     int var10 = var2.nextInt(9, 1146122894);
//     double var13 = var2.nextGaussian(3.968056069960501d, 0.4997320104385629d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 356759443);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 3.8828873801456796d);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)12.742325413815996d, (java.lang.Number)25.99999999999489d, false);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt((-0.22007267450553075d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6037475394275218d));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var2.nextSecureLong(19L, (-55258480997125034L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    double var14 = var5.probability(715);
    double var16 = var5.upperCumulativeProbability((-1023));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh((-0.7835436474897771d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.3230004020298016d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(119.87204169238177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6868.162070589718d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.14837206047126122d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.14837206047126122d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     int var10 = var0.nextBinomial(147, 2.0910494117743932E-5d);
//     double var13 = var0.nextUniform(0.3616878291415171d, 0.5123778273012989d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var15 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5636000654793701d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "875"+ "'", var4.equals("875"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.42035141542101445d);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var3 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(byte)10);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-0.0010733045953172857d), (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NotFiniteNumberException var6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)3, (java.lang.Object[])var4);
    org.apache.commons.math3.exception.NumberIsTooLargeException var10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var12 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-11.35464876064149d));
    var10.addSuppressed((java.lang.Throwable)var12);
    java.lang.String var14 = var10.toString();
    var6.addSuppressed((java.lang.Throwable)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 3.162 is larger than, or equal to, the maximum (0)"+ "'", var14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 3.162 is larger than, or equal to, the maximum (0)"));

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    int var6 = var5.getNumberOfSuccesses();
    int var7 = var5.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    double var11 = var6.upperCumulativeProbability(1);
    double var12 = var6.getNumericalMean();
    int var13 = var6.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     int var20 = var0.nextInt(364, 440041583);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.27754671516368096d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "f49"+ "'", var4.equals("f49"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 6.165998550728478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.4783298214134946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 422573888);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var3.reSeed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(0.07490127724881365d, 14.975162885657241d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 14.975162885657241d);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians((-57.29577951308232d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.0d));

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-1433502403876603448L));
    java.lang.Number var2 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 0+ "'", var2.equals(0));

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextChiSquare(23.729908791521954d);
//     double var12 = var0.nextExponential(1.8210039787872987d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6792535199115233d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0de"+ "'", var4.equals("0de"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 30.350463920422605d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.6531967712257384d);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }


    float var1 = org.apache.commons.math3.util.FastMath.ulp(0.6058011f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5.9604645E-8f);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.41933189414688476d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.007318722211487477d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    double var11 = var6.upperCumulativeProbability(1);
    double var12 = var6.getNumericalMean();
    int var13 = var6.getSupportLowerBound();
    boolean var14 = var6.isSupportConnected();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     int var12 = var2.nextInt(17, 100);
//     int var15 = var2.nextInt(270, 500);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.07184024675286484d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 453);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-16849120), 440041583);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-16849120));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }


    double var2 = org.apache.commons.math3.util.FastMath.min(19.274896820740654d, 0.3010672345889634d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.3010672345889634d);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign(0.8605623f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8605623f);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    double var4 = var1.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9815751184692503d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.06934869829732719d, (java.lang.Number)1.1996792375614571d, (java.lang.Number)19L);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     java.lang.Throwable var6 = null;
//     org.apache.commons.math3.exception.util.Localizable var7 = null;
//     int[] var8 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var9 = new org.apache.commons.math3.random.Well19937c(var8);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var13 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var9, 6, 0, 1);
//     boolean var14 = var13.isSupportConnected();
//     int var15 = var13.sample();
//     double var17 = var13.upperCumulativeProbability((-1));
//     double var18 = var13.getNumericalMean();
//     int[] var20 = var13.sample(1);
//     int var21 = var13.getPopulationSize();
//     java.lang.Object[] var22 = new java.lang.Object[] { var13};
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException(var6, var7, var22);
//     org.apache.commons.math3.exception.MathIllegalStateException var24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, var22);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.6058011f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.0010733045953172857d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.001073305007460365d));

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(18.68288699366835d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2997945870518182E8d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.39434982251580614d, 3.3433718707484554d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.39434982251580614d);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var17 = var0.nextGamma(0.04943097798541802d, 57.8782148542884d);
//     var0.reSeedSecure((-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "516"+ "'", var10.equals("516"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.09672944951672298d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.05022688870834958d);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(732);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(0.8872303f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8872303f);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var9 = var6.nextInt(102, 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 376458525);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var7 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 422573888, 45, (-188551922));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(613248789088187663L);
    var2.reSeed();

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(2.78527454092035d, 1.1336467843554507d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.12245825571939604d);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    double var1 = org.apache.commons.math3.util.FastMath.sqrt(11.349316962981089d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.3688747324560895d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    var1.setSeed(9L);
    org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var15 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.9987546359241628d);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    var2.reSeed(2419047238712938144L);
    double var12 = var2.nextF(0.4681888166880769d, 1.9581294241070768d);
    double var15 = var2.nextGaussian(5.395512929437507d, 3.968056069960501d);
    double var19 = var2.nextUniform(0.35130019259683d, 5.934367433599625d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var2.nextSecureInt(376458525, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.936138296956352d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.5136451675886344d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.6963340289321303d);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.39823927240827994d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.3884000293897739d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(125, 26, 1413078328);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    double var14 = var5.upperCumulativeProbability(281614168);
    int var15 = var5.getSupportLowerBound();
    var5.reseedRandomGenerator(2241856882564607076L);
    var5.reseedRandomGenerator((-1486998192385879714L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(0.0d, 0.8850169682561488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)86, (java.lang.Number)0.1306629546226212d, true);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     var0.reSeed();
//     double var18 = var0.nextGamma(0.1306629546226212d, 0.7216599837973326d);
//     int var21 = var0.nextSecureInt((-79134244), 6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = var0.nextPermutation(1146122894, 1632050914);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 293432690371673867L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5.1840676474993845E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-73536463));
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)577710999442321806L);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    double var1 = org.apache.commons.math3.util.FastMath.acosh(4.609715589221844d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.209335121995391d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     long var12 = var0.nextLong((-214947668324021772L), 8L);
//     double var15 = var0.nextCauchy(10.90009547671185d, 0.019948546946239154d);
//     double var18 = var0.nextWeibull(10778.571382009482d, 64.02359586290171d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextHypergeometric(2, (-597052871), (-6));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5383417966534838d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.5845262640403825d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3675672002549652467L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-63474844660315454L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.903770930788552d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 64.02164672231139d);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var22 = var17.sample();
//     int var23 = var17.getNumberOfSuccesses();
//     int var24 = var17.getSupportUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "b86"+ "'", var10.equals("b86"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(2.0000002f, 1132524014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    double var9 = var2.nextUniform((-0.9262160379374064d), 2.9748236757560673d, false);
    org.apache.commons.math3.random.RandomGenerator var10 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextPascal(327709799, 2.4522501851384604d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0821957873042685d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.9609202961889456d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8534683546359614d);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)7.02545717536151d, (java.lang.Number)2.1831717298115714d, true);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2676508E30f);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var3.reSeedSecure();
    long var7 = var3.nextLong((-214947668324021772L), 31L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-6798055552557696L));

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    double var11 = var6.cumulativeProbability(3, 1024);
    int var12 = var6.getSupportLowerBound();
    int var13 = var6.getSupportUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, 397);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextExponential(0.6820038473615311d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var7 = var0.nextPermutation((-1023), 39);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.011451435190121394d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.4722326548923317d);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.3816923737356146d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1L);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
//     int var11 = var2.nextSecureInt(0, 6);
//     int var14 = var2.nextInt((-1413078328), 0);
//     java.util.Collection var15 = null;
//     java.lang.Object[] var17 = var2.nextSample(var15, (-56171189));
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }


    double var1 = org.apache.commons.math3.util.FastMath.toDegrees(0.03132321019379296d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.7946877449054939d);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.05034846331660371d, (java.lang.Number)(-584986072174970266L), (java.lang.Number)5.960465E-8f);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-584986072174970266L)+ "'", var4.equals((-584986072174970266L)));

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(15L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 15L);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int var11 = var5.getNumberOfSuccesses();
    double var12 = var5.getNumericalMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     int var11 = var2.nextBinomial(5, 0.07180988227597636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextSecureInt((-16849120), (-2083745733));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(12L);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.7450520880645612d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.29430114618146475d));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    double var8 = var2.nextUniform(0.0d, 18.58616942859271d);
    double var11 = var2.nextGaussian(2.974823675756067d, 0.9040580270688509d);
    long var14 = var2.nextLong(9L, 31L);
    var2.reSeedSecure(0L);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var20 = var2.nextBeta((-0.9262160379374064d), (-11.0d));
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9.568906036844316d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.847732150080772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 26L);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(1.8348931695478938d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.2242504190122387d);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.4210855E-14f);
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var1.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)100.0d, var6);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)2.161909012740015d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1.3816923737356146d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)(-8));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    var2.reSeedSecure();
    var2.reSeedSecure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
    java.lang.Number var5 = var4.getLo();
    java.lang.Number var6 = var4.getLo();
    java.lang.Number var7 = var4.getLo();
    java.lang.Number var8 = var4.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.8152769730283367d+ "'", var5.equals(0.8152769730283367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.8152769730283367d+ "'", var6.equals(0.8152769730283367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.8152769730283367d+ "'", var7.equals(0.8152769730283367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.8152769730283367d+ "'", var8.equals(0.8152769730283367d));

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     int var17 = var8.getNumberOfSuccesses();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var8.cumulativeProbability(364, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.17305115828338244d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.23194910076661474d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.22987486320805342d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 1);
//     double var15 = var2.nextWeibull(0.48426586993164683d, 2.78527454092035d);
//     double var18 = var2.nextCauchy(1.734723475976807E-18d, 1.6845993484197912E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2.1951970479591294d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.7904776031539309E-6d);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-126731243878266010L));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var11 = var0.nextCauchy(0.23194910076661474d, 4.609715589221844d);
//     double var13 = var0.nextT(3.4006531419542196d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.004591489248785328d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "66c"+ "'", var4.equals("66c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.08590185157504787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.148628176310107d);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.9899924966004454d));

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.27873123f, 0.06547008362712589d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2787312f);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextGamma(0.0d, 1.0294368809983006E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "cfd"+ "'", var10.equals("cfd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.03724810434920715d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 837);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 0.03167492013216357d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(2.3283872144743825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextWeibull(30.973188990298414d, 18.58616942859271d);
    double var11 = var2.nextExponential(0.05547762620443311d);
    double var13 = var2.nextT(0.04943097798541802d);
    double var15 = var2.nextChiSquare(2.78527454092035d);
    double var17 = var2.nextT(0.003787966974016121d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 18.392781021818884d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0673006305030055d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.1372214103398305E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.8247062529561346d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.3407807929942314E154d));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }


    float var2 = org.apache.commons.math3.util.FastMath.nextAfter(Float.POSITIVE_INFINITY, 0.12245825571939604d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 3.4028235E38f);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal((-8), 2.6251584714114255E-7d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    double var10 = var2.nextWeibull(3.4724687469699105d, 15.925797012802406d);
    double var13 = var2.nextGaussian(0.0d, 0.3616878291415171d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 23.729908791521954d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-0.36646562969203167d));

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    int var11 = var5.sample();
    double var12 = var5.getNumericalMean();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var5.inverseCumulativeProbability(3.215307210570628d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     var0.reSeedSecure();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var12 = var0.nextPermutation(12, 500);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.4039802407402935d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "52a"+ "'", var4.equals("52a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    var1.clear();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    long var7 = var6.nextLong();
    double var8 = var6.nextGaussian();
    byte[] var12 = new byte[] { (byte)0, (byte)0, (byte)1};
    var6.nextBytes(var12);
    var1.nextBytes(var12);
    long var15 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2419047238712938144L);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(30.9570417874309d, 0.8850169682561488d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 30.969689879991442d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var4 = var1.nextLong(10L);
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var7 = new int[] { };
    var6.setSeed(var7);
    byte[] var9 = new byte[] { };
    var6.nextBytes(var9);
    var1.nextBytes(var9);
    double var12 = var1.nextGaussian();
    org.apache.commons.math3.random.RandomDataGenerator var13 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-51616135), 281614168, 2);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.7700247882582713d);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 1);
//     double var14 = var2.nextExponential(0.04015334158805609d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.007211407955966349d);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-11.35464876064149d));
    var3.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var7 = var3.getMax();
    java.lang.Number var8 = var3.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0L+ "'", var7.equals(0L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0L+ "'", var8.equals(0L));

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    double var1 = org.apache.commons.math3.util.FastMath.asin(2.8961942241580267E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.896194224562912E-5d);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     int var9 = var0.nextSecureInt((-2), 0);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0028189382685788436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "6fe71064007bac00b9c076e29615ee08a67d85eaadcb3f14af43f22da2a630c7a245a2b2c27bcb6db7027318570261c292fd3bc2a973cd5231f70a66f46ef6a344f8d3e3af488f9c73fb554f426fbb84247b933afab6b80ef9017f5a9e4a84d191f8723ee343b8c708fa68e2e980510899fa996d8dff405e5329b37938e47c0b53e933a41d7ae89a707f2110d11702673dd0c91e582d8c487f39ddfee12127a65b97ba976e8d87b7cf89daa3c038b0153845383179bfb1a30d8fd8db96dc84b3107898dca07b58690ee41585908dce7b07c419f9355320599ac3b81b9ec5a735949d0213d13cb2591e924c9a228ecfadd31b85be3a6988869774538c4c54563df14a5483926949f3cd59ed58562d6a50ea6cb83b35b8e2969a6707b2880a45f88358ab47a332a9dd5b2bd6a1c1af96521ca9756aa7537075d8fd10288135eca504a9ba797ff05ae009a4efee2303bbf133cc1682d310ed14f1a4d5a484e22c0bb82fcafd3c2d56e28348bca6156ad9dd6bb8ccf04e3d72308a1b89f901359b45462cf754cc13d5c8e1f9d563b5f10df14ca789c69d78c7c5210f8be168866d73597c5792fb34c96bf6f2eb74c0921d1afe3d15e4d504699061093174ded942e1f2787ad70cc8fef8ffa6b79e7737c6f18a849bb3779ff7f03896b6b8b878bb2bebfd7ba2db302a8b09182ebc9f4e87b0e455b8430db3d529ff33c5334903c7c0"+ "'", var4.equals("6fe71064007bac00b9c076e29615ee08a67d85eaadcb3f14af43f22da2a630c7a245a2b2c27bcb6db7027318570261c292fd3bc2a973cd5231f70a66f46ef6a344f8d3e3af488f9c73fb554f426fbb84247b933afab6b80ef9017f5a9e4a84d191f8723ee343b8c708fa68e2e980510899fa996d8dff405e5329b37938e47c0b53e933a41d7ae89a707f2110d11702673dd0c91e582d8c487f39ddfee12127a65b97ba976e8d87b7cf89daa3c038b0153845383179bfb1a30d8fd8db96dc84b3107898dca07b58690ee41585908dce7b07c419f9355320599ac3b81b9ec5a735949d0213d13cb2591e924c9a228ecfadd31b85be3a6988869774538c4c54563df14a5483926949f3cd59ed58562d6a50ea6cb83b35b8e2969a6707b2880a45f88358ab47a332a9dd5b2bd6a1c1af96521ca9756aa7537075d8fd10288135eca504a9ba797ff05ae009a4efee2303bbf133cc1682d310ed14f1a4d5a484e22c0bb82fcafd3c2d56e28348bca6156ad9dd6bb8ccf04e3d72308a1b89f901359b45462cf754cc13d5c8e1f9d563b5f10df14ca789c69d78c7c5210f8be168866d73597c5792fb34c96bf6f2eb74c0921d1afe3d15e4d504699061093174ded942e1f2787ad70cc8fef8ffa6b79e7737c6f18a849bb3779ff7f03896b6b8b878bb2bebfd7ba2db302a8b09182ebc9f4e87b0e455b8430db3d529ff33c5334903c7c0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "32115b"+ "'", var6.equals("32115b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2));
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var15 = var0.nextChiSquare(5.298342365610589d);
//     var0.reSeed();
//     var0.reSeed();
//     double var20 = var0.nextGamma(10.903155589330058d, 0.792126722906372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.07045687870086555d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "9dc"+ "'", var4.equals("9dc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 5.877968844828481E-6d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.8330570943101214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.530570867969733d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 9.329378986158627d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)1.0f, var2, false);
    boolean var5 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.4382037266346042d, (java.lang.Number)2.9489244855586554d, false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.016070048990239574d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.804752658364707E-4d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomDataGenerator var3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var1.nextInt(356759443);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 13906712);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var4.nextInt(281614168, 1132524014);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 391442915);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
//     double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
//     double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
//     java.lang.String var11 = var2.nextSecureHexString(29);
//     double var14 = var2.nextF(0.6690819439439122d, 1.7538036993385602d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 66.89123388852185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.00797810778992547d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "d2b4ed9636ab7819561f22c3b24b8"+ "'", var11.equals("d2b4ed9636ab7819561f22c3b24b8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 75.91055213056157d);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1665514280923435908L), var1, false);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs(1228372035613083129L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1228372035613083129L);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     int var9 = var2.nextPascal(6, 1.4210854715202004E-14d);
//     long var12 = var2.nextLong((-7034676902218012687L), 26L);
//     double var14 = var2.nextChiSquare(1.7254007680220103d);
//     double var17 = var2.nextCauchy(0.9714897973416567d, 0.006493101352562512d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-5510741753851645455L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.28320654578796184d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.9747575540282892d);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextGaussian(2.0000000000000004d, 1.4382037266346042d);
    double var11 = var2.nextT(0.05022688870834958d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.00797810778992547d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 3.9799861524408863E27d);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     var0.reSeed((-6798055552557696L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.03975222781371839d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e1cd7b0bc176737588c05da61229ccfaac477d35064306b38cbafb2a0df6c837d06562493f59799d94488dc317a459710b5d04fdd4742650696bf1eb6674a992492af50b1bf155b094d2342853555ba4d94bc3aafecb299149dbda2c1374463967450ce2ebae69dbb8117ea3d984ac84a675a5f827eb94ea2185b0ef32f4365dd159d81dd86b685ee6e63f4815142ec6af716986c84e28de3e9ba89be5bb0ea666abde885f1b420e3dbd1b5d326fe8c763561f0bc600c5d217d809c1ce4881583014e25e0fe0ac1b38f566aa6a61036c93a31dff3deeb9c78ef1354f1cb040fa1b9e74959829e1da227800fbb77ebd6f89ac6207cc777212a1506345a9d7489c26f89f5358c637d70201e507795c509c48e3a54a1ba329f2baabfff571b12acd3b146433d5d4c0674c85ccef796b72a01c8a9def40aee1ac35bec5eb66e62f1d99b968a3ac0007a0fae8dc1880217657bd2ca7816907dcc5cd906702a31e9c54a838c148a479a4cacb2cdfe7c33d3b0d6346b3bc1ab4cf0c9f306a72e15b970f2e4d39b34a6aab932d01239e0fc67f7def51e9da495cc4ba797374a54ffee2bf8b380ef0559c3b616c5304055b2416df396c9b7935029cac050a3a64ff8493f1b5fb10e9d4ebf4cf5e9f7b2c3f2ce479a830367fa53b9bd72ed6b5a5a53cba74579ca04108c47de79e70ffff277b004c5479ec53884b6462cbe2bd191e83dec3"+ "'", var4.equals("e1cd7b0bc176737588c05da61229ccfaac477d35064306b38cbafb2a0df6c837d06562493f59799d94488dc317a459710b5d04fdd4742650696bf1eb6674a992492af50b1bf155b094d2342853555ba4d94bc3aafecb299149dbda2c1374463967450ce2ebae69dbb8117ea3d984ac84a675a5f827eb94ea2185b0ef32f4365dd159d81dd86b685ee6e63f4815142ec6af716986c84e28de3e9ba89be5bb0ea666abde885f1b420e3dbd1b5d326fe8c763561f0bc600c5d217d809c1ce4881583014e25e0fe0ac1b38f566aa6a61036c93a31dff3deeb9c78ef1354f1cb040fa1b9e74959829e1da227800fbb77ebd6f89ac6207cc777212a1506345a9d7489c26f89f5358c637d70201e507795c509c48e3a54a1ba329f2baabfff571b12acd3b146433d5d4c0674c85ccef796b72a01c8a9def40aee1ac35bec5eb66e62f1d99b968a3ac0007a0fae8dc1880217657bd2ca7816907dcc5cd906702a31e9c54a838c148a479a4cacb2cdfe7c33d3b0d6346b3bc1ab4cf0c9f306a72e15b970f2e4d39b34a6aab932d01239e0fc67f7def51e9da495cc4ba797374a54ffee2bf8b380ef0559c3b616c5304055b2416df396c9b7935029cac050a3a64ff8493f1b5fb10e9d4ebf4cf5e9f7b2c3f2ce479a830367fa53b9bd72ed6b5a5a53cba74579ca04108c47de79e70ffff277b004c5479ec53884b6462cbe2bd191e83dec3"));
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    long var9 = var6.nextLong(26L, 4137880971203176105L);
    double var12 = var6.nextUniform((-0.9513406221111023d), 3.552713678800501E-15d);
    double var14 = var6.nextChiSquare(1.9668566104518523d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3831766526879059053L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.8239521269796352d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 5.216539583593347d);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(4.67271537421983E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextF(0.04015334158805609d, Double.NaN);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var11 = var5.cumulativeProbability(10, 17);
    int var12 = var5.getNumberOfSuccesses();
    int var13 = var5.getSupportUpperBound();
    boolean var14 = var5.isSupportConnected();
    int var16 = var5.inverseCumulativeProbability(4.9E-324d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8872303f);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    var0.reSeedSecure((-7113760168377139929L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.nextUniform(1.3230004020298016d, 0.20650036564733387d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var7 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)100.0d, var6);
    java.lang.Throwable[] var8 = var7.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)100L, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.04943097798541802d, (java.lang.Object[])var8);
    org.apache.commons.math3.exception.MathIllegalStateException var11 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    double var2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.936138296956352d, (-3.461368137530299d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4747701594260527d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    long var9 = var2.nextPoisson(0.24542394462207118d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-0.6084426608200659d), (java.lang.Number)0.05036975957415425d, true);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }


    double var2 = org.apache.commons.math3.util.FastMath.log(0.0d, 2.060554502158076d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-0.0d));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.61864936f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.61864936f);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     double var20 = var0.nextBeta(3.659423199395708d, 0.20650036564733387d);
//     var0.reSeed((-2081060580518884217L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "e36"+ "'", var10.equals("e36"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.507861673479688d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 564);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.9918752809834485d);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    org.apache.commons.math3.exception.NotStrictlyPositiveException var5 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)(-11.35464876064149d));
    var3.addSuppressed((java.lang.Throwable)var5);
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var12 = var11.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var7, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextExponential(0.5418954798163613d);
//     long var13 = var0.nextLong(19L, 153907406580627565L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7.385056873520985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a5c"+ "'", var4.equals("a5c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9659307075186127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 28999821043157547L);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     var0.reSeedSecure(10L);
//     double var20 = var0.nextGaussian(0.0d, 1.0821957873042685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "05a"+ "'", var10.equals("05a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.13954974695788333d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.8489671157925772d);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)2.477700611594034d, var2, true);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    long var4 = var1.nextLong();
    org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(6);
    long var7 = var6.nextLong();
    double var8 = var6.nextGaussian();
    byte[] var12 = new byte[] { (byte)0, (byte)0, (byte)1};
    var6.nextBytes(var12);
    var1.nextBytes(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.nextInt((-8));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    double var1 = org.apache.commons.math3.util.FastMath.sin(0.9594552990421228d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8188790499039597d);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(0.5247304743765772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.009158274463423011d);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)2.8822137015004015d, (java.lang.Number)9.317898532933117E29d, false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    double var6 = var5.getNumericalVariance();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var9 = var5.getNumericalVariance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     var0.reSeed();
//     int var8 = var0.nextPascal(1, 0.0d);
//     double var10 = var0.nextChiSquare(23.729908791521954d);
//     long var12 = var0.nextPoisson(0.8850169682561488d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.48413030032922305d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "532"+ "'", var4.equals("532"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 18.45996423725697d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0L);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    float var2 = org.apache.commons.math3.util.FastMath.copySign((-1.0f), 0.61864936f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0f);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     var8.reseedRandomGenerator((-6798055552557696L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.9208418868014623d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.3433718707484554d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
    var2.reSeed((-4649104417600447144L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8201071802366467d);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeedSecure();
//     long var9 = var2.nextSecureLong((-4740792029645458057L), 13L);
//     var2.reSeed(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-278974959396645380L));
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     double var16 = var0.nextWeibull(0.7450520880645611d, 2.9489244855586554d);
//     int var19 = var0.nextInt(4, 9);
//     double var21 = var0.nextT(3.942186149242891d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "f8a"+ "'", var10.equals("f8a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.08884947924821136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0011645467487367844d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-0.21515703973512715d));
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     int var2 = var1.nextInt();
//     int[] var3 = null;
//     var1.setSeed(var3);
//     double var5 = var1.nextDouble();
//     var1.setSeed(15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1413078328));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.26640184265662437d);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }


    float var1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1(1.4187781918456641d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.1320687594828374d);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.8872303f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.2787312f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-2));

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeedSecure();
//     double var16 = var0.nextT(0.26234589613270526d);
//     long var19 = var0.nextSecureLong((-339878989410455899L), 8L);
//     double var22 = var0.nextBeta(0.6111282050782465d, 0.6153990834719214d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "462"+ "'", var10.equals("462"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.06879870822598295d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-5014.395198978923d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-14515742731500709L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.6528864491099772d);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(3.432600494654796d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.287317754626317d);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextWeibull(2.161909012740015d, 5.616474220487839E28d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextSecureInt(13906712, 715);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.870145190617211E28d);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)11L);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(1.7877593912976595d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2L);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(31.4104f, 5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31.4104f);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var2.nextPascal((-1737377827), 3.993369341651611E-5d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     var2.reSeedSecure(4137880971203176105L);
//     java.lang.String var12 = var2.nextHexString(1024);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var15 = var2.nextPermutation(440041583, 897);
//       fail("Expected exception of type java.lang.OutOfMemoryError");
//     } catch (java.lang.OutOfMemoryError e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "93b3df2d56534b467f339e66e21b949dff29428e82ba19185b4f75e34dd7cc60ceed2e077bb4bda2fc89701136d552acb29282239c24b323e5ea01d66c2ead044a3e6142484620fbd0f0e4fb9b89097d613e9a18a309ef34419eae7e16841a84ed0fb98bbe41c6246455d0cd19fa6958088e61bd24dd10b99e04d7dffec17353c1e242a0364e04ef863d9a8bece948fcdea81cc6b7f030ff9a533da591414b8e3fb0b54e4e91090e09427be57b1c5b44b666c6441de582b22b69a82eb355b44fc46cf232c61084a00ddef17ce97c863b4a72520eef5f19f5b0db8664cc43b71938d35e2cd73a6611f60796bccd9d6d60a90e51bc4cad7a4a7003ad915e3db9856a52fa8c351a30ebb8a73a89ec7cbedca93f35ced1320f0136f3db51d4f4858f7e2e0f816cf0ee418ae3748b3841426e8fcb8877884b6d2cd7128c4f0704e6c65f572d9bbfa70ace9a5a2ed8e10578dc4a6fe623fef0f90fa7b5f716df65250fa2590254b734417dbadfac06e0c10bcf1ec086af3994d77eb6c0a999061692494e3774b179e8f23f0e5d2517f7f1f5b59dba3c8f667809ff7432454728677a68c3b6cb1427fba723dedab9305bba88780dce44a1f5ebf1af73900747230b72bcfc68dfda2808f77e8d560520b489f205901cabb59f513e79fcd16070a06ef3be8990393e537ab97c7094f02efb71bf62b11732e498e3c5c769d1c50dcbf64b5d"+ "'", var12.equals("93b3df2d56534b467f339e66e21b949dff29428e82ba19185b4f75e34dd7cc60ceed2e077bb4bda2fc89701136d552acb29282239c24b323e5ea01d66c2ead044a3e6142484620fbd0f0e4fb9b89097d613e9a18a309ef34419eae7e16841a84ed0fb98bbe41c6246455d0cd19fa6958088e61bd24dd10b99e04d7dffec17353c1e242a0364e04ef863d9a8bece948fcdea81cc6b7f030ff9a533da591414b8e3fb0b54e4e91090e09427be57b1c5b44b666c6441de582b22b69a82eb355b44fc46cf232c61084a00ddef17ce97c863b4a72520eef5f19f5b0db8664cc43b71938d35e2cd73a6611f60796bccd9d6d60a90e51bc4cad7a4a7003ad915e3db9856a52fa8c351a30ebb8a73a89ec7cbedca93f35ced1320f0136f3db51d4f4858f7e2e0f816cf0ee418ae3748b3841426e8fcb8877884b6d2cd7128c4f0704e6c65f572d9bbfa70ace9a5a2ed8e10578dc4a6fe623fef0f90fa7b5f716df65250fa2590254b734417dbadfac06e0c10bcf1ec086af3994d77eb6c0a999061692494e3774b179e8f23f0e5d2517f7f1f5b59dba3c8f667809ff7432454728677a68c3b6cb1427fba723dedab9305bba88780dce44a1f5ebf1af73900747230b72bcfc68dfda2808f77e8d560520b489f205901cabb59f513e79fcd16070a06ef3be8990393e537ab97c7094f02efb71bf62b11732e498e3c5c769d1c50dcbf64b5d"));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeed();
//     long var9 = var2.nextPoisson(0.4593664907342236d);
//     org.apache.commons.math3.random.RandomGenerator var10 = var2.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     var2.reSeed();
//     int var11 = var2.nextBinomial(5, 0.07180988227597636d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextZipf(352, (-397.8191812788444d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     java.lang.String var11 = var0.nextHexString(5);
//     double var13 = var0.nextChiSquare(1.4458039286025248d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextF((-3.461368137530299d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.5635236631848677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.9017308439616422d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3235874341503958926L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "0cede"+ "'", var11.equals("0cede"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1.3632733824538248d);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    double var1 = org.apache.commons.math3.util.FastMath.abs(0.005514177742691755d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.005514177742691755d);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    double var10 = var5.upperCumulativeProbability(3);
    int[] var12 = var5.sample(3);
    int var13 = var5.getSupportLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(3.9799861524408863E27d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 27.59988156103626d);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(0.09921987291129965d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(1.0768010541618303d, 125);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.580205142664366E37d);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test341"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh(5.530681361120931E28d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == Double.POSITIVE_INFINITY);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test342"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.8872303f, 207);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == Float.POSITIVE_INFINITY);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test343"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(5.9604645E-8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test344"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int var7 = var0.nextZipf(3, 3.4724687469699105d);
//     double var10 = var0.nextUniform((-1.7626381930754416d), 0.0d);
//     long var13 = var0.nextSecureLong(0L, 26L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextPoisson((-1.4992844715101683d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.8216191209872656d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.5868441168790074d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.3423637101265757d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 22L);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test345"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)(-1L), (java.lang.Number)(byte)10, true);
    boolean var5 = var4.getBoundIsAllowed();
    java.lang.Number var6 = var4.getMax();
    java.lang.Throwable[] var7 = var4.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (byte)10+ "'", var6.equals((byte)10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test346"); }


    double var1 = org.apache.commons.math3.util.FastMath.nextUp(1.4862784988981086d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4862784988981088d);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test347"); }


    int var2 = org.apache.commons.math3.util.FastMath.max(897, 213);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 897);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test348"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextF(0.9040580270688509d, 1.4100249074148754d);
//     double var6 = var0.nextUniform(0.5142856083511866d, 4.765158102961618d);
//     var0.reSeed(126L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 222.3528063767103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.07934659949419d);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test349"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.RealDistribution var3 = null;
//     double var4 = var2.nextInversionDeviate(var3);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test350"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    long var4 = var1.nextLong();
    int var5 = var1.nextInt();
    var1.setSeed(2L);
    var1.setSeed(2L);
    boolean var10 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2083745733));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test351"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var9 = var2.nextBeta(0.7350525871447157d, 26.0d);
//     long var12 = var2.nextLong((-7034676902218012687L), 0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.021613068831984203d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-4282531410488739172L));
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test352"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(5L);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test353"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    org.apache.commons.math3.random.RandomDataGenerator var5 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    double var7 = var1.nextDouble();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.1311368140377014d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test354"); }


    double var2 = org.apache.commons.math3.util.FastMath.max(1.4382037266346042d, 1.4675804129174533E11d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4675804129174533E11d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     double var11 = var0.nextChiSquare(1.0477911379678095E-4d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextGamma(30.9570417874309d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.635982496485571E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.6742761092784535d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-418587121300991210L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1.1367033396343355E-9d);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test356"); }


    long var1 = org.apache.commons.math3.util.FastMath.abs((-3012399215156379713L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3012399215156379713L);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)5.873060404051843d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test358"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8152769730283367d);
//     org.apache.commons.math3.exception.util.Localizable var3 = null;
//     java.lang.Number var5 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var7 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var5, (java.lang.Number)0.0f);
//     java.lang.Number var8 = var7.getLo();
//     java.lang.Number var9 = var7.getLo();
//     java.lang.Throwable[] var10 = var7.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var11 = null;
//     java.lang.Number var12 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var17 = var16.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var18 = new org.apache.commons.math3.exception.NotFiniteNumberException(var12, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var7, var11, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathIllegalStateException var20 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var2, var3, (java.lang.Object[])var17);
//     org.apache.commons.math3.exception.MathInternalError var21 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var17);
//     java.lang.String var22 = var21.toString();
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test359"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    double var7 = var2.nextExponential(0.001426069753303551d);
    int var10 = var2.nextInt(6, 563228325);
    org.apache.commons.math3.random.RandomGenerator var11 = var2.getRandomGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var14 = var2.nextInt(563228325, 29);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0017299837809377156d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 281614168);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test360"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    int var4 = var1.nextInt(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, (-438907248), 422573888, 1024);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test361"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    var2.reSeed((-6069125204240848293L));
    java.lang.String var7 = var2.nextHexString(41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "3fb13788eebbc6b7a025d527f41050557cd4a0051"+ "'", var7.equals("3fb13788eebbc6b7a025d527f41050557cd4a0051"));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test362"); }


    double var1 = org.apache.commons.math3.util.FastMath.ulp(0.5574599702686449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1102230246251565E-16d);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test363"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
//     int var16 = var2.nextInt(17, 2147483647);
//     int var19 = var2.nextSecureInt((-494780561), 1024);
//     double var22 = var2.nextCauchy(4.609715589221844d, Double.NaN);
//     double var25 = var2.nextWeibull(1.9090738156391573d, 1.2242504190122387d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 15.925797012802406d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1146122894);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-398007614));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1.5314081976970921d);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test364"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(6L, 4L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4L);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test365"); }


    double var1 = org.apache.commons.math3.util.FastMath.log1p(3.1622776601683795d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.4260624389053682d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test366"); }


    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NotPositiveException var3 = new org.apache.commons.math3.exception.NotPositiveException(var1, (java.lang.Number)5.873060404051843d);
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var8 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var4, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
    var3.addSuppressed((java.lang.Throwable)var8);
    java.lang.Throwable[] var10 = var8.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)12.978452428686579d, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test367"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("c66", "644eef56fcd32eb2735ea4594308b");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test368"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.log10((-650.5734518382081d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test369"); }


    long var1 = org.apache.commons.math3.util.FastMath.round(6.651369377311933E13d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 66513693773119L);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     int var7 = var0.nextInt(0, 1);
//     int var10 = var0.nextBinomial(147, 2.0910494117743932E-5d);
//     double var13 = var0.nextUniform(0.3616878291415171d, 0.5123778273012989d);
//     double var15 = var0.nextExponential(0.6217097382835118d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.9462734954627106d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "3b1"+ "'", var4.equals("3b1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.4306847709744095d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1.5306284866685973d);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test371"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)0.03167492013216357d, (java.lang.Number)1.0348711345288815d, true);
    java.lang.Number var4 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0348711345288815d+ "'", var4.equals(1.0348711345288815d));

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     long var9 = var0.nextSecureLong((-6069125204240848293L), 0L);
//     long var12 = var0.nextLong((-214947668324021772L), 8L);
//     double var15 = var0.nextCauchy(10.90009547671185d, 0.019948546946239154d);
//     double var18 = var0.nextGaussian(0.0d, 5.764512407651128E29d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.09025870420782302d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.4432295444183707d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-921775037336355167L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-38748060543528751L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 10.925228099532275d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1.4820492527876358E30d);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test373"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var7 = var6.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var2, (java.lang.Object[])var7);
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)0.35130019259683d, (java.lang.Object[])var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test374"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)16L, (java.lang.Number)51, (java.lang.Number)0.022388164554628116d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test375"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)1.3871986638222313E-5d);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test376"); }
// 
// 
//     org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     org.apache.commons.math3.exception.util.Localizable var4 = null;
//     java.lang.Number var7 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var9 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var7, (java.lang.Number)0.0f);
//     java.lang.Number var10 = var9.getLo();
//     java.lang.Number var11 = var9.getLo();
//     java.lang.Throwable[] var12 = var9.getSuppressed();
//     org.apache.commons.math3.exception.util.Localizable var13 = null;
//     java.lang.Number var14 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.apache.commons.math3.exception.NotFiniteNumberException var20 = new org.apache.commons.math3.exception.NotFiniteNumberException(var14, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var9, var13, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.NotFiniteNumberException var22 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)1024, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathIllegalStateException var23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var3, var4, (java.lang.Object[])var19);
//     org.apache.commons.math3.exception.MathInternalError var24 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var23);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test377"); }


    float var1 = org.apache.commons.math3.util.FastMath.nextUp(0.7432415f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.74324155f);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test378"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    float var4 = var1.nextFloat();
    double var5 = var1.nextGaussian();
    long var6 = var1.nextLong();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2419047238712938144L);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test379"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     double var20 = var0.nextCauchy(6.5412698750025651E17d, 130.89136659412873d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "dc2"+ "'", var10.equals("dc2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.2785634988453677d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 972);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1.3407807929942204E154d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 6.5412698750025638E17d);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test380"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var5 = var2.nextZipf(3, 100.0d);
//     var2.reSeed();
//     double var9 = var2.nextGaussian(0.0d, 100.0d);
//     var2.reSeedSecure((-6069125204240848293L));
//     long var13 = var2.nextPoisson(12.978452428686579d);
//     double var16 = var2.nextF(1.0313075864862578E8d, 1.665429362717771d);
//     var2.reSeed(0L);
//     java.lang.String var20 = var2.nextHexString(246);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 158.34136888820112d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.9731408681251136d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5560b024803c29248e108866f1306a8907cadfa5dd3b04c2343d42766aa8579072a6c53d40aceebc2135d234dad22885d3432f6f03e1554701a78b9cbfd5f9c0274e480ac22f6d596b9"+ "'", var20.equals("7c95c53e6ebf6e7867c80117938712b6d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91a0aff620518352d5560b024803c29248e108866f1306a8907cadfa5dd3b04c2343d42766aa8579072a6c53d40aceebc2135d234dad22885d3432f6f03e1554701a78b9cbfd5f9c0274e480ac22f6d596b9"));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test381"); }


    float var2 = org.apache.commons.math3.util.FastMath.scalb(0.7432415f, (-597052871));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     int var9 = var0.nextSecureInt((-2), 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGaussian(0.0d, (-0.944161429707643d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.8898845544101692d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d9b98f5692d3326ecc82c372d66e378748b7118f5bcdf3c720183d6ef97878c36f029ead6a8edf182b30d89cdf853b89ce53c25e70d57bf4d8cb39aa9606e9f45cdd3a2390ec424244431869a1274ece696fea33422dc37906d4df2071d05fad249fdf5ade9f8744106e12c6bde98ae903f9006d39326b530e2a5ec171d648d2b43252a325087e2a6ee679c9620a59f2e12b56eb80b7a4e64a73a327b06d1d348a9d0ccc90c711ccbecddf71ba11d920b8b876bc406161c869971b709ff311eb2eeb16e1cc34a69b419fff8df5f160f007a389f695625650d695b82a346d8f9e90e7bc430396737182bba42f411b8bad070eb0115460ae41c082f3f36eeb1e653ad2c514c2ff319288163bc55a486702b692f3c0d755c82281aa5c147ca9f81c34c43e2a6c654c815f1fefbbd8d22286d150e71f8756de1bb13bb1d28e429edea87876fe679ea026010397dfd310a0d0a76f87f7f7769bfaa029eae6e9ec223233be2febfeed62089884a3cbb922450ddb5e61d8b43e4ffec8a174ca1d3a23aa2dcf731cecbca8c9fb214a3cfb9f5691d65aa8325de4bda116912166f0a9e0e040ecb3bdcb4abae60a7fa1e9ae2b0501f39ed0201d146b86d6549219c5cdbf7d2fa27f47bd70bd64e889ad64cab3ef427ac2e800db9cae40cbb1bbbf422446284d31311873262054f0ff71e77d84091543dfc529088a7287ebe16df0401d21fc"+ "'", var4.equals("d9b98f5692d3326ecc82c372d66e378748b7118f5bcdf3c720183d6ef97878c36f029ead6a8edf182b30d89cdf853b89ce53c25e70d57bf4d8cb39aa9606e9f45cdd3a2390ec424244431869a1274ece696fea33422dc37906d4df2071d05fad249fdf5ade9f8744106e12c6bde98ae903f9006d39326b530e2a5ec171d648d2b43252a325087e2a6ee679c9620a59f2e12b56eb80b7a4e64a73a327b06d1d348a9d0ccc90c711ccbecddf71ba11d920b8b876bc406161c869971b709ff311eb2eeb16e1cc34a69b419fff8df5f160f007a389f695625650d695b82a346d8f9e90e7bc430396737182bba42f411b8bad070eb0115460ae41c082f3f36eeb1e653ad2c514c2ff319288163bc55a486702b692f3c0d755c82281aa5c147ca9f81c34c43e2a6c654c815f1fefbbd8d22286d150e71f8756de1bb13bb1d28e429edea87876fe679ea026010397dfd310a0d0a76f87f7f7769bfaa029eae6e9ec223233be2febfeed62089884a3cbb922450ddb5e61d8b43e4ffec8a174ca1d3a23aa2dcf731cecbca8c9fb214a3cfb9f5691d65aa8325de4bda116912166f0a9e0e040ecb3bdcb4abae60a7fa1e9ae2b0501f39ed0201d146b86d6549219c5cdbf7d2fa27f47bd70bd64e889ad64cab3ef427ac2e800db9cae40cbb1bbbf422446284d31311873262054f0ff71e77d84091543dfc529088a7287ebe16df0401d21fc"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b9ebcb"+ "'", var6.equals("b9ebcb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test383"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.19048333f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test384"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     var2.reSeed();
//     double var11 = var2.nextExponential(0.4203357266970343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.3607072435393456E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.5595155228219726d);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test385"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)500);
//     java.lang.Number var3 = var2.getMin();
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var2);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test386"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     long var14 = var0.nextLong(1L, 7009605301686414442L);
//     var0.reSeed();
//     double var19 = var0.nextUniform((-1.0333020151941645d), 2.4783298214134946d, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 4093755611243242726L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2.08515805168829d);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test387"); }


    double var1 = org.apache.commons.math3.util.FastMath.signum(1.1175052971553494E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test388"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.8152769730283367d);
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    java.lang.Number var4 = null;
    org.apache.commons.math3.exception.OutOfRangeException var6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var4, (java.lang.Number)0.0f);
    java.lang.Number var7 = var6.getLo();
    java.lang.Number var8 = var6.getLo();
    java.lang.Throwable[] var9 = var6.getSuppressed();
    org.apache.commons.math3.exception.util.Localizable var10 = null;
    java.lang.Number var11 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var16 = var15.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var17 = new org.apache.commons.math3.exception.NotFiniteNumberException(var11, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var6, var10, (java.lang.Object[])var16);
    org.apache.commons.math3.exception.MathIllegalStateException var19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var1, var2, (java.lang.Object[])var16);
    java.lang.Number var20 = var1.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0+ "'", var20.equals(0));

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test389"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.lang.String var2 = var0.nextHexString(453);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "85f99641a02d3aeb95c0af8a8a491cef4398afa9fa34e616791d5cc6cf04612b5e54ab7078b3607001040203b5cf81235d8607cf972ea25ba8d6b1ae011a95c627d53e62b79644cf1d0d905e4752bc1becfe48cb454d22bf2207f1415efabadebcf7adc333d27dcf37401100e4a262859973929c9f51f0018905d4ca5f70c117f4e409b9c4d75d8831804c5253fc5e528ef2baf4ceb5c380eb7b6411e36f83d97f6de32c1b30b713aba5141f6e6ac4a710822b4e2901c9544ed05a45a59a8ac8130cb3b35f48332c91342bdbcdc41f0db25c3f28d2ccbdcce213b6ba8206c5b7da109"+ "'", var2.equals("85f99641a02d3aeb95c0af8a8a491cef4398afa9fa34e616791d5cc6cf04612b5e54ab7078b3607001040203b5cf81235d8607cf972ea25ba8d6b1ae011a95c627d53e62b79644cf1d0d905e4752bc1becfe48cb454d22bf2207f1415efabadebcf7adc333d27dcf37401100e4a262859973929c9f51f0018905d4ca5f70c117f4e409b9c4d75d8831804c5253fc5e528ef2baf4ceb5c380eb7b6411e36f83d97f6de32c1b30b713aba5141f6e6ac4a710822b4e2901c9544ed05a45a59a8ac8130cb3b35f48332c91342bdbcdc41f0db25c3f28d2ccbdcce213b6ba8206c5b7da109"));
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test390"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var10 = var5.cumulativeProbability(213, 352);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test391"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(2.000000000000001d, 0.31911931783537784d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.4125704438079667d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test392"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    int var5 = var2.nextZipf(3, 100.0d);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextSecureLong(613248789088187663L, (-7034676902218012687L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test393"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)1.5314081976970921d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test394"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(0.5142856083511866d, 54.02225343578707d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 54.02470135009878d);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test395"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var3.nextChiSquare(0.8052334543333898d);
    var3.reSeed((-6052487647205118893L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.31911931783537784d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test396"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(0.3616878291415171d, 0.0028189382685788436d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.9971373189742552d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test397"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.7009419562497021d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test398"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test399"); }


    double var2 = org.apache.commons.math3.util.FastMath.scalb(34.09010925358515d, 397);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.1003647558004955E121d);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test400"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    int var10 = var5.getSupportLowerBound();
    double var12 = var5.probability(503);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test401"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.059279958251462046d, 2.286069913668499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05927995825146205d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test402"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextGaussian(30.9570417874309d, 9.568906036844316d);
    java.lang.String var7 = var2.nextHexString(6);
    org.apache.commons.math3.random.RandomGenerator var8 = var2.getRandomGenerator();
    var2.reSeedSecure((-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.70543202901362d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "629ec7"+ "'", var7.equals("629ec7"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test403"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     java.util.Collection var11 = null;
//     java.lang.Object[] var13 = var2.nextSample(var11, (-520651098));
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test404"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    int var8 = var5.getSampleSize();
    int var9 = var5.getSupportLowerBound();
    double var10 = var5.getNumericalVariance();
    double var12 = var5.probability((-1));
    double var14 = var5.upperCumulativeProbability(281614168);
    double var15 = var5.getNumericalVariance();
    double var17 = var5.cumulativeProbability(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test405"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     java.lang.String var10 = var2.nextHexString(1);
//     double var13 = var2.nextGamma(0.7069172585519206d, 30.969689879991442d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.6214723746103038E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "4"+ "'", var10.equals("4"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 17.726294272389328d);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test406"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var12 = var0.nextExponential(0.5517493820104129d);
//     int var15 = var0.nextSecureInt((-2), 1024);
//     double var17 = var0.nextT(1.73260320806421E-6d);
//     long var20 = var0.nextLong(1L, 577710999442321806L);
//     var0.reSeed(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b8691150fc268767205d341a176c74c24073c3d2d6c160dbb8fe03bd9ff45492c28d46f8f3818977a89d5263ef5a0e0c1a85333114e540529fbbe4b1d35a899f421e23070ee32a9d5f4eff1d461d0015af478dcaf724946658d37eb845ec050f36d9fdafc0550a50f3d135a58f7edd52437cdb84d55a1a3039b5cf014c4b8647b14266d1b496cbcf53c353d1199be272310c42d03111baf14172a26dfce8bb67bd611a47b39622e1d445d5348e02513187491362560f8bc45100ee5ba07466b24705f27c80ba2227d683823863acaeeb6bcad3eda963773735beaead99bb06b25e787cb23a3a898d300a6bcf1741381a357169c58fcb7d7b568f60ef6ca3c5b5abb3b71e284669e3a0648733ee5e3465f8d81a4406d55b0fa565700e71db75f3048653c6570ccd4a7cdb0ab2f67985cd78c5f1fdf86f3f4a9b5f1616a5d15043681d5f3f39383bb7c8ec1c91149ac51f5cd69d7ff10da449d77da22bb06ebdc38450c289e27cf4bc6499ba6447996f72b18f47b299323dad91ecd0268ba79e9dd8caf8ddbe2a7fe42a77f90b975ab66502cffaa2acc15aa1f20308d3b891893730d14f906aefa4e185d0b5fcea88ec29f9c06b70fc6fb5ceedfcaf0060fc22f7a5291823c97ca02f7663752941bf3b94e8f153ae25a13cb65ca2e881d482c09c56dd9abdd023193635e4cac3e7eb638fd091a886356da083728cabb4451cfb19", "79f");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "47c"+ "'", var10.equals("47c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1.0200440291372643d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 197);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.3407807929942597E154d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 86146597605570685L);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test407"); }


    double var1 = org.apache.commons.math3.util.FastMath.cosh(0.577427448394613d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.1713951239901914d);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test408"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextZipf((-8), (-2.657331226469821d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test409"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    var1.clear();
    int var4 = var1.nextInt();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var1.nextLong((-584986072174970266L));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1413078328));

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test410"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(3);
//     double var7 = var0.nextF(0.13813975938570944d, 2.974823675756067d);
//     double var11 = var0.nextUniform(1.0d, 2.847732150080772d, true);
//     var0.reSeed(1L);
//     double var16 = var0.nextGaussian(100.0d, 14.975162885657241d);
//     long var18 = var0.nextPoisson(0.5148401381795025d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var0.nextUniform(0.9948000358043659d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.07454057199941193d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "324"+ "'", var4.equals("324"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9.47989869508109d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2.6160224852932865d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 119.87204169238177d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test411"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextBeta(3.1622776601683795d, 30.973188990298414d);
//     var0.reSeed((-213915053556550245L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "d6d"+ "'", var10.equals("d6d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.11415938985950391d);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test412"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)1.242017221677235d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test413"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(886);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test414"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var22 = var17.sample();
//     double var24 = var17.probability(715);
//     int var25 = var17.getSampleSize();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "182"+ "'", var10.equals("182"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test415"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     double var13 = var0.nextCauchy((-5.21416038369738d), 2.220446049250313E-16d);
//     var0.reSeed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "08f"+ "'", var10.equals("08f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-5.21416038369738d));
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test416"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var2);
    double var5 = var4.nextDouble();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.1753021164154851d);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test417"); }


    double var1 = org.apache.commons.math3.util.FastMath.exp(0.640164261330767d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.8967924233645805d);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test418"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(3831766526879059053L, (-2349309494509100384L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-2349309494509100384L));

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test419"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     var2.reSeedSecure();
//     var2.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var12 = var2.getRandomGenerator();
//     double var15 = var2.nextBeta(2.3283872144743825d, 0.022388164554628116d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var18 = var2.nextZipf((-8), 0.7635378011037546d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.9999999982285809d);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test420"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.6232857187980742d, 0.9987546359241628d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.6232857187980743d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test421"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    org.apache.commons.math3.random.RandomDataImpl var3 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.nextInt((-6));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test422"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(732, (-597052871));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-597052871));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test423"); }


    double var1 = org.apache.commons.math3.util.FastMath.ceil(3.774581056178469E252d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3.774581056178469E252d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test424"); }


    int var2 = org.apache.commons.math3.util.FastMath.max((-2), 108);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 108);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test425"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)3.3688747324560895d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test426"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
    org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
    var2.reSeedSecure();
    java.lang.String var9 = var2.nextHexString(100);
    var2.reSeedSecure();
    double var13 = var2.nextUniform(11.505629813076833d, 19.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var16 = var2.nextBinomial((-8), (-1.3813117226938723d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 18.58616942859271d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"+ "'", var9.equals("bb104c0334291850629ec7e1ea2c36a65c01c87b25ae12a1204edf1e71e7267529a9129864074ac211cbd778e3812d876192"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15.925797012802406d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test427"); }


    double var1 = org.apache.commons.math3.util.FastMath.tan(0.18547433770925792d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.18763083413278228d);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test428"); }


    java.lang.Number var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, var1, true);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test429"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)1.5707963267948966d, (java.lang.Number)3.993369341651611E-5d, false);
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 1.571 is larger than, or equal to, the maximum (0)"+ "'", var4.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 1.571 is larger than, or equal to, the maximum (0)"));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test430"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(0.6232857187980742d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5886894182968756d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test431"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var1, (java.lang.Number)1L, false);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.util.Localizable var7 = null;
    org.apache.commons.math3.exception.util.Localizable var8 = null;
    org.apache.commons.math3.exception.util.Localizable var9 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    java.lang.Throwable[] var14 = var13.getSuppressed();
    org.apache.commons.math3.exception.MathIllegalStateException var15 = new org.apache.commons.math3.exception.MathIllegalStateException(var9, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathInternalError var16 = new org.apache.commons.math3.exception.MathInternalError(var8, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalArgumentException var17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var7, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathIllegalStateException var18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var6, (java.lang.Object[])var14);
    org.apache.commons.math3.exception.MathInternalError var19 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test432"); }
// 
// 
//     double var2 = org.apache.commons.math3.util.FastMath.pow((-1.3407807929942273E154d), 108);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test433"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)1.0d, (java.lang.Number)(-1L), true);
    boolean var4 = var3.getBoundIsAllowed();
    boolean var5 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Number var7 = null;
    org.apache.commons.math3.exception.OutOfRangeException var10 = new org.apache.commons.math3.exception.OutOfRangeException(var6, var7, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
    java.lang.Number var11 = var10.getLo();
    var3.addSuppressed((java.lang.Throwable)var10);
    java.lang.Number var13 = var10.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0.8152769730283367d+ "'", var11.equals(0.8152769730283367d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 1.2676506E30f+ "'", var13.equals(1.2676506E30f));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test434"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1024);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test435"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     double var12 = var0.nextCauchy(0.8394859904584389d, 3.141592653589793d);
//     int[] var15 = var0.nextPermutation(10, 6);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.distribution.HypergeometricDistribution var20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var16, 13906712, 987587419, 1632050914);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.05981681785921036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-0.7294522550837418d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.65136937731206E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8.096450767075554d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test436"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    int[] var2 = new int[] { };
    var1.setSeed(var2);
    byte[] var4 = new byte[] { };
    var1.nextBytes(var4);
    double var6 = var1.nextDouble();
    var1.setSeed(0L);
    org.apache.commons.math3.distribution.HypergeometricDistribution var12 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 26, 0, 1);
    double var13 = var12.getNumericalVariance();
    double var14 = var12.getNumericalMean();
    double var16 = var12.probability(563228325);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5207931322143664d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test437"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     long var8 = var0.nextPoisson(0.005514177742691754d);
//     double var11 = var0.nextGaussian(9.409188131594754E27d, 0.5002970871024577d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0023149794441964257d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2390742c111e37e43ec47963b75c6245c92c559068d08302d069d91a92c1d9e2663b26095d1b11560a6876a1d3ecf417e28423348171af84c4d20716af9eb866ee2995b8d91249b92ac7e902297663958edc012c9900350f977632fcee5fd4dd4b18bc0d160eb061007b7f9def1b6758f0741dd5012cbd2947aa75cb9f269e1b34a18c96eb26b55773fcddd93366c35554514210976568df892574674382f1538bddebd4b710abde4e46b72131ae8f705193a1ca70babeeb549ad12269de389f9fe6de1d18962d42d4b0bd2acf5d9cc5b7803052ac19b324854b08023d6d7367a8d6fba5d4ad9c49be17995f2e128eb9d6d383bfd10b5acbc9f2ba91bfcdf69e75a637f40c2c094db390085d89b4593a6704ab6ea61a026d5dd2051527cf5302d0c24d3f6b8df23ec24ac3eb8f94213ca7cec7c9c436708075482c97a6b5741d51822fa56fa6a39a2ba67fa018a46f1545db64f9008f8fb1f1154137e9fe95d92b6ec0a8868dfdaf6ad9590f02dfd1f0f34d5be05a2590d2492a4e683e06b0f340cfbbc794023efe65ae84146a8aeac23d54f646e2faeb2d356569aaebceed824ab922a86233921bc82fe722738cc307c944e9d5a0806543737aa0392cc96a4283a35367d03ebb790e4f5a37e0741d5ed6cd120135de89b695f290fa4dbee62f0bd6de89b0dabf5f4daa6ca7705a6a51ab3d03e720b38f3fd31c49f0225c464f"+ "'", var4.equals("2390742c111e37e43ec47963b75c6245c92c559068d08302d069d91a92c1d9e2663b26095d1b11560a6876a1d3ecf417e28423348171af84c4d20716af9eb866ee2995b8d91249b92ac7e902297663958edc012c9900350f977632fcee5fd4dd4b18bc0d160eb061007b7f9def1b6758f0741dd5012cbd2947aa75cb9f269e1b34a18c96eb26b55773fcddd93366c35554514210976568df892574674382f1538bddebd4b710abde4e46b72131ae8f705193a1ca70babeeb549ad12269de389f9fe6de1d18962d42d4b0bd2acf5d9cc5b7803052ac19b324854b08023d6d7367a8d6fba5d4ad9c49be17995f2e128eb9d6d383bfd10b5acbc9f2ba91bfcdf69e75a637f40c2c094db390085d89b4593a6704ab6ea61a026d5dd2051527cf5302d0c24d3f6b8df23ec24ac3eb8f94213ca7cec7c9c436708075482c97a6b5741d51822fa56fa6a39a2ba67fa018a46f1545db64f9008f8fb1f1154137e9fe95d92b6ec0a8868dfdaf6ad9590f02dfd1f0f34d5be05a2590d2492a4e683e06b0f340cfbbc794023efe65ae84146a8aeac23d54f646e2faeb2d356569aaebceed824ab922a86233921bc82fe722738cc307c944e9d5a0806543737aa0392cc96a4283a35367d03ebb790e4f5a37e0741d5ed6cd120135de89b695f290fa4dbee62f0bd6de89b0dabf5f4daa6ca7705a6a51ab3d03e720b38f3fd31c49f0225c464f"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "b84104"+ "'", var6.equals("b84104"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9.409188131594754E27d);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test438"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(64.02248189018178d, (-11.7204516580769d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.744770635234011E-22d);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test439"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure();
//     int var6 = var2.nextPascal(17, 0.9458707273495791d);
//     java.lang.String var8 = var2.nextSecureHexString(246);
//     int var11 = var2.nextSecureInt(687, 13906712);
//     org.apache.commons.math3.random.RandomGenerator var12 = var2.getRandomGenerator();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f7f8680cd950aff556c3ffb6f2ad405ab1235028e8060836ea5d45f47ad77feda72ecd19131f03e9e3d794a50134bdf65436ba7c4b736f511c0b851627509b637ba1237fb092ae54ce6b035f4d388f0b992c930a11e288d5cb080699e80edae4d199fb919f36bf402ec5947b9457d03bb0b686c2a4423c2a2ff1cb"+ "'", var8.equals("f7f8680cd950aff556c3ffb6f2ad405ab1235028e8060836ea5d45f47ad77feda72ecd19131f03e9e3d794a50134bdf65436ba7c4b736f511c0b851627509b637ba1237fb092ae54ce6b035f4d388f0b992c930a11e288d5cb080699e80edae4d199fb919f36bf402ec5947b9457d03bb0b686c2a4423c2a2ff1cb"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 8778092);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test440"); }


    long var2 = org.apache.commons.math3.util.FastMath.min(0L, (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test441"); }


    double var1 = org.apache.commons.math3.util.FastMath.sinh((-0.24073213499030574d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.24306403151949452d));

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test442"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     long var6 = var0.nextPoisson(12.978452428686579d);
//     double var9 = var0.nextF(0.26448968695715014d, 0.0017299837809377156d);
//     double var12 = var0.nextCauchy(0.8394859904584389d, 3.141592653589793d);
//     int[] var15 = var0.nextPermutation(10, 6);
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     var16.setSeed(2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.7800627982038152d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.6619188002498984d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 6.6513693773119125E13d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.17747042884727127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test443"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(9.999999f, 1.2676508E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 9.999999f);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test444"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.NotPositiveException var5 = new org.apache.commons.math3.exception.NotPositiveException(var3, (java.lang.Number)5.873060404051843d);
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var10 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var6, (java.lang.Number)(-1.0f), (java.lang.Number)(short)(-1), true);
    var5.addSuppressed((java.lang.Throwable)var10);
    java.lang.Throwable[] var12 = var10.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)0.6820038473615311d, (java.lang.Object[])var12);
    org.apache.commons.math3.exception.MathIllegalStateException var14 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, (java.lang.Object[])var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test445"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextBeta(8.653297910537354d, 2.847732150080772d);
//     double var9 = var2.nextUniform((-0.9262160379374064d), 2.9748236757560673d, false);
//     org.apache.commons.math3.random.RandomGenerator var10 = var2.getRandomGenerator();
//     long var13 = var2.nextSecureLong((-2081060580518884217L), 58365653636984266L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.8201071802366467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0821957873042685d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1144488963013662491L));
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test446"); }


    int var2 = org.apache.commons.math3.util.FastMath.min(0, 500);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test447"); }


    float var2 = org.apache.commons.math3.util.FastMath.min(0.8605623f, 1.2676506E30f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8605623f);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test448"); }


    double var2 = org.apache.commons.math3.util.FastMath.copySign((-1.183768252115504d), 0.9747575540282892d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.183768252115504d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test449"); }


    double var1 = org.apache.commons.math3.util.FastMath.tanh(2.286069913668499d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.9795398342351607d);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test450"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(0.6820038473615311d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.8802288692593572d);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test451"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs((-597052871));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 597052871);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test452"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(0.7812076300540747d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.7100637184681227d);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test453"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     double var11 = var2.nextGaussian(0.0d, 14.975162885657241d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var2.nextF(0.16939840861717922d, (-0.36646562969203167d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.4233014779497907E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 26.24230001808893d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test454"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var1, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getLo();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test455"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)281614168, (java.lang.Number)Double.NEGATIVE_INFINITY, true);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test456"); }


    double var2 = org.apache.commons.math3.util.FastMath.atan2(25.70088361328929d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.5707963267948966d);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test457"); }


    int[] var0 = new int[] { };
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    org.apache.commons.math3.distribution.HypergeometricDistribution var5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var1, 6, 0, 1);
    boolean var6 = var5.isSupportConnected();
    int var7 = var5.sample();
    double var9 = var5.upperCumulativeProbability((-1));
    double var10 = var5.getNumericalMean();
    int[] var12 = var5.sample(1);
    double var14 = var5.cumulativeProbability(563228325);
    double var17 = var5.cumulativeProbability((-2083745733), 9);
    double var19 = var5.cumulativeProbability((-188551922));
    int var21 = var5.inverseCumulativeProbability(0.17948253149278287d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test458"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     int[] var3 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var4, 6, 0, 1);
//     boolean var9 = var8.isSupportConnected();
//     int var10 = var8.sample();
//     int var11 = var8.getSampleSize();
//     double var13 = var8.upperCumulativeProbability(3);
//     int[] var15 = var8.sample(3);
//     int var16 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var8);
//     int var20 = var0.nextHypergeometric(125, 27, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.198236218703503d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test459"); }


    double var2 = org.apache.commons.math3.util.FastMath.pow(5.455868397056974d, 0.9815751184692503d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5.287948979122532d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test460"); }


    double var2 = org.apache.commons.math3.util.FastMath.hypot(6.651369377311933E13d, 1.8453830087804857d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 6.651369377311933E13d);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test461"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)(short)(-1), var1, (java.lang.Number)0.0f);
    java.lang.Number var4 = var3.getHi();
    java.lang.Number var5 = var3.getLo();
    java.lang.Number var6 = var3.getLo();
    java.lang.Number var7 = var3.getHi();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0f+ "'", var7.equals(0.0f));

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test462"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    int var10 = var6.getSampleSize();
    double var12 = var6.upperCumulativeProbability(207);
    int var13 = var6.getNumberOfSuccesses();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test463"); }


    org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
    int[] var1 = new int[] { };
    org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
    org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
    boolean var7 = var6.isSupportConnected();
    int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
    int var9 = var6.getSampleSize();
    double var11 = var6.upperCumulativeProbability(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var13 = var6.sample((-51616135));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test464"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var2 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)3.8828873801456796d, var2, false);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test465"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     var2.reSeed();
//     double var8 = var2.nextChiSquare(0.13813975938570944d);
//     var2.reSeed();
//     org.apache.commons.math3.random.RandomGenerator var10 = var2.getRandomGenerator();
//     double var12 = var2.nextChiSquare(8.653297910537354d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var2.nextGamma(4.020494098909096E28d, (-1.0333020151941645d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.58616942859271d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.2886746159947125E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 8.808585671791956d);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test466"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     int var11 = var0.nextInt(0, 100);
//     java.lang.String var13 = var0.nextHexString(2);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 10);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test467"); }


    double var1 = org.apache.commons.math3.util.FastMath.asinh(2.3283872144743825d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.581538888432681d);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test468"); }


    double var1 = org.apache.commons.math3.util.FastMath.log10(0.2080097758206445d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6819162540507206d));

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test469"); }


    double var2 = org.apache.commons.math3.util.FastMath.nextAfter(0.5595155228219726d, 0.6528864491099772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5595155228219727d);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test470"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     double var4 = var0.nextT(2.9748236757560673d);
//     int[] var5 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var6 = new org.apache.commons.math3.random.Well19937c(var5);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var6, 6, 0, 1);
//     boolean var11 = var10.isSupportConnected();
//     int var12 = var10.sample();
//     int var13 = var10.getSampleSize();
//     int var14 = var10.getSupportLowerBound();
//     double var15 = var10.getNumericalVariance();
//     double var17 = var10.probability((-1));
//     double var19 = var10.upperCumulativeProbability(281614168);
//     int var20 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.8309973622861248d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.07835522770582182d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test471"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)1.799453453475944d, (java.lang.Number)19.0d, (java.lang.Number)6.211368153355547E-4d);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test472"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, var1, (java.lang.Number)0.8152769730283367d, (java.lang.Number)1.2676506E30f);
//     java.lang.Number var5 = var4.getLo();
//     java.lang.Number var6 = var4.getLo();
//     org.apache.commons.math3.exception.util.ExceptionContext var7 = var4.getContext();
//     java.lang.String var8 = var4.toString();
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test473"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextChiSquare(1.0d);
//     java.lang.String var4 = var0.nextSecureHexString(1024);
//     java.lang.String var6 = var0.nextHexString(6);
//     long var8 = var0.nextPoisson(0.005514177742691754d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextGamma((-0.9262160379374064d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.7089590292287036d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "d9468a0102a732e19bc08b42f0e5339e20f39dbfb652033e73ba418af12ebff5452d515caeb914a7a1dede0243096d84dc5a716980d1e07bda9ea2c410888e9e76d8a7c7607c63e89bc8df1f1c612c46ff3e2a2a715721f228ce0d2baf153e15684e48dd73d630e2326647b4fc0cb09b1de344238e36343aa9049ffd2ef3714cd15681b61dec5f08ddac9abcac8c61845be3fcdc82e9ad498dbc1165ec4eef75ebf701db53f4e804052d96a86992db35860e8eab9208c9270c5f2575f2e391f90ff9818c906739a26b07a8d3d9b79cd90e45aed5930db7220a0490fb93a1f3c3dcdf856e66ce97ae16d094d331925e9169622277e84ad3e05c0083a4e0985477d2b33f133817ee31ffcc26e508831c828d1599e73334cf1755a7913f99015e3bc1174fff3dcc5c68771976d8f855936509f64d2ec9f391ba79d00fb4df3894bd637bbb43961bf04948109fa0dfdffc979660f320fd6b578e47b99b09b5457130058ea08e81841ea0e8e602966e8ae3e42601f352a38481d4de4b2c1a75f292019ba803c201b28b1022daef7a3807fd6ad3787a22a0056d6d64f2e2fb3dce3667171c31a4e1b51a2eca34c1125bbbcd98c555b054528385fc6ad2c3117807e237a811f2f688ee3caa5238bcecff7728f33666855edfe9edc4519897d9de0b03d9ada27887527b1e8e5db984e5627c1a54d260ce532bb93f0dd114c220073df483"+ "'", var4.equals("d9468a0102a732e19bc08b42f0e5339e20f39dbfb652033e73ba418af12ebff5452d515caeb914a7a1dede0243096d84dc5a716980d1e07bda9ea2c410888e9e76d8a7c7607c63e89bc8df1f1c612c46ff3e2a2a715721f228ce0d2baf153e15684e48dd73d630e2326647b4fc0cb09b1de344238e36343aa9049ffd2ef3714cd15681b61dec5f08ddac9abcac8c61845be3fcdc82e9ad498dbc1165ec4eef75ebf701db53f4e804052d96a86992db35860e8eab9208c9270c5f2575f2e391f90ff9818c906739a26b07a8d3d9b79cd90e45aed5930db7220a0490fb93a1f3c3dcdf856e66ce97ae16d094d331925e9169622277e84ad3e05c0083a4e0985477d2b33f133817ee31ffcc26e508831c828d1599e73334cf1755a7913f99015e3bc1174fff3dcc5c68771976d8f855936509f64d2ec9f391ba79d00fb4df3894bd637bbb43961bf04948109fa0dfdffc979660f320fd6b578e47b99b09b5457130058ea08e81841ea0e8e602966e8ae3e42601f352a38481d4de4b2c1a75f292019ba803c201b28b1022daef7a3807fd6ad3787a22a0056d6d64f2e2fb3dce3667171c31a4e1b51a2eca34c1125bbbcd98c555b054528385fc6ad2c3117807e237a811f2f688ee3caa5238bcecff7728f33666855edfe9edc4519897d9de0b03d9ada27887527b1e8e5db984e5627c1a54d260ce532bb93f0dd114c220073df483"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "76faed"+ "'", var6.equals("76faed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test474"); }


    double var1 = org.apache.commons.math3.util.FastMath.cos(1.370316637323428E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test475"); }


    double var1 = org.apache.commons.math3.util.FastMath.cbrt(4.07934659949419d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.5978286430644746d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test476"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var5 = var2.nextCauchy(0.13813975938570944d, 30.973188990298414d);
//     org.apache.commons.math3.random.RandomGenerator var6 = var2.getRandomGenerator();
//     var2.reSeedSecure();
//     java.lang.String var9 = var2.nextHexString(100);
//     int var12 = var2.nextSecureInt(0, 1);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var2.nextSample(var13, 1132524014);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test477"); }


    double var1 = org.apache.commons.math3.util.FastMath.atanh((-0.9262160379374064d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1.6310856817664894d));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test478"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    long var2 = var1.nextLong();
    double var3 = var1.nextGaussian();
    byte[] var7 = new byte[] { (byte)0, (byte)0, (byte)1};
    var1.nextBytes(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var9.nextBeta(0.0d, 1.1336467843554507d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test479"); }
// 
// 
//     double var1 = org.apache.commons.math3.util.FastMath.acosh(0.17948253149278287d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == Double.NaN);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test480"); }


    int var1 = org.apache.commons.math3.util.FastMath.getExponent(0.01179864038469449d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-7));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test481"); }


    float var2 = org.apache.commons.math3.util.FastMath.max(12.190933f, 12.190933f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 12.190933f);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test482"); }


    float var1 = org.apache.commons.math3.util.FastMath.signum(0.27873123f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0f);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test483"); }


    double var1 = org.apache.commons.math3.util.FastMath.expm1((-1.1268915383987361d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.6759610448260509d));

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test484"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.HypergeometricDistribution var4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(var0, (-6), 440041583, 1069190818);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test485"); }


    int var1 = org.apache.commons.math3.util.FastMath.round(0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test486"); }


    double var1 = org.apache.commons.math3.util.FastMath.atan(0.006405110490684677d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0064050229020144595d);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test487"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var0 = new org.apache.commons.math3.random.Well19937c();
//     boolean var1 = var0.nextBoolean();
//     org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(6);
//     org.apache.commons.math3.random.RandomDataGenerator var4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var3);
//     double var7 = var4.nextGaussian(30.9570417874309d, 9.568906036844316d);
//     double var9 = var4.nextExponential(0.001426069753303551d);
//     int var12 = var4.nextInt(6, 563228325);
//     int[] var15 = var4.nextPermutation(1024, 886);
//     var0.setSeed(var15);
//     var0.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 25.70543202901362d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.0017299837809377156d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 281614168);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test488"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)3.1622776601683795d, (java.lang.Number)0L, false);
    java.lang.Number var4 = var3.getArgument();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 3.1622776601683795d+ "'", var4.equals(3.1622776601683795d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 3.162 is larger than, or equal to, the maximum (0)"+ "'", var5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 3.162 is larger than, or equal to, the maximum (0)"));

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test489"); }


    int var2 = org.apache.commons.math3.util.FastMath.min((-597052871), 1069190818);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-597052871));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test490"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    org.apache.commons.math3.exception.util.Localizable var6 = null;
    java.lang.Object[] var8 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var9 = new org.apache.commons.math3.exception.NotFiniteNumberException(var6, (java.lang.Number)100.0d, var8);
    java.lang.Throwable[] var10 = var9.getSuppressed();
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException(var4, (java.lang.Number)100L, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var12 = new org.apache.commons.math3.exception.NotFiniteNumberException(var2, (java.lang.Number)0.5418954798163614d, (java.lang.Object[])var10);
    org.apache.commons.math3.exception.NotFiniteNumberException var13 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.9208418868014623d, (java.lang.Object[])var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test491"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.00363892281204757d, (java.lang.Number)0.05034846331660371d, false);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.05034846331660371d+ "'", var5.equals(0.05034846331660371d));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test492"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.RandomGenerator var3 = var2.getRandomGenerator();
    double var6 = var2.nextUniform((-0.6321205588285577d), 100.0d);
    double var9 = var2.nextWeibull(30.973188990298414d, 18.58616942859271d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var2.nextHypergeometric(715, 327709799, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 66.89123388852185d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 18.392781021818884d);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test493"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)0.6247958739991177d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test494"); }


    double var1 = org.apache.commons.math3.util.FastMath.toRadians(3.552713678800501E-15d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 6.200655107570901E-17d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test495"); }


    double var1 = org.apache.commons.math3.util.FastMath.log(0.7100637184681227d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-0.3424005686522571d));

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test496"); }


    int var1 = org.apache.commons.math3.util.FastMath.abs(840);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 840);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(3);
    org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(6);
    long var5 = var4.nextLong();
    double var6 = var4.nextGaussian();
    float var7 = var4.nextFloat();
    double var8 = var4.nextGaussian();
    int[] var9 = new int[] { };
    org.apache.commons.math3.random.Well19937c var10 = new org.apache.commons.math3.random.Well19937c(var9);
    var4.setSeed(var9);
    var1.setSeed(var9);
    boolean var13 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-6069125204240848293L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.3850762971330945d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.981575f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.12952473180939125d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test498"); }


    java.lang.Number var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)0.548552626348489d, false);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var1 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var2 = new org.apache.commons.math3.random.Well19937c(var1);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var6 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var2, 6, 0, 1);
//     boolean var7 = var6.isSupportConnected();
//     int var8 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var6);
//     java.lang.String var10 = var0.nextSecureHexString(3);
//     org.apache.commons.math3.random.RandomDataImpl var11 = new org.apache.commons.math3.random.RandomDataImpl();
//     int[] var12 = new int[] { };
//     org.apache.commons.math3.random.Well19937c var13 = new org.apache.commons.math3.random.Well19937c(var12);
//     org.apache.commons.math3.distribution.HypergeometricDistribution var17 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator)var13, 6, 0, 1);
//     boolean var18 = var17.isSupportConnected();
//     int var19 = var11.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     int var20 = var17.getSampleSize();
//     int var21 = var0.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution)var17);
//     double var23 = var0.nextChiSquare(0.548552626348489d);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var0.nextBinomial(5, (-1.4432295444183707d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "07d"+ "'", var10.equals("07d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1.1187417585946142E-6d);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test500"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.08111900113979116d, (java.lang.Number)0.39823927240827994d, (java.lang.Number)2.8822137015004015d);
//     java.lang.String var5 = var4.toString();
// 
//   }

}
